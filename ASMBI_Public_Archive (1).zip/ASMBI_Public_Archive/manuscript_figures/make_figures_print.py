"""Redraw every figure of the ASMBI submission at its printed size, so that no text is smaller than 7.5 pt.

Each figure is drawn at a width of at most 6.5 in (the text width) and included in LaTeX at natural size, so
the font sizes set here are the printed sizes. Plotted values are read from the sealed FINAL_V1 figure-data
files (Final_Study_v1/analysis/figures/*_data.csv, read only), which are the values the sealed figures plot;
the Experiment-3 fit lines use experiments/Exp3/O3.3_scaling_fit.json. Colors, markers and line styles come
from the sealed style module fa_style. Layouts differ from the sealed figures only where a wide figure had to
be re-arranged to fit the page (for example 2 x 4 panels became 4 x 2).

Outputs (PDF in the LaTeX folders; PDF and a 600 dpi TIFF of each in figures_for_submission):
  ../main/figures/        fig2_validation_mechanism, fig3_efficiency_crossover, fig4_contamination_ladder
  ../supplement/figures/  figS_exp5_reevaluation, figS_x4_all, figS_x4_null, figS_validation_intensity,
                          figS_validation_intensity_other, figS_ladder_full, figS_ladder_other,
                          figS8_inverse_T_scaling, figS9_dissociation
  ../figures_for_submission/  the same files renamed by their printed numbers (Figure1.pdf ... FigureS9.tif)

Run: python3 -I -B make_figures_print.py
"""
import csv, json, math, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.environ.get("FIG_OUT", os.path.join(HERE, "output")))
A = os.path.abspath(os.environ.get("FV1_ANALYSIS", os.path.join(HERE, "..", "final_study_v1", "analysis")))
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.join(A, "code"))

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import numpy as np  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402
from matplotlib.ticker import FixedLocator, NullLocator  # noqa: E402
from scipy.interpolate import RegularGridInterpolator  # noqa: E402

import fa_style as S  # noqa: E402  (sealed style module; read only)

plt = S.plt
W = 6.3            # drawing width in inches; saved files are checked to be at most 6.5 in wide
FS = 8.0           # base printed font size
MAIN = os.path.join(ROOT, "main")
SUPP = os.path.join(ROOT, "supplement")
SUB = os.path.join(ROOT, "figures_for_submission")
for d in (MAIN, SUPP, SUB):
    os.makedirs(d, exist_ok=True)
for f in os.listdir(SUB):
    os.remove(os.path.join(SUB, f))

SHORT = {"E-1": "Naive", "E-2": "Lab.-only IPW", "E-3": "PPI (obs.)", "E-4": "PPI (CR)", "E-5": "Unw. CF rect.",
         "E-6": "HT rect.", "E-7": "Reg. cal.", "E-8": "HT rect. (jk)", "E-9": "Hist. CDA", "E-6H": "Hajek var.",
         "E-12a": "CF-u HT", "E-12b": "CF-w HT", "E-12c": "CF-w unif.", "HT-TDS-I": "HT-TDS-I",
         "PS-TDS-I": "PS-TDS-I", "HT-TDS-CF": "HT-TDS-CF"}   # fa_common.SHORT
MAIN_FIG = ["E-1", "E-7", "E-2", "E-4", "E-5", "E-6", "E-9", "E-12a", "E-12b"]          # fa_main.MAIN_FIG
SUPP_FIG = ["E-2", "E-8", "HT-TDS-I", "PS-TDS-I", "E-12c", "E-6H", "HT-TDS-CF", "E-3"]  # fa_main.SUPP_FIG
BAND = 1.959964 * math.sqrt(0.95 * 0.05 / 5000)
LOG = []


def lab(e):
    return e if SHORT.get(e, e) == e else f"{SHORT[e]} ({e})"


def num(v):
    """Parse a CSV cell; the sealed intensity files store values as 'np.float64(x)'."""
    m = re.fullmatch(r"np\.float64\((.*)\)", v.strip())
    return float(m.group(1) if m else v)


def rd(p):
    with open(os.path.join(A, p), newline="") as fh:
        return list(csv.DictReader(fh))


def setup():
    S.setup()
    plt.rcParams.update({"font.size": FS, "axes.titlesize": FS + 0.5, "axes.labelsize": FS,
                         "xtick.labelsize": FS - 0.5, "ytick.labelsize": FS - 0.5, "legend.fontsize": FS - 0.5})


def save(fig, folder, stem, number):
    pdf = os.path.join(folder, stem + ".pdf")
    fig.savefig(pdf, bbox_inches="tight", pad_inches=0.02)
    fig.savefig(os.path.join(SUB, number + ".tif"), dpi=600, bbox_inches="tight", pad_inches=0.02,
                pil_kwargs={"compression": "tiff_lzw"})
    w, h = fig.get_size_inches()
    plt.close(fig)
    from pypdf import PdfReader
    box = PdfReader(pdf).pages[0].mediabox
    wi, hi = float(box.width) / 72, float(box.height) / 72
    assert wi <= 6.5 + 1e-6, (stem, wi)
    shutil.copyfile(pdf, os.path.join(SUB, number + ".pdf"))
    LOG.append(f"{number:10s} {stem:34s} {wi:.2f} x {hi:.2f} in")


def ebar(ax, x, y, err, e, line=True, ms=4.2, **kw):
    ax.errorbar(x, y, yerr=1.96 * np.asarray(err), capsize=0, elinewidth=0.8, **S.est_kw(e, line=line, markersize=ms), **kw)


# ======================================================================================= Experiment 2 (Figure 1)
X2 = rd("figures/FigureX2_design_heterogeneity_data.csv")
CELLS2 = ["A0B0", "A0B1", "A1B0", "A1B1", "LAMBDA-B0", "LAMBDA-B1"]
E2a = ["E-5", "E-12c", "E-4", "E-12a", "E-12b", "E-6", "E-2"]
E2b = ["E-4", "E-5", "E-12c", "E-6", "E-12a", "E-12b"]
setup()
fig, axes = plt.subplots(1, 2, figsize=(W, 3.15), gridspec_kw={"width_ratios": [1.55, 1]})
ax = axes[0]
for k, e in enumerate(E2a):
    dx = 0.1 * (k - (len(E2a) - 1) / 2)
    rows = {r["cell"]: r for r in X2 if r["panel"] == "a" and r["estimator"] == e}
    ebar(ax, np.arange(6) + dx, [float(rows[c]["bias"]) for c in CELLS2], [float(rows[c]["bias_mcse"]) for c in CELLS2],
         e, line=False)
ax.axhline(0, color=S.INK2, lw=0.7)
ax.axvline(3.5, color="#bdbcb6", lw=0.8)
ax.set_xticks(range(6))
ax.set_xticklabels(["A0B0\nuniform\n$\\tau$ = 0", "A0B1\nuniform\n$\\tau$ = 0.30", "A1B0\nunequal\n$\\tau$ = 0",
                    "A1B1\nunequal\n$\\tau$ = 0.30", "const. $\\lambda_1$\n$\\tau$ = 0", "const. $\\lambda_1$\n$\\tau$ = 0.30"])
ax.grid(axis="x", visible=False)
ax.set_ylabel(r"bias ($\gamma_W$ = 0.15)")
ax.set_title("a. Bias by design cell", loc="left")
ax = axes[1]
lo = hi = 0.0
for e in E2b:
    pts = [r for r in X2 if r["panel"] == "b" and r["estimator"] == e and r["predicted"] != ""]
    xs, ys = [float(r["predicted"]) for r in pts], [float(r["observed_bias"]) for r in pts]
    ax.plot(xs, ys, **S.est_kw(e, line=False, markersize=4.2))
    lo, hi = min([lo] + xs + ys), max([hi] + xs + ys)
pad = 0.05 * (hi - lo + 1e-9)
ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], color=S.INK2, lw=0.8, ls=(0, (4, 3)))
ax.set_xlabel("predicted displacement (Proposition 1)")
ax.set_ylabel("observed bias")
ax.set_title("b. Observed against predicted", loc="left")
h = S.proxies(E2a, lab, line=False) + [Line2D([], [], color=S.INK2, lw=0.8, ls=(0, (4, 3)), label="observed = predicted")]
fig.legend(handles=h, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.13))
fig.tight_layout(w_pad=1.0)
save(fig, MAIN, "fig2_validation_mechanism", "Figure1")

# ======================================================================================= Experiment 4 contours
FL = (0.03, 0.05, 0.10, 0.20, 0.35, 0.50)
SD = (0.15, 0.25, 0.35, 0.55, 0.80)
RECT = ["E-4", "E-5", "E-6", "HT-TDS-I", "PS-TDS-I", "E-9", "E-12a", "E-12b"]
C4 = {False: rd("figures/FigureX4_crossover_contours_data.csv"), True: rd("figures/FigureS4_crossover_contours_null_data.csv")}


def field(e, null):
    Z = np.full((len(FL), len(SD)), np.nan)
    info = {}
    for r in C4[null]:
        if r["estimator"] != e:
            continue
        i, j = FL.index(float(r["f"])), SD.index(float(r["sd_e"]))
        flagged = r["flagged"] == "True"
        lr = float(r["log_rmse_ratio"]) if r["log_rmse_ratio"] not in ("", "nan") else float("nan")
        info[(FL[i], SD[j])] = {"flagged": flagged, "classification": r["classification"]}
        if not flagged and math.isfinite(lr):
            Z[i, j] = lr
    assert len(info) == 30, (e, null, len(info))
    return Z, info


def vmax_of(null):
    Zs = [field(e, null)[0] for e in RECT]
    v = max(0.25, max(float(np.nanmax(np.abs(Z))) if np.isfinite(Z).any() else 0 for Z in Zs))
    return min(v, 2.5)


def contour(ests, null, nrow, ncol, height, folder, stem, number):
    setup()
    fig, axes = plt.subplots(nrow, ncol, figsize=(W, height), sharex=True, sharey=True)
    lf = np.log(FL)
    gx, gy = np.linspace(lf[0], lf[-1], 241), np.linspace(SD[0], SD[-1], 201)
    GX, GY = np.meshgrid(gx, gy, indexing="ij")
    vmax = vmax_of(null)
    cmap = LinearSegmentedColormap.from_list("div", list(S.DIVERGING))
    norm = TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)
    im = None
    for ax, e in zip(axes.ravel(), ests):
        Z, info = field(e, null)
        rgi = RegularGridInterpolator((lf, np.array(SD)), Z, method="linear", bounds_error=False, fill_value=np.nan)
        V = rgi(np.stack([GX.ravel(), GY.ravel()], axis=1)).reshape(GX.shape)
        im = ax.pcolormesh(gx, gy, np.clip(V, -vmax, vmax).T, cmap=cmap, norm=norm, shading="auto", rasterized=True)
        if np.isfinite(V).any() and np.nanmin(V) < 0 < np.nanmax(V):
            ax.contour(gx, gy, V.T, levels=[0.0], colors=S.INK, linewidths=1.3)
        for (f, sd), r in info.items():
            x, y = math.log(f), sd
            if r["flagged"]:
                ax.add_patch(Rectangle((x - 0.14, y - 0.035), 0.28, 0.07, fill=False, hatch="////", edgecolor=S.INK2, lw=0.6))
            mk = {"rectification pays": ("v", S.INK), "labeled-only better": ("^", S.INK),
                  "indeterminate": ("o", "white")}[r["classification"]]
            ax.plot([x], [y], marker=mk[0], color=S.INK, mfc=mk[1], ms=4.2, mew=0.8, ls="none")
        ax.set_title(lab(e), loc="left")
        ax.set_xticks(lf)
        ax.set_xticklabels([".03", ".05", ".10", ".20", ".35", ".50"])
        ax.set_yticks(SD)
        ax.set_xlim(lf[0] - 0.25, lf[-1] + 0.25)
        ax.set_ylim(SD[0] - 0.06, SD[-1] + 0.06)
        ax.grid(False)
    for ax in axes[-1, :]:
        ax.set_xlabel("labeled-cluster fraction $f$ (log scale)")
    for ax in axes[:, 0]:
        ax.set_ylabel(r"machine-error SD $\sigma_e$")
    cb = fig.colorbar(im, ax=axes, shrink=0.8, pad=0.03, extend="both")
    cb.set_label(r"$\log R_{\mathrm{RMSE}}$ (< 0: rectification pays)")
    h = [Line2D([], [], marker="v", color=S.INK, ls="none", label="pays (95% CI < 0)"),
         Line2D([], [], marker="^", color=S.INK, ls="none", label="labeled-only better (CI > 0)"),
         Line2D([], [], marker="o", color=S.INK, mfc="white", ls="none", label="indeterminate"),
         Line2D([], [], color=S.INK, lw=1.3, label=r"$\log R_{\mathrm{RMSE}}$ = 0"),
         Rectangle((0, 0), 1, 1, fill=False, hatch="////", edgecolor=S.INK2, label="failure rate > 5% (excluded)")]
    fig.legend(handles=h, loc="lower center", ncol=3, bbox_to_anchor=(0.45, -0.075 if nrow == 2 else -0.04))
    save(fig, folder, stem, number)
    return vmax


v_main = contour(["E-12b", "E-5", "E-4", "E-6"], False, 2, 2, 5.3, MAIN, "fig3_efficiency_crossover", "Figure2")
ALL8 = ["E-12a", "E-12b", "E-5", "E-4", "E-6", "HT-TDS-I", "PS-TDS-I", "E-9"]
v_all = contour(ALL8, False, 4, 2, 8.4, SUPP, "figS_x4_all", "FigureS2")
contour(ALL8, True, 4, 2, 8.4, SUPP, "figS_x4_null", "FigureS3")
assert v_main == v_all

# ======================================================================================= contamination ladder
K = (0.0, 0.15, 0.30, 0.45, 0.60, 0.75, 0.90)
KL = ["0", ".15", ".30", ".45", ".60", ".75", ".90"]
RHO = (0.0, 0.60)
LAD = {False: rd("figures/Figure2_ladder_data.csv"), True: rd("figures/FigureS2_ladder_other_estimators_data.csv")}


def ladder_value(other, rho, e, q):
    rows = [r for r in LAD[other] if float(r["rho_e"]) == rho and r["estimator"] == e and r["quantity"] == q]
    d = {float(r["kappa"]): r for r in rows}
    return [float(d[k]["value"]) for k in K], [float(d[k]["mcse"]) for k in K]


def decorate(ax, q):
    if q == "bias":
        ax.axhspan(-0.02, 0.02, color="#ecebe7", lw=0, zorder=0)
        ax.axhline(0, color=S.INK2, lw=0.7)
    elif q == "se_ratio":
        ax.axhspan(0.9, 1.1, color="#ecebe7", lw=0, zorder=0)
        ax.axhline(1, color=S.INK2, lw=0.7)
    elif q == "coverage":
        ax.axhspan(0.95 - BAND, 0.95 + BAND, color="#d9d8d3", lw=0, zorder=0)
        ax.axhline(0.95, color=S.INK2, lw=0.7)
        ax.axhline(0.92, color=S.INK2, lw=0.7, ls=":")
    else:
        ax.axhspan(0.05 - BAND, 0.05 + BAND, color="#d9d8d3", lw=0, zorder=0)
        ax.axhline(0.05, color=S.INK2, lw=0.7)


QLAB = {"bias": r"bias ($\gamma_W$ = 0.15)", "se_ratio": "mean SE / empirical SE",
        "coverage": r"coverage ($\gamma_W$ = 0.15)", "type1": r"Type I error ($\gamma_W$ = 0)"}

# main: bias and coverage, seven procedures (as in the submitted Figure 3)
LADM = ["E-1", "E-7", "E-2", "E-5", "E-6", "E-12a", "E-12b"]
setup()
fig, axes = plt.subplots(2, 2, figsize=(W, 5.0), sharex=True)
for i, rho in enumerate(RHO):
    for j, q in enumerate(("bias", "coverage")):
        ax = axes[i, j]
        for k_, e in enumerate(LADM):
            y, err = ladder_value(False, rho, e, q)
            ebar(ax, np.array(K) + 0.016 * (k_ - (len(LADM) - 1) / 2), y, err, e, ms=3.8)
        decorate(ax, q)
        ax.set_title(rf"$\rho_e$ = {rho:.2f}: {QLAB[q]}", loc="left")
for ax in axes.ravel():
    ax.set_xticks(K)
    ax.set_xticklabels(KL)
for ax in axes[1]:
    ax.set_xlabel(r"contamination intensity $\kappa$")
fig.legend(handles=S.proxies(LADM, lab), loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.075))
fig.tight_layout()
save(fig, MAIN, "fig4_contamination_ladder", "Figure3")


def ladder_full(other, ests, stem, number):
    setup()
    fig, axes = plt.subplots(4, 2, figsize=(W, 8.4), sharex=True)
    for j, rho in enumerate(RHO):
        for i, q in enumerate(("bias", "se_ratio", "coverage", "type1")):
            ax = axes[i, j]
            vals = []
            for k_, e in enumerate(ests):
                y, err = ladder_value(other, rho, e, q)
                vals += y
                ebar(ax, np.array(K) + 0.016 * (k_ - (len(ests) - 1) / 2), y, err, e, ms=3.6)
            decorate(ax, q)
            title = QLAB[q]
            if q == "se_ratio":
                if all(0.6 < v < 1.4 for v in vals):
                    ax.set_ylim(0.6, 1.4)
                else:
                    ax.set_yscale("log")
                    lo_, hi_ = ax.get_ylim()
                    tk = [t for t in (0.5, 0.7, 1.0, 1.5, 2.0, 3.0, 5.0, 7.0, 10.0, 20.0, 50.0) if lo_ <= t <= hi_]
                    ax.yaxis.set_major_locator(FixedLocator(tk))
                    ax.yaxis.set_minor_locator(NullLocator())
                    ax.set_yticklabels([f"{t:g}" for t in tk])
                    title = "SE ratio (log scale)"
            ax.set_title(rf"$\rho_e$ = {rho:.2f}: {title}", loc="left")
    for ax in axes.ravel():
        ax.set_xticks(K)
        ax.set_xticklabels(KL)
    for ax in axes[-1]:
        ax.set_xlabel(r"contamination intensity $\kappa$")
    fig.legend(handles=S.proxies(ests, lab), loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout()
    save(fig, SUPP, stem, number)


ladder_full(False, MAIN_FIG, "figS_ladder_full", "FigureS6")
ladder_full(True, SUPP_FIG, "figS_ladder_other", "FigureS7")

# ======================================================================================= Experiment 5 (Figure S1)
X5 = rd("figures/FigureX5_exp5_reevaluation_data.csv")
cells5 = []
for r in X5:
    if r["cell"] not in cells5:
        cells5.append(r["cell"])
assert len(cells5) == 16
V5 = {(r["cell"], r["estimator"]): r for r in X5}
E5 = ["E-5", "E-12c", "E-12a", "E-12b", "E-2", "E-6"]
setup()
fig, axes = plt.subplots(2, 1, figsize=(W, 5.4), sharex=True)
for k_, e in enumerate(E5):
    x = np.arange(16) + 0.11 * (k_ - (len(E5) - 1) / 2)
    m = [V5[(c, e)] for c in cells5]
    ebar(axes[0], x, [float(q["bias"]) for q in m], [float(q["bias_mcse"]) for q in m], e, line=False, ms=3.6)
    ebar(axes[1], x, [float(q["coverage"]) for q in m], [float(q["coverage_mcse"]) for q in m], e, line=False, ms=3.6)
decorate(axes[0], "bias")
decorate(axes[1], "coverage")
labs5 = []
for c in cells5:
    kv = dict(t.split("=") for t in c.split("|")[1:] if "=" in t)
    if c.startswith("P|"):
        labs5.append(f"{float(kv['icc']):.1f}\n{float(kv['rho']):.1f}\n{float(kv['kappa']):.1f}")
    else:
        labs5.append({"N=250": "$N$\n250", "N=600": "$N$\n600", "tau=0": "$\\tau$\n0",
                      "tau=0.30": "$\\tau$\n0.30"}[c.split("|")[1]])
for ax in axes:
    ax.axvline(11.5, color="#bdbcb6", lw=0.8)
    ax.grid(axis="x", visible=False)
axes[1].set_xticks(range(16))
axes[1].set_xticklabels(labs5, fontsize=FS - 0.5)
axes[1].text(-0.075, -0.115, "ICC\n$\\rho_e$\n$\\kappa$", transform=axes[1].transAxes, ha="right", va="top", fontsize=FS - 0.5,
             color=S.INK2)
axes[0].set_ylabel("bias")
axes[1].set_ylabel("coverage")
axes[0].set_title("a. Bias: 12 primary non-null cells | 4 stress cells", loc="left")
axes[1].set_title("b. Coverage of nominal 95% intervals", loc="left")
fig.legend(handles=S.proxies(E5, lab, line=False), loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.08))
fig.tight_layout()
save(fig, SUPP, "figS_exp5_reevaluation", "FigureS1")

# ======================================================================================= validation intensity
VI = {False: rd("figures/Figure3_validation_intensity_data.csv"),
      True: rd("figures/FigureS3_validation_intensity_other_estimators_data.csv")}


def intensity(other, ests, stem, number):
    rows = VI[other]
    xs = sorted({num(r["expected_labeled_clusters"]) for r in rows})
    x = np.array(xs)
    get = {(r["estimator"], num(r["expected_labeled_clusters"])): r for r in rows}
    setup()
    fig, axes = plt.subplots(1, 2, figsize=(W, 3.2))
    nn = len(ests)
    for k, e in enumerate(ests):
        dx = 1.0 + 0.018 * (k - (nn - 1) / 2)
        m = [get[(e, v)] for v in xs]
        ebar(axes[0], x * dx, [num(q["coverage"]) for q in m], [num(q["coverage_mcse"]) for q in m], e, ms=3.8)
        ebar(axes[1], x * dx, [num(q["width_median"]) for q in m], [num(q["width_median_bmcse"]) for q in m], e, ms=3.8)
    decorate(axes[0], "coverage")
    axes[0].set_ylabel("coverage of nominal 95% intervals")
    cov = {e: [num(get[(e, v)]["coverage"]) for v in xs] for e in ests}
    low = [e for e in ests if min(cov[e]) < 0.80]
    if low:
        rest = [c for e in ests if e not in low for c in cov[e]]
        lo_y = min(0.80, math.floor((min(rest) - 0.02) * 50) / 50) if rest else 0.0
        axes[0].set_ylim(lo_y, 1.0)
        axes[0].text(0.02, 0.03, f"off scale (below {lo_y:.2f}):\n" + ", ".join(
            f"{lab(e)} {min(cov[e]):.3f}-{max(cov[e]):.3f}" for e in low), transform=axes[0].transAxes,
            fontsize=FS - 0.5, color=S.INK2)
    axes[1].set_yscale("log")
    axes[1].set_ylabel("median interval width (log scale)")
    ref_e = "E-2" if "E-2" in ests else ests[0]
    w0 = num(get[(ref_e, xs[0])]["width_median"])
    xr = np.array([x.min(), x.max()])
    axes[1].plot(xr, w0 * np.sqrt(xr[0] / xr), color=S.INK2, lw=0.8, ls=(0, (4, 3)))
    ylo, yhi = axes[1].get_ylim()
    tk = [t for t in (0.05, 0.07, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0, 1.5, 2.0) if ylo <= t <= yhi]
    axes[1].yaxis.set_major_locator(FixedLocator(tk))
    axes[1].yaxis.set_minor_locator(NullLocator())
    axes[1].set_yticklabels([f"{t:g}" for t in tk])
    for ax in axes:
        ax.set_xscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels([f"{v:g}" for v in np.round(x, 2)], rotation=0)
        ax.minorticks_off()
        ax.set_xlabel("expected labeled clusters")
    h = S.proxies(ests, lab) + [Line2D([], [], color=S.INK2, lw=0.8, ls=(0, (4, 3)), label="slope $-1/2$ reference")]
    fig.legend(handles=h, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.2 if not other else -0.17))
    fig.tight_layout()
    save(fig, SUPP, stem, number)


intensity(False, MAIN_FIG, "figS_validation_intensity", "FigureS4")
intensity(True, SUPP_FIG, "figS_validation_intensity_other", "FigureS5")

# ======================================================================================= Experiment 3 (Figure S8)
X3 = rd("figures/FigureX3_inverse_T_data.csv")
FITS = json.load(open(os.path.join(A, "experiments/Exp3/O3.3_scaling_fit.json")))["fits"]
X3_EST = ["E-1", "E-7", "E-2", "E-6"]   # fa_common.X3_EST
TS = (4, 6, 8, 10, 12, 16)
setup()
fig, axes = plt.subplots(1, 2, figsize=(W, 3.0))
for k, e in enumerate(X3_EST):
    rr = [r for r in X3 if r["estimator"] == e]
    T = np.array([float(r["T"]) for r in rr])
    ebar(axes[0], T * (1 + 0.012 * (k - 1.5)), [float(r["T_abs_displacement"]) for r in rr],
         [float(r["T_abs_displacement_mcse"]) for r in rr], e, ms=3.8)
    if "note" in FITS[e]:
        continue
    d = np.array([float(r["displacement"]) for r in rr])
    axes[1].plot(np.log(T), np.log(np.abs(d)), **S.est_kw(e, line=False, markersize=3.8))
xx = np.log(np.array([4, 16]))
fit_h = []
for e in ("E-1", "E-7"):
    f = FITS[e]
    axes[1].plot(xx, f["intercept"] + f["slope"] * xx, color=S.STYLE[e]["color"], lw=1.2)
    fit_h.append(Line2D([], [], color=S.STYLE[e]["color"], lw=1.2,
                        label=f"{e} fit: slope {f['slope']:.2f} [{f['ci95'][0]:.2f}, {f['ci95'][1]:.2f}]"))
f = FITS["E-1"]
x8 = math.log(8)
y8 = f["intercept"] + f["slope"] * x8
axes[1].plot(xx, y8 - (xx - x8), color=S.INK2, lw=0.8, ls=(0, (4, 3)))
fit_h.append(Line2D([], [], color=S.INK2, lw=0.8, ls=(0, (4, 3)), label="reference slope $-1$"))
axes[0].set_xscale("log")
axes[0].set_xticks(TS)
axes[0].set_xticklabels([str(t) for t in TS])
axes[0].minorticks_off()
axes[0].set_xlabel("panel length $T$")
axes[0].set_ylabel(r"$T\,|d(T)|$")
axes[0].set_title(r"a. $T\,|d(T)|$ (flat under $1/T$ scaling)", loc="left")
axes[1].set_xlabel(r"$\log T$")
axes[1].set_ylabel(r"$\log|d(T)|$")
axes[1].set_title("b. Weighted log-log fit", loc="left")
axes[0].legend(handles=S.proxies(X3_EST, lab), loc="upper center", ncol=2, bbox_to_anchor=(0.5, -0.22))
axes[1].legend(handles=fit_h, loc="upper center", ncol=1, bbox_to_anchor=(0.5, -0.22))
fig.tight_layout()
save(fig, SUPP, "figS8_inverse_T_scaling", "FigureS8")

# ======================================================================================= dissociation (Figure S9)
D = rd("figures/Figure4_agreement_predictive_value_data.csv")
k = np.array([float(r["kappa"]) for r in D])
setup()
fig, axes = plt.subplots(1, 2, figsize=(W, 2.8))
for nm, lb, col, mk in (("QWK", r"QWK ($Z_L$ vs discretized $Z_H$)", S.SLOT["blue"], "o"),
                        ("rank_corr_spearman", "rank correlation (Spearman)", S.SLOT["violet"], "s")):
    axes[0].errorbar(k, [float(r[nm]) for r in D], yerr=[1.96 * float(r[nm + "_mcse"]) for r in D], color=col,
                     marker=mk, lw=1.5, ms=4.2, label=lb, capsize=0)
axes[0].set_ylabel("agreement")
axes[0].set_title(r"a. Agreement of $Z_L$ with $Z_H$", loc="left")
axes[1].errorbar(k, [float(r["incremental_oos_r2_pct"]) for r in D],
                 yerr=[1.96 * float(r["incremental_oos_r2_pct_mcse"]) for r in D], color=S.SLOT["orange"],
                 marker="D", lw=1.5, ms=4.2, capsize=0)
axes[1].axhline(0, color=S.INK2, lw=0.7)
axes[1].set_ylabel(r"incremental out-of-sample $R^2$ (%)")
axes[1].set_title(r"b. Predictive value of $Z_L$", loc="left")
for ax in axes:
    ax.set_xlabel(r"contamination intensity $\kappa$")
    ax.set_xticks(k)
axes[0].legend(loc="lower left")
fig.tight_layout()
save(fig, SUPP, "figS9_dissociation", "FigureS9")

open(os.path.join(ROOT, "FIGURES_PRINT_LOG.txt"), "w").write("\n".join(LOG) + "\n")
print("\n".join(LOG))
