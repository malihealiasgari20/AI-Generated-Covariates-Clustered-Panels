# Reproducibility archive: Valid Inference with AI-Generated Covariates in Clustered Business Panels

Yousef Nejatbakhsh and Malihe Aliasgari. Simulation study submitted to *Applied Stochastic Models in Business and Industry*.

This archive holds what is needed to reproduce every table and figure of the article and its Supplementary Material:
- the frozen study protocol;
- the simulation code;
- the seed logic;
- the cell-level simulation outputs;
- the analysis scripts.

The study uses simulated data only.

## Contents

| Path | What it is |
|---|---|
| `final_study_v1/FINAL_V1_PRE_RUN_RECORD*.txt`, `*.sha256`, `FINAL_V1_SEAL_RECORD.txt` | The binding pre-run record, sealed on 3 November 2026 before any replication was generated, with its later revisions and seals. |
| `final_study_v1/FINAL_V1_CELL_REGISTRY_FROZEN.csv`, `build_registry.py` | The 149 frozen configurations and the arithmetic that builds them. |
| `final_study_v1/protocol/` | The study protocol, versions 1.5 to 1.10. |
| `final_study_v1/code/` | The simulation code. `fv1_run.py` is the entry point, `fv1/` holds the generator, estimators, seeds and runner, and `deps/` holds the hash-checked dependencies. See `code/README_CODE.txt`. |
| `final_study_v1/gates/` | The pre-performance gate scripts and their reports. |
| `final_study_v1/run/` | The run log, execution summary and close-out report. The per-replication checkpoints (`run/raw/`, about 500 MB) are not included; see "Regenerating the raw output". |
| `final_study_v1/analysis/` | The analysis code (`analysis/code/`) and all of its outputs: cell-level performance tables, experiment outputs, hypothesis decisions, supplementary tables, and figure-data files (`figures/*_data.csv`). |
| `manuscript_figures/make_figures_print.py` | Redraws the article's Figures 1–3 and Supplementary Figures S1–S9 at their printed size from `final_study_v1/analysis/figures/*_data.csv`. |
| `MANIFEST_SHA256_FILES.txt` | SHA-256 hashes of every file in this archive. |

The study's own manifest, `final_study_v1/MANIFEST_SHA256_FINAL.txt`, covers the complete sealed package. Because the `run/raw/` checkpoints are not included here, its entries for those files will report as missing. Every other entry verifies.

## Software

The study ran with Python 3.13.16, NumPy 2.5.3 and SciPy 1.18.1, recorded in every checkpoint. The manuscript figures were drawn with Matplotlib 3.11.2.

## Reproducing the results

The scripts were run with the package located at `/mnt/user-data/outputs/Final_Study_v1`. The analysis code reads the environment variables `FV1_STUDY`, `FV1_RUN`, `FV1_OUT` and `FV1_CACHE`. The simulation runner, gate scripts and registry script check sealed files at that location, so place `final_study_v1/` there (for example with a symbolic link) before running them. Always run Python with `-I -B`.

1. **Figures from the stored outputs** (seconds):
   ```
   python3 -I -B manuscript_figures/make_figures_print.py
   ```
2. **Analysis from the raw checkpoints** (about 20 minutes on two cores): run the six commands in `final_study_v1/analysis/README_ANALYSIS.txt`, starting with `fa_closeout.py` and ending with `fa_repro.py`. Run this step after step 3.
3. **Regenerating the raw output** (about 3.9 hours of worker time on two cores):
   ```
   cd final_study_v1/code
   python3 -I -B fv1_run.py run --mode production --gate-record ../gates/FINAL_V1_GATE_RECORD.json --workers 2
   ```
   The seed hierarchy in `code/fv1/seeds.py` makes every configuration reproducible from its seeds. The pre-performance gates verified bit-for-bit reproduction of the generator and of each procedure.

## License

The code is released under the MIT License (`LICENSE`). The protocol, outputs and documentation are released under CC BY 4.0.

## Citation

See `CITATION.cff`. Please cite the article and this archive.
