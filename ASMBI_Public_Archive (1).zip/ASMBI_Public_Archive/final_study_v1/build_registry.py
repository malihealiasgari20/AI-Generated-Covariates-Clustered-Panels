"""FINAL_V1 cell registry (DRAFT 0.1). Enumerates every configuration each module needs,
deduplicates identical configurations, and computes counts and a compute estimate. NO simulation
is run: only parameter arithmetic, the frozen latent reference scale and the frozen theta_0 key.
Run:  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=../Stage2_Target_Direction_Stabilization/deps python3 build_registry.py
(frozen modules are imported read-only; bytecode writing is disabled so no sealed folder changes)."""
import json, math, csv, itertools
from dataclasses import replace, asdict
import numpy as np
from stage0_dgp import DGPParams, latent_reference_sd
import stage0_theta0 as T0

BASE = replace(DGPParams(), sd_ZH_within=0.62, cut_spacing=0.65, sd_e=0.55, lambda1=(1.20, 1.05, 0.45),
               icc=0.30, rho_e=0.60, kappa=0.0, tau=0.10, N=300, T=8, gamma_W=0.15, pi=(0.15, 0.30, 0.60))
REF_SCALE = latent_reference_sd(BASE) * BASE.cut_spacing           # frozen absolute cut scale
PI0 = np.array([0.15, 0.30, 0.60])

def num(x):  return format(round(float(x), 12), ".12g")
def vec(v):  return ",".join(num(x) for x in v)

def pi_target_fraction(f):
    """Ledger Q3 rule: overall expected labeled fraction f, stratum proportions preserved as far as the cap at 1 allows."""
    lo, hi = 0.0, 1.0 / PI0.min()
    for _ in range(200):
        c = 0.5 * (lo + hi)
        if np.minimum(1.0, c * PI0).mean() < f: lo = c
        else: hi = c
    c = 0.5 * (lo + hi)
    if np.all(c * PI0 <= 1.0): c = f / PI0.mean()          # exact scaling when the cap does not bind
    return tuple(np.minimum(1.0, c * PI0))

def sdW_for_T(T):  # Exp 3, C3: expected within signal moment held at its T = 8 value
    return 0.62 * math.sqrt((7.0 / 8.0) / ((T - 1.0) / T))

def kappa_terminal(T, kbar):  # Exp 3, C2: mean loading over contaminated periods = kbar, frozen ramp shape
    c = T // 2; h = T - c
    return 0.0 if kbar == 0 else 2.0 * h * kbar / (h + 1.0)

configs = {}
def add(module, battery, R, **kw):
    p = replace(BASE, **kw)
    seed_id = (f"N={p.N}|T={p.T}|icc={num(p.icc)}|rho={num(p.rho_e)}|tau={num(p.tau)}|pi={vec(p.pi)}"
               f"|sde={num(p.sd_e)}|sdW={num(p.sd_ZH_within)}|lam={vec(p.lambda1)}|g={num(p.gamma_W)}")
    cid = seed_id + f"|kappa={num(p.kappa)}"
    c = configs.setdefault(cid, dict(cid=cid, seed_id=seed_id, p=p, modules=set(), R={}))
    c["modules"].add(module)
    c["R"][battery] = max(R, c["R"].get(battery, 0))

G = (0.15, 0.0)
# P: primary grid
for icc, rho, k, g in itertools.product((0.10, 0.30, 0.50), (0.0, 0.60), (0.0, 0.60), G):
    add("P", "FULL", 5000, icc=icc, rho_e=rho, kappa=k, gamma_W=g)
# L: Experiment 1 contamination ladder
for k, rho, g in itertools.product((0, .15, .30, .45, .60, .75, .90), (0.0, 0.60), G):
    add("L", "FULL", 5000, kappa=k, rho_e=rho, gamma_W=g)
# S: stress grid, one factor at a time from the stress baseline, each with a null companion
stress = [("N=250", dict(N=250)), ("N=600", dict(N=600)),
          ("T=5 budget", dict(T=5, pi=pi_target_fraction(0.35 * 8 / 5))), ("T=10 budget", dict(T=10, pi=pi_target_fraction(0.35 * 8 / 10))),
          ("tau=0", dict(tau=0.0)), ("tau=0.30", dict(tau=0.30)), ("kappa=0.30", dict(kappa=0.30)), ("kappa=0.90", dict(kappa=0.90)),
          ("sd_e=0.35", dict(sd_e=0.35)), ("sd_e=0.80", dict(sd_e=0.80)), ("low within", dict(sd_ZH_within=0.31))]
stress += [(f"m={m}", dict(pi=pi_target_fraction(0.35 * m))) for m in (0.33, 0.50, 0.75, 1.50, 2.00)]
for lab, kw in stress:
    for g in G: add("S", "FULL", 5000, gamma_W=g, **kw)
for g in G: add("S", "FULL", 5000, gamma_W=g)                      # stress baseline / m = 1.00 reference
# X2: Experiment 2 (2 x 2 x gamma) + E2-LAMBDA arm
for pi, tau, g in itertools.product(((0.35,) * 3, (0.15, 0.30, 0.60)), (0.0, 0.30), G):
    add("X2", "FULL", 5000, pi=pi, tau=tau, gamma_W=g)
for tau in (0.0, 0.30):
    add("X2", "FULL", 5000, tau=tau, lambda1=(0.90, 0.90, 0.90))
# X3: Experiment 3 (1/T scaling)
for T, kb in itertools.product((4, 6, 8, 10, 12, 16), (0.0, 0.60)):
    add("X3", "X3", 5000, T=T, rho_e=0.0, sd_ZH_within=sdW_for_T(T), kappa=kappa_terminal(T, kb))
# X4: Experiment 4 crossover + uniform-validation diagnostic
for f, sde, g in itertools.product((0.03, 0.05, 0.10, 0.20, 0.35, 0.50), (0.15, 0.25, 0.35, 0.55, 0.80), G):
    add("X4", "FULL", 2000, pi=pi_target_fraction(f), sd_e=sde, gamma_W=g); add("X4", "E10", 2000, pi=pi_target_fraction(f), sd_e=sde, gamma_W=g)
for g in G:
    add("X4", "FULL", 5000, pi=(0.35,) * 3, gamma_W=g); add("X4", "E10", 5000, pi=(0.35,) * 3, gamma_W=g)
# D: agreement / predictive-value diagnostic
for k in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0):
    add("D", "D", 1000, kappa=k)

# theta_0 availability (union of frozen maps; values must agree where keys overlap)
maps = ["/mnt/user-data/outputs/Stage0_Reconstruction_v1.1_FROZEN/config/theta0_map.json",
        "/mnt/user-data/outputs/S0.11_Holdout_Package/stage0_theta0_map.json",
        "/mnt/user-data/outputs/Stage1_Experiment5/stage0_theta0_map.json",
        "/mnt/user-data/outputs/Stage2_Target_Direction_Stabilization/stage0_theta0_map.json"]
union, clash = {}, 0
for m in maps:
    for k, v in json.load(open(m)).items():
        if k in union and union[k]["theta0"] != v["theta0"]: clash += 1
        union.setdefault(k, v)

def cost_ms(p, bat):
    n, t = (p.N / 300) ** 1.14, (p.T / 8)
    return {"FULL": 31.0 * n * t ** 2.1, "E10": 2.0 * n * t ** 2.1, "X3": 2.2 * n * t ** 1.56, "D": 3.5 * n * t ** 1.56}[bat]

rows, need_t0, core_s = [], set(), 0.0
for c in sorted(configs.values(), key=lambda c: (sorted(c["modules"])[0], c["cid"])):
    p = c["p"]; ref = latent_reference_sd(p)
    cs_eff = REF_SCALE / ref
    assert abs(ref * cs_eff - REF_SCALE) < 1e-14
    k0 = T0._key(BASE, {k: getattr(p, k) for k in ("T", "gamma_W", "tau", "icc", "rho_e", "sd_ZH_within")})
    have = k0 in union
    if not have: need_t0.add(k0)
    s = sum(c["R"][b] * cost_ms(p, b) for b in c["R"]) / 1000.0; core_s += s
    rows.append(dict(config_id=c["cid"], seed_cell_id=c["seed_id"], kappa=num(p.kappa), modules="+".join(sorted(c["modules"])),
                     R_FULL=c["R"].get("FULL", 0), R_E10=c["R"].get("E10", 0), R_X3=c["R"].get("X3", 0), R_D=c["R"].get("D", 0),
                     expected_labeled_clusters=num(p.N * np.mean(p.pi)), cut_spacing_effective=num(cs_eff),
                     latent_reference_sd=num(ref), theta0_key=k0, theta0_in_frozen_maps=have, est_core_seconds=round(s, 1)))

with open("FINAL_V1_CELL_REGISTRY.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

mods = {}
for c in configs.values():
    for m in c["modules"]: mods.setdefault(m, 0); mods[m] += 1
print("module cell counts (incl. shared):", dict(sorted(mods.items())))
print("unique configurations:", len(configs))
reps = sum(max(c["R"].values()) for c in configs.values())
print("panel replications (each unique configuration x its max R):", reps)
for b in ("FULL", "E10", "X3", "D"):
    print(f"  battery {b}: configs {sum(1 for c in configs.values() if b in c['R'])}, estimator-battery replications {sum(c['R'].get(b,0) for c in configs.values())}")
print("theta_0 union map keys:", len(union), "value clashes:", clash, "| new theta_0 keys needed:", len(need_t0))
for k in sorted(need_t0): print("   ", k)
print(f"estimated compute: {core_s/3600:.2f} core-hours  (wall-clock on 2 workers ~{core_s/3600/2:.2f} h before overhead)")
shared = [c for c in configs.values() if len(c["modules"]) > 1]
print("configurations shared by >1 module:", len(shared))
print("pi rule checks: m=2.00 ->", [round(x, 4) for x in pi_target_fraction(0.70)], "expected clusters", round(300 * np.mean(pi_target_fraction(0.70)), 2),
      "| f=0.03 ->", [round(x, 5) for x in pi_target_fraction(0.03)], "| T=5 ->", [round(x, 4) for x in pi_target_fraction(0.56)])
print("Exp3 terminal kappa_T at kbar=0.60:", {T: round(kappa_terminal(T, 0.6), 4) for T in (4, 6, 8, 10, 12, 16)})
print("Exp3 sdW(T):", {T: round(sdW_for_T(T), 4) for T in (4, 6, 8, 10, 12, 16)})
print("frozen absolute cut scale:", REF_SCALE, "cut points:", list(np.array([-1.5, -0.5, 0.5, 1.5]) * REF_SCALE))
