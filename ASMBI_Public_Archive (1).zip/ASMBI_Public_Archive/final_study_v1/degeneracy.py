"""DRAFT 0.1. Exact design probabilities of the FROZEN degeneracy rules (no simulation): strata of 100 units at N = 300,
independent Bernoulli(pi_s) labeling. G_S < 10 -> cross-fitted family undefined (E-5, E-12a/b/c, HT-TDS-CF);
G_S < 5 -> E-2 undefined; any n_s = 0 -> post-stratified estimators undefined (PS-TDS-I, E-9);
any n_s <= 1 -> E-9 undefined (a jackknife deletion empties a stratum, P19)."""
import numpy as np
from scipy.stats import binom
import build_registry as B
def probs(pi, Ns=(100, 100, 100)):
    pmfs = [binom.pmf(np.arange(n + 1), n, p) for n, p in zip(Ns, pi)]
    g = pmfs[0]
    for q in pmfs[1:]: g = np.convolve(g, q)
    p0 = [pm[0] for pm in pmfs]; p01 = [pm[0] + (pm[1] if len(pm) > 1 else 0) for pm in pmfs]
    any0 = 1 - np.prod([1 - x for x in p0]); any01 = 1 - np.prod([1 - x for x in p01])
    return g[:10].sum(), g[:5].sum(), any0, any01
print(f"{'design':<22}{'E[G_S]':>8}{'P(G_S<10)':>11}{'P(G_S<5)':>10}{'P(n_s=0)':>10}{'P(n_s<=1)':>11}")
for f in (0.03, 0.05, 0.10, 0.20, 0.35, 0.50):
    pi = B.pi_target_fraction(f); a = probs(pi)
    print(f"{'X4 f='+str(f):<22}{300*np.mean(pi):8.1f}{a[0]:11.4f}{a[1]:10.4f}{a[2]:10.4f}{a[3]:11.4f}")
for m in (0.33, 0.50, 0.75, 1.50, 2.00):
    pi = B.pi_target_fraction(0.35 * m); a = probs(pi)
    print(f"{'S m='+str(m):<22}{300*np.mean(pi):8.1f}{a[0]:11.4f}{a[1]:10.4f}{a[2]:10.4f}{a[3]:11.4f}")
for T in (5, 10):
    pi = B.pi_target_fraction(0.35 * 8 / T); a = probs(pi)
    print(f"{'S T='+str(T)+' budget':<22}{300*np.mean(pi):8.1f}{a[0]:11.4f}{a[1]:10.4f}{a[2]:10.4f}{a[3]:11.4f}")
for lab, pi, Ns in (("S N=250", (0.15, 0.30, 0.60), (84, 83, 83)), ("S N=600", (0.15, 0.30, 0.60), (200, 200, 200)), ("X2 A0 uniform", (0.35,) * 3, (100, 100, 100))):
    a = probs(pi, Ns); print(f"{lab:<22}{sum(n*p for n,p in zip(Ns,pi)):8.1f}{a[0]:11.4f}{a[1]:10.4f}{a[2]:10.4f}{a[3]:11.4f}")
