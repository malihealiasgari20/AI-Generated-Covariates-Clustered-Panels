FINAL_V1 -- FINAL PROSPECTIVELY FROZEN PUBLICATION STUDY: SEALING-TIME PACKAGE
Sealed 2026-11-03T17:19:02Z (UTC), before any FINAL_V1 replication was generated and before any
FINAL_V1 performance quantity existed.

FINAL_V1_PRE_RUN_RECORD.txt      the binding pre-run record (draft 0.1 approved 3 November 2026
                                 with correction A); SHA-256 65e9336db6c312121c8a81c80a4a05fd46b8198a163512d25b78f96d60f7a608
FINAL_V1_PRE_RUN_RECORD.sha256   the seal: hash and UTC timestamp
FINAL_V1_CELL_REGISTRY.csv       the 149 configurations (unchanged from draft 0.1)
build_registry.py, degeneracy.py arithmetic behind the registry, counts, compute estimate and the
                                 design probabilities of the frozen degeneracy rules (no simulation);
                                 their printed outputs: registry_output.txt, degeneracy_output.txt
protocol/                        ASMBI protocol v1.6 (v1.5 + amendment A6, written at sealing) and
                                 v1.5 unaltered
superseded/                      draft 0.1 of the record, unaltered

Code, gates, raw output and results are added to this package in later steps; nothing here is
modified by them. Final_Study_v1_DRAFT/ was the drafting folder and is not part of the package.
