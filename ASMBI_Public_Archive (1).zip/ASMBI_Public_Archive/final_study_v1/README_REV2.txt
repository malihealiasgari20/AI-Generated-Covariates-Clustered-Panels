FINAL_V1 -- REVISION 2 OF THE PRE-RUN RECORD (sealed 2026-11-03T18:39:16Z, UTC)

BINDING RECORD: FINAL_V1_PRE_RUN_RECORD_REV2.txt, SHA-256 4bc50fef8217af9e796de4628489c18ecbf04ec885db67a7a92582070e473163
  draft 0.1 with the authors' corrections A, B, C and D; seal in FINAL_V1_PRE_RUN_RECORD_REV2.sha256.
SUPERSEDED, retained unaltered:
  FINAL_V1_PRE_RUN_RECORD.txt (revision 1: draft 0.1 with correction A), sealed 2026-11-03T17:19:02Z,
  SHA-256 65e9336db6c312121c8a81c80a4a05fd46b8198a163512d25b78f96d60f7a608;
  superseded/FINAL_V1_PRE_RUN_RECORD_DRAFT.txt (draft 0.1).
The authors' corrections B-D arrived after revision 1 was sealed. No FINAL_V1 replication was generated
and no FINAL_V1 performance quantity existed at either seal.
PROTOCOL: protocol/ASMBI_Post_Primary_Extension_Protocol_v1.7.txt (v1.6 + amendment A7), SHA-256 df397ffb0ec4c00d8056906a1dde5b25d4302d9ed994cfb34fe255f18b1a4350;
  v1.6 and v1.5 retained unaltered in protocol/.
README.txt and MANIFEST_SHA256.txt describe the revision-1 seal and are left unaltered;
MANIFEST_SHA256_REV2.txt covers every file in the package now.
