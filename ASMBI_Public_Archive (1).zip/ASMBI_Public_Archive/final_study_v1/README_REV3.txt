FINAL_V1 -- REVISION 3 OF THE PRE-RUN RECORD (sealed 2026-11-03T19:00:08Z, UTC)

BINDING RECORD: FINAL_V1_PRE_RUN_RECORD_REV3.txt, SHA-256 bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0
  draft 0.1 with the authors' corrections A-D plus the clerical corrections of the pre-seal
  verification; seal in FINAL_V1_PRE_RUN_RECORD_REV3.sha256.
VERIFICATION: FINAL_V1_PRE_RUN_VERIFICATION.txt, SHA-256 c3c96abf7ec7821054ecb4affbd1689d87ea209a1a6461ef99b63c3502c10312 (all 16 items PASS after the
  clerical corrections; no simulation run; no FINAL_V1 performance quantity exists).
SUPERSEDED, retained unaltered: revision 2 (FINAL_V1_PRE_RUN_RECORD_REV2.txt, sealed 2026-11-03T18:39:16Z),
  revision 1 (FINAL_V1_PRE_RUN_RECORD.txt, sealed 2026-11-03T17:19:02Z), draft 0.1 (superseded/).
PROTOCOL: protocol/ASMBI_Post_Primary_Extension_Protocol_v1.8.txt (v1.7 + amendment A8), SHA-256 3189561eea3bee7972d3436347e31dc4f672a96542ac062ffda2764dead7c4b6;
  v1.7, v1.6 and v1.5 retained unaltered in protocol/.
Earlier READMEs and manifests are left unaltered; MANIFEST_SHA256_REV3.txt covers every file now.
