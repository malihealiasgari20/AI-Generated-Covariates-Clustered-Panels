"""Mechanical tests of the FINAL_V1 runner (throwaway namespaces only; nothing here is a result).

Every simulated panel comes from a namespace that no study uses (FV1_MT_*). The tests compare
arrays for equality and read failure codes, design counts and runtimes; no estimate, SE level,
bias or coverage is printed or summarized. All test output is deleted at the end, unread.

    python3 -I -B tests/test_mechanics.py <Final_Study_v1 root> <scratch dir>
"""
import json, os, re, shutil, signal, subprocess, sys, time

sys.dont_write_bytecode = True

CODE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, CODE)
import fv1.env as env  # noqa: E402
import numpy as np  # noqa: E402
from dataclasses import fields  # noqa: E402
from stage0_dgp import generate_panel, make_rng, stream_key  # noqa: E402
from stage0_naive import _period_design  # noqa: E402
import stage0_crossppi, stage1_design_aware  # noqa: E402
from fv1 import compute, estimators as E, registry, seeds, runner, store  # noqa: E402

ROOT, SCRATCH = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
RUN = [sys.executable, "-I", "-B", os.path.join(CODE, "fv1_run.py")]
shutil.rmtree(SCRATCH, ignore_errors=True); os.makedirs(SCRATCH)
results = []


def check(tid, label, ok, info=""):
    results.append((tid, label, bool(ok)))
    print(f"  {'PASS' if ok else 'FAIL'}  {tid} {label}" + (f"  [{info}]" if info else ""), flush=True)


def run(out, *extra, ns="FV1_MT", wait=True):
    cmd = RUN + ["run", "--mode", "test", "--study-root", ROOT, "--out", out, "--namespace", ns, *extra]
    if not wait:
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    cp = subprocess.run(cmd, capture_output=True, text=True)
    if cp.returncode != 0:
        raise RuntimeError(f"runner failed ({cp.returncode}): {cp.stderr[-2000:]}")
    return cp


def digests(out):
    d = {}
    for f in sorted(os.listdir(os.path.join(out, "raw"))):
        if f.endswith(".sha256"):
            d[f[:-7]] = store.read_sidecar(os.path.join(out, "raw", f))[1]
    return d


def events(out):
    return [json.loads(l) for l in open(os.path.join(out, "RUN_LOG.jsonl"))]


DET = ("rows_r", "rows_est", "rows_estimate", "rows_se", "rows_crit", "rows_lo", "rows_hi", "rows_cover",
       "rows_reject", "rows_fail", "rows_bind")


def load(out, name):
    with np.load(os.path.join(out, "raw", f"{name}.npz")) as z:
        return {k: z[k] for k in z.files}


def eq(a, b):
    a, b = np.asarray(a), np.asarray(b)
    if a.shape != b.shape:
        return False
    if a.dtype.kind == "f":
        return bool(np.all((a == b) | (np.isnan(a) & np.isnan(b))))
    return bool(np.all(a == b))


configs, prov = registry.load(ROOT)
by = {c.name: c for c in configs}
ns = seeds.test_namespace("FV1_MT")

# ---------------------------------------------------------------- M1 registry and seed keys
groups = {}
for c in configs:
    groups.setdefault(c.seed_cell_id, []).append(c)
same_but_kappa = all(all({k: v for k, v in vars(a.p).items() if k not in ("kappa",)} ==
                         {k: v for k, v in vars(b.p).items() if k not in ("kappa",)} for b in g) for g in groups.values() for a in g)
check("M1", "registry rebuilt byte-identical; 149 configurations; 567,000 panel replications; 87 at cut spacing 0.65",
      prov["registry_rebuild"] == "byte-identical" and prov["configs"] == 149 and prov["panel_replications"] == 567000
      and prov["baseline_scale_configs"] == 87)
check("M1", "seed cell ids exclude kappa; configurations sharing a seed id differ only in kappa",
      all("kappa" not in c.seed_cell_id for c in configs) and same_but_kappa,
      f"{len(groups)} seed ids, {sum(len(g) > 1 for g in groups.values())} shared by several kappa values")

# ---------------------------------------------------------------- M2 namespaces
try:
    seeds.test_namespace("FINAL_V1_X"); bad_prefix_refused = False
except ValueError:
    bad_prefix_refused = True
k = seeds.keys_for(ns, by["C001"].seed_cell_id, 7)
check("M2", "production ids are FINAL_V1_PANEL/_FOLDS/_OOS; test prefixes cannot start with FINAL_V1; keys use the frozen rule",
      vars(seeds.PRODUCTION) == {"panel": "FINAL_V1_PANEL", "folds": "FINAL_V1_FOLDS", "oos": "FINAL_V1_OOS"}
      and bad_prefix_refused and k[0] == stream_key("FV1_MT_PANEL", by["C001"].seed_cell_id, 7))
src = {f: open(os.path.join(CODE, "fv1", f)).read() for f in os.listdir(os.path.join(CODE, "fv1")) if f.endswith(".py")}
check("M2", "the runner code never uses FINAL_V1_BOOT or FINAL_V1_GATE streams",
      not any(re.search(r"make_rng\([^)]*FINAL_V1_(BOOT|GATE)", s) for s in src.values()))

# ---------------------------------------------------------------- M3/M4 common random numbers
shared = ("Y", "ZH", "X", "eps", "eps_next", "u", "labeled", "strata")
ok3, n3, worst = True, 0, 0.0
for sid, g in groups.items():
    if len(g) < 2:
        continue
    for r in range(3):
        pans = [generate_panel(c.p, seeds.panel_rng(ns, sid, r)) for c in g]
        for p_ in pans[1:]:
            ok3 &= all(np.array_equal(getattr(p_, f), getattr(pans[0], f)) for f in shared)
            base = [q.Zstar - q.C for q in (pans[0], p_)]
            worst = max(worst, float(np.abs(base[0] - base[1]).max()))
            n3 += 1
check("M3", "kappa-paired configurations share every base draw (Y, Z_H, X, eps, u, labels, strata identical; "
      "Z* - C equal to 1e-12)", ok3 and worst < 1e-12, f"{n3} pairs, max |diff| {worst:.1e}")
a, b = by["C001"], [c for c in configs if c.seed_cell_id != by["C001"].seed_cell_id and c.p.N == 300 and c.p.T == 8][0]
pa, pb = generate_panel(a.p, seeds.panel_rng(ns, a.seed_cell_id, 0)), generate_panel(b.p, seeds.panel_rng(ns, b.seed_cell_id, 0))
check("M4", "configurations differing in any other factor use different streams", not np.array_equal(pa.ZH, pb.ZH))

# ---------------------------------------------------------------- M5 panel immutability guard
cfg = by["C001"]
orig_full = E.FULL


def mutate(rep):
    rep.pan.Y[0, 0] += 1.0
    return E.Result(0.0, 1.0, 1.96)


E.FULL = orig_full + (("E-1", mutate),)
try:
    compute.run_configuration(cfg, ns, 0.15, False, cap=1); guarded = False
except RuntimeError as ex:
    guarded = "modified the shared panel" in str(ex)
E.FULL = orig_full
check("M5", "one panel per (configuration, r) shared by all estimators; a modification aborts the run", guarded)

# ---------------------------------------------------------------- M6 shared folds
ok6 = True
for r in range(5):
    pan = generate_panel(cfg.p, seeds.panel_rng(ns, cfg.seed_cell_id, r))
    key = seeds.fold_key(ns, cfg.seed_cell_id, r)
    f0 = stage0_crossppi.crossfit_predictions(pan, make_rng(*key))
    f1 = stage1_design_aware.crossfit_predictions(pan, make_rng(*key), False)
    ok6 &= all(np.array_equal(x, y) for x, y in zip(f0, f1))
    lab = np.flatnonzero(pan.labeled)
    ok6 &= np.array_equal(make_rng(*key).permutation(lab), make_rng(*key).permutation(lab))
    pan4 = generate_panel(by["C004"].p, seeds.panel_rng(ns, by["C004"].seed_cell_id, r))
    ok6 &= np.array_equal(pan.labeled, pan4.labeled) and seeds.fold_key(ns, by["C004"].seed_cell_id, r) == key
check("M6", "E-5 and the E-12/HT-TDS-CF code paths draw identical folds from one key; kappa pairs share folds", ok6)

# ---------------------------------------------------------------- M7 failure isolation
o_ref, o_inj = os.path.join(SCRATCH, "m7_ref"), os.path.join(SCRATCH, "m7_inj")
run(o_ref, "--configs", "C001,C094", "--cap", "6", "--workers", "1")
run(o_inj, "--configs", "C001,C094", "--cap", "6", "--workers", "1", "--inject", "E-7,E-3/E-4")
ok7 = True
for nm in ("C001", "C094"):
    A_, B_ = load(o_ref, nm), load(o_inj, nm)
    hit = np.isin(B_["rows_est"], [E.EST_INDEX[x] for x in ("E-7", "E-3", "E-4")])
    ok7 &= bool(np.all(B_["rows_fail"][hit] == E.EXCEPTION)) and eq(A_["rows_est"], B_["rows_est"])
    ok7 &= all(eq(A_[k][~hit], B_[k][~hit]) for k in DET)
    det = set(B_["fail_detail"][np.isin(B_["fail_row"], np.flatnonzero(hit))])
    ok7 &= det == {"RuntimeError: injected test fault in E-7", "RuntimeError: injected test fault in E-3/E-4"}
    ok7 &= all(eq(A_[k], B_[k]) for k in A_ if k.startswith("diag__") and k not in ("diag__e7_cZL", "diag__diag_runtime")
               and not k.endswith(("__E-4",)) and "pred__E-4" not in k)
check("M7", "an estimator that raises is recorded as 'exception' and every other estimator's rows are unchanged", ok7)

# ---------------------------------------------------------------- M8 failure codes in a sparse cell
o8 = os.path.join(SCRATCH, "m8")
run(o8, "--configs", "C094", "--cap", "400", "--workers", "1")
Z = load(o8, "C094")
G = Z["diag__G_S"]; ns_ = np.stack([Z[f"diag__n_s{j}"] for j in range(3)], 1)
r_, e_, f_ = Z["rows_r"], Z["rows_est"], Z["rows_fail"]
code = lambda name: f_[e_ == E.EST_INDEX[name]]
gs = lambda name: G[r_[e_ == E.EST_INDEX[name]]]
ok8 = True
for nm in ("E-5", "E-12a", "E-12b", "E-12c", "HT-TDS-CF"):
    ok8 &= bool(np.all((code(nm) == E.BELOW_MIN) == (gs(nm) < 10)))
for nm in ("E-2", "E-3", "E-4", "E-6", "E-6H", "E-8", "HT-TDS-I", "E-10"):
    ok8 &= bool(np.all((code(nm) == E.BELOW_MIN) == (gs(nm) < 5)))
ps = ns_[r_[e_ == E.EST_INDEX["PS-TDS-I"]]]
ok8 &= bool(np.all((code("PS-TDS-I") == E.EMPTY_PS_FULL) == ((gs("PS-TDS-I") >= 5) & np.any(ps == 0, 1))))
e9n = ns_[r_[e_ == E.EST_INDEX["E-9"]]]
ok8 &= bool(np.all((code("E-9") == E.EMPTY_PS_FULL) == np.any(e9n == 0, 1)))
ok8 &= bool(np.all((code("E-9") == E.EMPTY_PS_DEL) == (~np.any(e9n == 0, 1) & np.any(e9n == 1, 1))))
ok8 &= not np.any(code("E-1") == E.BELOW_MIN) and not np.any(code("E-7") == E.BELOW_MIN)
ok8 &= Z["fail_row"].size == int(np.sum(f_ != 0)) and all(len(s) > 0 for s in Z["fail_detail"])
counts = {E.FAIL_NAMES[c]: int(np.sum(f_ == c)) for c in range(1, 7) if np.sum(f_ == c)}
check("M8", "f = 0.03 cell: every failure carries the code its pre-specified rule implies, with a detail string", ok8,
      "; ".join(f"{k}: {v}" for k, v in counts.items()))

# ---------------------------------------------------------------- M9 determinism
o9a, o9b = os.path.join(SCRATCH, "m9a"), os.path.join(SCRATCH, "m9b")
cfg_list = "C001,C002,C075,C089,C094,C148"
run(o9a, "--configs", cfg_list, "--cap", "25", "--workers", "2")
run(o9b, "--configs", cfg_list, "--cap", "25", "--workers", "1")
da, db = digests(o9a), digests(o9b)
same_arrays = all(all(eq(load(o9a, n)[k], load(o9b, n)[k]) for k in load(o9a, n) if k not in compute.NONDETERMINISTIC)
                  for n in da)
check("M9", "two runs (2 workers, then 1 worker) give identical content digests and identical arrays",
      da == db and len(da) == 6 and same_arrays)

# ---------------------------------------------------------------- M10 restart after a kill
o10 = os.path.join(SCRATCH, "m10")
ref = os.path.join(SCRATCH, "m10_ref")
r10 = "C001,C075,C148"
run(ref, "--configs", r10, "--cap", "150", "--workers", "1")
proc = run(o10, "--configs", r10, "--cap", "150", "--workers", "1", wait=False)
t0 = time.time(); killed_during = None
while time.time() - t0 < 120:
    time.sleep(0.2)
    if not os.path.exists(os.path.join(o10, "RUN_LOG.jsonl")):
        continue
    ev = events(o10)
    started = [e["config"] for e in ev if e["event"] == "CONFIG_START"]
    done = [e["config"] for e in ev if e["event"] == "CONFIG_DONE"]
    if "C075" in started and "C001" in done and os.path.exists(os.path.join(o10, "raw", "C075.started")):
        time.sleep(1.0)
        os.killpg(proc.pid, signal.SIGKILL); proc.wait(); killed_during = "C075"
        break
pre = {f for f in os.listdir(os.path.join(o10, "raw"))}
run(o10, "--configs", r10, "--cap", "150", "--workers", "2")
ev = events(o10)
second = ev[max(i for i, e in enumerate(ev) if e["event"] == "RUN_START"):]
recomputed = [e["config"] for e in second if e["event"] == "INTERRUPTED_RECOMPUTE"]
restarted = [e["config"] for e in second if e["event"] == "CONFIG_START"]
check("M10", "a run killed inside a configuration resumes: completed checkpoints kept, the interrupted one "
      "quarantined, recomputed from identical seeds and logged; final digests equal an uninterrupted run",
      killed_during == "C075" and "C075.started" in pre and recomputed == ["C075"] and "C001" not in restarted
      and digests(o10) == digests(ref) and os.listdir(os.path.join(o10, "quarantine")),
      f"killed during {killed_during}; second run started {restarted}")

# ---------------------------------------------------------------- M11 schema
ok11 = True
for nm in da:
    c = by[nm]; z = load(o9a, nm); R = {b: min(v, 25) for b, v in c.R.items()}
    exp_rows = R["FULL"] * 16 + (R["X3"] * 4 if not R["FULL"] else 0) + R["E10"] + (R["D"] if not R["FULL"] else 0)
    pairs = set(zip(z["rows_r"].tolist(), z["rows_est"].tolist()))
    ok11 &= z["rows_r"].size == exp_rows and len(pairs) == exp_rows
    Rp = max(R.values())
    ok11 &= list(z["key_panel"]) == [stream_key("FV1_MT_PANEL", c.seed_cell_id, r) for r in range(Rp)]
    ok11 &= all((z["key_folds"][r] != "") == (r < R["FULL"]) for r in range(Rp))
    ok11 &= all((z["key_oos"][r] != "") == (r < R["D"]) for r in range(Rp))
    m = json.loads(str(z["meta_det"]))
    ok11 &= m["config_id"] == c.config_id and m["seed_cell_id"] == c.seed_cell_id and m["production"] is False
check("M11", "one row per (configuration, r, estimator) for exactly the batteries the registry assigns; "
      "every replication stores its stream keys", ok11)

# ---------------------------------------------------------------- M12 run health only
st = subprocess.run(RUN + ["status", "--out", o9a], capture_output=True, text=True).stdout.splitlines()
allowed = re.compile(r"^(checkpoints complete: \d+   worker wall time: [\d.]+ h|  failures  .+ \d+)$")
reads = set(re.findall(r'z\["(\w+)"\]', src["runner.py"])) | set(re.findall(r'z\["(\w+)"\]', src["store.py"]))
check("M12", "status reports completion, failure counts and runtime only; the runner reads no estimate, SE or interval",
      all(allowed.match(l) for l in st) and reads <= {"meta_run", "rows_est", "rows_fail", "meta_det"}, f"reads {sorted(reads)}")

# ---------------------------------------------------------------- M13 production interlock (in-process, nothing computed)
class A:  # minimal argparse stand-in
    def __init__(self, **kw):
        self.__dict__.update(dict(study_root=ROOT, out=None, gate_record=None, cap=None, inject=None, configs=None,
                                  namespace=None, no_e10=False, mode="production"), **kw)


def refused(**kw):
    try:
        runner._settings(A(**kw)); return False
    except SystemExit:
        return True


fake = os.path.join(SCRATCH, "fake_gate.json")
json.dump({"gates": {"G-A": "PASS", "G-B": "FAIL"}, "e10_status": "ABSENT"}, open(fake, "w"))
prod_dir_before = os.path.exists(os.path.join(ROOT, "run"))
check("M13", "production refuses to start without a gate record, with a failed gate, or with test options",
      refused() and refused(gate_record=fake) and refused(gate_record=fake, cap=5)
      and refused(mode="test", out=os.path.join(ROOT, "run", "x")) and
      os.path.exists(os.path.join(ROOT, "run")) == prod_dir_before)

# ---------------------------------------------------------------- M14 E-10 switch
o14 = os.path.join(SCRATCH, "m14")
run(o14, "--configs", "C148", "--cap", "4", "--workers", "1", "--no-e10")
z = load(o14, "C148")
check("M14", "with E-10 switched off (ABSENT after a failed V10) no E-10 row is written",
      not np.any(z["rows_est"] == E.EST_INDEX["E-10"]) and json.loads(str(z["meta_det"]))["e10"] == "DISABLED_TEST")

npass = sum(r[2] for r in results)
print(f"\nMECHANICAL TESTS: {npass}/{len(results)} PASS")
shutil.rmtree(SCRATCH, ignore_errors=True)
print("test output deleted unread")
sys.exit(0 if npass == len(results) else 1)
