"""Development equivalence checks (throwaway namespace FV1_DEVEQ; NOT the formal gates).

Checks, on panels from a seed namespace no study uses, that the FINAL_V1 wrappers reproduce the
frozen functions they wrap. The formal gate G-C repeats this on FINAL_V1_GATE panels.
Only equalities are printed; no estimate, bias, SE level or coverage is printed or summarized.

    python3 -I -B tests/dev_equivalence.py <Final_Study_v1 root>
"""
import os, sys

sys.dont_write_bytecode = True

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fv1.env  # noqa: E402,F401
import numpy as np  # noqa: E402
from stage0_dgp import generate_panel, make_rng  # noqa: E402
from stage0_naive import _period_design  # noqa: E402
import s09_run, e5_core, s2_core  # noqa: E402
from stage1_design_aware import crossfit_predictions  # noqa: E402
from fv1 import registry, estimators as E, diagnostics, theta0 as T0  # noqa: E402

ROOT = sys.argv[1]
configs, _ = registry.load(ROOT)
by = {c.name: c for c in configs}
th_map = T0.lookup(T0.frozen_union(), configs, require_all=False)
NPAN = 10
fails = []


def check(label, ok):
    print(f"  {'PASS' if ok else 'FAIL'}  {label}")
    if not ok:
        fails.append(label)


def same(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((a == b) | (np.isnan(a) & np.isnan(b))))


# baseline-scale configurations: frozen parameterization reproduced exactly
for cname in ("C001", "C004"):
    cfg = by[cname]
    q = s09_run.P.__class__(**{**vars(s09_run.P), **{k: getattr(cfg.p, k) for k in
                                                         ("icc", "rho_e", "kappa", "gamma_W", "tau", "N", "T", "pi")}})
    check(f"{cname}: FINAL_V1 parameters equal the frozen S0.9 parameterization field by field", vars(q) == vars(cfg.p))
    D = _period_design(cfg.p.N, cfg.p.T)
    th0 = th_map[cfg.index]
    ok1 = ok2 = ok3 = ok4 = True
    for r in range(NPAN):
        pan = generate_panel(cfg.p, make_rng("FV1_DEVEQ_PANEL", cfg.seed_cell_id, r))
        key = ("FV1_DEVEQ_FOLDS", cfg.seed_cell_id, r)
        rep = E.Rep(pan, D, key, float(__import__("scipy").stats.t.ppf(0.975, cfg.p.N - 1)))
        res = E.run_battery(E.FULL, rep, th0, __import__("time").perf_counter)
        # (1) E-1..E-9 against the S0.9 driver row
        row = dict(zip(s09_run.COLS, s09_run.one(pan, D, make_rng(*key))))
        pairs = [("E-1", "e1_th", "e1_se"), ("E-2", "e2_th", "e2_se"), ("E-3", "e34_th", "e3_se"), ("E-4", "e34_th", "e4_se"),
                 ("E-5", "e5_th", "e5_se"), ("E-6", "e6_th", "e6_se"), ("E-7", "e7_th", "e7_se"), ("E-8", "e8_th", "e8_se"),
                 ("E-9", "e9_th", "e9_se")]
        ok1 &= all(res[e].est == row[t] and res[e].se == row[s] for e, t, s in pairs)
        ok1 &= res["E-2"].crit * res["E-2"].se == row["e2_hw"] and res["E-9"].crit == row["e9_crit"]
        ok1 &= res["E-7"].extras["e7_cZL"] == row["e7_cZL"] and res["E-9"].extras["e9_nu_eff"] == row["e9_nu"]
        ok1 &= res["E-8"].est == res["E-6"].est or abs(res["E-8"].est - res["E-6"].est) < 1e-12
        # (2) Experiment-5 set and mechanism block against e5_core.fit_all
        f = dict(zip(e5_core.COLS, e5_core.fit_all(pan, D, key, th0)))
        for e, c in (("E-6H", "E6H"), ("E-12a", "E12a"), ("E-12b", "E12b"), ("E-12c", "E12c")):
            ok2 &= res[e].est == f[f"{c}_th"] and res[e].se == f[f"{c}_se"] and res[e].extras[f"s_nt__{e}"] == f[f"{c}_schur"]
        vals, bad = diagnostics.full(rep, res, th0)
        ok3 &= not bad
        for fr in "Luw":
            for s in range(3):
                ok3 &= same(vals[f"D_{fr}_s{s}"], f[f"D_{fr}_s{s}"])
        for rr in ("uniform", "ht", "hajek"):
            for s in range(3):
                ok3 &= same(vals[f"share_{rr}_s{s}"], f[f"share_{rr}_s{s}"])
        for e, c in (("E-4", "E4"), ("E-5", "E5"), ("E-6", "E6"), ("E-6H", "E6H"), ("E-12a", "E12a"), ("E-12b", "E12b"), ("E-12c", "E12c")):
            ok3 &= abs(vals[f"pred__{e}"] - f[f"pred_{c}"]) <= 1e-12 * max(1.0, abs(f[f"pred_{c}"]))
        for e, c in (("E-4", "E4"), ("E-5", "E5"), ("E-6", "E6")):
            ok3 &= abs(vals[f"s_nt__{e}"] - f[f"{c}_schur"]) <= 1e-12 * abs(f[f"{c}_schur"])
        ok3 &= same(diagnostics.basic(rep)["G_S"], f["G_S"]) and same(vals["kish_ht"], f["kish_ht"]) \
            and same(vals["delta_spread"], f["delta_spread"])
        # (3) Stage-2 TDS variants against s2_core.estimate_all(deltas=(0.10,))
        Zf, Zo, _ = crossfit_predictions(pan, make_rng(*key), False)
        s2 = s2_core.estimate_all(pan, D, Zf, Zo, deltas=(0.10,))
        for e, k in (("HT-TDS-I", "HT-TDS-I@0.1"), ("PS-TDS-I", "PS-TDS-I@0.1"), ("HT-TDS-CF", "HT-TDS-CF@0.1")):
            th, se, s_, b = s2[k]
            ok4 &= res[e].est == th and res[e].se == se and res[e].extras[f"s_nt__{e}"] == s_ / (cfg.p.N * cfg.p.T) \
                and res[e].bind == int(b)
        ok4 &= abs(res["E-12a"].est - res["HT-TDS-CF"].est) < 1e-12 or res["HT-TDS-CF"].bind == 1
    check(f"{cname}: E-1..E-9 wrappers equal s09_run.one exactly ({NPAN} panels)", ok1)
    check(f"{cname}: E-6H, E-12a/b/c equal e5_core.fit_all exactly ({NPAN} panels)", ok2)
    check(f"{cname}: mechanism diagnostics equal e5_core.fit_all (D_s, shares exact; predicted displacement, "
          f"Schur information to 1e-12)", ok3)
    check(f"{cname}: TDS wrappers equal s2_core.estimate_all exactly; E-12a = HT-TDS-CF where unbound", ok4)

print("ALL DEVELOPMENT EQUIVALENCE CHECKS PASS" if not fails else f"FAILURES: {fails}")
sys.exit(1 if fails else 0)
