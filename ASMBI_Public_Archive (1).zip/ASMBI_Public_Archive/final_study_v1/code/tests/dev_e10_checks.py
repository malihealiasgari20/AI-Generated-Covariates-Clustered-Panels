"""Development checks of the new E-10 code (throwaway namespace FV1_DEVE10; NOT gate V10).

1. theta_lambda solves the rectified M-estimation equation (relative residual < 1e-12).
2. lambda^ lies in [0, 1]; the unclipped value is recorded.
3. Coding invariance of the target estimate and SE (the Stage-2 tests used by V10.3):
   (a) nuisance recoding W_nuis -> W_nuis R, (c) Y -> Y + 0.75 X + D c, (d) Z -> 2Z gives theta/2, SE/2,
   (f) unit reordering.  Tolerance 1e-10.
4. Structure of the reference implementation (own numpy code; ppi-python is NOT executed here):
   ppi-python 0.2.3 computes the OLS point estimate as an imputed fit plus a rectifier fit, two
   separate least-squares fits. That equals the solution of the PPI++ M-estimation equation (E-10's
   definition) when the labeled and unlabeled covariate Gram matrices coincide, and not otherwise.
Only equalities and differences are printed; no estimate level, bias or coverage.
"""
import os, sys

sys.dont_write_bytecode = True

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fv1.env  # noqa: E402,F401
import numpy as np  # noqa: E402
from dataclasses import replace  # noqa: E402
from stage0_dgp import generate_panel, make_rng, within_demean  # noqa: E402
from stage0_naive import _period_design  # noqa: E402
from fv1 import registry, e10  # noqa: E402

ROOT = sys.argv[1]
configs, _ = registry.load(ROOT)
by = {c.name: c for c in configs}
fails = []


def check(label, ok):
    print(f"  {'PASS' if ok else 'FAIL'}  {label}")
    if not ok:
        fails.append(label)


def contrib(pan, D, R=None):
    """Per-unit contributions with an optional nuisance recoding W -> [z, W_nuis R]."""
    N, T = pan.Y.shape
    yy = within_demean(pan.Y)
    nu = np.column_stack([within_demean(pan.X).reshape(N * T), D])
    if R is not None:
        nu = nu @ R
    W = lambda Z: np.column_stack([within_demean(np.asarray(Z, float)).reshape(N * T), nu]).reshape(N, T, -1)
    WL, WH = W(pan.ZL), W(pan.ZH)
    return (np.einsum("ntj,ntk->njk", WL, WL), np.einsum("ntj,ntk->njk", WH, WH),
            np.einsum("ntk,nt->nk", WL, yy), np.einsum("ntk,nt->nk", WH, yy))


def fit(pan, D, R=None, perm=None):
    if perm is not None:
        pan = replace(pan, **{k: getattr(pan, k)[perm] for k in ("Y", "ZH", "ZL", "X", "labeled", "strata")})
    AL, AH, bL, bH = contrib(pan, D, R)
    lab = pan.labeled.astype(bool); U = ~lab; n = lab.sum()
    return e10.e10_core(AH[lab], bH[lab], AL[lab], bL[lab], AL[U], bL[U], AH[lab].sum(0) / n, coord=0)


ok_res = ok_lam = True
inv = {"a": [], "c": [], "d": [], "f": []}
for cname in ("C001", "C094", "C118", "C148"):
    cfg = by[cname]
    D = _period_design(cfg.p.N, cfg.p.T)
    K = D.shape[1] + 1
    Rn = np.eye(K) + np.triu(np.full((K, K), 0.3), 1)
    cvec = np.linspace(-0.3, 0.4, cfg.p.T)
    for r in range(8):
        pan = generate_panel(cfg.p, make_rng("FV1_DEVE10_PANEL", cfg.seed_cell_id, r))
        if pan.labeled.sum() < 5:
            continue
        base = fit(pan, D)
        if "fail" in base:
            continue
        # (1) residual of the rectified equation at the final lambda
        AL, AH, bL, bH = contrib(pan, D)
        lab = pan.labeled.astype(bool); U = ~lab; n, Nu = lab.sum(), (~lab).sum()
        lam = base["lam"]
        M = AH[lab].sum(0) / n + lam * (AL[U].sum(0) / Nu - AL[lab].sum(0) / n)
        v = bH[lab].sum(0) / n + lam * (bL[U].sum(0) / Nu - bL[lab].sum(0) / n)
        ok_res &= np.linalg.norm(M @ base["theta"] - v) <= 1e-12 * np.linalg.norm(v)
        ok_lam &= 0.0 <= lam <= 1.0
        # (3) invariances
        t0, s0 = base["theta"][0], base["se"][0]
        a = fit(pan, D, R=Rn)
        inv["a"].append(max(abs(a["theta"][0] - t0), abs(a["se"][0] - s0)) / max(abs(t0), 1e-12))
        Ys = pan.Y + 0.75 * pan.X + cvec[None, :]
        c = fit(replace(pan, Y=Ys), D)
        inv["c"].append(max(abs(c["theta"][0] - t0), abs(c["se"][0] - s0)) / max(abs(t0), 1e-12))
        d = fit(replace(pan, ZH=2 * pan.ZH, ZL=2 * pan.ZL.astype(float)), D)
        inv["d"].append(max(abs(2 * d["theta"][0] - t0), abs(2 * d["se"][0] - s0)) / max(abs(t0), 1e-12))
        f = fit(pan, D, perm=make_rng("FV1_DEVE10_PERM", cname, r).permutation(cfg.p.N))
        inv["f"].append(max(abs(f["theta"][0] - t0), abs(f["se"][0] - s0)) / max(abs(t0), 1e-12))
check("E-10: theta_lambda solves the rectified equation (relative residual <= 1e-12)", ok_res)
check("E-10: lambda^ in [0, 1]", ok_lam)
for k, lab_ in (("a", "nuisance recoding"), ("c", "outcome span Y + 0.75X + Dc"), ("d", "target scaling 2Z"),
                ("f", "unit reordering")):
    check(f"E-10 invariance ({k}) {lab_}: max relative deviation {max(inv[k]):.1e} <= 1e-10", max(inv[k]) <= 1e-10)

# (4) structure of ppi-python's OLS point estimate versus the M-estimation solution (own code)
rng = make_rng("FV1_DEVE10_OLS", "structure", 0)


def ols(X, y):
    return np.linalg.lstsq(X, y, rcond=None)[0]


def closed_form(X, Y, Yh, Xu, Yhu, lam):      # ppi_ols_pointestimate's formula: imputed + rectifier
    return ols(Xu, lam * Yhu) + ols(X, Y - lam * Yh)


def m_estimation(X, Y, Yh, Xu, Yhu, lam):     # E-10's definition in the predicted-outcome setting
    A = lambda Z: np.einsum("ij,ik->ijk", Z, Z)
    return e10.theta_lambda(A(X), X * Y[:, None], A(X), X * Yh[:, None], A(Xu), Xu * Yhu[:, None], lam)


n, Nu, d = 200, 800, 3
X = np.column_stack([np.ones(n), rng.normal(size=(n, d - 1))]); Y = X @ np.array([1.0, 0.5, -0.3]) + rng.normal(size=n)
Yh = Y + 0.4 * rng.normal(size=n) + 0.2
Xu = np.column_stack([np.ones(Nu), rng.normal(size=(Nu, d - 1))]); Yhu = Xu @ np.array([1.2, 0.5, -0.3]) + rng.normal(size=Nu)
gap_general = max(np.abs(closed_form(X, Y, Yh, Xu, Yhu, l) - m_estimation(X, Y, Yh, Xu, Yhu, l)).max() for l in (0.3, 1.0))
Xt = np.tile(X, (4, 1))  # unlabeled design = labeled design repeated: equal Gram matrices
Yht = Xt @ np.array([1.1, 0.45, -0.25]) + 0.5 * rng.normal(size=4 * n)
gap_equal = max(np.abs(closed_form(X, Y, Yh, Xt, Yht, l) - m_estimation(X, Y, Yh, Xt, Yht, l)).max() for l in (0.3, 1.0))
print(f"  NOTE  OLS predicted-outcome setting: closed form minus M-estimation solution, max |diff|:"
      f" {gap_general:.1e} with unequal labeled/unlabeled Gram matrices; {gap_equal:.1e} with equal ones")
check("the two forms coincide when the Gram matrices coincide (<= 1e-10)", gap_equal <= 1e-10)
check("the two forms differ when they do not (> 1e-8), so V10.1 as worded cannot pass on such data", gap_general > 1e-8)


# (5) lambda estimated: where ppi-python evaluates lambda for the interval (own re-implementation of the
#     logic of ppi_ols_pointestimate / ppi_ols_ci / _ols_get_stats, read from the 0.2.3 source; not executed)
def stats_pooled(th, X, Y, Yh, Xu, Yhu):      # _ols_get_stats, unit weights: pooled Hessian over n + N
    H = (Xu.T @ Xu + X.T @ X) / (X.shape[0] + Xu.shape[0])
    return (X * (X @ th - Y)[:, None], X * (X @ th - Yh)[:, None], Xu * (Xu @ th - Yhu)[:, None], np.linalg.inv(H))


def ppi_pe(X, Y, Yh, Xu, Yhu, coord):
    th1 = closed_form(X, Y, Yh, Xu, Yhu, 1.0)
    lam = e10.calc_lam_glm(*stats_pooled(th1, X, Y, Yh, Xu, Yhu), coord=coord, clip=True)
    return closed_form(X, Y, Yh, Xu, Yhu, lam), lam


def ppi_ci_lam(X, Y, Yh, Xu, Yhu, coord):     # the lambda ppi_ols_ci(lam=None) uses for its interval
    th_pe, _ = ppi_pe(X, Y, Yh, Xu, Yhu, coord)
    return e10.calc_lam_glm(*stats_pooled(th_pe, X, Y, Yh, Xu, Yhu), coord=coord, clip=True)


A_ = lambda Z: np.einsum("ij,ik->ijk", Z, Z)
pe_ok, interior_gap = True, []
for noise in (0.5, 1.5, 3.0):                 # prediction quality varies, so lambda^ is sometimes interior
    Yh2 = Y + noise * rng.normal(size=n) + 0.2
    Yht2 = Xt @ np.array([1.1, 0.45, -0.25]) + noise * rng.normal(size=4 * n)
    for coord in (0, None):
        out = e10.e10_core(A_(X), X * Y[:, None], A_(X), X * Yh2[:, None], A_(Xt), Xt * Yht2[:, None],
                           (Xt.T @ Xt + X.T @ X) / (X.shape[0] + Xt.shape[0]), coord=coord)
        th_pe, lam_pe = ppi_pe(X, Y, Yh2, Xt, Yht2, coord)
        lam_ci = ppi_ci_lam(X, Y, Yh2, Xt, Yht2, coord)
        pe_ok &= abs(out["lam"] - lam_pe) <= 1e-10 and np.abs(out["theta"] - th_pe).max() <= 1e-10
        if 0.0 < out["lam"] < 1.0:
            interior_gap.append(abs(out["lam"] - lam_ci))
check("equal Gram matrices, lambda estimated (coord 0 and None): E-10's pilot lambda and point estimate equal "
      "ppi_ols_pointestimate's (<= 1e-10)", pe_ok)
print(f"  NOTE  interior lambda^ cases: {len(interior_gap)}; |E-10 lambda - ppi_ols_ci interval lambda| "
      f"min {min(interior_gap):.1e}, max {max(interior_gap):.1e}" if interior_gap else "  NOTE  no interior lambda^ case")
check("ppi_ols_ci(lam=None) re-estimates lambda at the tuned point estimate: whenever lambda^ is interior its "
      "interval lambda differs from E-10's pilot lambda (record 3.4)", bool(interior_gap) and min(interior_gap) > 1e-10)
print("E-10 DEVELOPMENT CHECKS COMPLETE" + ("" if not fails else f" -- FAILURES: {fails}"))
sys.exit(1 if fails else 0)
