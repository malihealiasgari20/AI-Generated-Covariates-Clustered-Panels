"""
Stage 0, step S0.8 -- E-8 (HT rectifier + exact cluster jackknife) and E-9 (CDA).

Both are built from PER-CLUSTER contributions to the rectified Gram matrix and
right-hand side. Unit demeaning and the demeaned period indicators are computed
within each unit, so deleting a cluster leaves every other cluster's transformed
data unchanged and the delete-one problems are exact.

For cluster i with rectifier weight w_i (R_i = labeled indicator):
    A_i = A_L,i + R_i w_i (A_H,i - A_L,i),   b_i = b_L,i + R_i w_i (b_H,i - b_L,i)
    A   = sum_i A_i,                          b   = sum_i b_i

E-8   HT weights w_i = 1/pi_{s_i} (design constants). Point estimate = E-6.
      Delete-one: A_(-i) = A - A_i, b_(-i) = b - b_i. No floor.
      V_JK = (N-1)/N * sum_i d_i^2,  d_i = theta_(-i) - mean(theta_(-i)).
      Normal critical value.

E-9   CDA, four separate components:
      (1) post-stratified weights w_s = N_s / n_s. In each delete-one sample the
          SAME functional is applied with N_s(-i) = N_s - 1(s_i = s) and
          n_s(-i) = n_s - 1(s_i = s, R_i = 1); only stratum s_i's weight changes:
            A_(-i) = A - A_L,i - w_{s_i} dA_{s_i} + w_{s_i}(-i) (dA_{s_i} - R_i dA_i)
          with dA_i = A_H,i - A_L,i and dA_s = sum_{j in s} R_j dA_j.
      (2) spectral floor, applied SEPARATELY to the full Gram matrix and to
          EVERY delete-one Gram matrix, each from its own spectrum, after
          numerical symmetrization:
            A_delta = A + max{0, delta tr(A)/K - lambda_min(A)} I,  delta = 0.10
      (3) exact leave-one-cluster-out jackknife variance, as for E-8;
      (4) Satterthwaite nu_eff = (sum d_i^2)^2 / sum d_i^4, NO floor, two-sided
          t(nu_eff) critical value.

Frozen failure conventions (ledger P19, P20): an empty required post-stratum in
the full sample, or created by a deletion, makes the replication a numerical
failure; sum d_i^4 = 0 is a failure; nu_eff is never floored.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import t as tdist

from stage0_dgp import within_demean
from stage0_naive import _period_design

DELTA = 0.10
Z_CRIT = 1.959963984540054


def contributions(panel, D=None):
    """Per-cluster Gram and RHS contributions for the machine and human designs."""
    N, T = panel.Y.shape
    D = _period_design(N, T) if D is None else D
    yy = within_demean(panel.Y)
    zL = within_demean(panel.ZL.astype(float)).reshape(N * T)
    zH = within_demean(panel.ZH).reshape(N * T)
    x = within_demean(panel.X).reshape(N * T)
    WL = np.column_stack([zL, x, D]).reshape(N, T, -1)
    WH = np.column_stack([zH, x, D]).reshape(N, T, -1)
    AL = np.einsum("ntj,ntk->njk", WL, WL)
    AH = np.einsum("ntj,ntk->njk", WH, WH)
    bL = np.einsum("ntk,nt->nk", WL, yy)
    bH = np.einsum("ntk,nt->nk", WH, yy)
    return AL, AH, bL, bH


def floor_matrix(A):
    """Spectral floor on one matrix or a stack. Returns (A_delta, shift, lmin, binds)."""
    As = 0.5 * (A + np.swapaxes(A, -1, -2))
    K = As.shape[-1]
    ev = np.linalg.eigvalsh(As)
    lmin = ev[..., 0]
    thr = DELTA * np.trace(As, axis1=-2, axis2=-1) / K
    shift = np.maximum(0.0, thr - lmin)
    return As + shift[..., None, None] * np.eye(K), shift, lmin, shift > 0.0


def _schur(A):
    """Target-direction information 1/[A^{-1}]_00 of the UNSTABILIZED matrix."""
    try:
        return 1.0 / np.linalg.inv(0.5 * (A + A.T))[0, 0]
    except np.linalg.LinAlgError:
        return np.nan


def jackknife_fit(panel, weights="ht", floor=False, satterthwaite=False,
                  D=None, order=None):
    """Generic delete-one-cluster estimator.

    weights: "ht" (1/pi_s, design constants) or "ps" (N_s/n_s, recomputed per
    deletion). floor: apply the spectral floor to the full and every delete-one
    Gram matrix. satterthwaite: t(nu_eff) critical value instead of normal.
    order: optional permutation of deletion order (invariant 4).
    Returns a dict, or {"fail": reason} under the frozen failure rule.
    """
    N, T = panel.Y.shape
    AL, AH, bL, bH = contributions(panel, D)
    dA, db = AH - AL, bH - bL
    R = panel.labeled.astype(float)
    s = panel.strata
    nS = np.array([np.sum(s == k) for k in range(3)], dtype=float)          # N_s
    nL = np.array([np.sum((s == k) & panel.labeled) for k in range(3)], dtype=float)  # n_s

    if weights == "ht":
        w = 1.0 / np.asarray(panel.params.pi)[s]
    elif weights == "ps":
        if np.any(nL == 0):
            return {"fail": "empty post-stratum (full sample)", "n_s": nL}
        w = (nS / nL)[s]
    else:
        raise ValueError(weights)

    Ai = AL + (R * w)[:, None, None] * dA
    bi = bL + (R * w)[:, None] * db
    A, b = Ai.sum(axis=0), bi.sum(axis=0)

    out = {"n_s": nL, "lmin_full": float(np.linalg.eigvalsh(0.5 * (A + A.T))[0]) / (N * T),
           "schur_full": _schur(A) / (N * T)}
    if floor:
        Af, sh, _, bind = floor_matrix(A)
        out.update(shift_full=float(sh) / (N * T), bind_full=bool(bind))
    else:
        Af = A
    theta = np.linalg.solve(Af, b)

    # delete-one matrices
    if weights == "ht":
        Am, bm = A[None] - Ai, b[None] - bi
    else:
        dAs = np.stack([(R[s == k][:, None, None] * dA[s == k]).sum(axis=0) for k in range(3)])
        dbs = np.stack([(R[s == k][:, None] * db[s == k]).sum(axis=0) for k in range(3)])
        nS_m = nS[s] - 1.0
        nL_m = nL[s] - R
        if np.any(nL_m == 0):
            return {"fail": "empty post-stratum (jackknife deletion)", "n_s": nL}
        w_old, w_new = (nS / nL)[s], nS_m / nL_m
        Am = (A[None] - AL - w_old[:, None, None] * dAs[s]
              + w_new[:, None, None] * (dAs[s] - R[:, None, None] * dA))
        bm = (b[None] - bL - w_old[:, None] * dbs[s]
              + w_new[:, None] * (dbs[s] - R[:, None] * db))

    idx = np.arange(N) if order is None else np.asarray(order)
    Am, bm = Am[idx], bm[idx]
    if floor:
        Am, shm, _, bindm = floor_matrix(Am)
        out["bind_jk_frac"] = float(bindm.mean())
    th_m = np.linalg.solve(Am, bm[..., None])[:, 0, 0]
    if order is not None:
        back = np.empty(N); back[idx] = th_m; th_m = back

    d = th_m - th_m.mean()
    s2, s4 = np.sum(d ** 2), np.sum(d ** 4)
    if s4 == 0.0:
        return {"fail": "sum d^4 = 0", "n_s": nL}
    se = float(np.sqrt((N - 1) / N * s2))
    nu = float(s2 ** 2 / s4)
    crit = float(tdist.ppf(0.975, nu)) if satterthwaite else Z_CRIT
    out.update(theta=float(theta[0]), se=se, nu_eff=nu, crit=crit,
               max_abs_d=float(np.abs(d).max()), d=d, theta_minus=th_m)
    return out


def e8_fit(panel, D=None, order=None):
    """E-8: HT point estimate (= E-6), exact cluster jackknife SE, normal crit."""
    return jackknife_fit(panel, "ht", floor=False, satterthwaite=False, D=D, order=order)


def e9_fit(panel, D=None, order=None):
    """E-9: CDA -- post-stratified, floored, exact jackknife, Satterthwaite t."""
    return jackknife_fit(panel, "ps", floor=True, satterthwaite=True, D=D, order=order)
