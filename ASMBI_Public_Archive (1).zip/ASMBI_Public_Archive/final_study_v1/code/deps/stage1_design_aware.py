"""
STAGE 1 -- DESIGN-AWARE COMPARATOR ESTIMATORS (Experiment 5, protocol v1.4 Section 6A).

Kept deliberately SEPARATE from the original nine specifications (stage0_*.py),
which are not modified by this module.

NOT TO BE RUN FOR PERFORMANCE until Stage 0 is frozen and the G7-G9 holdout has
been computed once (protocol v1.4, Section 6A.0). The only permitted use before
then is the algebraic invariant tests in stage1_invariant_tests.py, which check
code paths and report no performance quantity.

All estimators below are instances of ONE generalized rectified estimating
equation for cluster i in validation stratum s_i, selected with known
probability pi_i = pi_{s_i} under Poisson sampling (R_i ~ Bernoulli(pi_i)):

    sum_i m_i(theta; f) + sum_i w_i R_i [ m_i(theta; Z_H) - m_i(theta; f_{-i}) ] = 0

    m_i(theta; Z) = sum_t W_it(Z) (Ytilde_it - W_it(Z)' theta),   W = [Ztilde, Xtilde, D]

f is the prediction rule used in the first moment (applied to every unit) and
f_{-i} the rule used in unit i's rectifier term. Specifications differ in
(a) the prediction rule and (b) the rectifier weight w_i:

    rectifier "uniform":  w_i = 1 / pibar,          pibar = G_S / N
    rectifier "ht":       w_i = 1 / pi_i                         (Horvitz-Thompson)
    rectifier "hajek":    w_i = (1/pi_i) * N / sum_j (R_j / pi_j)  (Hajek)

New specifications defined here:
    E-6H   identity predictor (f = Z_L), Hajek rectifier. This is the HAJEK
           POINT-ESTIMATOR VARIANT of the IPW-PPI rectifier with a stated
           clustered-sandwich variance convention (normalizer treated as fixed).
           It is NOT a faithful implementation of Datta & Polson's Hajek
           procedure, whose variance uses linearization / the delta method,
           until checked against the authors' reference implementation
           (protocol v1.4, Section 6A.2).
    E-12a  cross-fitted calibration, UNWEIGHTED calibration fit, HT rectifier
    E-12b  cross-fitted calibration, DESIGN-WEIGHTED calibration fit, HT rectifier
           = design-aware cross-fitted rectifier
    E-12c  cross-fitted calibration, DESIGN-WEIGHTED calibration fit, UNIFORM
           rectifier  (negative control: weights the fit, not the rectifier)
With E-5 (unweighted fit, uniform rectifier) these form a 2 x 2 in
{calibration weighted?} x {rectifier design-unbiased?}.

NOTE: the HT rectifier with the identity predictor is exactly the manuscript's
E-6 ("DSL" in its tables) -- i.e. the HT form of IPW-PPI is ALREADY in the
original grid. That identity is invariant T2 in the test file.

E-13, the Predict-Then-Debias bootstrap of Kluger, Lu, Zrnic, Wang & Bates
(arXiv:2501.18577 -- a recent PREPRINT with an official reference
implementation, not a journal-published method), is NOT implemented here; see
the stub at the end of this file.
"""

from __future__ import annotations

import numpy as np

from stage0_dgp import within_demean
from stage0_naive import _period_design

N_FOLDS = 5


def _calibration_matrix(panel) -> np.ndarray:
    """[1, Z_L, X, unit mean of Z_L] in levels -- identical to E-5 (frozen P18)."""
    N, T = panel.Y.shape
    zl = panel.ZL.astype(float)
    zlbar = zl.mean(axis=1, keepdims=True) * np.ones((1, T))
    return np.column_stack([np.ones(N * T), zl.reshape(N * T),
                            panel.X.reshape(N * T), zlbar.reshape(N * T)])


def _rows(units: np.ndarray, T: int) -> np.ndarray:
    return np.repeat(units, T) * T + np.tile(np.arange(T), units.size)


def crossfit_predictions(panel, fold_rng, calibration_weighted: bool):
    """Out-of-fold and fold-averaged calibration predictions.

    Fold construction is IDENTICAL to E-5 (same permutation call on the same
    RNG stream), so that E-5 and E-12a/b/c are paired on identical folds.
    When calibration_weighted is True the fit is weighted least squares with
    unit-level weights 1/pi_i, so the fitted rule targets the POPULATION
    calibration rather than the selected-cluster mixture.
    """
    N, T = panel.Y.shape
    C = _calibration_matrix(panel)
    zh = panel.ZH.reshape(N * T)
    lab_idx = np.flatnonzero(panel.labeled)
    pi_i = np.asarray(panel.params.pi)[panel.strata]

    folds = np.array_split(fold_rng.permutation(lab_idx), N_FOLDS)
    coefs = np.zeros((N_FOLDS, C.shape[1]))
    Zhat_oof = np.zeros((N, T))
    for f, held in enumerate(folds):
        train = np.setdiff1d(lab_idx, held, assume_unique=False)
        rows = _rows(train, T)
        if calibration_weighted:
            sw = np.sqrt(np.repeat(1.0 / pi_i[train], T))
            coef, *_ = np.linalg.lstsq(C[rows] * sw[:, None], zh[rows] * sw,
                                       rcond=None)
        else:
            coef, *_ = np.linalg.lstsq(C[rows], zh[rows], rcond=None)
        coefs[f] = coef
        if held.size:
            Zhat_oof[held] = (C[_rows(held, T)] @ coef).reshape(held.size, T)
    Zhat_full = (C @ coefs.mean(axis=0)).reshape(N, T)
    return Zhat_full, Zhat_oof, coefs


def rectifier_weights(panel, rectifier: str) -> np.ndarray:
    """Unit-level rectifier weight w_i R_i."""
    N = panel.Y.shape[0]
    R = panel.labeled.astype(float)
    if rectifier == "uniform":
        return R / (R.sum() / N)
    pi_i = np.asarray(panel.params.pi)[panel.strata]
    ht = R / pi_i
    if rectifier == "ht":
        return ht
    if rectifier == "hajek":
        return ht * N / ht.sum()
    raise ValueError(rectifier)


def generalized_rectifier_fit(panel, rectifier: str, predictor: str = "identity",
                              fold_rng=None, calibration_weighted: bool = False,
                              period_design=None):
    """Solve the generalized rectified estimating equation.

    predictor: "identity" (f = f_{-i} = Z_L) or "crossfit" (frozen P18 rule).
    Returns (theta_target, se_CR1) or None if too few labeled units.
    Covariance: unit-clustered sandwich with the N/(N-1) factor only, matching
    the manuscript's CR1 for the rectified procedures. For the Hajek rectifier
    the normalizer is treated as fixed at its realized value (a stated
    convention; the exact cluster jackknife is the sensitivity variant).
    """
    N, T = panel.Y.shape
    if panel.labeled.sum() < 2 * N_FOLDS:
        return None
    if predictor == "identity":
        Zf = Zo = panel.ZL.astype(float)
    elif predictor == "crossfit":
        Zf, Zo, _ = crossfit_predictions(panel, fold_rng, calibration_weighted)
    else:
        raise ValueError(predictor)

    y = within_demean(panel.Y).reshape(N * T)
    x = within_demean(panel.X).reshape(N * T)
    D = _period_design(N, T) if period_design is None else period_design
    Wf = np.column_stack([within_demean(Zf).reshape(N * T), x, D])
    Wo = np.column_stack([within_demean(Zo).reshape(N * T), x, D])
    WH = np.column_stack([within_demean(panel.ZH).reshape(N * T), x, D])
    k = Wf.shape[1]
    rw = np.repeat(rectifier_weights(panel, rectifier), T)

    A = Wf.T @ Wf + (WH * rw[:, None]).T @ WH - (Wo * rw[:, None]).T @ Wo
    b = Wf.T @ y + (WH * rw[:, None]).T @ y - (Wo * rw[:, None]).T @ y
    A_inv = np.linalg.inv(A)
    theta = A_inv @ b

    rf, rH, ro = y - Wf @ theta, y - WH @ theta, y - Wo @ theta
    g = Wf * rf[:, None] + rw[:, None] * (WH * rH[:, None] - Wo * ro[:, None])
    gc = g.reshape(N, T, k).sum(axis=1)
    V = A_inv @ (gc.T @ gc) @ A_inv * (N / (N - 1.0))
    return float(theta[0]), float(np.sqrt(V[0, 0]))


# Named specifications ---------------------------------------------------------

def e6h_fit(panel, D=None):
    """E-6H: Hajek point-estimator variant, clustered-sandwich convention.

    Not yet a faithful implementation of the published Hajek procedure: the
    sandwich treats the random normalizer as fixed. See protocol v1.4, 6A.2.
    """
    return generalized_rectifier_fit(panel, "hajek", "identity", period_design=D)


def e12a_fit(panel, fold_rng, D=None):
    """E-12a: cross-fitted, unweighted calibration fit, HT rectifier."""
    return generalized_rectifier_fit(panel, "ht", "crossfit", fold_rng, False, D)


def e12b_fit(panel, fold_rng, D=None):
    """E-12b: design-aware cross-fitted rectifier (weighted fit, HT rectifier)."""
    return generalized_rectifier_fit(panel, "ht", "crossfit", fold_rng, True, D)


def e12c_fit(panel, fold_rng, D=None):
    """E-12c: negative control (weighted fit, UNIFORM rectifier)."""
    return generalized_rectifier_fit(panel, "uniform", "crossfit", fold_rng, True, D)


def e13_ptd_bootstrap(*args, **kwargs):
    """E-13: Predict-Then-Debias bootstrap (Kluger, Lu, Zrnic, Wang & Bates,
    arXiv:2501.18577, preprint).

    DELIBERATELY NOT IMPLEMENTED. The protocol requires a FAITHFUL port of the
    authors' published algorithm for clustered / stratified nonuniform
    sampling, including their tuning-matrix subroutine, validated to reproduce
    the reference implementation (R package PTDBoot, github.com/DanKluger/
    PTDBoot) on a shared test dataset before any simulation use. An ad hoc
    variant written from a summary would not satisfy that requirement. If the
    validation cannot be completed, E-13 is reported as absent.
    """
    raise NotImplementedError("E-13 requires a validated port of PTDBoot; "
                              "see protocol v1.4, Section 6A.2.")
