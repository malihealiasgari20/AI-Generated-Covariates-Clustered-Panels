"""
Stage 0, step S0.7 -- REGRESSION CALIBRATION (E-7).

As the manuscript specifies: a DESIGN-WEIGHTED (1/pi_s) linear calibration of
Z_H on Z_L, X and the unit mean of Z_L is fitted on labeled units; the fitted
construct is imputed for every unit-period; the within-panel regression is run
on the imputed construct; a JOINT estimating-equation sandwich propagates the
first-stage uncertainty and clusters by unit (N/(N-1) factor, as for the other
rectified procedures); normal critical value. Calibration matrix conventions
follow the frozen P18 reading (intercept; no period dummies).

STRUCTURAL IDENTITY (exact, not approximate). After unit demeaning, the
intercept and the unit-mean-of-Z_L columns of the calibration matrix vanish, so
the demeaned imputed covariate is c_ZL * Ztilde_L + c_X * Xtilde. Because Xtilde
is already a regressor, the second stage spans the same column space as the
naive regression, and therefore
        theta_RC = theta_naive / c_ZL       exactly.
Only the standard error differs, through first-stage propagation. This is why
the manuscript reports near-identical naive and RC rejection rates.

RC is NOT a calibration target (G1-G6 do not include it). S0.7 implements it,
verifies the identity, and compares with Table 4's RC row as a consistency check
only. Nothing is tuned.
"""
import numpy as np
from stage0_dgp import within_demean
from stage0_naive import _period_design


def _cal_matrix(panel):
    N, T = panel.Y.shape
    zl = panel.ZL.astype(float)
    return np.column_stack([np.ones(N*T), zl.reshape(N*T), panel.X.reshape(N*T),
                            (zl.mean(axis=1, keepdims=True)*np.ones((1, T))).reshape(N*T)])


def rc_fit(panel, D=None):
    """Return (theta_RC, se_joint, c_ZL)."""
    N, T = panel.Y.shape
    D = _period_design(N, T) if D is None else D
    C = _cal_matrix(panel); kc = C.shape[1]
    zh = panel.ZH.reshape(N*T)
    w_unit = panel.labeled / np.asarray(panel.params.pi)[panel.strata]   # R_i / pi_i
    wr = np.repeat(w_unit, T)

    # first stage: design-weighted LS on labeled units
    J11 = -(C * wr[:, None]).T @ C
    c = np.linalg.solve(-J11, (C * wr[:, None]).T @ zh)

    # second stage on the imputed construct
    C3 = C.reshape(N, T, kc)
    Ct = (C3 - C3.mean(axis=1, keepdims=True)).reshape(N*T, kc)   # demean over TIME
    zt = Ct @ c
    y = within_demean(panel.Y).reshape(N*T); x = within_demean(panel.X).reshape(N*T)
    W = np.column_stack([zt, x, D]); k = W.shape[1]
    J22 = -W.T @ W
    theta = np.linalg.solve(-J22, W.T @ y)
    r = y - W @ theta

    # joint sandwich
    e1 = np.zeros(k); e1[0] = 1.0
    J21 = np.outer(e1, (r[:, None] * Ct).sum(axis=0)) - theta[0] * (W.T @ Ct)
    J = np.block([[J11, np.zeros((kc, k))], [J21, J22]])
    r1 = zh - C @ c
    m1 = (C * (wr * r1)[:, None]).reshape(N, T, kc).sum(axis=1)
    m2 = (W * r[:, None]).reshape(N, T, k).sum(axis=1)
    psi = np.hstack([m1, m2])
    Ji = np.linalg.inv(J)
    V = Ji @ (psi.T @ psi) @ Ji.T * (N / (N - 1.0))
    return float(theta[0]), float(np.sqrt(V[kc, kc])), float(c[1])
