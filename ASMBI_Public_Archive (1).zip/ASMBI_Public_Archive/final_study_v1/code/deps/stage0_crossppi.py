"""
Stage 0, step S0.5 -- UNWEIGHTED CROSS-FITTED CALIBRATION RECTIFIER (E-5) AND
CALIBRATION OF THE lambda1(s) SPREAD AGAINST G4.

P18 reconstruction convention, frozen in the ledger BEFORE any G4 result was
inspected:
  - five folds of labeled UNITS (clusters), not rows;
  - fold assignment from a SEPARATE deterministic RNG stream;
  - calibration of Z_H on an intercept, Z_L, X and the unit mean of Z_L, in
    levels, fitted on out-of-fold labeled units;
  - no period dummies in the calibration;
  - each labeled unit enters the rectifier via its genuinely out-of-fold
    prediction;
  - the five fitted coefficient vectors are averaged and applied to the FULL
    panel for the first moment;
  - neither the fit nor the rectifier uses inclusion probabilities; the
    rectifier weight is the uniform 1/pibar;
  - CR1 clustered by unit, normal critical value.

G4 targets:      bias 0.0338, median coverage 0.892
Consistency:     emp SE 0.0509, mean SE 0.0506, RMSE 0.0612, width 0.195,
                 Type I 0.108

lambda1(s) is searched as a SYMMETRIC spread (0.90-d, 0.90, 0.90+d) so that the
feature G4 identifies is isolated from overall machine quality. G1 is invariant
to lambda1 (E-2 never uses Z_L); G2 and G3 must be re-checked at any accepted
candidate.
"""

from __future__ import annotations

import csv
import os
import time
from dataclasses import replace

import numpy as np

from stage0_dgp import DGPParams, generate_panel, make_rng, within_demean
from stage0_naive import PRIMARY_CELLS, _period_design
from stage0_theta0 import theta0_for

Z_CRIT = 1.959963984540054
N_FOLDS = 5

G4_TARGETS = {"bias": 0.0338, "coverage": 0.892}
G4_CHECKS = {"emp_se": 0.0509, "model_se": 0.0506, "rmse": 0.0612,
             "width": 0.195, "type1": 0.108}


def _calibration_matrix(panel) -> np.ndarray:
    """[1, Z_L, X, unit mean of Z_L] in LEVELS, one row per unit-period."""
    N, T = panel.Y.shape
    zl = panel.ZL.astype(float)
    zlbar = zl.mean(axis=1, keepdims=True) * np.ones((1, T))
    return np.column_stack([np.ones(N * T), zl.reshape(N * T),
                            panel.X.reshape(N * T), zlbar.reshape(N * T)])


def crossfit_predictions(panel, fold_rng):
    """Return (Zhat_full, Zhat_oof, fold_coefs).

    Zhat_full  (N, T) fold-averaged calibration applied to the whole panel
    Zhat_oof   (N, T) out-of-fold prediction, meaningful for labeled units only
    fold_coefs (N_FOLDS, 4) per-fold calibration coefficients
    """
    N, T = panel.Y.shape
    C = _calibration_matrix(panel)
    zh = panel.ZH.reshape(N * T)
    lab_idx = np.flatnonzero(panel.labeled)

    folds = np.array_split(fold_rng.permutation(lab_idx), N_FOLDS)
    coefs = np.zeros((N_FOLDS, C.shape[1]))
    Zhat_oof = np.zeros((N, T))

    for f, held in enumerate(folds):
        train = np.setdiff1d(lab_idx, held, assume_unique=False)
        rows = (np.repeat(train, T) * T + np.tile(np.arange(T), train.size))
        coef, *_ = np.linalg.lstsq(C[rows], zh[rows], rcond=None)
        coefs[f] = coef
        if held.size:
            hrows = (np.repeat(held, T) * T + np.tile(np.arange(T), held.size))
            Zhat_oof[held] = (C[hrows] @ coef).reshape(held.size, T)

    Zhat_full = (C @ coefs.mean(axis=0)).reshape(N, T)
    return Zhat_full, Zhat_oof, coefs


def crossppi_fit(panel, fold_rng, period_design=None, theta0=None):
    """Unweighted cross-fitted calibration rectifier.

    Returns (theta, se, diagnostics) or None.
    """
    N, T = panel.Y.shape
    R = panel.labeled.astype(float)
    G_S = R.sum()
    if G_S < N_FOLDS * 2:
        return None
    pibar = G_S / N

    Zf, Zo, coefs = crossfit_predictions(panel, fold_rng)

    y = within_demean(panel.Y).reshape(N * T)
    x = within_demean(panel.X).reshape(N * T)
    D = _period_design(N, T) if period_design is None else period_design
    Wf = np.column_stack([within_demean(Zf).reshape(N * T), x, D])
    Wo = np.column_stack([within_demean(Zo).reshape(N * T), x, D])
    WH = np.column_stack([within_demean(panel.ZH).reshape(N * T), x, D])
    k = Wf.shape[1]

    rw = np.repeat(R, T) / pibar        # uniform rectifier weight, unweighted

    A = Wf.T @ Wf + (WH * rw[:, None]).T @ WH - (Wo * rw[:, None]).T @ Wo
    b = Wf.T @ y + (WH * rw[:, None]).T @ y - (Wo * rw[:, None]).T @ y
    A_inv = np.linalg.inv(A)
    theta = A_inv @ b

    rf = y - Wf @ theta
    rH = y - WH @ theta
    ro = y - Wo @ theta
    g = Wf * rf[:, None] + rw[:, None] * (WH * rH[:, None] - Wo * ro[:, None])
    gc = g.reshape(N, T, k).sum(axis=1)
    V = A_inv @ (gc.T @ gc) @ A_inv * (N / (N - 1.0))

    diag = {"cal_beta_ZL": coefs[:, 1].copy()}
    if theta0 is not None:
        # ------------------------------------------------------------------
        # WARNING -- SUPERSEDED DIAGNOSTIC (ledger finding F10a).
        # This evaluates the moment difference at theta = (theta_0, 0, ..., 0),
        # i.e. with the control coefficient and every period-effect coefficient
        # set to ZERO. Proposition 1 defines D_s(theta) from the FULL estimating
        # equation, whose parameter vector includes the demeaned control and the
        # period indicators. The numbers produced here are therefore suggestive
        # only and must NOT be quoted as evaluations of the theoretical D_s.
        # The corrected procedure, to be implemented at S0.9, uses the complete
        # full-information vector theta_0_full = (gamma_W, beta, delta_2..delta_T)
        # from the 120,000-unit auxiliary panel, and maps the score displacement
        # through the Jacobian: delta_theta approx -A^{-1} sum_s (q_s-p_s) D_s.
        # No G-target depends on this diagnostic: lambda1 was fitted against G4's
        # bias and coverage alone.
        # ------------------------------------------------------------------
        # stratum-specific rectifier moments, target coefficient only
        th0 = np.zeros(k); th0[0] = theta0
        rH0 = y - WH @ th0
        ro0 = y - Wo @ th0
        d_it = (WH[:, 0] * rH0 - Wo[:, 0] * ro0).reshape(N, T).sum(axis=1)
        diag["D_s"] = np.array([
            d_it[panel.labeled & (panel.strata == s)].mean()
            if np.any(panel.labeled & (panel.strata == s)) else np.nan
            for s in range(3)])
    return float(theta[0]), float(np.sqrt(V[0, 0])), diag


def run_cell(p: DGPParams, cell: dict, reps: int, theta0: float, tag: str,
             collect_diag: bool = False):
    q = replace(p, **cell)
    D = _period_design(q.N, q.T)
    cell_id = f"icc={cell['icc']}|rho={cell['rho_e']}|kappa={cell['kappa']}"
    est, se, fail = [], [], 0
    cal, Ds = [], []
    for r in range(reps):
        pan = generate_panel(q, make_rng("S0_5_XPPI", f"{tag}|{cell_id}", r))
        frng = make_rng("S0_5_FOLDS", f"{tag}|{cell_id}", r)   # separate stream
        out = crossppi_fit(pan, frng, D,
                           theta0 if (collect_diag and r < 200) else None)
        if out is None:
            fail += 1
            continue
        est.append(out[0]); se.append(out[1])
        if collect_diag and r < 200:
            cal.append(out[2]["cal_beta_ZL"]); Ds.append(out[2]["D_s"])
    est = np.asarray(est); se = np.asarray(se)
    res = {
        "bias": float(est.mean() - theta0),
        "emp_se": float(est.std(ddof=1)),
        "model_se": float(se.mean()),
        "rmse": float(np.sqrt(np.mean((est - theta0) ** 2))),
        "coverage": float(np.mean(np.abs(est - theta0) <= Z_CRIT * se)),
        "width": float(np.median(2 * Z_CRIT * se)),
        "failures": fail,
    }
    if collect_diag and cal:
        res["cal_beta_ZL"] = float(np.mean(cal))
        res["cal_beta_ZL_foldsd"] = float(np.mean([np.std(c) for c in cal]))
        res["D_s"] = np.nanmean(np.array(Ds), axis=0)
    return res


def evaluate(p: DGPParams, reps: int, tag: str, collect_diag: bool = False):
    rows = [run_cell(p, c, reps, theta0_for(p, c), tag, collect_diag)
            for c in PRIMARY_CELLS]
    agg = {k: float(np.mean([r[k] for r in rows]))
           for k in ("bias", "emp_se", "model_se", "rmse", "width")}
    agg["coverage"] = float(np.median([r["coverage"] for r in rows]))
    agg["cov_min"] = float(min(r["coverage"] for r in rows))
    agg["cov_max"] = float(max(r["coverage"] for r in rows))
    agg["failures"] = int(sum(r["failures"] for r in rows))
    if collect_diag and "D_s" in rows[0]:
        agg["cal_beta_ZL"] = float(np.mean([r["cal_beta_ZL"] for r in rows]))
        agg["cal_beta_ZL_foldsd"] = float(np.mean(
            [r["cal_beta_ZL_foldsd"] for r in rows]))
        agg["D_s"] = np.nanmean(np.array([r["D_s"] for r in rows]), axis=0)
    agg["cells"] = rows
    return agg


def loss(res: dict) -> float:
    return (((res["bias"] - G4_TARGETS["bias"]) / 0.0051) ** 2
            + ((res["coverage"] - G4_TARGETS["coverage"]) / 0.010) ** 2)


LOGFILE = "stage0_s05_candidates.csv"
_FIELDS = ["stage", "reps", "lambda1", "d", "bias", "emp_se", "model_se",
           "rmse", "coverage", "width", "cal_beta_ZL", "D_s0", "D_s1", "D_s2",
           "failures", "loss", "seconds"]


def assess(stage: str, p: DGPParams, reps: int, tag: str, d: float,
           collect_diag: bool = True) -> dict:
    t0 = time.time()
    res = evaluate(p, reps, tag, collect_diag)
    secs = time.time() - t0
    new = not os.path.exists(LOGFILE)
    Ds = res.get("D_s", [float("nan")] * 3)
    with open(LOGFILE, "a", newline="") as fh:
        w = csv.DictWriter(fh, _FIELDS)
        if new:
            w.writeheader()
        w.writerow({"stage": stage, "reps": reps,
                    "lambda1": "/".join(f"{v:.2f}" for v in p.lambda1), "d": d,
                    **{k: round(res[k], 6) for k in
                       ("bias", "emp_se", "model_se", "rmse", "coverage",
                        "width")},
                    "cal_beta_ZL": round(res.get("cal_beta_ZL", float("nan")), 5),
                    "D_s0": round(float(Ds[0]), 4), "D_s1": round(float(Ds[1]), 4),
                    "D_s2": round(float(Ds[2]), 4),
                    "failures": res["failures"], "loss": round(loss(res), 2),
                    "seconds": round(secs, 1)})
    return res
