"""S0.9 -- unified reconstruction validation. ONE panel per (cell, rep) -> E1..E9.
Seed hierarchy: panel  make_rng("S0_9", cell_id, r);  E-5 folds make_rng("S0_9_FOLDS", cell_id, r).
Final parameterization; no parameter changed. No Experiment-5 estimator is imported."""
import os, sys, time, itertools
from dataclasses import replace
import numpy as np
from stage0_dgp import DGPParams, generate_panel, make_rng
from stage0_naive import naive_fit, _period_design
from stage0_labeled_only import labeled_only_fit
from stage0_ppi import ppi_fit
from stage0_crossppi import crossppi_fit
from stage0_ht import ht_fit
from stage0_rc import rc_fit
from stage0_cda import e8_fit, e9_fit, contributions
from stage0_theta0 import theta0_for

P = replace(DGPParams(), sd_ZH_within=0.62, cut_spacing=0.65, sd_e=0.55, lambda1=(1.20, 1.05, 0.45))
CELLS = [{"icc": i, "rho_e": r, "kappa": k, "gamma_W": g}
         for g, i, r, k in itertools.product((0.15, 0.0), (0.10, 0.30, 0.50), (0.0, 0.60), (0.0, 0.60))]
OUT = "s09_raw"; NAN = np.nan
COLS = ["e1_th","e1_se","e2_th","e2_se","e2_hw","e34_th","e3_se","e4_se","e34_th_contrib",
        "e5_th","e5_se","e6_th","e6_se","e7_th","e7_se","e7_cZL","e8_th","e8_se",
        "e9_th","e9_se","e9_crit","e9_nu","e9_bind","e9_shift","e9_fail","ps_nofloor_th","n_s0","n_s1","n_s2"]

def cid(c): return f"g={c['gamma_W']}|icc={c['icc']}|rho={c['rho_e']}|kappa={c['kappa']}"

def point_from_contrib(pan, D, weights):
    """Rectified point estimate rebuilt from per-cluster contributions (independent code path)."""
    AL, AH, bL, bH = contributions(pan, D); R = pan.labeled.astype(float); s = pan.strata
    if weights == "uniform": w = np.full(R.size, R.size / R.sum())
    else:
        nS = np.array([np.sum(s == k) for k in range(3)]); nL = np.array([np.sum((s == k) & pan.labeled) for k in range(3)])
        if np.any(nL == 0): return NAN
        w = (nS / nL)[s]
    A = (AL + (R * w)[:, None, None] * (AH - AL)).sum(0); b = (bL + (R * w)[:, None] * (bH - bL)).sum(0)
    return float(np.linalg.solve(0.5 * (A + A.T), b)[0])

def one(pan, D, frng):
    e1 = naive_fit(pan, D); e2 = labeled_only_fit(pan, D); e34 = ppi_fit(pan, D)
    e5 = crossppi_fit(pan, frng, D); e6 = ht_fit(pan, D); e7 = rc_fit(pan, D)
    e8 = e8_fit(pan, D); e9 = e9_fit(pan, D)
    f9 = "fail" in e9
    return [e1[0], e1[1], e2[0], e2[1], e2[2], e34[0], e34[1], e34[2], point_from_contrib(pan, D, "uniform"),
            e5[0], e5[1], e6[0], e6[1], e7[0], e7[1], e7[2], e8["theta"], e8["se"],
            NAN if f9 else e9["theta"], NAN if f9 else e9["se"], NAN if f9 else e9["crit"],
            NAN if f9 else e9["nu_eff"], NAN if f9 else float(e9["bind_full"]),
            NAN if f9 else e9["shift_full"], float(f9), point_from_contrib(pan, D, "ps"), *list(e9["n_s"])]

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True); t0 = time.time()
    for c in CELLS:
        f = f"{OUT}/{cid(c).replace('|','_').replace('=','')}.npz"
        if os.path.exists(f): continue
        if time.time() - t0 > 245: print("budget; resume", flush=True); sys.exit(0)
        q = replace(P, **c); D = _period_design(q.N, q.T)
        R = [one(generate_panel(q, make_rng("S0_9", cid(c), r)), D, make_rng("S0_9_FOLDS", cid(c), r)) for r in range(5000)]
        np.savez_compressed(f, R=np.array(R), th0=theta0_for(P, c), cols=np.array(COLS))
        print("done", cid(c), round(time.time() - t0), "s", flush=True)
    print("cells complete:", len([x for x in os.listdir(OUT) if x.endswith(".npz")]), "of 24", flush=True)
