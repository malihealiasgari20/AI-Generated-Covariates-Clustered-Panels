"""
Stage 0, step S0.3 -- DESIGN-WEIGHTED LABELED-ONLY IPW ESTIMATOR (E-2) AND
CALIBRATION AGAINST G1.

E-2, exactly as the manuscript specifies it:
    labeled units only; the HUMAN construct Z_H in place of Z_L; inverse-
    probability weights 1/pi_s; cluster-robust covariance over LABELED units;
    t(G_S - 1) critical value, with G_S the number of labeled units.

E-2 never touches Z_L. G1 therefore identifies the human-signal / outcome-noise
side of the DGP -- principally P1 (the Z_H variance components) and P11
(sigma_eps) -- and must NOT be used to tune P9 (sd_e) or P10 (cut_spacing).

Targets (published Table 4, labeled-only IPW row, 12 non-null primary cells):
    bias        0.0028   (G1, primary)
    RMSE        0.0656   (G1, primary)
    empirical SE 0.0655  (consistency check)
    mean SE      0.0636  (consistency check)
    coverage     0.941   (consistency check, NOT fitted)
    median width 0.245   (consistency check)
"""

from __future__ import annotations

import csv
import time
from dataclasses import replace

import numpy as np
from scipy.stats import t as tdist

from stage0_dgp import DGPParams, generate_panel, make_rng, within_demean
from stage0_naive import PRIMARY_CELLS, _period_design
from stage0_theta0 import theta0_for

G1_TARGETS = {"bias": 0.0028, "rmse": 0.0656, "emp_se": 0.0655,
              "model_se": 0.0636, "coverage": 0.941, "width": 0.245}


def labeled_only_fit(panel, period_design=None):
    """Return (theta_hat, se, half_width, G_S) or None if degenerate."""
    N, T = panel.Y.shape
    lab = panel.labeled
    G_S = int(lab.sum())
    if G_S < 5:
        return None

    w_unit = 1.0 / np.asarray(panel.params.pi)[panel.strata[lab]]

    y = within_demean(panel.Y[lab]).reshape(G_S * T)
    z = within_demean(panel.ZH[lab]).reshape(G_S * T)   # HUMAN construct
    x = within_demean(panel.X[lab]).reshape(G_S * T)
    D = (_period_design(G_S, T) if period_design is None
         else period_design[:G_S * T])
    W = np.column_stack([z, x, D])
    k = W.shape[1]

    wt = np.repeat(w_unit, T)
    A = W.T @ (W * wt[:, None])
    A_inv = np.linalg.inv(A)
    theta = A_inv @ (W.T @ (y * wt))
    resid = y - W @ theta

    # CR1 over labeled units: G_S/(G_S - 1) factor, weighted scores
    Wc = (W * wt[:, None]).reshape(G_S, T, k)
    rc = resid.reshape(G_S, T)
    scores = np.einsum("gtk,gt->gk", Wc, rc)
    meat = scores.T @ scores
    V = A_inv @ meat @ A_inv * (G_S / (G_S - 1.0))
    se = float(np.sqrt(V[0, 0]))
    crit = tdist.ppf(0.975, G_S - 1)            # t(G_S - 1)
    return float(theta[0]), se, crit * se, G_S


def run_cell(p: DGPParams, cell: dict, reps: int, theta0: float, tag: str):
    q = replace(p, **cell)
    cell_id = f"icc={cell['icc']}|rho={cell['rho_e']}|kappa={cell['kappa']}"
    est, se, hw, fail = [], [], [], 0
    for r in range(reps):
        pan = generate_panel(q, make_rng("S0_3_LABELED", f"{tag}|{cell_id}", r))
        out = labeled_only_fit(pan)
        if out is None:
            fail += 1
            continue
        est.append(out[0]); se.append(out[1]); hw.append(out[2])
    est = np.asarray(est); se = np.asarray(se); hw = np.asarray(hw)
    return {
        "bias": float(est.mean() - theta0),
        "emp_se": float(est.std(ddof=1)),
        "model_se": float(se.mean()),
        "rmse": float(np.sqrt(np.mean((est - theta0) ** 2))),
        "coverage": float(np.mean(np.abs(est - theta0) <= hw)),
        "width": float(np.median(2 * hw)),
        "failures": fail,
    }


def evaluate(p: DGPParams, reps: int, tag: str) -> dict:
    rows = [run_cell(p, c, reps, theta0_for(p, c), tag) for c in PRIMARY_CELLS]
    agg = {k: float(np.mean([r[k] for r in rows]))
           for k in ("bias", "emp_se", "model_se", "rmse", "width")}
    agg["coverage"] = float(np.median([r["coverage"] for r in rows]))
    agg["failures"] = int(sum(r["failures"] for r in rows))
    agg["cells"] = rows
    return agg


def loss(res: dict) -> float:
    """Search criterion: G1's two primary quantities only."""
    return (((res["bias"] - G1_TARGETS["bias"]) / 0.0060) ** 2
            + ((res["rmse"] - G1_TARGETS["rmse"]) / 0.0098) ** 2)


LOGFILE = "stage0_s03_candidates.csv"
_FIELDS = ["stage", "reps", "sd_ZH_within", "sd_ZH_between", "sigma_eps",
           "cut_spacing", "sd_e", "bias", "emp_se", "model_se", "rmse",
           "coverage", "width", "failures", "loss", "seconds"]


def assess(stage: str, p: DGPParams, reps: int, tag: str) -> dict:
    t0 = time.time()
    res = evaluate(p, reps, tag)
    secs = time.time() - t0
    new = not __import__("os").path.exists(LOGFILE)
    with open(LOGFILE, "a", newline="") as fh:
        w = csv.DictWriter(fh, _FIELDS)
        if new:
            w.writeheader()
        w.writerow({"stage": stage, "reps": reps,
                    "sd_ZH_within": p.sd_ZH_within,
                    "sd_ZH_between": p.sd_ZH_between,
                    "sigma_eps": p.sigma_eps, "cut_spacing": p.cut_spacing,
                    "sd_e": p.sd_e,
                    **{k: round(res[k], 6) for k in
                       ("bias", "emp_se", "model_se", "rmse", "coverage",
                        "width")},
                    "failures": res["failures"],
                    "loss": round(loss(res), 3), "seconds": round(secs, 1)})
    return res
