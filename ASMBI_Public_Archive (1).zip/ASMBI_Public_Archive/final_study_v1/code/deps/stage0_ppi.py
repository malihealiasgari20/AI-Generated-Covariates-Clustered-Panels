"""
Stage 0, step S0.4 -- PREDICTION-POWERED SPECIFICATIONS E-3 AND E-4.

E-3 and E-4 share ONE rectified point estimate and differ only in the covariance
estimator. That is enforced as an implementation invariant here: the common
theta_PPI is computed once and two covariance estimators are attached to it. The
identical-point-estimate property is therefore structural, not something the
Monte Carlo is asked to confirm.

    E-3  uniform rectifier, OBSERVATION-LEVEL sandwich, normal critical value
    E-4  uniform rectifier, unit-clustered CR1 sandwich with the N/(N-1)
         factor only, normal critical value

Rectified estimating equation (manuscript Equation 5, with the uniform weight
w_i = 1/pibar and pibar = G_S / N the realized labeled fraction):

    (1/NT) sum_it psi_it(theta; Z_L)
  + (1/NT) sum_i R_i (1/pibar) sum_t [psi_it(theta; Z_H) - psi_it(theta; Z_L)]
  = 0

For the linear case this is solved directly from the corrected Gram matrix and
right-hand side.

G3 is defined by the COVERAGE CONTRAST alone:
    median coverage 0.932 (E-3) versus 0.970 (E-4)
The published point-estimation summaries -- bias 0.0090, empirical SE 0.0707,
RMSE 0.0713, identical across the two rows -- are consistency checks, not
calibration targets.

Per the S0.4 instruction, sd_e, cut_spacing and sd_ZH_within are NOT adjusted
here unless G3 shows the reconstructed dependence structure itself is wrong.
"""

from __future__ import annotations

import csv
import os
import time
from dataclasses import replace

import numpy as np

from stage0_dgp import DGPParams, generate_panel, make_rng, within_demean
from stage0_naive import PRIMARY_CELLS, _period_design
from stage0_theta0 import theta0_for

Z_CRIT = 1.959963984540054          # normal critical value, both specifications

G3_TARGETS = {"cov_iid": 0.932, "cov_cr": 0.970}
CHECKS = {"bias": 0.0090, "emp_se": 0.0707, "rmse": 0.0713,
          "width_iid": 0.247, "width_cr": 0.286,
          "type1_iid": 0.072, "type1_cr": 0.036}


def ppi_fit(panel, period_design=None):
    """Common rectified point estimate plus BOTH covariance estimators.

    Returns (theta, se_obs_level, se_cluster).
    """
    N, T = panel.Y.shape
    R = panel.labeled.astype(float)
    G_S = R.sum()
    if G_S < 5:
        return None
    pibar = G_S / N                                   # realized labeled fraction

    y = within_demean(panel.Y).reshape(N * T)
    zL = within_demean(panel.ZL.astype(float)).reshape(N * T)
    zH = within_demean(panel.ZH).reshape(N * T)
    x = within_demean(panel.X).reshape(N * T)
    D = _period_design(N, T) if period_design is None else period_design

    WL = np.column_stack([zL, x, D])
    WH = np.column_stack([zH, x, D])
    k = WL.shape[1]

    # rectifier weight per observation: R_i / pibar
    rw = np.repeat(R, T) / pibar

    # corrected Gram matrix and RHS
    A = WL.T @ WL + (WH * rw[:, None]).T @ WH - (WL * rw[:, None]).T @ WL
    b = WL.T @ y + (WH * rw[:, None]).T @ y - (WL * rw[:, None]).T @ y
    A_inv = np.linalg.inv(A)
    theta = A_inv @ b

    # observation-level scores of the SAME rectified moment
    rL = y - WL @ theta
    rH = y - WH @ theta
    g = WL * rL[:, None] + rw[:, None] * (WH * rH[:, None] - WL * rL[:, None])

    # E-3: observation-level sandwich, no cluster correction
    V_obs = A_inv @ (g.T @ g) @ A_inv

    # E-4: CR1 by unit, N/(N-1) factor only
    gc = g.reshape(N, T, k).sum(axis=1)
    V_cl = A_inv @ (gc.T @ gc) @ A_inv * (N / (N - 1.0))

    return (float(theta[0]), float(np.sqrt(V_obs[0, 0])),
            float(np.sqrt(V_cl[0, 0])))


def run_cell(p: DGPParams, cell: dict, reps: int, theta0: float, tag: str):
    q = replace(p, **cell)
    D = _period_design(q.N, q.T)
    cell_id = f"icc={cell['icc']}|rho={cell['rho_e']}|kappa={cell['kappa']}"
    est, se_o, se_c, fail = [], [], [], 0
    for r in range(reps):
        pan = generate_panel(q, make_rng("S0_4_PPI", f"{tag}|{cell_id}", r))
        out = ppi_fit(pan, D)
        if out is None:
            fail += 1
            continue
        est.append(out[0]); se_o.append(out[1]); se_c.append(out[2])
    est = np.asarray(est); se_o = np.asarray(se_o); se_c = np.asarray(se_c)
    return {
        "bias": float(est.mean() - theta0),
        "emp_se": float(est.std(ddof=1)),
        "rmse": float(np.sqrt(np.mean((est - theta0) ** 2))),
        "model_se_iid": float(se_o.mean()),
        "model_se_cr": float(se_c.mean()),
        "cov_iid": float(np.mean(np.abs(est - theta0) <= Z_CRIT * se_o)),
        "cov_cr": float(np.mean(np.abs(est - theta0) <= Z_CRIT * se_c)),
        "width_iid": float(np.median(2 * Z_CRIT * se_o)),
        "width_cr": float(np.median(2 * Z_CRIT * se_c)),
        "failures": fail,
    }


def evaluate(p: DGPParams, reps: int, tag: str) -> dict:
    rows = [run_cell(p, c, reps, theta0_for(p, c), tag) for c in PRIMARY_CELLS]
    agg = {k: float(np.mean([r[k] for r in rows]))
           for k in ("bias", "emp_se", "rmse", "model_se_iid", "model_se_cr",
                     "width_iid", "width_cr")}
    for k in ("cov_iid", "cov_cr"):
        agg[k] = float(np.median([r[k] for r in rows]))
        agg[k + "_min"] = float(min(r[k] for r in rows))
        agg[k + "_max"] = float(max(r[k] for r in rows))
    agg["failures"] = int(sum(r["failures"] for r in rows))
    agg["cells"] = rows
    return agg


LOGFILE = "stage0_s04_candidates.csv"
_FIELDS = ["stage", "reps", "sd_ZH_within", "cut_spacing", "sd_e", "bias",
           "emp_se", "rmse", "model_se_iid", "model_se_cr", "cov_iid", "cov_cr",
           "width_iid", "width_cr", "failures", "seconds"]


def assess(stage: str, p: DGPParams, reps: int, tag: str) -> dict:
    t0 = time.time()
    res = evaluate(p, reps, tag)
    secs = time.time() - t0
    new = not os.path.exists(LOGFILE)
    with open(LOGFILE, "a", newline="") as fh:
        w = csv.DictWriter(fh, _FIELDS)
        if new:
            w.writeheader()
        w.writerow({"stage": stage, "reps": reps,
                    "sd_ZH_within": p.sd_ZH_within,
                    "cut_spacing": p.cut_spacing, "sd_e": p.sd_e,
                    **{k: round(res[k], 6) for k in
                       ("bias", "emp_se", "rmse", "model_se_iid",
                        "model_se_cr", "cov_iid", "cov_cr", "width_iid",
                        "width_cr")},
                    "failures": res["failures"], "seconds": round(secs, 1)})
    return res
