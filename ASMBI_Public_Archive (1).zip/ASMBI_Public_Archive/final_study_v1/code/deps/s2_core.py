"""Stage 2 core: Schur-form rectified solver with target-direction stabilization (TDS)."""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import numpy as np
from dataclasses import replace
from stage0_dgp import within_demean, generate_panel, make_rng
import s09_run as S
from stage0_naive import _period_design
from stage0_labeled_only import labeled_only_fit
from stage0_cda import e9_fit
from stage1_design_aware import crossfit_predictions

FROZEN = S.P
DELTAS = (0.10, 0.05, 0.20)          # 0.10 primary; 0.05, 0.20 sensitivity

def schur_info(M):
    Ms = 0.5 * (M + M.T); b = Ms[1:, 0]
    return float(Ms[0, 0] - b @ np.linalg.solve(Ms[1:, 1:], b))

def schur_solve(A, g, sM=None, delta=None):
    As = 0.5 * (A + A.T); a, b, C = As[0, 0], As[1:, 0], As[1:, 1:]
    Cb, CgN = np.linalg.solve(C, b), np.linalg.solve(C, g[1:])
    s = a - b @ Cb; r = g[0] - b @ CgN
    sd = s if delta is None else max(s, delta * sM)
    th0 = r / sd; th = np.concatenate([[th0], CgN - Cb * th0])
    Au = As.copy(); Au[0, 0] += sd - s
    return th, Au, float(s), bool(sd > s)

def cr1_se(Au, th, Wf, Wo, WH, y, rw, N, T):
    k = Wf.shape[1]; rf, rH, ro = y - Wf @ th, y - WH @ th, y - Wo @ th
    gc = (Wf * rf[:, None] + rw[:, None] * (WH * rH[:, None] - Wo * ro[:, None])).reshape(N, T, k).sum(axis=1)
    Ai = np.linalg.inv(Au); V = Ai @ (gc.T @ gc) @ Ai * (N / (N - 1.0))
    return float(np.sqrt(V[0, 0]))

def designs(pan, D, Zf, Zo, nuis_R=None):
    N, T = pan.Y.shape; dm = lambda Z: within_demean(np.asarray(Z, dtype=float)).reshape(N * T)
    Nn = np.column_stack([dm(pan.X), D])
    if nuis_R is not None: Nn = Nn @ nuis_R
    W = lambda z: np.column_stack([z, Nn])
    return dict(y=dm(pan.Y), WL=W(dm(pan.ZL)), WH=W(dm(pan.ZH)), Wf=W(dm(Zf)), Wo=W(dm(Zo)))

def weights(pan, kind):
    R = pan.labeled.astype(float); s = pan.strata
    if kind == "ht": return R / np.asarray(pan.params.pi)[s]
    nS = np.array([np.sum(s == j) for j in range(3)]); nL = np.array([np.sum((s == j) & pan.labeled) for j in range(3)])
    return None if np.any(nL == 0) else R * (nS / nL)[s]

FAMS = {"I": ("WL", "WL"), "CF": ("Wf", "Wo")}
NAMES = {("I","ht"): "E6", ("I","ps"): "PS-I", ("CF","ht"): "E12a", ("CF","ps"): "PS-CF"}
TDSN = {("I","ht"): "HT-TDS-I", ("I","ps"): "PS-TDS-I", ("CF","ht"): "HT-TDS-CF", ("CF","ps"): "PS-TDS-CF"}

def estimate_all(pan, D, Zf, Zo, deltas=DELTAS, nuis_R=None, rowperm=None):
    """Returns {name: (theta, se, s, bind)} for the 8 Schur-solver estimators and TDS variants."""
    N, T = pan.Y.shape; d = designs(pan, D, Zf, Zo, nuis_R); out = {}
    sM = {"I": schur_info(d["WL"].T @ d["WL"]), "CF": schur_info(d["Wf"].T @ d["Wf"])}
    for kind in ("ht", "ps"):
        w = weights(pan, kind)
        for fam, (f, o) in FAMS.items():
            keys = [NAMES[(fam, kind)]] + [f"{TDSN[(fam, kind)]}@{dl}" for dl in deltas]
            if w is None:
                for kk in keys: out[kk] = (np.nan, np.nan, np.nan, False)
                continue
            rw = np.repeat(w, T); Wf, Wo, WH, y = d[f], d[o], d["WH"], d["y"]
            if rowperm is not None: Wf, Wo, WH, y, rw = Wf[rowperm], Wo[rowperm], WH[rowperm], y[rowperm], rw[rowperm]
            A = Wf.T @ Wf + (WH * rw[:, None]).T @ WH - (Wo * rw[:, None]).T @ Wo
            g = Wf.T @ y + (WH * rw[:, None]).T @ y - (Wo * rw[:, None]).T @ y
            for kk, dl in zip(keys, [None] + list(deltas)):
                th, Au, s, bind = schur_solve(A, g, sM[fam], dl)
                out[kk] = (float(th[0]), cr1_se(Au, th, Wf, Wo, WH, y, rw, N, T), s, bind)
    out["_sM"] = sM
    return out

def full_gram_floor_point(pan, D, nuis_R=None):
    """Re-implementation of CDA-old's POINT estimator (PS weights, floor on the full spectrum)."""
    N, T = pan.Y.shape; d = designs(pan, D, pan.ZL, pan.ZL, nuis_R); w = weights(pan, "ps")
    if w is None: return np.nan
    rw = np.repeat(w, T); WL, WH, y = d["WL"], d["WH"], d["y"]
    A = WL.T @ WL + (WH * rw[:, None]).T @ WH - (WL * rw[:, None]).T @ WL; A = 0.5 * (A + A.T)
    g = WL.T @ y + (WH * rw[:, None]).T @ y - (WL * rw[:, None]).T @ y
    c = max(0.0, 0.10 * np.trace(A) / A.shape[0] - np.linalg.eigvalsh(A)[0])
    return float(np.linalg.solve(A + c * np.eye(A.shape[0]), g)[0])
