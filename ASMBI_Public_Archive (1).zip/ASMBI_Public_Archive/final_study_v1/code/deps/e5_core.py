"""Experiment 5 core: all estimators on one panel + mechanism diagnostics.
Separate from Stage 0. Benchmarks E2, E8, E9 call the frozen Stage-0 code; E4, E5, E6 are
recomputed through the generalized rectified equation and verified equal to the frozen code."""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import numpy as np
from dataclasses import replace
from stage0_dgp import within_demean, generate_panel, make_rng
import s09_run as S
from stage0_naive import _period_design
from stage0_labeled_only import labeled_only_fit
from stage0_cda import e8_fit, e9_fit
from stage1_design_aware import crossfit_predictions, rectifier_weights

FROZEN = S.P
CONFIGS = ["E4", "E5", "E6", "E6H", "E12a", "E12b", "E12c"]
# (predictor, rectifier): predictor L = identity Z_L, u = unweighted fit, w = weighted fit
SPEC = {"E4": ("L", "uniform"), "E5": ("u", "uniform"), "E6": ("L", "ht"), "E6H": ("L", "hajek"),
        "E12a": ("u", "ht"), "E12b": ("w", "ht"), "E12c": ("w", "uniform")}

def solve_rect(Wf, Wo, WH, y, rw, N, T):
    k = Wf.shape[1]
    A = Wf.T @ Wf + (WH * rw[:, None]).T @ WH - (Wo * rw[:, None]).T @ Wo
    b = Wf.T @ y + (WH * rw[:, None]).T @ y - (Wo * rw[:, None]).T @ y
    try:
        Ai = np.linalg.inv(A)
    except np.linalg.LinAlgError:
        return None
    th = Ai @ b
    rf, rH, ro = y - Wf @ th, y - WH @ th, y - Wo @ th
    g = Wf * rf[:, None] + rw[:, None] * (WH * rH[:, None] - Wo * ro[:, None])
    gc = g.reshape(N, T, k).sum(axis=1)
    V = Ai @ (gc.T @ gc) @ Ai * (N / (N - 1.0))
    return float(th[0]), float(np.sqrt(V[0, 0])), float(1.0 / Ai[0, 0] / (N * T)), A

COLS = (["E2_th", "E2_se", "E2_hw"] + [f"{c}_{q}" for c in CONFIGS for q in ("th", "se", "schur")]
        + ["E8_th", "E8_se", "E9_th", "E9_se", "E9_crit", "E9_fail"]
        + [f"D_{f}_s{s}" for f in "Luw" for s in range(3)]
        + [f"share_{r}_s{s}" for r in ("uniform", "ht", "hajek") for s in range(3)]
        + [f"pred_{c}" for c in CONFIGS] + ["G_S", "kish_ht", "delta_spread"])

def fit_all(pan, D, fold_key, theta0):
    N, T = pan.Y.shape; p = pan.params
    y = within_demean(pan.Y).reshape(N * T); x = within_demean(pan.X).reshape(N * T)
    W = lambda Z: np.column_stack([within_demean(Z).reshape(N * T), x, D])
    WL, WH = W(pan.ZL.astype(float)), W(pan.ZH)
    Zfu, Zou, _ = crossfit_predictions(pan, make_rng(*fold_key), False)
    Zfw, Zow, _ = crossfit_predictions(pan, make_rng(*fold_key), True)
    Wpair = {"L": (WL, WL), "u": (W(Zfu), W(Zou)), "w": (W(Zfw), W(Zow))}
    rwu = {r: rectifier_weights(pan, r) for r in ("uniform", "ht", "hajek")}
    row, A = [], {}
    e2 = labeled_only_fit(pan, D); row += [e2[0], e2[1], e2[2]] if e2 else [np.nan] * 3
    for c in CONFIGS:
        f, r = SPEC[c]; out = solve_rect(*Wpair[f], WH, y, np.repeat(rwu[r], T), N, T)
        if out is None: row += [np.nan] * 3
        else: row += list(out[:3]); A[c] = out[3]
    e8 = e8_fit(pan, D); e9 = e9_fit(pan, D); f9 = "fail" in e9
    row += [e8.get("theta", np.nan), e8.get("se", np.nan),
            np.nan if f9 else e9["theta"], np.nan if f9 else e9["se"], np.nan if f9 else e9["crit"], float(f9)]
    # ---- mechanism diagnostics: full parameter vector (F10a corrected procedure) ----
    s = pan.strata; gW = p.gamma_W + p.tau * (s - 1)
    ZHbar = pan.ZH.mean(axis=1, keepdims=True)
    rest = gW[:, None] * (pan.ZH - ZHbar) + p.gamma_B * ZHbar + p.beta * pan.X + pan.u[:, None] + pan.eps
    resid_d = pan.Y - rest; delta = resid_d.mean(axis=0)
    theta_full = np.concatenate([[theta0, p.beta], delta[:T - 1] - delta[T - 1]])
    def m_unit(Wm):
        k = Wm.shape[1]; return np.einsum("ntk,nt->nk", Wm.reshape(N, T, k), (y - Wm @ theta_full).reshape(N, T))
    mH = m_unit(WH); Dfull = {}
    for f in "Luw":
        dm = mH - m_unit(Wpair[f][0]); Dfull[f] = np.stack([dm[s == j].mean(axis=0) for j in range(3)])
        row += list(Dfull[f][:, 0])
    pS = np.array([np.mean(s == j) for j in range(3)]); shares = {}
    for r in ("uniform", "ht", "hajek"):
        shares[r] = np.array([rwu[r][s == j].sum() / N for j in range(3)]); row += list(shares[r])
    for c in CONFIGS:
        f, r = SPEC[c]
        if c in A:
            g = ((shares[r] - pS)[:, None] * Dfull[f]).sum(axis=0)
            row.append(float(np.linalg.solve(A[c] / N, g)[0]))
        else: row.append(np.nan)
    wl = 1.0 / np.asarray(p.pi)[s[pan.labeled]]
    row += [float(pan.labeled.sum()), float(wl.sum() ** 2 / (wl ** 2).sum()), float(resid_d.std(axis=0).max())]
    return row
