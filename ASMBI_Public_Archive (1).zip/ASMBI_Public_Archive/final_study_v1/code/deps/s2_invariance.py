"""Stage-2 invariance tests -- run BEFORE any performance quantity."""
import numpy as np
from dataclasses import replace
from s2_core import *
from stage0_naive import _period_design
from stage0_ht import ht_fit
from stage1_design_aware import generalized_rectifier_fit, _calibration_matrix, _rows
TOL = 1e-10
def cf_explicit(pan, fold_of):        # crossfit predictions with fold membership carried by unit
    N, T = pan.Y.shape; C = _calibration_matrix(pan); zh = pan.ZH.reshape(-1); lab = np.flatnonzero(pan.labeled)
    Zo = np.zeros((N, T)); coefs = []
    for f in range(5):
        te = lab[fold_of[lab] == f]; tr = lab[fold_of[lab] != f]
        cf, *_ = np.linalg.lstsq(C[_rows(tr, T)], zh[_rows(tr, T)], rcond=None); coefs.append(cf)
        Zo[te] = (C[_rows(te, T)] @ cf).reshape(te.size, T)
    return (C @ np.mean(coefs, axis=0)).reshape(N, T), Zo
def fold_labels(pan, key):
    lab = np.flatnonzero(pan.labeled); fo = np.full(pan.Y.shape[0], -1)
    for f, idx in enumerate(np.array_split(make_rng(*key).permutation(lab), 5)): fo[idx] = f
    return fo
def permute_units(pan, p):
    from dataclasses import fields
    kw = {f.name: (getattr(pan, f.name)[p] if isinstance(getattr(pan, f.name), np.ndarray) and getattr(pan, f.name).ndim >= 1
                   and getattr(pan, f.name).shape[0] == pan.Y.shape[0] else getattr(pan, f.name)) for f in fields(pan)}
    return type(pan)(**kw)
cells = {"baseline": dict(icc=0.30, tau=0.10, rho_e=0.0, kappa=0.0, gamma_W=0.15, cut_spacing=0.65, pi=(0.15, 0.30, 0.60)),
         "hard":     dict(icc=0.30, tau=0.10, rho_e=0.60, kappa=0.60, gamma_W=0.15, cut_spacing=0.50, pi=tuple(0.33*np.array([0.15,0.30,0.60])))}
Rdiag = np.diag([2.0, 0.5, 3.0, 0.25, 1.5, 4.0, 0.7, 1.2]); Rup = np.eye(8) + np.triu(np.full((8, 8), 0.3), 1)
Rper = np.diag([1.0, 0.5, 2.0, 3.0, 0.2, 1.7, 5.0, 0.8]); cvec = np.array([-0.30, -0.20, -0.10, 0.10, 0.20, 0.30, 0.40, 0.0])
res = {k: [] for k in ["recode_diag", "recode_upper", "period_scale", "outcome_span", "target_scale", "inactive", "perm_cluster", "perm_row", "xcheck"]}
neg = {"recode": [], "period_scale": [], "outcome_span_frozen_e9": []}; nbind = 0; nrep = 0
def cmp(a, b):
    return max(min(abs(a[k][i] - b[k][i]), abs(a[k][i] - b[k][i]) / max(abs(b[k][i]), 1e-300)) for k in a if not k.startswith("_") and not np.isnan(b[k][0]) for i in (0, 1))
for cname, cfg in cells.items():
    q = replace(FROZEN, **cfg); D = _period_design(q.N, q.T)
    for r in range(8):
        pan = generate_panel(q, make_rng("S2_CHECK", cname, r)); key = ("S2_CHECK_F", cname, r)
        Zf, Zo, _ = crossfit_predictions(pan, make_rng(*key), False); nrep += 1
        fo = fold_labels(pan, key); Zf2, Zo2 = cf_explicit(pan, fo)
        res["xcheck"].append(max(np.abs(Zf - Zf2).max(), np.abs(Zo - Zo2).max()))
        for dl in (0.10, 1.0):
            base = estimate_all(pan, D, Zf, Zo, deltas=(dl,))
            nbind += sum(v[3] for k, v in base.items() if "@" in k)
            res["recode_diag"].append(cmp(estimate_all(pan, D, Zf, Zo, (dl,), nuis_R=Rdiag), base))
            res["recode_upper"].append(cmp(estimate_all(pan, D, Zf, Zo, (dl,), nuis_R=Rup), base))
            res["period_scale"].append(cmp(estimate_all(pan, D, Zf, Zo, (dl,), nuis_R=Rper), base))
            ps = replace(pan, Y=pan.Y + 0.75 * pan.X + cvec[None, :])
            res["outcome_span"].append(cmp(estimate_all(ps, D, Zf, Zo, (dl,)), base))
            p2 = replace(pan, ZH=2 * pan.ZH, ZL=2 * pan.ZL.astype(float)); Zf2s, Zo2s, _ = crossfit_predictions(p2, make_rng(*key), False)
            s2 = estimate_all(p2, D, Zf2s, Zo2s, (dl,))
            res["target_scale"].append(max(abs(2 * s2[k][i] - base[k][i]) / max(abs(base[k][i]), 1e-12) for k in base if not k.startswith("_") and not np.isnan(base[k][0]) for i in (0, 1)))
            for k, v in base.items():
                if "@" in k and not v[3]:
                    b0 = base[k.split("@")[0].replace("HT-TDS-I","E6").replace("PS-TDS-I","PS-I").replace("HT-TDS-CF","E12a").replace("PS-TDS-CF","PS-CF")]
                    res["inactive"].append(max(abs(v[0] - b0[0]), abs(v[1] - b0[1])))
            p = make_rng("S2_CHECK_P", cname, r).permutation(pan.Y.shape[0]); pp = permute_units(pan, p)
            Zfp, Zop = cf_explicit(pp, fo[p]); res["perm_cluster"].append(cmp(estimate_all(pp, D, Zfp, Zop, (dl,)), base))
            N, T = pan.Y.shape; rp = np.concatenate([i * T + make_rng("S2_CHECK_R", f"{cname}|{i}", r).permutation(T) for i in range(N)])
            res["perm_row"].append(cmp(estimate_all(pan, D, Zf, Zo, (dl,), rowperm=rp), base))
        e6 = ht_fit(pan, D); b = estimate_all(pan, D, Zf, Zo, (0.10,))
        e12 = generalized_rectifier_fit(pan, "ht", "crossfit", make_rng(*key), False, D)
        res["xcheck"].append(max(abs(b["E6"][0] - e6[0]), abs(b["E6"][1] - e6[1]), abs(b["E12a"][0] - e12[0]), abs(b["E12a"][1] - e12[1])))
        e9 = e9_fit(pan, D)
        if "fail" not in e9:
            fg = full_gram_floor_point(pan, D); res["xcheck"].append(abs(fg - e9["theta"]))
            neg["recode"].append(abs(full_gram_floor_point(pan, D, Rup) - fg)); neg["period_scale"].append(abs(full_gram_floor_point(pan, D, Rper) - fg))
            e9s = e9_fit(replace(pan, Y=pan.Y + 0.75 * pan.X + cvec[None, :]), D)
            if "fail" not in e9s: neg["outcome_span_frozen_e9"].append(abs(e9s["theta"] - e9["theta"]))
lab = {"recode_diag": "(a) nuisance recoding, diagonal", "recode_upper": "(a) nuisance recoding, upper-triangular mix",
       "period_scale": "(b) nonuniform period-column scaling", "outcome_span": "(c) Y* = Y + 0.75X + Dc",
       "target_scale": "(d) target scaling 2Z: 2theta, 2SE (relative)", "inactive": "(e) inactive floor == base (point, SE)",
       "perm_cluster": "(f) cluster reordering (folds carried by unit)", "perm_row": "(f) within-cluster row reordering",
       "xcheck": "cross-checks: folds, E6/E12a vs Exp-5, floor re-impl vs e9"}
print(f"STAGE-2 INVARIANCE TESTS -- {nrep} panels (baseline + hard cell), delta 0.10 and 1.0; floor binding instances: {nbind}\n")
allpass = True
for k, v in res.items():
    m = max(v); p = m <= TOL; allpass &= p
    print(f"  {lab[k]:<52} max dev {m:.1e}   {'PASS' if p else 'FAIL'}   (n={len(v)})")
print(f"\nNEGATIVE CONTROL -- CDA-old (full-Gram floor) target shifts, expected NONZERO:")
for k, v in neg.items(): print(f"  {k:<26} max |change| {max(v):.2e}  median {np.median(v):.2e}  (n={len(v)})")
print("\nALL TDS INVARIANCE TESTS PASS -- performance run permitted" if allpass else "\nINVARIANCE FAILURE -- do not run performance")
