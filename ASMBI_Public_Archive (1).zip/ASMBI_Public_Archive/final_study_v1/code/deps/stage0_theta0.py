"""Frozen theta_0 map (manuscript Section 3.1).

Performance is evaluated against the numerical probability limit of the
infeasible full-information within estimator, computed from a 120,000-unit
auxiliary panel with contamination disabled -- NOT against the analytic value
gamma_W. Values are cached in stage0_theta0_map.json so that every step of
Stage 0 evaluates against the identical frozen numbers.

Each entry averages 20 auxiliary panels and stores the Monte Carlo SE of that
average, because a single 120,000-unit panel carries an SD of roughly 0.0012
(ledger finding F1).
"""

import json
import os
from dataclasses import replace

from stage0_dgp import DGPParams, compute_theta0

CACHE = "stage0_theta0_map.json"
N_PANELS = 20


def _key(p: DGPParams, cell: dict) -> str:
    q = replace(p, **cell)
    return "|".join(f"{k}={v}" for k, v in [
        ("T", q.T), ("gamma_W", q.gamma_W), ("tau", q.tau), ("icc", q.icc),
        ("rho_e", q.rho_e), ("sdB", q.sd_ZH_between), ("sdW", q.sd_ZH_within),
        ("sig", q.sigma_eps), ("gB", q.gamma_B), ("beta", q.beta),
        ("corrX", q.corr_X_ZH), ("sdX", q.sd_X)])


def _load() -> dict:
    if os.path.exists(CACHE):
        with open(CACHE) as fh:
            return json.load(fh)
    return {}


def theta0_for(p: DGPParams, cell: dict) -> float:
    cache = _load()
    k = _key(p, cell)
    if k not in cache:
        q = replace(p, **cell)
        mean, mcse, sd1 = compute_theta0(q, n_panels=N_PANELS)
        cache[k] = {"theta0": mean, "mcse": mcse, "sd_single_panel": sd1}
        with open(CACHE, "w") as fh:
            json.dump(cache, fh, indent=1, sort_keys=True)
    return float(cache[k]["theta0"])
