"""
Stage 0, step S0.6 -- HORVITZ-THOMPSON RECTIFIER (E-6) AND EVALUATION OF G5.

E-6, exactly as the manuscript specifies it: the full-sample machine moment plus
a rectifier weighted by the KNOWN stratum-specific inclusion probability
1/pi_{s_i}, with unit-clustered CR1 covariance and a normal critical value.

    A_HT = W_L' W_L + sum_i (R_i / pi_{s_i}) (W_H,i' W_H,i - W_L,i' W_L,i)
    b_HT = W_L' y   + sum_i (R_i / pi_{s_i}) (W_H,i' y     - W_L,i' y)
    theta_HT = A_HT^{-1} b_HT

    g_i = sum_t [ psi_it(theta; Z_L)
                  + (R_i / pi_{s_i}) { psi_it(theta; Z_H) - psi_it(theta; Z_L) } ]
    V   = A^{-1} (sum_i g_i g_i') A^{-1} * N/(N-1)

NOTE: no pibar appears anywhere in E-6. The manuscript distinguishes the uniform
1/pibar PPI rectifier (E-3, E-4) from the Horvitz-Thompson 1/pi_{s_i} rectifier.

G5 primary:      bias 0.0115, RMSE 0.1052
G5 consistency:  emp SE 0.1045, mean SE 0.0974, median coverage 0.968,
                 median width 0.329

Run at the S0.5 parameterization with NOTHING tuned.
"""

from __future__ import annotations

import csv
import os
import time
from dataclasses import replace

import numpy as np

from stage0_dgp import DGPParams, generate_panel, make_rng, within_demean
from stage0_naive import PRIMARY_CELLS, _period_design
from stage0_theta0 import theta0_for

Z_CRIT = 1.959963984540054
G5_TARGETS = {"bias": 0.0115, "rmse": 0.1052}
G5_CHECKS = {"emp_se": 0.1045, "model_se": 0.0974, "coverage": 0.968,
             "width": 0.329}


def ht_fit(panel, period_design=None, jackknife=False):
    """Horvitz-Thompson rectifier. Returns (theta, se_CR1, se_jackknife|None)."""
    N, T = panel.Y.shape
    R = panel.labeled.astype(float)
    if R.sum() < 5:
        return None

    pi_s = np.asarray(panel.params.pi)[panel.strata]     # known pi_{s_i}
    w_unit = R / pi_s                                     # HT rectifier weight
    rw = np.repeat(w_unit, T)

    y = within_demean(panel.Y).reshape(N * T)
    zL = within_demean(panel.ZL.astype(float)).reshape(N * T)
    zH = within_demean(panel.ZH).reshape(N * T)
    x = within_demean(panel.X).reshape(N * T)
    D = _period_design(N, T) if period_design is None else period_design
    WL = np.column_stack([zL, x, D])
    WH = np.column_stack([zH, x, D])
    k = WL.shape[1]

    A = WL.T @ WL + (WH * rw[:, None]).T @ WH - (WL * rw[:, None]).T @ WL
    b = WL.T @ y + (WH * rw[:, None]).T @ y - (WL * rw[:, None]).T @ y
    A_inv = np.linalg.inv(A)
    theta = A_inv @ b

    rL = y - WL @ theta
    rH = y - WH @ theta
    g = WL * rL[:, None] + rw[:, None] * (WH * rH[:, None] - WL * rL[:, None])
    gc = g.reshape(N, T, k).sum(axis=1)
    V = A_inv @ (gc.T @ gc) @ A_inv * (N / (N - 1.0))

    se_jk = None
    if jackknife:
        # exact leave-one-cluster-out (E-8); cluster contributions to A and b
        Ai = (np.einsum("ntj,ntk->njk", WL.reshape(N, T, k), WL.reshape(N, T, k))
              + rw.reshape(N, T)[:, :, None].mean(axis=1)[:, None] * 0)
        AL = np.einsum("ntj,ntk->njk", WL.reshape(N, T, k), WL.reshape(N, T, k))
        AH = np.einsum("ntj,ntk->njk", WH.reshape(N, T, k), WH.reshape(N, T, k))
        wi = w_unit[:, None, None]
        Ai = AL + wi * (AH - AL)
        bL = np.einsum("ntk,nt->nk", WL.reshape(N, T, k), y.reshape(N, T))
        bH = np.einsum("ntk,nt->nk", WH.reshape(N, T, k), y.reshape(N, T))
        bi = bL + w_unit[:, None] * (bH - bL)
        thetas = np.empty(N)
        for i in range(N):
            thetas[i] = np.linalg.solve(A - Ai[i], b - bi[i])[0]
        dev = thetas - thetas.mean()
        se_jk = float(np.sqrt((N - 1) / N * np.sum(dev ** 2)))

    return float(theta[0]), float(np.sqrt(V[0, 0])), se_jk


def run_cell(p, cell, reps, theta0, tag, jackknife=False):
    q = replace(p, **cell)
    D = _period_design(q.N, q.T)
    cid = f"icc={cell['icc']}|rho={cell['rho_e']}|kappa={cell['kappa']}"
    est, se, sejk, fail = [], [], [], 0
    for r in range(reps):
        pan = generate_panel(q, make_rng("S0_6_HT", f"{tag}|{cid}", r))
        out = ht_fit(pan, D, jackknife)
        if out is None:
            fail += 1
            continue
        est.append(out[0]); se.append(out[1])
        if jackknife:
            sejk.append(out[2])
    est = np.asarray(est); se = np.asarray(se)
    res = {"bias": float(est.mean() - theta0),
           "emp_se": float(est.std(ddof=1)),
           "model_se": float(se.mean()),
           "rmse": float(np.sqrt(np.mean((est - theta0) ** 2))),
           "coverage": float(np.mean(np.abs(est - theta0) <= Z_CRIT * se)),
           "width": float(np.median(2 * Z_CRIT * se)),
           "failures": fail}
    if jackknife:
        sejk = np.asarray(sejk)
        res["model_se_jk"] = float(sejk.mean())
        res["coverage_jk"] = float(np.mean(np.abs(est - theta0) <= Z_CRIT * sejk))
        res["width_jk"] = float(np.median(2 * Z_CRIT * sejk))
    return res


def evaluate(p, reps, tag, jackknife=False):
    rows = [run_cell(p, c, reps, theta0_for(p, c), tag, jackknife)
            for c in PRIMARY_CELLS]
    keys = ["bias", "emp_se", "model_se", "rmse", "width"]
    if jackknife:
        keys += ["model_se_jk", "width_jk"]
    agg = {k: float(np.mean([r[k] for r in rows])) for k in keys}
    agg["coverage"] = float(np.median([r["coverage"] for r in rows]))
    agg["cov_min"] = float(min(r["coverage"] for r in rows))
    agg["cov_max"] = float(max(r["coverage"] for r in rows))
    if jackknife:
        agg["coverage_jk"] = float(np.median([r["coverage_jk"] for r in rows]))
    agg["failures"] = int(sum(r["failures"] for r in rows))
    agg["cells"] = rows
    return agg


LOGFILE = "stage0_s06_candidates.csv"
_FIELDS = ["stage", "reps", "lambda1", "bias", "emp_se", "model_se", "rmse",
           "coverage", "width", "failures", "seconds"]


def assess(stage, p, reps, tag, jackknife=False):
    t0 = time.time()
    res = evaluate(p, reps, tag, jackknife)
    secs = time.time() - t0
    new = not os.path.exists(LOGFILE)
    with open(LOGFILE, "a", newline="") as fh:
        w = csv.DictWriter(fh, _FIELDS)
        if new:
            w.writeheader()
        w.writerow({"stage": stage, "reps": reps,
                    "lambda1": "/".join(f"{v:.2f}" for v in p.lambda1),
                    **{k: round(res[k], 6) for k in
                       ("bias", "emp_se", "model_se", "rmse", "coverage",
                        "width")},
                    "failures": res["failures"], "seconds": round(secs, 1)})
    return res
