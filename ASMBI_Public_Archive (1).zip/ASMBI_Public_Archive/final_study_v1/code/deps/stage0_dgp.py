"""
Stage 0, step S0.1 -- DATA-GENERATING PROCESS ONLY.

Reconstruction of the DGP in Nejatbakhsh & Aliasgari, "Stress-Testing Inference
with AI-Generated Covariates in Clustered Panels", for the ASMBI post-primary
extensions.

NO ESTIMATOR IS IMPLEMENTED IN THIS FILE. Its only purpose is to generate panels
and verify that they are structurally sensible against the checks listed in
Stage 0 of the reconstruction ledger.

All free parameters carry PROVISIONAL values. Nothing here has been calibrated
against G1-G6. Calibration begins at step S0.2.

Governing documents:
  ASMBI_Post_Primary_Extension_Protocol_v1.2.txt
  Stage0_Reconstruction_Parameter_Ledger.txt  (v0.2)
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, asdict

import numpy as np

# ----------------------------------------------------------------------------
# Seed rule (protocol Section 2.1)
# ----------------------------------------------------------------------------

STUDY_SEED = "ASMBI-2026-09-22"


def make_rng(experiment_id: str, cell_id: str, replication: int) -> np.random.Generator:
    """Deterministic independent stream per (experiment, cell, replication)."""
    key = f"{STUDY_SEED}|{experiment_id}|{cell_id}|{replication}"
    digest = hashlib.sha256(key.encode()).digest()[:16]
    return np.random.default_rng(int.from_bytes(digest, "big"))


def stream_key(experiment_id: str, cell_id: str, replication: int) -> str:
    return f"{STUDY_SEED}|{experiment_id}|{cell_id}|{replication}"


# ----------------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------------

@dataclass
class DGPParams:
    # --- fixed by the manuscript (NOT calibrated) ---
    N: int = 300
    T: int = 8
    gamma_W: float = 0.15
    tau: float = 0.10
    rho_e: float = 0.60
    kappa: float = 0.60                       # terminal maximum loading
    icc: float = 0.30
    pi: tuple = (0.15, 0.30, 0.60)            # stratum inclusion probabilities
    n_strata: int = 3                         # equal population shares

    # --- free parameters, PROVISIONAL values (ledger P1-P20) ---
    sd_ZH_between: float = 0.80               # P1
    sd_ZH_within: float = 0.80                # P1
    rho_ZH: float = 0.00                      # P1, serial dependence in Z_H
    sd_X: float = 1.00                        # P3
    corr_X_ZH: float = 0.30                   # P3
    beta: float = 0.50                        # P4
    gamma_B: float = 0.50                     # P5
    lambda1: tuple = (0.70, 0.90, 1.10)       # P6, by stratum
    lambda2: float = 0.30                     # P7
    sd_nu: float = 0.20                       # P8
    sd_e: float = 0.50                        # P9  (convention: SD(e_it) alone)
    cutpoint_family: str = "equal_width"      # P10: "equal_width" | "quantile"
    cut_spacing: float = 1.00                 # P10: bin width, in units of the
                                              # a-priori reference scale below
    sigma_eps: float = 1.00                   # P11
    icc_convention: str = "u_over_u_plus_eps"  # P12
    sd_delta: float = 0.20                    # P13

    # --- contamination schedule (ledger P14/P15/P16, set a priori) ---
    # kappa_t = 0 for t <= c ; kappa (t-c)/(T-c) for t > c ; c = floor(T/2)
    # eps_{i,1..T+1} generated, T retained, C_it = kappa_t eps_{i,t+1}

    def kappa_schedule(self) -> np.ndarray:
        c = self.T // 2
        t = np.arange(1, self.T + 1)
        k = np.where(t <= c, 0.0, self.kappa * (t - c) / (self.T - c))
        return k

    def mean_contaminated_loading(self) -> float:
        k = self.kappa_schedule()
        c = self.T // 2
        return float(k[c:].mean())

    def var_u(self) -> float:
        """P12: ICC = Var(u) / (Var(u) + Var(eps)), Var(eps) held fixed."""
        return self.icc / (1.0 - self.icc) * self.sigma_eps ** 2


# Cut points for the five-point ordinal scale (P10). Fixed a priori, NOT
# estimated per replication, so that discretization carries no sample
# information. Expressed in units of the latent index SD.
EQUAL_WIDTH_CUTS = np.array([-1.5, -0.5, 0.5, 1.5])
QUANTILE_CUTS = np.array([-0.8416, -0.2533, 0.2533, 0.8416])  # normal quintiles


# ----------------------------------------------------------------------------
# Panel generation
# ----------------------------------------------------------------------------

@dataclass
class Panel:
    Y: np.ndarray            # (N, T)
    ZH: np.ndarray           # (N, T)
    ZL: np.ndarray           # (N, T) ordinal 1..5
    Zstar: np.ndarray        # (N, T) latent machine index
    X: np.ndarray            # (N, T)
    eps: np.ndarray          # (N, T)   observed periods only
    eps_next: np.ndarray     # (N, T)   eps_{i,t+1}, used for contamination
    C: np.ndarray            # (N, T)   contamination component
    u: np.ndarray            # (N,)
    strata: np.ndarray       # (N,) in {0,1,2}
    labeled: np.ndarray      # (N,) bool
    kappa_t: np.ndarray      # (T,)
    params: DGPParams
    diagnostics: dict = field(default_factory=dict)


def _ar1(rng, N, T, rho, sigma):
    """Stationary AR(1) with marginal variance sigma^2, T periods."""
    out = np.empty((N, T))
    out[:, 0] = rng.normal(0.0, sigma, N)
    if T > 1:
        sd_eta = sigma * np.sqrt(1.0 - rho ** 2) if abs(rho) < 1 else 0.0
        eta = rng.normal(0.0, sd_eta, (N, T - 1))
        for t in range(1, T):
            out[:, t] = rho * out[:, t - 1] + eta[:, t - 1]
    return out


def generate_panel(p: DGPParams, rng: np.random.Generator,
                   contamination: bool = True) -> Panel:
    N, T = p.N, p.T

    # --- human construct Z_H: between + within components ---------------
    a = rng.normal(0.0, p.sd_ZH_between, N)                  # unit means
    # NOTE: w is NOT exactly within-centered. Exact centering would force the
    # realized within variance to sigma_W^2 (1 - 1/T) rather than sigma_W^2,
    # which makes the ledger's nominal and realized values disagree for no
    # modelling reason. The unit mean of Z_H is then a_i + wbar_i, which is
    # still correlated with the stratum as the manuscript requires.
    w = _ar1(rng, N, T, p.rho_ZH, p.sd_ZH_within)            # within component
    ZH = a[:, None] + w

    # --- validation strata: tertiles of the unit mean of Z_H -------------
    # The stratum score is Zbar_H,i = mean_t Z_H,it, NOT the latent between
    # component a_i. Equal population shares hold by construction (rank
    # tertiles), and the unit mean of the human construct is correlated with
    # the stratum, as the manuscript requires. Because a_i and the within
    # component are independent, the within-unit signal moment is common across
    # strata, which is what makes omega_s = 1/3 and theta_0 = gamma_W.
    zbar = ZH.mean(axis=1)
    order = np.argsort(np.argsort(zbar))
    strata = np.minimum((order * p.n_strata) // N, p.n_strata - 1)

    # --- structured control X --------------------------------------------
    zh_sd = np.sqrt(p.sd_ZH_between ** 2 + p.sd_ZH_within ** 2)
    x_noise = rng.normal(0.0, 1.0, (N, T))
    X = p.sd_X * (p.corr_X_ZH * (ZH / zh_sd)
                  + np.sqrt(max(0.0, 1.0 - p.corr_X_ZH ** 2)) * x_noise)

    # --- disturbances: T+1 periods generated, T retained ------------------
    eps_full = _ar1(rng, N, T + 1, p.rho_e, p.sigma_eps)
    eps = eps_full[:, :T]
    eps_next = eps_full[:, 1:T + 1]

    # --- unit effects and period effects ----------------------------------
    u = rng.normal(0.0, np.sqrt(p.var_u()), N)
    delta = rng.normal(0.0, p.sd_delta, T)

    # --- outcome ----------------------------------------------------------
    gamma_W_i = p.gamma_W + p.tau * (strata - 1)
    ZH_within = ZH - ZH.mean(axis=1, keepdims=True)
    Y = (gamma_W_i[:, None] * ZH_within
         + p.gamma_B * zbar[:, None]      # Equation (1) uses gamma_B Zbar_H,i
         + p.beta * X
         + delta[None, :]
         + u[:, None]
         + eps)

    # --- machine measurement ----------------------------------------------
    kappa_t = p.kappa_schedule()
    C = (kappa_t[None, :] * eps_next) if contamination else np.zeros((N, T))
    nu = rng.normal(0.0, p.sd_nu, N)
    e = rng.normal(0.0, p.sd_e, (N, T))
    lam1 = np.asarray(p.lambda1)[strata]
    Zstar = lam1[:, None] * ZH + p.lambda2 * X + nu[:, None] + e + C

    ZL = discretize(Zstar, p)

    # --- cluster-level informative validation ------------------------------
    pi_i = np.asarray(p.pi)[strata]
    labeled = rng.random(N) < pi_i

    return Panel(Y=Y, ZH=ZH, ZL=ZL, Zstar=Zstar, X=X, eps=eps,
                 eps_next=eps_next, C=C, u=u, strata=strata, labeled=labeled,
                 kappa_t=kappa_t, params=p)


def discretize(Zstar: np.ndarray, p: DGPParams) -> np.ndarray:
    """Five-point ordinal scale with a priori cut points (ledger P10)."""
    cuts = EQUAL_WIDTH_CUTS if p.cutpoint_family == "equal_width" else QUANTILE_CUTS
    scale = latent_reference_sd(p) * p.cut_spacing
    return np.searchsorted(cuts * scale, Zstar, side="right") + 1


def latent_reference_sd(p: DGPParams) -> float:
    """A-PRIORI REFERENCE SCALE for the cut points. NOT an exact population SD.

    With a stratum-dependent loading lambda1(s) that is correlated with Z_H
    through the stratum assignment, E[lambda1^2] Var(Z_H) is not in general the
    exact variance of lambda1(s_i) Z_H,it. The expression below is therefore a
    fixed a-priori scale used only to place the cut points, not a recovered
    feature of the original DGP.

    The equal-width thresholds and the cut_spacing multiplier are reconstruction
    conventions (ledger P10) and are subject to the planned sensitivity
    analysis. The calibration search must not treat this formula as identified.
    """
    var_zh = p.sd_ZH_between ** 2 + p.sd_ZH_within ** 2
    lam1_bar2 = float(np.mean(np.asarray(p.lambda1) ** 2))
    zh_sd = np.sqrt(var_zh)
    # Cov(ZH, X) = corr_X_ZH * sd_X * zh_sd  under the construction above.
    cov_zh_x = p.corr_X_ZH * p.sd_X * zh_sd
    var = (lam1_bar2 * var_zh
           + p.lambda2 ** 2 * p.sd_X ** 2
           + 2.0 * np.mean(p.lambda1) * p.lambda2 * cov_zh_x
           + p.sd_nu ** 2 + p.sd_e ** 2)
    return float(np.sqrt(var))


# ----------------------------------------------------------------------------
# theta_0: numerical probability limit of the infeasible full-information
# within estimator (manuscript Section 3.1; ledger anchor A7)
# ----------------------------------------------------------------------------

def within_demean(M: np.ndarray) -> np.ndarray:
    return M - M.mean(axis=1, keepdims=True)


def infeasible_within_fit(panel: Panel) -> float:
    """Within regression of Y on demeaned Z_H and X, with period dummies.

    Period effects enter as demeaned regressors rather than through a second
    demeaning step (manuscript Section 3.1).
    """
    N, T = panel.Y.shape
    y = within_demean(panel.Y).ravel()
    z = within_demean(panel.ZH).ravel()
    x = within_demean(panel.X).ravel()
    D = np.tile(np.eye(T)[:, :T - 1], (N, 1))
    D = D - D.reshape(N, T, T - 1).mean(axis=1).repeat(T, axis=0)
    W = np.column_stack([z, x, D])
    coef, *_ = np.linalg.lstsq(W, y, rcond=None)
    return float(coef[0])


def compute_theta0(p: DGPParams, n_units: int = 120_000, n_panels: int = 1,
                   seed_tag: str = "theta0") -> tuple:
    """Auxiliary panel(s) with contamination disabled (manuscript Section 3.1).

    Returns (mean theta_0, Monte Carlo SE). The manuscript reports a single
    figure and states that the Monte Carlo uncertainty of this computation is
    not quantified; protocol Section 10.3(ix) requires that we quantify it, so
    the estimate is averaged over n_panels auxiliary panels and its MCSE is
    returned alongside.
    """
    q = DGPParams(**{**asdict(p), "N": n_units})
    vals = []
    for j in range(n_panels):
        rng = make_rng("S0_1_DGP",
                       f"{seed_tag}|T={p.T}|icc={p.icc}|rho={p.rho_e}", j)
        vals.append(infeasible_within_fit(generate_panel(q, rng,
                                                         contamination=False)))
    vals = np.asarray(vals)
    if n_panels > 1:
        sd_single = float(vals.std(ddof=1))          # SD of ONE 120k estimate
        mcse = sd_single / np.sqrt(n_panels)          # MCSE of the average
    else:
        sd_single = mcse = float("nan")
    return float(vals.mean()), mcse, sd_single


# ----------------------------------------------------------------------------
# Association measures (ledger A8: raw AND within-transformed)
# ----------------------------------------------------------------------------

def quadratic_weighted_kappa(a: np.ndarray, b: np.ndarray, k: int = 5) -> float:
    a = np.asarray(a).ravel() - 1
    b = np.asarray(b).ravel() - 1
    O = np.zeros((k, k))
    np.add.at(O, (a, b), 1.0)
    O /= O.sum()
    ha = O.sum(axis=1)
    hb = O.sum(axis=0)
    E = np.outer(ha, hb)
    i = np.arange(k)
    Wt = (i[:, None] - i[None, :]) ** 2 / (k - 1) ** 2
    den = (Wt * E).sum()
    return float(1.0 - (Wt * O).sum() / den) if den > 0 else float("nan")


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    from scipy.stats import rankdata
    return float(np.corrcoef(rankdata(a.ravel()), rankdata(b.ravel()))[0, 1])


def associations(panel: Panel) -> dict:
    ZH_disc = discretize(panel.ZH * float(np.mean(panel.params.lambda1)),
                         panel.params)
    zl_w = within_demean(panel.ZL.astype(float))
    zh_w = within_demean(panel.ZH)
    return {
        "raw_pearson_ZL_ZH": float(np.corrcoef(panel.ZL.ravel(),
                                               panel.ZH.ravel())[0, 1]),
        "raw_spearman_ZL_ZH": spearman(panel.ZL, panel.ZH),
        "raw_qwk_ZL_ZHdisc": quadratic_weighted_kappa(panel.ZL, ZH_disc),
        "within_pearson_ZL_ZH": float(np.corrcoef(zl_w.ravel(),
                                                  zh_w.ravel())[0, 1]),
        "within_spearman_ZL_ZH": spearman(zl_w, zh_w),
    }
