"""
Stage 0, step S0.2 -- NAIVE-ESTIMATOR RECONSTRUCTION AND JOINT CALIBRATION
AGAINST G2 AND A1.

Implements E-1 only. E-2 is NOT implemented here.

E-1, exactly as the manuscript specifies it:
    unit-demeaned Y on unit-demeaned Z_L, unit-demeaned X, and T-1 period
    indicators (entered as demeaned regressors, not via a second demeaning
    step); CR1 covariance clustered by unit; t(N-1) critical value; no
    validation labels used anywhere.

Calibration targets, evaluated on the ORIGINAL 12-cell non-null primary
crossing ICC x rho_e x kappa at gamma_W = 0.15, N = 300, T = 8, tau = 0.10,
aggregated exactly as the published table aggregates:

    mean bias          -0.0739     (G2)
    mean empirical SE   0.0200     (A1)
    mean model SE       0.0200     (A1)
    RMSE                0.0794
    median coverage     0.011      (consistency check only; NOT fitted)

Staged search, fixed before any candidate was run:
    screening   400 replications per cell
    refinement  1000 replications per cell
    final       5000 replications per cell (protocol requirement)

Only G1-G6, A1 and A2 may drive the search. G7-G9 are untouched.
Every candidate evaluated is written to stage0_s02_candidates.csv.
"""

from __future__ import annotations

import csv
import itertools
import time
from dataclasses import asdict, replace

import numpy as np

from stage0_dgp import DGPParams, generate_panel, make_rng, within_demean
from stage0_theta0 import theta0_for

# ---------------------------------------------------------------------------
# The 12 non-null primary cells
# ---------------------------------------------------------------------------

PRIMARY_CELLS = [
    {"icc": icc, "rho_e": rho, "kappa": kap}
    for icc, rho, kap in itertools.product((0.10, 0.30, 0.50), (0.0, 0.60),
                                           (0.0, 0.60))
]

TARGETS = {"bias": -0.0739, "emp_se": 0.0200, "model_se": 0.0200,
           "rmse": 0.0794, "cov_med": 0.011}


# ---------------------------------------------------------------------------
# E-1 naive estimator
# ---------------------------------------------------------------------------

def _period_design(N: int, T: int) -> np.ndarray:
    """T-1 period indicators, demeaned within unit (manuscript Section 3.1)."""
    D = np.tile(np.eye(T)[:, :T - 1], (N, 1)).reshape(N, T, T - 1)
    D = D - D.mean(axis=1, keepdims=True)
    return D.reshape(N * T, T - 1)


def naive_fit(panel, period_design=None) -> tuple:
    """Return (theta_hat, se_CR1, covered, rejected_null_at_theta0=None).

    Coverage is evaluated against theta_0 by the caller.
    """
    N, T = panel.Y.shape
    y = within_demean(panel.Y).reshape(N * T)
    z = within_demean(panel.ZL.astype(float)).reshape(N * T)
    x = within_demean(panel.X).reshape(N * T)
    D = _period_design(N, T) if period_design is None else period_design
    W = np.column_stack([z, x, D])

    XtX = W.T @ W
    XtX_inv = np.linalg.inv(XtX)
    theta = XtX_inv @ (W.T @ y)
    resid = y - W @ theta

    # CR1 cluster-robust sandwich, clustered by unit
    k = W.shape[1]
    Wc = W.reshape(N, T, k)
    rc = resid.reshape(N, T)
    scores = np.einsum("ntk,nt->nk", Wc, rc)
    meat = scores.T @ scores
    # CR1 as the manuscript defines it: the cluster sandwich with the G/(G-1)
    # finite-sample factor and nothing else. An additional (n-1)/(n-k) term is
    # common in software but is NOT in the written specification, so it is not
    # applied here.
    c1 = N / (N - 1.0)
    V = XtX_inv @ meat @ XtX_inv * c1
    return float(theta[0]), float(np.sqrt(V[0, 0]))


# ---------------------------------------------------------------------------
# Cell and grid evaluation
# ---------------------------------------------------------------------------

def run_cell(p: DGPParams, cell: dict, reps: int, theta0: float,
             tag: str) -> dict:
    from scipy.stats import t as tdist
    q = replace(p, **cell)
    crit = tdist.ppf(0.975, q.N - 1)
    D = _period_design(q.N, q.T)
    est = np.empty(reps)
    se = np.empty(reps)
    cell_id = f"icc={cell['icc']}|rho={cell['rho_e']}|kappa={cell['kappa']}"
    for r in range(reps):
        pan = generate_panel(q, make_rng("S0_2_NAIVE", f"{tag}|{cell_id}", r))
        est[r], se[r] = naive_fit(pan, D)
    lo, hi = est - crit * se, est + crit * se
    return {
        "bias": float(est.mean() - theta0),
        "emp_se": float(est.std(ddof=1)),
        "model_se": float(se.mean()),
        "rmse": float(np.sqrt(np.mean((est - theta0) ** 2))),
        "coverage": float(np.mean((lo <= theta0) & (theta0 <= hi))),
    }


def evaluate(p: DGPParams, reps: int, tag: str, theta0=None) -> dict:
    """Aggregate over the 12 non-null primary cells as the published table does.

    theta_0 is taken per cell from the frozen auxiliary-panel map (manuscript
    Section 3.1), not from the analytic value gamma_W. Pass a float to override.
    """
    if theta0 is None:
        rows = [run_cell(p, c, reps, theta0_for(p, c), tag) for c in PRIMARY_CELLS]
    else:
        rows = [run_cell(p, c, reps, theta0, tag) for c in PRIMARY_CELLS]
    return {
        "bias": float(np.mean([r["bias"] for r in rows])),
        "emp_se": float(np.mean([r["emp_se"] for r in rows])),
        "model_se": float(np.mean([r["model_se"] for r in rows])),
        "rmse": float(np.mean([r["rmse"] for r in rows])),
        "cov_med": float(np.median([r["coverage"] for r in rows])),
        "cells": rows,
    }


def loss(res: dict) -> float:
    """Search criterion: bias and SE only. Coverage is NOT fitted."""
    return (((res["bias"] - TARGETS["bias"]) / 0.0074) ** 2
            + ((res["emp_se"] - TARGETS["emp_se"]) / 0.0020) ** 2)


# ---------------------------------------------------------------------------
# Candidate log
# ---------------------------------------------------------------------------

LOGFILE = "stage0_s02_candidates.csv"
_FIELDS = ["stage", "reps", "cut_spacing", "sd_e", "sd_ZH_within", "lambda1",
           "bias", "emp_se", "model_se", "rmse", "cov_med", "loss", "seconds"]


def log_candidate(stage: str, reps: int, p: DGPParams, res: dict,
                  secs: float) -> None:
    new = False
    try:
        open(LOGFILE).close()
    except FileNotFoundError:
        new = True
    with open(LOGFILE, "a", newline="") as fh:
        w = csv.DictWriter(fh, _FIELDS)
        if new:
            w.writeheader()
        w.writerow({"stage": stage, "reps": reps, "cut_spacing": p.cut_spacing,
                    "sd_e": p.sd_e, "sd_ZH_within": p.sd_ZH_within,
                    "lambda1": "/".join(f"{v:.2f}" for v in p.lambda1),
                    "bias": round(res["bias"], 6),
                    "emp_se": round(res["emp_se"], 6),
                    "model_se": round(res["model_se"], 6),
                    "rmse": round(res["rmse"], 6),
                    "cov_med": round(res["cov_med"], 4),
                    "loss": round(loss(res), 3), "seconds": round(secs, 1)})


def assess(stage: str, p: DGPParams, reps: int, tag: str) -> dict:
    t0 = time.time()
    res = evaluate(p, reps, tag)
    secs = time.time() - t0
    log_candidate(stage, reps, p, res, secs)
    return res
