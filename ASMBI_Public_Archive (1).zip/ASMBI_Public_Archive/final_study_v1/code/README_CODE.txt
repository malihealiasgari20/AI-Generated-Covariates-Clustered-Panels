================================================================================
FINAL_V1 CODE PACKAGE -- Final_Study_v1/code/
Stress-Testing Inference with AI-Generated Covariates in Clustered Panels
Nejatbakhsh & Aliasgari -- target venue: ASMBI
================================================================================

STATUS (3 November 2026, built 20:50 UTC): Step 5 of the FINAL_V1 plan (record Section 10.1,
step 3). The runner is written to FINAL_V1_PRE_RUN_RECORD_FROZEN.txt (SHA-256
bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0) and the frozen registry
FINAL_V1_CELL_REGISTRY_FROZEN.csv (cdabf999...). It has NOT been run in production.
  - No FINAL_V1 seed stream (FINAL_V1_PANEL, _FOLDS, _OOS, _BOOT, _GATE) has been drawn.
  - No FINAL_V1 performance quantity exists.
  - No sealed file or package was modified. This folder and MANIFEST_SHA256_CODE.txt are new
    files; every earlier manifest of Final_Study_v1 still verifies.
  - The gates G-A to G-F (record 10.1 step 4) have not been run. A production run is refused
    until the gate record described in Section 8 exists.

Code fingerprint (fv1/*.py + fv1_run.py; stored in every checkpoint and required in the gate
record): 2d263942e63e44db60a02d6041aba51b3fad0a55c94a0941c45ee31e1d909cbd
Dependency record deps/DEPENDENCY_HASHES.json: 36ada4a14ec23fa9d06567480ee9fade37f6d30b6f6015033b965a64272898d3

--------------------------------------------------------------------------------
1. LAYOUT
--------------------------------------------------------------------------------

  fv1_run.py              entry point (plan / run / status)
  fv1/env.py              thread pinning (1 BLAS thread per process), no bytecode, deps path,
                          sealed-file, dependency and code-fingerprint checks
  fv1/registry.py         runs the sealed build_registry.py in a temporary folder; its CSV must
                          be byte-identical to the frozen registry; exact DGP parameters per row;
                          fixed absolute cut points (cut_spacing = 0.8050009202070365 /
                          latent_reference_sd)
  fv1/seeds.py            one study-wide seed hierarchy (frozen make_rng / stream_key)
  fv1/theta0.py           theta_0 lookup (production: the gate-G-F map; tests: frozen union)
  fv1/estimators.py       one wrapper per estimator, failure rules and failure types
  fv1/e10.py              E-10 (new code, gated by V10)
  fv1/diagnostics.py      record-3.8 diagnostics, module-D measures, Exp-3 within moment
  fv1/compute.py          one configuration: one panel per replication shared by all estimators
  fv1/store.py            atomic per-configuration checkpoints, interruption markers, run log
  fv1/runner.py           orchestration: two workers, budgets, resume, run-health status
  deps/                   hash-verified copies of the frozen code (Section 2)
  tests/dev_equivalence.py   wrappers versus the frozen functions (throwaway namespace)
  tests/dev_e10_checks.py    E-10 code checks (throwaway namespace; ppi-python not executed)
  tests/test_mechanics.py    runner mechanics (throwaway namespaces)
  tests/TEST_OUTPUT.txt      output of the three scripts on the delivered code

Always run with "python3 -I -B" (isolated, no bytecode). Read-only inputs used in place:
FINAL_V1_PRE_RUN_RECORD_FROZEN.txt, FINAL_V1_CELL_REGISTRY_FROZEN.csv and build_registry.py
(hash-checked against their seals at every start), and the four sealed theta_0 maps that
build_registry.py reads for its theta0_in_frozen_maps column.

--------------------------------------------------------------------------------
2. DEPENDENCIES (deps/; each copy's SHA-256 equals its sealed package manifest entry)
--------------------------------------------------------------------------------

  Stage0_Reconstruction_v1.1_FROZEN (manifest 34de2e3f...):
    stage0_dgp.py d05c95be  stage0_naive.py f0151fd5  stage0_labeled_only.py cc4dc4cd
    stage0_ppi.py a597de66  stage0_crossppi.py 6ea0c222  stage0_ht.py a1b91a56
    stage0_rc.py e492a68d  stage0_cda.py 30047e46  stage0_theta0.py 1fda602e
    s09_run.py 9b9079d8 (frozen parameterization P, imported by e5_core and s2_core;
      its driver one() is NOT used by the runner -- record 0.6(c))
    config/dgp_config.json 851a4dfe, config/SEED_SPECIFICATION.txt 9e6c1f6e,
    theta0_maps/v1.1_config_theta0_map.json 3c467f00
  S0.11_Holdout_Package (a32af1d2...): theta0_maps/S0.11_stage0_theta0_map.json f983bdad
  Stage1_Experiment5 (4c8bcb24...): e5_core.py 75aab505 (solve_rect),
    theta0_maps/E5_stage0_theta0_map.json 8aca334c
  Stage1_Experiment5_addendum (33b60baa...): nothing needed. It holds the E-8 tail audit, a
    JSON and figures, no code; the robust measures it motivated are analysis-stage.
  Stage2_Target_Direction_Stabilization (6e70c01d...): s2_core.py 05469cff,
    stage1_design_aware.py 20f56e15 (from its deps/; the only sealed copy), s2_invariance.py
    bd5960a3 (reference for gates G-D / V10.3 only), theta0_maps/S2_stage0_theta0_map.json eb9c537a

--------------------------------------------------------------------------------
3. HOW THE STEP-5 REQUIREMENTS ARE MET
--------------------------------------------------------------------------------

  One panel per (configuration, r), shared by every applicable estimator.
    compute.run_configuration generates it once from FINAL_V1_PANEL|seed_cell_id|r with the
    frozen generate_panel and passes the same object to every estimator and diagnostic. A digest
    of the panel is taken before and after; any change aborts the run (test M5).
    Configurations shared by several modules are computed once (registry de-duplication). Subset
    batteries are read from the FULL rows: the X3 battery and E-1 of module D are not recomputed
    where FULL rows exist. E-10 and the D measures run only for r < R_E10 and r < R_D.

  Cross-fitting folds shared exactly where specified.
    E-5 (frozen crossppi_fit), E-12a/b/c and HT-TDS-CF each build a fresh generator from the same
    key FINAL_V1_FOLDS|seed_cell_id|r, so their folds are identical (test M6). The Experiment-5
    mechanism diagnostics use the same key, as Experiment 5 did. The module-D out-of-sample folds
    come from FINAL_V1_OOS.

  kappa excluded from the base-draw seed key.
    The seed cell id is the registry's seed_cell_id (every factor except kappa). The loader
    asserts this for all 149 rows. Configurations that share a seed id differ only in kappa.
    Their panels have identical Y, Z_H, X, eps, u, labels and strata (126 pairs checked, test M3).

  Every estimator called separately.
    estimators.run_battery calls each wrapper in its own try block. A returned failure or any
    exception is recorded for that estimator only (test M7: injected exceptions in E-7 and E-3/E-4
    leave every other row unchanged). E-3 and E-4 come from one frozen call (one point estimate,
    two variance estimators). E-8 is called separately from E-6.

  All failure codes recorded.
    rows_fail holds one of: 0 ok; 1 below minimum (pre-specified eligibility/failure rule);
    2 empty post-stratum (full sample); 3 empty post-stratum (jackknife deletion); 4 singular
    system or invalid covariance (LinAlgError, cond(H) > 1e12 for E-10, P20 sum d^4 = 0);
    5 non-finite estimate, SE or interval; 6 exception. Each failure also stores its detail string.
    Rules, as frozen in record Section 5:
      E-2, E-3/E-4, E-6, E-8, E-6H, HT-TDS-I, PS-TDS-I, E-10: G_S < 5
      E-5, E-12a/b/c, HT-TDS-CF: G_S < 10
      PS-TDS-I: any n_s = 0
      E-9: P19 / P20
      E-10: also N_u < 2
    In an f = 0.03 cell every failure carried the code its rule implies (test M8).

  Raw replication-level output checkpointed per configuration.
    raw/C###.npz is written as .partial, fsync'd, then renamed; raw/C###.sha256 follows. The
    long table has one row per (configuration, r, estimator): estimate, SE, critical value,
    interval, coverage of theta_0, rejection of 0, failure code, binding flag, runtime. Coverage
    and rejection are per-row indicators, not rates.
    Also stored: per-replication diagnostics; stream keys for every replication (panel, folds,
    OOS); deterministic metadata (configuration, parameters, namespace, theta_0, code
    fingerprint, dependency and seal hashes); run metadata (times, pid, numpy/scipy/platform).

  Deterministic restart.
    A configuration's arrays depend only on (configuration, namespace, theta_0, code); BLAS runs
    single-threaded. Configurations are taken in frozen-registry order. Complete, hash-verified
    checkpoints whose metadata match the run are kept. A configuration with a start marker or
    partial file but no verified checkpoint is moved to quarantine/, recomputed from its identical
    seeds, and logged as INTERRUPTED_RECOMPUTE. Checkpoints written by different code are refused
    rather than mixed.
    Test M9: 1 and 2 workers gave identical content digests. Test M10: a run killed inside a
    configuration resumed and its final digests equal an uninterrupted run's.

  No performance-summary computation during execution.
    The runner writes raw arrays only. Its log records completion, per-configuration wall time and
    failure counts. "status" reads only failure codes, estimator ids and wall times (record D13).
    No bias, SE level, RMSE, coverage rate or rejection rate is computed until all 149
    configurations are complete (test M12 checks which arrays the runner reads).

--------------------------------------------------------------------------------
4. ESTIMATORS (record 3) AND HOW THEY ARE CALLED
--------------------------------------------------------------------------------

  FULL  E-1 naive_fit; E-2 labeled_only_fit; E-3/E-4 ppi_fit; E-5 crossppi_fit; E-6 ht_fit;
        E-7 rc_fit; E-8 e8_fit; E-9 e9_fit (all frozen Stage 0);
        E-6H, E-12a, E-12b, E-12c via e5_core.solve_rect with the design matrices, folds and
        weights built exactly as e5_core.fit_all builds them;
        HT-TDS-I, PS-TDS-I, HT-TDS-CF via s2_core designs / weights / schur_info / schur_solve /
        cr1_se exactly as s2_core.estimate_all builds them, delta = 0.10 only.
  X3    E-1, E-7, E-2, E-6.   D  E-1 + QWK, rank correlation, incremental OOS R^2.
  E-10  fv1/e10.py, record 3.4. It uses the frozen per-cluster contributions
        (stage0_cda.contributions), solves the rectified M-estimation equation exactly, and
        sets lambda^ by a line-by-line port of ppi_py _calc_lam_glm (coord = 0, clip = True)
        evaluated at the pilot lambda = 1. The variance is ppi_ols_ci's covariance block with
        unit-level gradients and the labeled-data Hessian of the true loss. It fails if
        G_S < 5, N_u < 2, cond(H) > 1e12, or any output is non-finite.
  Critical values as frozen: t(N-1) for E-1, t(G_S-1) for E-2, Satterthwaite t for E-9, normal
  otherwise.
  Diagnostics (record 3.8), per replication:
    - G_S, n_s, Kish size of the HT weights;
    - s/(NT), s_M/(NT) and s/s_M for E-4, E-5, E-6, E-6H, E-12a/b/c and the three TDS variants;
    - TDS binding flags; E-9 floor binding, shift, nu_eff and deletion binding fraction;
    - E-7 c_ZL;
    - D_s for the L/u/w rules, rectifier stratum shares, and the F10a predicted displacement for
      seven estimators;
    - raw and within Pearson/Spearman correlations and QWK;
    - Exp-3 within-signal moment (every configuration);
    - E-10 lambda^ (clipped and raw), cond(H), n, N_u;
    - module-D base/augmented/incremental OOS R^2;
    - per-estimator and diagnostic runtime.

--------------------------------------------------------------------------------
5. COMMANDS
--------------------------------------------------------------------------------

  python3 -I -B fv1_run.py plan
  python3 -I -B fv1_run.py run --mode production --gate-record ../gates/FINAL_V1_GATE_RECORD.json
          [--workers 2] [--budget-min 100]      -> writes Final_Study_v1/run/
  python3 -I -B fv1_run.py status --out ../run
  Test mode (throwaway namespace; cannot write into Final_Study_v1/run):
  python3 -I -B fv1_run.py run --mode test --out DIR --configs C001,C094 --cap 20
          [--namespace PREFIX] [--inject E-7] [--no-e10]
  Each production chunk stops dispatching after --budget-min minutes and finishes the
  configurations in flight. Restart the same command to resume; the run is complete when the
  log's RUN_END says all_complete.

--------------------------------------------------------------------------------
6. COMPUTE
--------------------------------------------------------------------------------

  Measured on this machine (throwaway namespace, 100 panels each), per panel:
    - 30.1 ms for FULL + E-10 + D at N 300, T 8;
    - 50.2 ms for FULL at N 600;
    - 6.6 ms for X3 at T 16;
    - 27.8 ms for FULL + E-10 in a uniform-validation cell.
  Diagnostics account for about 9 ms of the 30 ms. This matches the record's 10.2 timing model
  (31 ms; N 600 was modelled at 68.7 ms): about 4.3-4.6 core-hours, roughly 2.3 hours on two
  workers, so two or three 100-minute chunks.

--------------------------------------------------------------------------------
7. CHECKS RUN DURING THE BUILD (none is a gate; all on throwaway namespaces)
--------------------------------------------------------------------------------

  tests/dev_equivalence.py (FV1_DEVEQ). On 10 panels each of C001 and C004:
    - E-1..E-9 equal s09_run.one exactly;
    - E-6H and E-12a/b/c equal e5_core.fit_all exactly;
    - the mechanism diagnostics equal fit_all (D_s and shares exactly; predicted displacement
      and Schur information to 1e-12);
    - the TDS wrappers equal s2_core.estimate_all(deltas=(0.10,)) exactly;
    - E-12a equals HT-TDS-CF where the floor does not bind;
    - FINAL_V1's parameters equal the frozen S0.9 parameterization field by field.
  tests/dev_e10_checks.py (FV1_DEVE10):
    - theta_lambda solves the rectified equation and lambda^ lies in [0, 1];
    - invariance to nuisance recoding, outcome span, target scaling and unit order, to <= 6e-14;
    - a structural comparison with ppi-python's OLS routines (Section 9). ppi-python was not
      executed; its logic was re-implemented from the 0.2.3 source.
  tests/test_mechanics.py (FV1_MT): 16 of 16 pass (Section 3).
  Before these, a 4-configuration smoke run (5 panels each) and the timing run above used
  namespaces FV1_MECHTEST and FV1_TIMING. Only schemas, failure details and runtimes were looked
  at; those outputs were deleted. All test outputs are deleted unread.

--------------------------------------------------------------------------------
8. WHAT THE GATES STEP MUST PRODUCE (the runner checks it before any production run)
--------------------------------------------------------------------------------

  Final_Study_v1/gates/FINAL_V1_GATE_RECORD.json:
    {"record_sha256": "bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0",
     "code_fingerprint": "<fv1.env.code_fingerprint() of the code the gates ran on>",
     "gates": {"G-A": "PASS", "G-B": "PASS", "G-C": "PASS", "G-D": "PASS",
               "G-E": "PASS" or "FAIL", "G-F": "PASS"},
     "e10_status": "COMPUTED" (requires G-E PASS) or "ABSENT" (V10 failed or not completed),
     "theta0_map": {"path": "gates/FINAL_V1_THETA0_MAP.json", "sha256": "<map hash>"}}
  The theta_0 map holds the 42 union keys plus the 11 new keys computed by the frozen procedure
  (compute_theta0, 20 panels of 120,000 units, contamination off). Do not compute it with
  theta0_for, which writes a cache file into the working directory. The runner requires a
  finite value for every configuration's key.

--------------------------------------------------------------------------------
9. OPEN ITEM FOR THE GATES STEP -- GATE V10.1 AS WORDED
--------------------------------------------------------------------------------

  Record 3.4, V10.1: in ppi-python's own setting, "the FINAL_V1 generic code ... reproduces
  ppi_ols_pointestimate and ppi_ols_ci (alpha 0.05) to 1e-8", with lambda given and estimated.
  Reading the ppi-python 0.2.3 source shows two structural differences from E-10's sealed
  definition. Both were confirmed with own numpy code (tests/dev_e10_checks.py, part 4-5):
  (i) ppi_ols_pointestimate computes an imputed fit plus a rectifier fit (two separate least
      squares). That equals the solution of the PPI++ M-estimation equation, which is E-10's
      definition, only when the labeled and unlabeled covariate Gram matrices coincide.
      Difference on generic data: 1.5e-2. With equal Gram matrices: 2e-15.
  (ii) ppi_ols_ci(lam=None) re-estimates lambda at the tuned point estimate and centres its
      interval there, whereas E-10 keeps the pilot lambda^ (record 3.4, step 3). The interval
      lambdas differed by 1.6e-2 to 5.6e-2 whenever lambda^ was interior.
  The lambda formula itself (V10.2) and the covariance block are ported line by line and are
  unaffected.
  Consequence: run as worded on generic synthetic data, V10.1 fails, and by record 3.4 E-10 is then
  ABSENT. Any change to V10's wording is a design decision for the authors. It must be recorded as
  a dated amendment before V10 is run.

================================================================================
END OF README_CODE.txt
================================================================================
