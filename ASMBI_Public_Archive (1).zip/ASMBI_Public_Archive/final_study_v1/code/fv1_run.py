#!/usr/bin/env python3
"""Entry point of the FINAL_V1 runner. See fv1/runner.py and README_CODE.txt.

    python3 -I -B fv1_run.py plan
    python3 -I -B fv1_run.py run --mode production --gate-record ../gates/FINAL_V1_GATE_RECORD.json
    python3 -I -B fv1_run.py status --out ../run
"""
import os
import sys

sys.dont_write_bytecode = True          # before fv1 is imported (no __pycache__ anywhere)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fv1.env  # noqa: E402,F401  (thread pinning and deps path, before numpy)
from fv1.runner import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
