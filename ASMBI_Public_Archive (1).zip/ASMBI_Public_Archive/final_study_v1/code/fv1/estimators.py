"""FINAL_V1 estimator wrappers (record Sections 3 and 5).

Every estimator is a separate call on the SAME panel object; a failure (returned or raised) is
recorded for that estimator only and never removes another estimator's result. The wrappers add
nothing to the frozen estimators except the pre-specified eligibility/failure rules of Section 5
and the classification of failures into the recorded failure types.

    E-1..E-9            frozen Stage-0 functions, called directly (E-3 and E-4 are one frozen call:
                        one point estimate, two variance estimators)
    E-6H, E-12a/b/c     e5_core.solve_rect with stage1_design_aware folds and weights, built exactly
                        as e5_core.fit_all builds them
    HT-TDS-I, PS-TDS-I, HT-TDS-CF
                        s2_core.designs / weights / schur_info / schur_solve / cr1_se, built exactly as
                        s2_core.estimate_all builds them, delta = 0.10 only
    E-10                fv1.e10 (new code, gated by V10)

Cross-fitted estimators (E-5, E-12a/b/c, HT-TDS-CF) each draw a fresh generator from the same
FINAL_V1_FOLDS key, so their fold assignments are identical.
"""
import math
from dataclasses import dataclass, field

import numpy as np
from scipy.stats import t as tdist

import fv1.env  # noqa: F401
from stage0_dgp import make_rng, within_demean
from stage0_naive import naive_fit
from stage0_labeled_only import labeled_only_fit
from stage0_ppi import ppi_fit
from stage0_crossppi import crossppi_fit
from stage0_ht import ht_fit
from stage0_rc import rc_fit
from stage0_cda import e8_fit, e9_fit
import e5_core
from stage1_design_aware import crossfit_predictions, rectifier_weights
import s2_core
from fv1 import e10

Z_CRIT = 1.959963984540054
TDS_DELTA = 0.10

# Failure types (record Section 5). 0 = success.
OK, BELOW_MIN, EMPTY_PS_FULL, EMPTY_PS_DEL, SINGULAR, NONFINITE, EXCEPTION = range(7)
FAIL_NAMES = ("ok", "below minimum (pre-specified eligibility/failure rule)",
              "empty post-stratum (full sample)", "empty post-stratum (jackknife deletion)",
              "singular system or invalid covariance", "non-finite estimate, SE or interval",
              "exception")

EST_NAMES = ("E-1", "E-2", "E-3", "E-4", "E-5", "E-6", "E-7", "E-8", "E-9", "E-6H", "E-12a", "E-12b",
             "E-12c", "HT-TDS-I", "PS-TDS-I", "HT-TDS-CF", "E-10")
EST_INDEX = {n: i for i, n in enumerate(EST_NAMES)}

# Schur-solver estimators and the predictor family that defines s_M (record 3.8)
SM_FAMILY = {"E-4": "I", "E-5": "CFu", "E-6": "I", "E-6H": "I", "E-12a": "CFu", "E-12b": "CFw",
             "E-12c": "CFw", "HT-TDS-I": "I", "PS-TDS-I": "I", "HT-TDS-CF": "CFu"}


@dataclass
class Result:
    est: float = math.nan
    se: float = math.nan
    crit: float = math.nan
    fail: int = OK
    detail: str = ""
    bind: int = -1            # floor/TDS binding flag: -1 not applicable, 0 not binding, 1 binding
    extras: dict = field(default_factory=dict)
    runtime: float = 0.0
    lo: float = math.nan
    hi: float = math.nan
    cover: int = -1           # 1/0; -1 failed or theta_0 not available
    reject: int = -1          # rejection of theta = 0; -1 failed


def failed(code, detail):
    return Result(fail=code, detail=detail)


class Rep:
    """One replication: the single panel shared by every estimator, plus its fold key."""
    __slots__ = ("pan", "D", "fold_key", "crit_e1", "N", "T", "G_S")

    def __init__(self, pan, D, fold_key, crit_e1):
        self.pan, self.D, self.fold_key, self.crit_e1 = pan, D, fold_key, crit_e1
        self.N, self.T = pan.Y.shape
        self.G_S = int(pan.labeled.sum())


# --------------------------------------------------------------------------- frozen Stage 0

def w_e1(rep):
    th, se = naive_fit(rep.pan, rep.D)
    return Result(th, se, rep.crit_e1)


def w_e2(rep):
    out = labeled_only_fit(rep.pan, rep.D)
    if out is None:
        return failed(BELOW_MIN, f"G_S = {rep.G_S} < 5 (frozen labeled_only_fit)")
    th, se, hw, g = out
    return Result(th, se, float(tdist.ppf(0.975, g - 1)))


def w_e34(rep):
    out = ppi_fit(rep.pan, rep.D)
    if out is None:
        f = f"G_S = {rep.G_S} < 5 (frozen ppi_fit)"
        return {"E-3": failed(BELOW_MIN, f), "E-4": failed(BELOW_MIN, f)}
    th, se_obs, se_cl = out
    return {"E-3": Result(th, se_obs, Z_CRIT), "E-4": Result(th, se_cl, Z_CRIT)}


def w_e5(rep):
    out = crossppi_fit(rep.pan, make_rng(*rep.fold_key), rep.D)
    if out is None:
        return failed(BELOW_MIN, f"G_S = {rep.G_S} < 10 (frozen crossppi_fit)")
    return Result(out[0], out[1], Z_CRIT)


def w_e6(rep):
    out = ht_fit(rep.pan, rep.D)
    if out is None:
        return failed(BELOW_MIN, f"G_S = {rep.G_S} < 5 (frozen ht_fit)")
    return Result(out[0], out[1], Z_CRIT)


def w_e7(rep):
    th, se, c_zl = rc_fit(rep.pan, rep.D)
    return Result(th, se, Z_CRIT, extras={"e7_cZL": c_zl})


def _cda_failure(reason):
    if reason == "empty post-stratum (full sample)":
        return EMPTY_PS_FULL
    if reason == "empty post-stratum (jackknife deletion)":
        return EMPTY_PS_DEL
    if reason == "sum d^4 = 0":
        return SINGULAR            # P20: degenerate jackknife, invalid covariance
    return EXCEPTION


def w_e8(rep):
    if rep.G_S < 5:                # inherits E-6's minimum (record Section 5, D12)
        return failed(BELOW_MIN, f"G_S = {rep.G_S} < 5 (E-8 inherits E-6's minimum)")
    out = e8_fit(rep.pan, rep.D)
    if "fail" in out:
        return failed(_cda_failure(out["fail"]), out["fail"])
    return Result(out["theta"], out["se"], out["crit"],
                  extras={"e8_nu_eff": out["nu_eff"], "e8_schur_full": out["schur_full"],
                          "e8_lmin_full": out["lmin_full"]})


def w_e9(rep):
    out = e9_fit(rep.pan, rep.D)
    if "fail" in out:
        return failed(_cda_failure(out["fail"]), out["fail"] + " (P19/P20)")
    return Result(out["theta"], out["se"], out["crit"], bind=int(bool(out["bind_full"])),
                  extras={"e9_bind_full": float(out["bind_full"]), "e9_shift_full": out["shift_full"],
                          "e9_nu_eff": out["nu_eff"], "e9_bind_jk_frac": out["bind_jk_frac"],
                          "e9_schur_full": out["schur_full"], "e9_lmin_full": out["lmin_full"]})


# --------------------------------------------------------------------------- Experiment 5

def _e5_design(rep):
    """y and the column builder exactly as e5_core.fit_all."""
    pan, D, N, T = rep.pan, rep.D, rep.N, rep.T
    y = within_demean(pan.Y).reshape(N * T)
    x = within_demean(pan.X).reshape(N * T)
    return y, (lambda Z: np.column_stack([within_demean(Z).reshape(N * T), x, D]))


def _solve_rect(rep, Wf, Wo, WH, y, rectifier, name):
    rw = np.repeat(rectifier_weights(rep.pan, rectifier), rep.T)
    out = e5_core.solve_rect(Wf, Wo, WH, y, rw, rep.N, rep.T)
    if out is None:
        return failed(SINGULAR, "singular rectified system (e5_core.solve_rect)")
    th, se, schur, _A = out
    return Result(th, se, Z_CRIT, extras={f"s_nt__{name}": schur})


def w_e6h(rep):
    if rep.G_S < 5:
        return failed(BELOW_MIN, f"G_S = {rep.G_S} < 5 (identity-family minimum)")
    y, W = _e5_design(rep)
    WL, WH = W(rep.pan.ZL.astype(float)), W(rep.pan.ZH)
    return _solve_rect(rep, WL, WL, WH, y, "hajek", "E-6H")


def _w_e12(rep, weighted, rectifier, name):
    if rep.G_S < 10:
        return failed(BELOW_MIN, f"G_S = {rep.G_S} < 10 (cross-fitted eligibility rule)")
    y, W = _e5_design(rep)
    Zf, Zo, _ = crossfit_predictions(rep.pan, make_rng(*rep.fold_key), weighted)
    return _solve_rect(rep, W(Zf), W(Zo), W(rep.pan.ZH), y, rectifier, name)


def w_e12a(rep):
    return _w_e12(rep, False, "ht", "E-12a")


def w_e12b(rep):
    return _w_e12(rep, True, "ht", "E-12b")


def w_e12c(rep):
    return _w_e12(rep, True, "uniform", "E-12c")


# --------------------------------------------------------------------------- Stage 2 (TDS)

def _tds(rep, family, kind, name):
    pan, D, N, T = rep.pan, rep.D, rep.N, rep.T
    need = 5 if family == "I" else 10
    if rep.G_S < need:
        return failed(BELOW_MIN, f"G_S = {rep.G_S} < {need} ({name} minimum)")
    if family == "I":
        Zf = Zo = pan.ZL
    else:
        Zf, Zo, _ = crossfit_predictions(pan, make_rng(*rep.fold_key), False)
    d = s2_core.designs(pan, D, Zf, Zo)
    f, o = s2_core.FAMS[family]
    sM = s2_core.schur_info(d[f].T @ d[f])
    w = s2_core.weights(pan, kind)
    if w is None:
        return failed(EMPTY_PS_FULL, "empty post-stratum (any n_s = 0; Stage-2 rule)")
    rw = np.repeat(w, T)
    Wf, Wo, WH, y = d[f], d[o], d["WH"], d["y"]
    A = Wf.T @ Wf + (WH * rw[:, None]).T @ WH - (Wo * rw[:, None]).T @ Wo
    g = Wf.T @ y + (WH * rw[:, None]).T @ y - (Wo * rw[:, None]).T @ y
    th, Au, s, bind = s2_core.schur_solve(A, g, sM, TDS_DELTA)
    se = s2_core.cr1_se(Au, th, Wf, Wo, WH, y, rw, N, T)
    return Result(float(th[0]), se, Z_CRIT, bind=int(bind),
                  extras={f"s_nt__{name}": s / (N * T), f"sM_nt__{name}": sM / (N * T),
                          f"s_over_sM__{name}": s / sM, f"tds_bind__{name}": float(bind)})


def w_ht_tds_i(rep):
    return _tds(rep, "I", "ht", "HT-TDS-I")


def w_ps_tds_i(rep):
    return _tds(rep, "I", "ps", "PS-TDS-I")


def w_ht_tds_cf(rep):
    return _tds(rep, "CF", "ht", "HT-TDS-CF")


# --------------------------------------------------------------------------- E-10

def w_e10(rep):
    out = e10.e10_fit(rep.pan, rep.D)
    if isinstance(out, dict):
        return failed(BELOW_MIN if out["fail"] == "below_min" else SINGULAR, out["detail"])
    th, se, extras = out
    return Result(th, se, Z_CRIT, extras=extras)


# --------------------------------------------------------------------------- batteries (record 3.6)

FULL = (("E-1", w_e1), ("E-2", w_e2), ("E-3/E-4", w_e34), ("E-5", w_e5), ("E-6", w_e6), ("E-7", w_e7),
        ("E-8", w_e8), ("E-9", w_e9), ("E-6H", w_e6h), ("E-12a", w_e12a), ("E-12b", w_e12b),
        ("E-12c", w_e12c), ("HT-TDS-I", w_ht_tds_i), ("PS-TDS-I", w_ps_tds_i), ("HT-TDS-CF", w_ht_tds_cf))
X3 = (("E-1", w_e1), ("E-7", w_e7), ("E-2", w_e2), ("E-6", w_e6))
D_ONLY = (("E-1", w_e1),)
E10 = (("E-10", w_e10),)


def _finalize(res, theta0):
    if res.fail == OK:
        vals = (res.est, res.se, res.crit)
        if not all(np.isfinite(v) for v in vals):
            res.fail, res.detail = NONFINITE, "non-finite estimate, SE or critical value"
        else:
            res.lo, res.hi = res.est - res.crit * res.se, res.est + res.crit * res.se
            if not (np.isfinite(res.lo) and np.isfinite(res.hi)):
                res.fail, res.detail = NONFINITE, "non-finite interval"
    if res.fail == OK:
        res.cover = int(res.lo <= theta0 <= res.hi) if np.isfinite(theta0) else -1
        res.reject = int(res.lo > 0.0 or res.hi < 0.0)
    else:
        res.lo = res.hi = math.nan
        res.cover = res.reject = -1
        res.bind = -1
    return res


def run_battery(battery, rep, theta0, perf_counter, inject=None):
    """Call every estimator of the battery separately. Returns {estimator name: Result}."""
    out = {}
    for name, fn in battery:
        t0 = perf_counter()
        try:
            if inject and name in inject:
                raise RuntimeError(f"injected test fault in {name}")
            with np.errstate(all="ignore"):
                res = fn(rep)
        except np.linalg.LinAlgError as ex:
            res = failed(SINGULAR, f"LinAlgError: {ex}")
        except Exception as ex:  # numerical exception of any other kind
            res = failed(EXCEPTION, f"{type(ex).__name__}: {ex}")
        dt = perf_counter() - t0
        if isinstance(res, dict):                  # E-3/E-4: one frozen call, two estimators
            parts = res
        elif name == "E-3/E-4":                    # the shared call itself failed
            parts = {"E-3": res, "E-4": Result(fail=res.fail, detail=res.detail)}
        else:
            parts = {name: res}
        for nm, r in parts.items():
            r.runtime = dt
            out[nm] = _finalize(r, theta0)
    return out
