"""Per-configuration checkpoints (record 10.1 step 5, 10.4).

<out>/raw/C###.npz      raw replication-level arrays of one configuration (written atomically:
                        .partial file, then rename)
<out>/raw/C###.sha256   "<sha256>  C###.npz" and "content <digest>"; written after the rename
<out>/raw/C###.started  marker written when a worker starts the configuration and removed after
                        the checkpoint is complete; a marker without a complete checkpoint at
                        start-up means the configuration was interrupted
A configuration is complete only if its .npz matches its .sha256 and its stored code fingerprint,
configuration id and namespace match the current run.
"""
import json, os, socket, time, datetime

import numpy as np

import fv1.env as env


def utc():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def paths(out_dir, cfg_name):
    raw = os.path.join(out_dir, "raw")
    return {k: os.path.join(raw, f"{cfg_name}{ext}") for k, ext in
            (("npz", ".npz"), ("sha", ".sha256"), ("started", ".started"), ("partial", ".npz.partial"))}


def mark_started(out_dir, cfg_name):
    p = paths(out_dir, cfg_name)
    os.makedirs(os.path.dirname(p["npz"]), exist_ok=True)
    with open(p["started"], "w") as fh:
        json.dump({"utc": utc(), "pid": os.getpid(), "host": socket.gethostname()}, fh)


def write(out_dir, cfg_name, arrays, meta_det, meta_run, digest):
    p = paths(out_dir, cfg_name)
    arrays = dict(arrays)
    arrays["meta_det"] = np.asarray(json.dumps(meta_det, sort_keys=True))
    arrays["meta_run"] = np.asarray(json.dumps(meta_run, sort_keys=True))
    with open(p["partial"], "wb") as fh:
        np.savez_compressed(fh, **arrays)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(p["partial"], p["npz"])
    sha = env.sha256_file(p["npz"])
    tmp = p["sha"] + ".tmp"
    with open(tmp, "w") as fh:
        fh.write(f"{sha}  {cfg_name}.npz\ncontent {digest}\n")
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, p["sha"])
    if os.path.exists(p["started"]):
        os.remove(p["started"])
    return sha


def read_sidecar(path):
    with open(path) as fh:
        lines = fh.read().splitlines()
    return lines[0].split("  ")[0], lines[1].split(" ", 1)[1]


def status(out_dir, cfg_name, expect):
    """'complete', 'missing', 'interrupted' or 'mismatch:<reason>' for one configuration."""
    p = paths(out_dir, cfg_name)
    has_npz, has_sha = os.path.exists(p["npz"]), os.path.exists(p["sha"])
    if not has_npz and not has_sha:
        return "interrupted" if (os.path.exists(p["started"]) or os.path.exists(p["partial"])) else "missing"
    if not (has_npz and has_sha):
        return "interrupted"
    sha, _digest = read_sidecar(p["sha"])
    if env.sha256_file(p["npz"]) != sha:
        return "interrupted"
    with np.load(p["npz"]) as z:
        meta = json.loads(str(z["meta_det"]))
    for k, v in expect.items():
        if meta.get(k) != v:
            return f"mismatch:{k}"
    return "complete"


def quarantine(out_dir, cfg_name):
    """Move every file of an interrupted configuration aside (kept for the log, never reused)."""
    p = paths(out_dir, cfg_name)
    qdir = os.path.join(out_dir, "quarantine")
    os.makedirs(qdir, exist_ok=True)
    moved = []
    stamp = time.strftime("%Y%m%dT%H%M%S", time.gmtime())
    for k in ("npz", "sha", "started", "partial"):
        if os.path.exists(p[k]):
            dst = os.path.join(qdir, f"{os.path.basename(p[k])}.{stamp}")
            os.replace(p[k], dst)
            moved.append(os.path.basename(dst))
    return moved


class Log:
    """Append-only JSON-lines run log, written by the parent process only."""

    def __init__(self, out_dir):
        os.makedirs(out_dir, exist_ok=True)
        self.path = os.path.join(out_dir, "RUN_LOG.jsonl")

    def event(self, event, **kw):
        rec = {"utc": utc(), "event": event, **kw}
        with open(self.path, "a") as fh:
            fh.write(json.dumps(rec, sort_keys=True) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        return rec
