"""Seed hierarchy (record Section 4). One study-wide hierarchy under STUDY_SEED "ASMBI-2026-09-22":

    seed = first 128 bits of SHA-256("STUDY_SEED|experiment_id|cell_id|r"), PCG64,
    implemented by the frozen stage0_dgp.make_rng / stage0_dgp.stream_key.

Experiment ids used by the runner: FINAL_V1_PANEL (panels), FINAL_V1_FOLDS (cross-fitting
folds; E-5, E-12a/b/c and HT-TDS-CF each draw a fresh generator from the SAME key, so their
folds are identical), FINAL_V1_OOS (module D out-of-sample folds). FINAL_V1_BOOT (analysis
bootstrap) and FINAL_V1_GATE (gates) are never touched by the runner.

cell_id is the registry's seed_cell_id: every factor except kappa, so configurations that differ
only in kappa share their base draws (common random numbers).

Mechanical tests use a separate throwaway namespace that can never collide with FINAL_V1 ids.
"""
from dataclasses import dataclass

import fv1.env  # noqa: F401  (thread pinning, deps path)
from stage0_dgp import STUDY_SEED, make_rng, stream_key

assert STUDY_SEED == "ASMBI-2026-09-22"

PRODUCTION_PREFIX = "FINAL_V1"
RESERVED = ("FINAL_V1_BOOT", "FINAL_V1_GATE")


@dataclass(frozen=True)
class Namespace:
    panel: str
    folds: str
    oos: str

    @property
    def is_production(self):
        return self.panel == "FINAL_V1_PANEL"


PRODUCTION = Namespace("FINAL_V1_PANEL", "FINAL_V1_FOLDS", "FINAL_V1_OOS")


def test_namespace(prefix="FV1_MECHTEST"):
    """Throwaway namespace for mechanical tests. Must not start with FINAL_V1."""
    if prefix.upper().startswith(PRODUCTION_PREFIX):
        raise ValueError("test namespaces may not use the FINAL_V1 prefix")
    return Namespace(f"{prefix}_PANEL", f"{prefix}_FOLDS", f"{prefix}_OOS")


def panel_rng(ns, seed_cell_id, r):
    return make_rng(ns.panel, seed_cell_id, r)


def fold_key(ns, seed_cell_id, r):
    """Arguments for make_rng; every cross-fitted estimator builds its own generator from this."""
    return (ns.folds, seed_cell_id, r)


def oos_rng(ns, seed_cell_id, r):
    return make_rng(ns.oos, seed_cell_id, r)


def keys_for(ns, seed_cell_id, r):
    return (stream_key(ns.panel, seed_cell_id, r), stream_key(ns.folds, seed_cell_id, r),
            stream_key(ns.oos, seed_cell_id, r))
