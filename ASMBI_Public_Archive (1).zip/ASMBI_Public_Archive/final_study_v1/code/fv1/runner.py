"""FINAL_V1 run orchestration (record 10.1 steps 5-6).

    plan     list configurations, batteries, replication counts and the compute estimate (no simulation)
    run      compute missing configurations with worker processes, one checkpoint per configuration
    status   run health only: completion, failure counts, runtime (record D13; nothing else is read)

Production (--mode production) requires the gate record written by the gates step; it uses the
FINAL_V1 seed ids, the sealed theta_0 map named in the gate record, every configuration and the full
replication counts, and writes to Final_Study_v1/run/. Mechanical tests (--mode test) use a throwaway
namespace, the frozen theta_0 union (NaN where a key is missing), optional replication caps and fault
injection, and may never write into Final_Study_v1/run/.

Restart: configurations are taken in frozen-registry order; complete checkpoints are kept, an
interrupted configuration (marker or partial file without a verified checkpoint) is moved to
quarantine/ and recomputed from its identical seeds, and the event is logged.
"""
import argparse, json, multiprocessing, os, sys, time

import numpy as np

import fv1.env as env
from fv1 import compute, estimators as E, registry, seeds, store, theta0 as T0

GATES_REQUIRED = ("G-A", "G-B", "G-C", "G-D", "G-F")


# --------------------------------------------------------------------------- setup

def _gate_record(path, fingerprint, study_root):
    with open(path) as fh:
        rec = json.load(fh)
    gates = rec.get("gates", {})
    for g in GATES_REQUIRED:
        if gates.get(g) != "PASS":
            raise SystemExit(f"gate {g} is {gates.get(g)!r}, not PASS: production run refused")
    e10 = rec.get("e10_status")
    if e10 == "COMPUTED":
        if gates.get("G-E") != "PASS":
            raise SystemExit("E-10 marked COMPUTED but V10 (G-E) did not pass")
    elif e10 == "ABSENT":
        if gates.get("G-E") == "PASS":
            raise SystemExit("V10 passed but E-10 marked ABSENT")
    else:
        raise SystemExit(f"e10_status must be COMPUTED or ABSENT, not {e10!r}")
    if rec.get("code_fingerprint") != fingerprint:
        raise SystemExit("the gates were run on a different code fingerprint: production run refused")
    if rec.get("record_sha256") != env.SEALED["FINAL_V1_PRE_RUN_RECORD_FROZEN.txt"]:
        raise SystemExit("gate record does not name the sealed pre-run record")
    tm = rec["theta0_map"]
    tpath = tm["path"] if os.path.isabs(tm["path"]) else os.path.join(study_root, tm["path"])
    return rec, tpath, tm["sha256"], e10


def _settings(args):
    study_root = os.path.abspath(args.study_root or env.default_study_root())
    deps_rec, deps_sha = env.verify_deps()
    configs, prov = registry.load(study_root)
    fp, per_file = env.code_fingerprint()
    if args.mode == "production":
        for opt in ("cap", "inject", "configs", "namespace"):
            if getattr(args, opt, None):
                raise SystemExit(f"--{opt} is not allowed in production mode")
        if not args.gate_record:
            raise SystemExit("production mode needs --gate-record")
        _rec, tpath, tsha, e10 = _gate_record(args.gate_record, fp, study_root)
        gate_sha = env.sha256_file(args.gate_record)
        ns = seeds.PRODUCTION
        th = T0.lookup(T0.load_production_map(tpath, tsha), configs, require_all=True)
        out_dir = os.path.abspath(args.out or os.path.join(study_root, "run"))
        selected, cap, inject, tmap_sha = configs, None, None, tsha
    else:
        ns = seeds.test_namespace(args.namespace or "FV1_MECHTEST")
        if not args.out:
            raise SystemExit("test mode needs --out")
        out_dir = os.path.abspath(args.out)
        prod_dir = os.path.join(study_root, "run")
        if out_dir == prod_dir or out_dir.startswith(prod_dir + os.sep):
            raise SystemExit("test output may not be written into Final_Study_v1/run")
        th = T0.lookup(T0.frozen_union(), configs, require_all=False)
        e10 = "DISABLED_TEST" if args.no_e10 else "COMPUTED_TEST"
        want = set(args.configs.split(",")) if args.configs else None
        selected = [c for c in configs if want is None or c.name in want]
        cap, inject, tmap_sha = args.cap, set(args.inject.split(",")) if args.inject else None, "frozen-union(test)"
        gate_sha = None
    return dict(study_root=study_root, configs=configs, selected=selected, prov=prov, deps_sha=deps_sha,
                fingerprint=fp, per_file=per_file, ns=ns, theta0=th, e10=e10, out_dir=out_dir, cap=cap,
                inject=inject, theta0_map_sha256=tmap_sha, gate_record_sha256=gate_sha)


def _meta_det(S, cfg):
    p = cfg.p
    return {
        "config": cfg.name, "config_id": cfg.config_id, "seed_cell_id": cfg.seed_cell_id,
        "kappa": repr(cfg.kappa), "modules": list(cfg.modules), "R_registry": cfg.R,
        "namespace": {"panel": S["ns"].panel, "folds": S["ns"].folds, "oos": S["ns"].oos},
        "production": S["ns"].is_production, "theta0_key": cfg.theta0_key,
        "theta0": repr(S["theta0"][cfg.index]), "theta0_map_sha256": S["theta0_map_sha256"],
        "gate_record_sha256": S["gate_record_sha256"],
        "dgp_params": {k: repr(v) for k, v in vars(p).items()},
        "cut_spacing_effective": repr(p.cut_spacing), "e10": S["e10"],
        "code_fingerprint": S["fingerprint"], "deps_record_sha256": S["deps_sha"],
        "sealed": S["prov"]["sealed_files"], "cap": S["cap"], "inject": sorted(S["inject"] or []),
        "estimators": list(E.EST_NAMES), "failure_codes": list(E.FAIL_NAMES),
    }


def _expect(S, cfg):
    m = _meta_det(S, cfg)
    return {k: m[k] for k in ("config_id", "code_fingerprint", "namespace", "theta0", "e10", "cap", "inject",
                              "deps_record_sha256", "theta0_map_sha256")}


# --------------------------------------------------------------------------- worker

def _work(task):
    cfg, ns, th0, e10, out_dir, cap, inject, meta_det = task
    store.mark_started(out_dir, cfg.name)
    start, t0 = store.utc(), time.time()
    arrays, info = compute.run_configuration(cfg, ns, th0, e10 in ("COMPUTED", "COMPUTED_TEST"), cap, inject)
    digest = compute.content_digest({**arrays, "meta_det": np.asarray(json.dumps(meta_det, sort_keys=True))})
    meta_run = {"start_utc": start, "end_utc": store.utc(), "wall_s": time.time() - t0, "pid": os.getpid(),
                "environment": env.environment_record(), "R_used": info["R_used"]}
    sha = store.write(out_dir, cfg.name, arrays, meta_det, meta_run, digest)
    fails = {}
    for e_idx, code in zip(arrays["rows_est"], arrays["rows_fail"]):
        if code:
            key = f"{E.EST_NAMES[e_idx]}:{int(code)}"
            fails[key] = fails.get(key, 0) + 1
    return {"config": cfg.name, "wall_s": round(time.time() - t0, 2), "panel_reps": info["R_panel"],
            "rows": int(arrays["rows_r"].size), "failures": fails, "content_digest": digest, "sha256": sha}


# --------------------------------------------------------------------------- commands

def cmd_plan(args):
    configs, prov = registry.load(os.path.abspath(args.study_root or env.default_study_root()))
    tot = {b: 0 for b in registry.BATTERIES}
    for c in configs:
        for b in tot:
            tot[b] += c.R[b]
        print(f"{c.name}  R_panel {c.R_panel:5d}  " + "  ".join(f"{b} {c.R[b]:5d}" for b in registry.BATTERIES)
              + f"  est {c.est_core_seconds:7.1f}s  {c.modules}")
    print(f"configurations {len(configs)}; panel replications {prov['panel_replications']}; battery "
          f"replications {tot}; estimated {sum(c.est_core_seconds for c in configs) / 3600:.2f} core-hours")
    return 0


def cmd_run(args):
    S = _settings(args)
    log = store.Log(S["out_dir"])
    log.event("RUN_START", mode=args.mode, namespace=vars(S["ns"]), e10=S["e10"], workers=args.workers,
              budget_min=args.budget_min, code_fingerprint=S["fingerprint"], code_files=S["per_file"],
              deps_record_sha256=S["deps_sha"], registry={k: v for k, v in S["prov"].items()
                                                          if k != "build_registry_stdout"},
              environment=env.environment_record(), selected=len(S["selected"]), cap=S["cap"],
              inject=sorted(S["inject"] or []), theta0_map_sha256=S["theta0_map_sha256"],
              gate_record_sha256=S["gate_record_sha256"])
    pending, complete = [], 0
    for cfg in S["selected"]:
        st = store.status(S["out_dir"], cfg.name, _expect(S, cfg))
        if st == "complete":
            complete += 1
            continue
        if st.startswith("mismatch"):
            log.event("REFUSED", config=cfg.name, reason=st)
            raise SystemExit(f"{cfg.name}: existing checkpoint does not match this run ({st}); use a new --out")
        if st == "interrupted":
            moved = store.quarantine(S["out_dir"], cfg.name)
            log.event("INTERRUPTED_RECOMPUTE", config=cfg.name, quarantined=moved,
                      note="recomputed from its identical seeds")
        pending.append(cfg)
    log.event("PLAN", complete=complete, pending=len(pending), first_pending=pending[0].name if pending else None)
    budget = args.budget_min * 60.0
    t_start = time.time()
    ctx = multiprocessing.get_context("spawn")
    stopped = False
    with ctx.Pool(args.workers) as pool:
        inflight, queue = {}, list(pending)
        while queue or inflight:
            while queue and len(inflight) < args.workers and not stopped:
                if time.time() - t_start > budget:
                    stopped = True
                    log.event("BUDGET_STOP", elapsed_s=round(time.time() - t_start, 1), remaining=len(queue))
                    break
                cfg = queue.pop(0)
                task = (cfg, S["ns"], S["theta0"][cfg.index], S["e10"], S["out_dir"], S["cap"], S["inject"],
                        _meta_det(S, cfg))
                log.event("CONFIG_START", config=cfg.name)
                inflight[cfg.name] = pool.apply_async(_work, (task,))
            done = [k for k, a in inflight.items() if a.ready()]
            for k in done:
                a = inflight.pop(k)
                try:
                    log.event("CONFIG_DONE", **a.get())
                except Exception as ex:  # noqa: BLE001
                    log.event("CONFIG_ERROR", config=k, error=f"{type(ex).__name__}: {ex}")
                    pool.terminate()
                    raise SystemExit(f"{k} failed: {ex}")
            if not done:
                time.sleep(0.2)
            if stopped and not inflight:
                break
    n_done = sum(store.status(S["out_dir"], c.name, _expect(S, c)) == "complete" for c in S["selected"])
    log.event("RUN_END", complete=n_done, selected=len(S["selected"]), elapsed_s=round(time.time() - t_start, 1),
              all_complete=(n_done == len(S["selected"])))
    print(f"complete {n_done}/{len(S['selected'])}")
    return 0 if n_done == len(S["selected"]) or stopped else 1


def cmd_status(args):
    """Run health only (record D13): completion, failure counts by estimator and type, runtime."""
    out_dir = os.path.abspath(args.out)
    raw = os.path.join(out_dir, "raw")
    names = sorted(f[:-4] for f in os.listdir(raw) if f.endswith(".npz")) if os.path.isdir(raw) else []
    wall, fails, n_ok = 0.0, {}, 0
    for nm in names:
        side = os.path.join(raw, nm + ".sha256")
        if not os.path.exists(side):
            continue
        n_ok += 1
        with np.load(os.path.join(raw, nm + ".npz")) as z:       # only health fields are read
            wall += json.loads(str(z["meta_run"]))["wall_s"]
            for e_idx, code in zip(z["rows_est"], z["rows_fail"]):
                if code:
                    k = (E.EST_NAMES[e_idx], E.FAIL_NAMES[code])
                    fails[k] = fails.get(k, 0) + 1
    print(f"checkpoints complete: {n_ok}   worker wall time: {wall / 3600:.2f} h")
    for (e, f), n in sorted(fails.items()):
        print(f"  failures  {e:<10} {f:<55} {n}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="fv1_run.py")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("plan"); a.add_argument("--study-root")
    a = sub.add_parser("run")
    a.add_argument("--mode", choices=("production", "test"), required=True)
    a.add_argument("--study-root"); a.add_argument("--out"); a.add_argument("--gate-record")
    a.add_argument("--workers", type=int, default=2); a.add_argument("--budget-min", type=float, default=100.0)
    a.add_argument("--configs", help="test only: comma-separated C### names")
    a.add_argument("--cap", type=int, help="test only: cap every battery's replication count")
    a.add_argument("--namespace", help="test only: throwaway seed namespace prefix")
    a.add_argument("--inject", help="test only: estimator names to fail by an injected exception")
    a.add_argument("--no-e10", action="store_true", help="test only: skip E-10")
    a = sub.add_parser("status"); a.add_argument("--out", required=True)
    args = ap.parse_args(argv)
    return {"plan": cmd_plan, "run": cmd_run, "status": cmd_status}[args.cmd](args)
