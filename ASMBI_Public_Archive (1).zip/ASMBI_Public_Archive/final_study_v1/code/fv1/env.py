"""Process environment, paths and integrity checks. Import this module before numpy.

- Pins BLAS/OpenMP to one thread per process, so that results do not depend on thread
  scheduling and two worker processes use the two cores without oversubscription.
- Disables bytecode writing, so importing the frozen modules never writes into deps/.
- Puts deps/ (hash-verified copies of the frozen code) first on sys.path.
"""
import hashlib, json, os, sys

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
sys.dont_write_bytecode = True

CODE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEPS_DIR = os.path.join(CODE_DIR, "deps")
FV1_DIR = os.path.join(CODE_DIR, "fv1")
if DEPS_DIR not in sys.path:
    sys.path.insert(0, DEPS_DIR)

# Sealed FINAL_V1 files this code is written to (FINAL_V1_FROZEN.sha256, MANIFEST_SHA256_FROZEN.txt).
SEALED = {
    "FINAL_V1_PRE_RUN_RECORD_FROZEN.txt": "bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0",
    "FINAL_V1_CELL_REGISTRY_FROZEN.csv": "cdabf9992572e868146910117cc9177369762f686bfa469e4d6f954420f0ac2e",
    "build_registry.py": "a1591088026a7034aa60f3241d6988fd38dc2698216c9d45f2f5c18cb5e7243b",
}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def default_study_root():
    """Final_Study_v1/ is the parent of code/."""
    return os.path.dirname(CODE_DIR)


def verify_sealed(study_root):
    """The sealed record, registry and registry script must match their seal hashes."""
    out = {}
    for name, want in SEALED.items():
        got = sha256_file(os.path.join(study_root, name))
        if got != want:
            raise RuntimeError(f"sealed file {name}: SHA-256 {got} != sealed {want}")
        out[name] = got
    return out


def verify_deps():
    """Every deps/ file must match deps/DEPENDENCY_HASHES.json (which was checked against the
    sealed manifests when the copies were made). Returns (record, sha of the record file)."""
    rec_path = os.path.join(DEPS_DIR, "DEPENDENCY_HASHES.json")
    with open(rec_path) as fh:
        rec = json.load(fh)
    for dest, info in rec.items():
        if dest.startswith("_"):
            continue
        got = sha256_file(os.path.join(DEPS_DIR, dest))
        if got != info["sha256"]:
            raise RuntimeError(f"dependency {dest}: SHA-256 {got} != recorded {info['sha256']}")
    return rec, sha256_file(rec_path)


def code_fingerprint():
    """SHA-256 of every fv1 source file and the entry script; stored in every output so results are tied to code."""
    files = sorted(f for f in os.listdir(FV1_DIR) if f.endswith(".py"))
    per = {f"fv1/{f}": sha256_file(os.path.join(FV1_DIR, f)) for f in files}
    per["fv1_run.py"] = sha256_file(os.path.join(CODE_DIR, "fv1_run.py"))
    combined = hashlib.sha256("".join(f"{v}  {k}\n" for k, v in per.items()).encode()).hexdigest()
    return combined, per


def environment_record():
    import platform
    import numpy, scipy
    return {
        "python": sys.version.split()[0], "numpy": numpy.__version__, "scipy": scipy.__version__,
        "platform": platform.platform(), "machine": platform.machine(),
        "processor": platform.processor() or "", "cpu_count": os.cpu_count(),
        "threads": {v: os.environ.get(v) for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")},
    }
