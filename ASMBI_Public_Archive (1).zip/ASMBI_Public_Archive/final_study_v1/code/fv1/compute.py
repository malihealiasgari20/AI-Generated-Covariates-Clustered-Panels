"""One configuration, all its replications (record 2.2, 3.6, 4, 10.4).

For replication r = 0..R_panel-1 a single panel is generated from FINAL_V1_PANEL|seed_cell_id|r and
shared by every estimator that the configuration's modules need at r:
    r < R_FULL                FULL battery + record-3.8 diagnostics
    r < R_X3 (no FULL rows)   X3 battery (E-1, E-7, E-2, E-6); with FULL rows the X3 battery is read
                              from them and is not computed again
    r < R_E10                 E-10 (only if the gate record says E-10 is computed)
    r < R_D                   module-D measures; E-1 from the FULL rows where they exist
No estimator is computed twice for one replication. Nothing is aggregated over replications.
"""
import hashlib, math, time

import numpy as np
from scipy.stats import t as tdist

import fv1.env  # noqa: F401
from stage0_dgp import generate_panel
from stage0_naive import _period_design
from fv1 import diagnostics, estimators as E, seeds

ROW_FIELDS = (("r", np.int32), ("est", np.int8), ("estimate", np.float64), ("se", np.float64),
              ("crit", np.float64), ("lo", np.float64), ("hi", np.float64), ("cover", np.int8),
              ("reject", np.int8), ("fail", np.int8), ("bind", np.int8), ("runtime", np.float32))
NONDETERMINISTIC = ("rows_runtime", "diag__diag_runtime", "meta_run")


def _panel_digest(pan):
    h = hashlib.sha256()
    for a in (pan.Y, pan.ZH, pan.ZL, pan.X, pan.labeled, pan.strata, pan.u, pan.eps):
        h.update(np.ascontiguousarray(a).tobytes())
    return h.digest()


class _Rows:
    def __init__(self):
        self.cols = {k: [] for k, _ in ROW_FIELDS}
        self.fail_row, self.fail_detail = [], []

    def add(self, r, results):
        for name, res in results.items():
            if res.fail != E.OK:
                self.fail_row.append(len(self.cols["r"]))
                self.fail_detail.append(res.detail)
            for k, v in (("r", r), ("est", E.EST_INDEX[name]), ("estimate", res.est), ("se", res.se),
                         ("crit", res.crit), ("lo", res.lo), ("hi", res.hi), ("cover", res.cover),
                         ("reject", res.reject), ("fail", res.fail), ("bind", res.bind),
                         ("runtime", res.runtime)):
                self.cols[k].append(v)

    def arrays(self):
        out = {f"rows_{k}": np.asarray(self.cols[k], dtype=t) for k, t in ROW_FIELDS}
        out["fail_row"] = np.asarray(self.fail_row, dtype=np.int32)
        out["fail_detail"] = np.asarray(self.fail_detail, dtype=str) if self.fail_detail else np.zeros(0, "<U1")
        return out


class _Diag:
    def __init__(self, n):
        self.n, self.cols = n, {}

    def put(self, r, values):
        for k, v in values.items():
            a = self.cols.get(k)
            if a is None:
                a = self.cols[k] = np.full(self.n, np.nan)
            a[r] = v

    def arrays(self):
        return {f"diag__{k}": v for k, v in sorted(self.cols.items())}


def run_configuration(cfg, ns, theta0, e10_enabled, cap=None, inject=None, perf_counter=time.perf_counter):
    """Compute every replication of one configuration. Returns a dict of arrays (raw only)."""
    p = cfg.p
    N, T = p.N, p.T
    R = dict(cfg.R)
    if cap is not None:                       # mechanical tests only
        R = {b: min(v, cap) for b, v in R.items()}
    if not e10_enabled:
        R["E10"] = 0
    R_panel = max(R.values())                 # FULL rows always cover E-10 (registry invariant)
    D = _period_design(N, T)
    crit_e1 = float(tdist.ppf(0.975, N - 1))
    rows, diag = _Rows(), _Diag(R_panel)
    key_panel, key_folds, key_oos = [], [], []
    for r in range(R_panel):
        pan = generate_panel(p, seeds.panel_rng(ns, cfg.seed_cell_id, r))
        rep = E.Rep(pan, D, seeds.fold_key(ns, cfg.seed_cell_id, r), crit_e1)
        k_pan, k_fold, k_oos = seeds.keys_for(ns, cfg.seed_cell_id, r)
        before = _panel_digest(pan)
        diag.put(r, diagnostics.basic(rep))
        t_diag = 0.0
        if r < R["FULL"]:
            res = E.run_battery(E.FULL, rep, theta0, perf_counter, inject)
            rows.add(r, res)
            t0 = perf_counter()
            vals, bad = diagnostics.full(rep, res, theta0)
            t_diag += perf_counter() - t0
            vals.update({f"diag_fail__{b.split(':')[0]}": 1.0 for b in bad})
            diag.put(r, vals)
        elif r < R["X3"]:
            res = E.run_battery(E.X3, rep, theta0, perf_counter, inject)
            rows.add(r, res)
            diag.put(r, {k: v for x in res.values() for k, v in x.extras.items()})
        if r < R["E10"]:
            res = E.run_battery(E.E10, rep, theta0, perf_counter, inject)
            rows.add(r, res)
            diag.put(r, res["E-10"].extras)
        if r < R["D"]:
            t0 = perf_counter()
            if R["FULL"] == 0:
                res = E.run_battery(E.D_ONLY, rep, theta0, perf_counter, inject)
                rows.add(r, res)
                try:
                    with np.errstate(all="ignore"):
                        diag.put(r, diagnostics.assoc(rep))
                except Exception:  # noqa: BLE001
                    diag.put(r, {"diag_fail__assoc": 1.0})
            try:
                with np.errstate(all="ignore"):
                    diag.put(r, diagnostics.oos_r2(rep, seeds.oos_rng(ns, cfg.seed_cell_id, r)))
            except Exception:  # noqa: BLE001
                diag.put(r, {"diag_fail__oos": 1.0})
            t_diag += perf_counter() - t0
        if _panel_digest(pan) != before:
            raise RuntimeError(f"{cfg.name} r={r}: an estimator modified the shared panel")
        diag.put(r, {"diag_runtime": t_diag})
        key_panel.append(k_pan)
        key_folds.append(k_fold if (r < R["FULL"]) else "")
        key_oos.append(k_oos if r < R["D"] else "")
    out = rows.arrays()
    out.update(diag.arrays())
    out["key_panel"] = np.asarray(key_panel, dtype=str)
    out["key_folds"] = np.asarray(key_folds, dtype=str)
    out["key_oos"] = np.asarray(key_oos, dtype=str)
    out["est_names"] = np.asarray(E.EST_NAMES, dtype=str)
    out["fail_names"] = np.asarray(E.FAIL_NAMES, dtype=str)
    return out, {"R_used": R, "R_panel": R_panel, "theta0": theta0}


def content_digest(arrays):
    """SHA-256 over every deterministic array (runtime fields and run metadata excluded)."""
    h = hashlib.sha256()
    for k in sorted(arrays):
        if k in NONDETERMINISTIC:
            continue
        a = np.asarray(arrays[k])
        h.update(k.encode()); h.update(str(a.dtype).encode()); h.update(str(a.shape).encode())
        h.update(np.ascontiguousarray(a).tobytes())
    return h.hexdigest()
