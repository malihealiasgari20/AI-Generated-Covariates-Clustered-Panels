"""Configurations of FINAL_V1, taken from the sealed registry arithmetic.

The frozen companion script build_registry.py is executed (unchanged, hash-checked) in a
temporary directory. The CSV it writes must be byte-identical to FINAL_V1_CELL_REGISTRY_FROZEN.csv;
its in-memory configurations then supply the exact DGP parameters of every registry row (the CSV
holds 12-digit labels, the script holds the exact values produced by the frozen rules).

Fixed absolute cut points (record 1.2): each configuration runs with
    cut_spacing = 0.8050009202070365 / latent_reference_sd(configuration).
"""
import contextlib, csv, io, os, runpy, tempfile
from dataclasses import dataclass, replace, asdict

import fv1.env as env
from stage0_dgp import DGPParams, latent_reference_sd

REF_SCALE_SEALED = 0.8050009202070365
N_CONFIGS = 149
N_PANEL_REPS = 567_000
BATTERIES = ("FULL", "E10", "X3", "D")


@dataclass
class Config:
    index: int
    config_id: str
    seed_cell_id: str
    kappa: float
    modules: tuple
    R: dict
    theta0_key: str
    expected_labeled: str
    est_core_seconds: float
    p_frozen: DGPParams
    p: DGPParams

    @property
    def name(self):
        return f"C{self.index:03d}"

    @property
    def R_panel(self):
        return max(self.R.values())

    def describe(self):
        d = asdict(self.p)
        return {k: (list(v) if isinstance(v, tuple) else v) for k, v in d.items()}


def _rebuild(study_root):
    script = os.path.join(study_root, "build_registry.py")
    cwd = os.getcwd()
    buf = io.StringIO()
    with tempfile.TemporaryDirectory(prefix="fv1_registry_") as tmp:
        try:
            os.chdir(tmp)
            with contextlib.redirect_stdout(buf):
                ns = runpy.run_path(script, run_name="fv1_registry_rebuild")
            with open(os.path.join(tmp, "FINAL_V1_CELL_REGISTRY.csv"), "rb") as fh:
                rebuilt = fh.read()
        finally:
            os.chdir(cwd)
    return ns, rebuilt, buf.getvalue()


def load(study_root=None):
    """Return (configs in frozen-registry order, provenance dict). Raises on any mismatch."""
    study_root = study_root or env.default_study_root()
    sealed = env.verify_sealed(study_root)
    ns, rebuilt, printed = _rebuild(study_root)
    frozen_path = os.path.join(study_root, "FINAL_V1_CELL_REGISTRY_FROZEN.csv")
    with open(frozen_path, "rb") as fh:
        frozen = fh.read()
    if rebuilt != frozen:
        raise RuntimeError("build_registry.py output is not byte-identical to the frozen registry")
    ref = ns["REF_SCALE"]
    if ref != REF_SCALE_SEALED:
        raise RuntimeError(f"frozen absolute cut scale {ref!r} != {REF_SCALE_SEALED!r}")
    built = ns["configs"]
    rows = list(csv.DictReader(io.StringIO(frozen.decode())))
    configs, n_at_065 = [], 0
    for i, row in enumerate(rows, start=1):
        c = built[row["config_id"]]
        assert c["seed_id"] == row["seed_cell_id"]
        assert row["seed_cell_id"] == row["config_id"].rsplit("|kappa=", 1)[0], "kappa must not enter the seed key"
        assert "kappa" not in row["seed_cell_id"]
        R = {b: int(row[f"R_{b}"]) for b in BATTERIES}
        assert R == {b: c["R"].get(b, 0) for b in BATTERIES}
        assert row["modules"] == "+".join(sorted(c["modules"]))
        p0 = c["p"]
        cs = ref / latent_reference_sd(p0)
        assert abs(latent_reference_sd(p0) * cs - ref) < 1e-14
        p = replace(p0, cut_spacing=cs)
        baseline_scale = (p0.sd_e == 0.55 and p0.sd_ZH_within == 0.62 and tuple(p0.lambda1) == (1.20, 1.05, 0.45))
        if baseline_scale:
            if cs != 0.65:
                raise RuntimeError(f"{row['config_id']}: baseline-scale configuration has cut_spacing {cs!r}, not 0.65")
            n_at_065 += 1
        # battery-sharing invariants of record 2.2 (subset batteries read from FULL rows)
        if R["FULL"]:
            assert R["X3"] <= R["FULL"] and R["D"] <= R["FULL"] and R["E10"] <= R["FULL"]
        else:
            assert R["E10"] == 0 and (R["X3"] == 0 or R["D"] == 0)
        configs.append(Config(index=i, config_id=row["config_id"], seed_cell_id=row["seed_cell_id"],
                              kappa=float(p.kappa), modules=tuple(row["modules"].split("+")), R=R,
                              theta0_key=row["theta0_key"], expected_labeled=row["expected_labeled_clusters"],
                              est_core_seconds=float(row["est_core_seconds"]), p_frozen=p0, p=p))
    if len(configs) != N_CONFIGS:
        raise RuntimeError(f"{len(configs)} configurations, expected {N_CONFIGS}")
    total = sum(c.R_panel for c in configs)
    if total != N_PANEL_REPS:
        raise RuntimeError(f"{total} panel replications, expected {N_PANEL_REPS}")
    if n_at_065 != 87:
        raise RuntimeError(f"{n_at_065} configurations at the baseline latent scale, expected 87")
    prov = {"sealed_files": sealed, "registry_rebuild": "byte-identical", "ref_scale": repr(ref),
            "configs": len(configs), "panel_replications": total, "baseline_scale_configs": n_at_065,
            "build_registry_stdout": printed}
    return configs, prov
