"""E-10: PPI++-style general M-estimation comparator, unweighted for the validation design
(record Section 3.4; new code, gated by V10 -- if V10 fails, E-10 is ABSENT, no substitute).

Units are the data points. Labeled set L = {R_i = 1} (n = G_S), unlabeled set U = {R_i = 0}
(N_u = N - G_S). Unit loss l_i(theta; Z) = 1/2 ||y~_i - W~_i(Z) theta||^2 with W~_i(Z) = [Z~, X~, D~];
its gradient is A_i(Z) theta - b_i(Z) with A_i = W~_i'W~_i and b_i = W~_i'y~_i (the frozen per-cluster
contributions of stage0_cda.contributions). True covariate Z_H; prediction Z_L (identity predictor).

    theta_lambda solves (1/n) sum_L grad l_i(theta; Z_H)
                        + lambda [ (1/N_u) sum_U grad l_i(theta; Z_L) - (1/n) sum_L grad l_i(theta; Z_L) ] = 0
    1. pilot lambda = 1
    2. H = (1/n) sum_L A_i(Z_H)            (labeled-data Hessian of the true loss, Algorithm 2)
    3. lambda^ = _calc_lam_glm(grads, grads_hat, grads_hat_unlabeled, inv(H), coord=0, clip=True)
       evaluated at the pilot (ppi-python 0.2.3 rule, ported line by line below)
    4. theta^ = theta_lambda^; variance inv(H)[(n/N_u) Cov_U(lambda^ grad^f) + Cov_L(grad - lambda^ grad^f)]inv(H)
       at theta^ (ddof 1; ppi_ols_ci's structure with unit-level gradients), SE = sqrt(Sigma_00 / n),
       normal critical value.
Failure: G_S < 5, N_u < 2, cond(H) > 1e12, or any non-finite output.

The generic pieces (calc_lam_glm, ppi_sigma, theta_lambda) take per-unit arrays so that gate V10
can feed them ppi-python's own setting and Hessian convention.
"""
import numpy as np

import fv1.env  # noqa: F401
from stage0_cda import contributions

Z_CRIT = 1.959963984540054
COND_MAX = 1e12
MIN_LABELED = 5
MIN_UNLABELED = 2


def _reshape_to_2d(x):
    """ppi_py.utils.statistics_utils.reshape_to_2d (0.2.3)."""
    return x.reshape(-1, 1) if len(x.shape) == 1 else x.copy()


def calc_lam_glm(grads, grads_hat, grads_hat_unlabeled, inv_hessian, coord=None, clip=False):
    """Port of ppi_py.ppi._calc_lam_glm (0.2.3), optim_mode="overall"."""
    grads = _reshape_to_2d(grads)
    grads_hat = _reshape_to_2d(grads_hat)
    grads_hat_unlabeled = _reshape_to_2d(grads_hat_unlabeled)
    n = grads.shape[0]
    N = grads_hat_unlabeled.shape[0]
    d = inv_hessian.shape[0]
    if grads.shape[1] != d:
        raise ValueError("Dimension mismatch between the gradient and the inverse Hessian.")
    grads_cent = grads - grads.mean(axis=0)
    grad_hat_cent = grads_hat - grads_hat.mean(axis=0)
    cov_grads = (1 / n) * (grads_cent.T @ grad_hat_cent + grad_hat_cent.T @ grads_cent)
    var_grads_hat = np.cov(np.concatenate([grads_hat, grads_hat_unlabeled], axis=0).T)
    var_grads_hat = var_grads_hat.reshape(d, d)
    vhat = inv_hessian if coord is None else inv_hessian[coord, :]
    num = np.trace(vhat @ cov_grads @ vhat) if coord is None else vhat @ cov_grads @ vhat
    denom = (2 * (1 + (n / N)) * np.trace(vhat @ var_grads_hat @ vhat) if coord is None
             else 2 * (1 + (n / N)) * vhat @ var_grads_hat @ vhat)
    lam = num / denom
    lam = lam.item()
    if clip:
        lam = np.clip(lam, 0, 1)
    return lam


def ppi_sigma(grads, grads_hat, grads_hat_unlabeled, inv_hessian, lam):
    """Covariance block of ppi_py.ppi.ppi_ols_ci (0.2.3), lines 730-734, n = labeled, N = unlabeled."""
    n = grads.shape[0]
    N = grads_hat_unlabeled.shape[0]
    d = inv_hessian.shape[0]
    var_unlabeled = np.cov(lam * grads_hat_unlabeled.T).reshape(d, d)
    var = np.cov(grads.T - lam * grads_hat.T).reshape(d, d)
    return inv_hessian @ (n / N * var_unlabeled + var) @ inv_hessian


def theta_lambda(AH_L, bH_L, AL_L, bL_L, AL_U, bL_U, lam):
    """Exact solution of the linear rectified M-estimation equation for a given lambda."""
    n, Nu = AH_L.shape[0], AL_U.shape[0]
    M = AH_L.sum(axis=0) / n + lam * (AL_U.sum(axis=0) / Nu - AL_L.sum(axis=0) / n)
    v = bH_L.sum(axis=0) / n + lam * (bL_U.sum(axis=0) / Nu - bL_L.sum(axis=0) / n)
    return np.linalg.solve(M, v)


def unit_gradients(A, b, theta):
    """grad l_i(theta) = A_i theta - b_i for a stack of units."""
    return np.einsum("njk,k->nj", A, theta) - b


def e10_core(AH_L, bH_L, AL_L, bL_L, AL_U, bL_U, hessian, coord=0):
    """Steps 1-4 given per-unit contributions and the Hessian convention. Returns a dict."""
    n, Nu = AH_L.shape[0], AL_U.shape[0]
    cond = float(np.linalg.cond(hessian))
    if not np.isfinite(cond) or cond > COND_MAX:
        return {"fail": "singular", "detail": f"cond(H) = {cond:.3e} > {COND_MAX:.0e}", "cond_H": cond}
    inv_h = np.linalg.inv(hessian)
    th1 = theta_lambda(AH_L, bH_L, AL_L, bL_L, AL_U, bL_U, 1.0)
    g1 = (unit_gradients(AH_L, bH_L, th1), unit_gradients(AL_L, bL_L, th1), unit_gradients(AL_U, bL_U, th1))
    lam = calc_lam_glm(*g1, inv_h, coord=coord, clip=True)
    lam_raw = calc_lam_glm(*g1, inv_h, coord=coord, clip=False)
    th = theta_lambda(AH_L, bH_L, AL_L, bL_L, AL_U, bL_U, lam)
    g = (unit_gradients(AH_L, bH_L, th), unit_gradients(AL_L, bL_L, th), unit_gradients(AL_U, bL_U, th))
    sigma = ppi_sigma(*g, inv_h, lam)
    se_all = np.sqrt(np.diag(sigma) / n)
    return {"theta": th, "se": se_all, "lam": float(lam), "lam_raw": float(lam_raw), "cond_H": cond,
            "n": n, "N_u": Nu}


def e10_fit(panel, D):
    """E-10 on one panel. Returns (theta_target, se, extras) or a failure dict."""
    lab = np.asarray(panel.labeled, dtype=bool)
    n = int(lab.sum()); N = lab.size; Nu = N - n
    if n < MIN_LABELED or Nu < MIN_UNLABELED:
        return {"fail": "below_min", "detail": f"G_S = {n}, N_u = {Nu} (E-10 needs G_S >= 5, N_u >= 2)"}
    AL, AH, bL, bH = contributions(panel, D)
    U = ~lab
    hess = AH[lab].sum(axis=0) / n
    out = e10_core(AH[lab], bH[lab], AL[lab], bL[lab], AL[U], bL[U], hess, coord=0)
    if "fail" in out:
        return out
    return float(out["theta"][0]), float(out["se"][0]), {
        "e10_lam": out["lam"], "e10_lam_raw": out["lam_raw"], "e10_cond_H": out["cond_H"],
        "e10_n": float(n), "e10_N_u": float(Nu)}
