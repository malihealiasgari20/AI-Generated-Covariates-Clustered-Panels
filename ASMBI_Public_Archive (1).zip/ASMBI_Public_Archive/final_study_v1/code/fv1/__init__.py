"""FINAL_V1 runner package (Stress-Testing Inference with AI-Generated Covariates in Clustered Panels).

Implements the run procedure of FINAL_V1_PRE_RUN_RECORD_FROZEN.txt (SHA-256 bd001cda...). Import
fv1.env before numpy so that thread pinning and the dependency path are in place.
"""
