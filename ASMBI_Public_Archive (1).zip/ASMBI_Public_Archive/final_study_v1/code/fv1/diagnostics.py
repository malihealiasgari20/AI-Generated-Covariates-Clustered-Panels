"""Per-replication diagnostics (record 3.8), the module-D measures (record 7.6) and the
Experiment-3 within-signal moment (record 1.5, C3). Raw per-replication quantities only; nothing
here aggregates over replications.

Every group is computed inside its own try block: a diagnostic failure leaves NaN in its columns,
sets diag_fail__<group> = 1, and never touches an estimator result.

The Experiment-5 mechanism block reproduces e5_core.fit_all (F10a procedure) term by term:
D_s by stratum for the identity (L), unweighted (u) and weighted (w) prediction rules, realized
rectifier stratum shares, and the predicted displacement (A/N)^-1 sum_s (share_s - p_s) D_s for
E-4, E-5, E-6, E-6H, E-12a, E-12b, E-12c. It is evaluated only for estimators that succeeded in the
replication (as Experiment 5 did), and the cross-fitted rules only when G_S >= 10 (the eligibility
rule of the cross-fitted family).
"""
import numpy as np

import fv1.env  # noqa: F401
from stage0_dgp import associations, make_rng, within_demean
from stage1_design_aware import crossfit_predictions, rectifier_weights
import s2_core
from fv1.estimators import OK, SM_FAMILY

# Experiment-5 specifications: (prediction rule, rectifier); e5_core.SPEC with FINAL_V1 names
SPEC = {"E-4": ("L", "uniform"), "E-5": ("u", "uniform"), "E-6": ("L", "ht"), "E-6H": ("L", "hajek"),
        "E-12a": ("u", "ht"), "E-12b": ("w", "ht"), "E-12c": ("w", "uniform")}
OOS_FOLDS = 5


def _rect_gram(Wf, Wo, WH, rw):
    """The rectified Gram matrix, the same expression as e5_core.solve_rect."""
    return Wf.T @ Wf + (WH * rw[:, None]).T @ WH - (Wo * rw[:, None]).T @ Wo


def basic(rep):
    pan = rep.pan
    s, lab = pan.strata, pan.labeled
    out = {"G_S": float(rep.G_S), "within_moment": float(np.mean(within_demean(pan.ZH) ** 2))}
    for j in range(3):
        out[f"n_s{j}"] = float(np.sum((s == j) & lab))
    return out


def assoc(rep):
    return {f"assoc__{k}": v for k, v in associations(rep.pan).items()}


def full(rep, results, theta0):
    """Record 3.8 diagnostics for the FULL battery. Returns (values, failed groups)."""
    out, bad = {}, []
    for name, fn in (("assoc", lambda: assoc(rep)), ("mechanism", lambda: _mechanism(rep, results, theta0))):
        try:
            with np.errstate(all="ignore"):
                out.update(fn())
        except Exception as ex:  # noqa: BLE001
            bad.append(f"{name}: {type(ex).__name__}: {ex}")
    for r in results.values():
        out.update(r.extras)
    return out, bad


def _mechanism(rep, results, theta0):
    pan, D, N, T = rep.pan, rep.D, rep.N, rep.T
    p = pan.params
    ok = {k: (v.fail == OK) for k, v in results.items()}
    y = within_demean(pan.Y).reshape(N * T)
    x = within_demean(pan.X).reshape(N * T)
    W = lambda Z: np.column_stack([within_demean(Z).reshape(N * T), x, D])
    WL, WH = W(pan.ZL.astype(float)), W(pan.ZH)
    Wpair = {"L": (WL, WL)}
    if rep.G_S >= 10:
        Zfu, Zou, _ = crossfit_predictions(pan, make_rng(*rep.fold_key), False)
        Zfw, Zow, _ = crossfit_predictions(pan, make_rng(*rep.fold_key), True)
        Wpair["u"] = (W(Zfu), W(Zou))
        Wpair["w"] = (W(Zfw), W(Zow))
    rwu = {r: rectifier_weights(pan, r) for r in ("uniform", "ht", "hajek")}
    out = {}

    # target-direction information of the machine-only design, per predictor family
    fam_W = {"I": "L", "CFu": "u", "CFw": "w"}
    sM = {}
    for fam, rule in fam_W.items():
        if rule in Wpair:
            Wf = Wpair[rule][0]
            sM[fam] = s2_core.schur_info(Wf.T @ Wf)
            out[f"sM_nt__{fam}"] = sM[fam] / (N * T)

    # F10a: full parameter vector at theta_0 (e5_core.fit_all, lines 61-82)
    s = pan.strata
    gW = p.gamma_W + p.tau * (s - 1)
    ZHbar = pan.ZH.mean(axis=1, keepdims=True)
    rest = gW[:, None] * (pan.ZH - ZHbar) + p.gamma_B * ZHbar + p.beta * pan.X + pan.u[:, None] + pan.eps
    resid_d = pan.Y - rest
    delta = resid_d.mean(axis=0)
    theta_full = np.concatenate([[theta0, p.beta], delta[:T - 1] - delta[T - 1]])

    def m_unit(Wm):
        k = Wm.shape[1]
        return np.einsum("ntk,nt->nk", Wm.reshape(N, T, k), (y - Wm @ theta_full).reshape(N, T))

    mH = m_unit(WH)
    Dfull = {}
    for f in "Luw":
        if f in Wpair:
            dm = mH - m_unit(Wpair[f][0])
            Dfull[f] = np.stack([dm[s == j].mean(axis=0) for j in range(3)])
            for j in range(3):
                out[f"D_{f}_s{j}"] = float(Dfull[f][j, 0])
    pS = np.array([np.mean(s == j) for j in range(3)])
    shares = {}
    for r in ("uniform", "ht", "hajek"):
        shares[r] = np.array([rwu[r][s == j].sum() / N for j in range(3)])
        for j in range(3):
            out[f"share_{r}_s{j}"] = float(shares[r][j])
    for c, (f, r) in SPEC.items():
        if ok.get(c) and f in Dfull:
            A = _rect_gram(*Wpair[f], WH, np.repeat(rwu[r], T))
            g = ((shares[r] - pS)[:, None] * Dfull[f]).sum(axis=0)
            out[f"pred__{c}"] = float(np.linalg.solve(A / N, g)[0])
            if c in ("E-4", "E-5", "E-6"):        # frozen-code estimators: Schur information from A
                out[f"s_nt__{c}"] = float(1.0 / np.linalg.inv(A)[0, 0] / (N * T))
    # s / s_M for every Schur-solver estimator
    for c, fam in SM_FAMILY.items():
        key = f"s_nt__{c}"
        sv = out.get(key, results[c].extras.get(key) if c in results else None)
        if sv is not None and fam in sM and ok.get(c):
            out[f"s_over_sM__{c}"] = float(sv / (sM[fam] / (N * T)))
            out.setdefault(f"sM_nt__{c}", sM[fam] / (N * T))
    wl = 1.0 / np.asarray(p.pi)[s[pan.labeled]]
    out["kish_ht"] = float(wl.sum() ** 2 / (wl ** 2).sum())
    out["delta_spread"] = float(resid_d.std(axis=0).max())
    return out


def oos_r2(rep, oos_rng):
    """Record 7.6 [D8]: incremental out-of-sample R^2 of Z~_L for the within outcome, in percent.

    Units in 5 folds (permutation from FINAL_V1_OOS); in each fold OLS on the training units of y~ on
    [X~, D~] (base) and [Z~_L, X~, D~] (augmented); held-out units predicted from their own demeaned
    regressors; R^2_m = 1 - sum_held-out (y~ - y^_m)^2 / sum y~^2, pooled over folds (every unit is
    held out once).
    """
    pan, D, N, T = rep.pan, rep.D, rep.N, rep.T
    y = within_demean(pan.Y)
    zl = within_demean(pan.ZL.astype(float))
    x = within_demean(pan.X)
    Dm = D.reshape(N, T, T - 1)
    folds = np.array_split(oos_rng.permutation(N), OOS_FOLDS)
    sse_b = sse_a = 0.0
    for held in folds:
        train = np.setdiff1d(np.arange(N), held)

        def mats(units):
            xb = np.column_stack([x[units].reshape(-1), Dm[units].reshape(-1, T - 1)])
            xa = np.column_stack([zl[units].reshape(-1), xb])
            return xb, xa, y[units].reshape(-1)

        xb_tr, xa_tr, y_tr = mats(train)
        xb_te, xa_te, y_te = mats(held)
        cb, *_ = np.linalg.lstsq(xb_tr, y_tr, rcond=None)
        ca, *_ = np.linalg.lstsq(xa_tr, y_tr, rcond=None)
        sse_b += float(np.sum((y_te - xb_te @ cb) ** 2))
        sse_a += float(np.sum((y_te - xa_te @ ca) ** 2))
    sst = float(np.sum(y ** 2))
    r2b, r2a = 1.0 - sse_b / sst, 1.0 - sse_a / sst
    return {"oos_r2_base": r2b, "oos_r2_aug": r2a, "oos_r2_incr_pct": 100.0 * (r2a - r2b)}
