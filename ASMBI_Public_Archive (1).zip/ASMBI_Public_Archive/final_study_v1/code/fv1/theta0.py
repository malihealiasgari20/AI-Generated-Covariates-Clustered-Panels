"""theta_0 for every configuration (record 1.7).

Production: the FINAL_V1 map written and hashed by gate G-F (the union of the four frozen maps
plus the 11 keys computed by the frozen procedure). The runner never calls
stage0_theta0.theta0_for, which computes and writes a cache file in the working directory.

Mechanical tests: the union of the four frozen maps only; configurations whose key is not in it
get NaN (coverage is then recorded as not evaluable, code -1).
"""
import json, math, os

import fv1.env as env

FROZEN_MAPS = ("theta0_maps/v1.1_config_theta0_map.json", "theta0_maps/S0.11_stage0_theta0_map.json",
               "theta0_maps/E5_stage0_theta0_map.json", "theta0_maps/S2_stage0_theta0_map.json")


def frozen_union():
    """Union of the four frozen maps; any value conflict is an error."""
    union = {}
    for rel in FROZEN_MAPS:
        with open(os.path.join(env.DEPS_DIR, rel)) as fh:
            for k, v in json.load(fh).items():
                if k in union and union[k]["theta0"] != v["theta0"]:
                    raise RuntimeError(f"theta_0 conflict for {k}")
                union.setdefault(k, v)
    return union


def load_production_map(path, expected_sha256):
    got = env.sha256_file(path)
    if got != expected_sha256:
        raise RuntimeError(f"theta_0 map {path}: SHA-256 {got} != {expected_sha256}")
    with open(path) as fh:
        return json.load(fh)


def lookup(theta_map, configs, require_all):
    """Return {config index: theta_0}. With require_all, every key must be present and finite."""
    out = {}
    for c in configs:
        v = theta_map.get(c.theta0_key)
        val = float(v["theta0"]) if v is not None else float("nan")
        if require_all and not math.isfinite(val):
            raise RuntimeError(f"theta_0 missing for {c.name} ({c.theta0_key})")
        out[c.index] = val
    return out
