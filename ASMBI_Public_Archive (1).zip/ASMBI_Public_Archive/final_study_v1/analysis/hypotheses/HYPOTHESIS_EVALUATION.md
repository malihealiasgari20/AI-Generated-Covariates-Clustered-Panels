# FINAL_V1 hypothesis evaluation

Rules: sealed record Sections 7.1-7.5 and protocol v1.10 (H1.1-H4.4 verbatim from v1.5), operationalized by analysis/ANALYSIS_OPERATIONALIZATIONS.txt (fixed and hashed before any result). Vocabulary: SUPPORTED, REFUTED (the hypothesis's own REFUTED-IF criterion met), NOT SUPPORTED (a predicted clause fails, the REFUTED-IF criterion is not met), INCONCLUSIVE (record rule), ABSENT (E-10), REPORTED (open question).

| ID | Outcome | Status | Cells |
| --- | --- | --- | --- |
| H1.1 | REFUTED | CONFIRMATORY RE-ESTIMATE (rho_e 0.60 arm observed in S0.11) | L, rho_e 0.60, gamma_W 0.15, kappa 0-0.90; E-1 |
| H1.2 | SUPPORTED | rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE | L, gamma_W 0.15; E-7 |
| H1.3 | SUPPORTED | rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE | L, gamma_W 0.15, both rho_e, every kappa; E-6, E-8, E-9 |
| H1.3b | SUPPORTED | PROSPECTIVE except kappa 0 and 0.60 (Experiment 5 cells) | L, gamma_W 0.15, both rho_e, every kappa; E-12a, E-12b |
| H1.3c | REPORTED | mixed (see record 0.3) | L, gamma_W 0.15; E-5, E-12c (E-4 and E-2 in their own rows) |
| H1.4 | REFUTED | rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE | L, gamma_W 0.15, both rho_e, every kappa; E-4, E-6, E-8, E-9 |
| H2.1 | SUPPORTED | (i) PROSPECTIVE; (ii) CONFIRMATORY RE-ESTIMATE | X2 2x2, gamma_W 0.15; E-5 |
| H2.1b | SUPPORTED | PROSPECTIVE (A0 cells never run) | X2 2x2, gamma_W 0.15; E-5 |
| H2.2 | NOT SUPPORTED | uniform cells PROSPECTIVE; (A1,B1) CONFIRMATORY | X2 2x2, gamma_W 0.15; E-5 |
| H2.3 | SUPPORTED | CONFIRMATORY RE-ESTIMATE | X2 (A1,B1), gamma_W 0.15; E-5 |
| H2.4 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (A1 cells); A0 cells PROSPECTIVE | X2 2x2, gamma_W 0.15; E-2, E-6, E-8, E-9 |
| H2.4b | SUPPORTED | A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5) | X2 2x2, gamma_W 0.15; E-12a, E-12b |
| H2.5 | SUPPORTED | A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5) | X2 2x2, gamma_W 0.15; E-12c vs E-5 |
| H3.1 | SUPPORTED | PROSPECTIVE (kappabar 0.60 at T 8 never run) | X3 T = 8, kappabar 0 vs 0.60; E-1 |
| H3.1b | SUPPORTED; scaling clause: REFUTED | PROSPECTIVE | X3, six T; E-1 |
| H3.2 | REFUTED | PROSPECTIVE | X3, six T; E-1 |
| H3.3 | SUPPORTED | PROSPECTIVE | X3, six T; E-1 |
| H3.4 | REFUTED | PROSPECTIVE (T 8 cell: CONFIRMATORY) | X3 kappabar 0, six T; E-1 |
| H3.5 | REPORTED | positioning statement (no test) | - |
| H4.1 | SUPPORTED | PROSPECTIVE (60 of 62 cells never run); not informative for E-12a/E-12b | X4 grid, gamma_W 0.15; rectified set (E-10 ABSENT) |
| H4.2 | E-10 part: ABSENT; interpretation rule (record 7.4) applied to E-6, E-12a, E-12b: branch 1 -- E-12a, E-12b attain R_RMSE < 1 at the baseline | baseline: CONFIRMATORY (development: E-12a below 1); uniform cell PROSPECTIVE | X4 baseline f 0.35, sd_e 0.55, gamma_W 0.15 (R 2,000) and uniform-validation cell (R 5,000) |
| H4.3 | E-4: NOT SUPPORTED; E-5: SUPPORTED; E-6: NOT SUPPORTED; HT-TDS-I: NOT SUPPORTED; PS-TDS-I: NOT SUPPORTED; E-9: NOT SUPPORTED; E-12a: NOT SUPPORTED; E-12b: NOT SUPPORTED | PROSPECTIVE | X4 grid, gamma_W 0.15 |
| H4.4 | E-10: ABSENT; E-6: SUPPORTED | PROSPECTIVE | X4 grid, 30 gamma_W 0.15 cells |
| H4.4b | E-10: ABSENT; E-12a: REFUTED; E-12b: REFUTED; HT-TDS-I: SUPPORTED | PROSPECTIVE | X4 grid, 30 gamma_W 0.15 cells |
| H4.5 | REPORTED (open question) | PROSPECTIVE | X4 grid, gamma_W 0.15 |
| H4.6 | REPORTED (open question; table supplementary/H4.6_TDS_sparse_validation.csv) | PROSPECTIVE | X4 f <= 0.10; S m 0.33, 0.50 |
| H5.1 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5) | 24 primary + 8 stress (tau 0/0.30, N 250/600) |
| H5.2 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5) | 24 primary + 8 stress (tau 0/0.30, N 250/600) |
| H5.3 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5) | 24 primary + 8 stress (tau 0/0.30, N 250/600) |
| H5.4 | REPORTED (open question) | CONFIRMATORY RE-ESTIMATE | 32 cells |
| H5.5 | REPORTED (open question) | CONFIRMATORY RE-ESTIMATE | 32 cells |
| H5.6 | REPORTED (open question) | CONFIRMATORY RE-ESTIMATE | 32 cells |

## H1.1 -- REFUTED

- status: CONFIRMATORY RE-ESTIMATE (rho_e 0.60 arm observed in S0.11)
- cells: L, rho_e 0.60, gamma_W 0.15, kappa 0-0.90; E-1
- rule: analysis plan G, H1.1
- bias_kappa0: -0.09506
- bias_kappa0_mcse: 2.859e-04
- clause_a_negative: True
- clause_b_monotone: True
- increments: [[0.02143, 7.179e-05], [0.01972, 7.056e-05], [0.01743, 6.678e-05], [0.01459, 6.252e-05], [0.01186, 5.799e-05], [0.009381, 5.391e-05]]
- crossing: 0.9121
- crossing_status: extrapolated (outside the simulated range)
- crossing_ci95: [0.9019, 0.9229]
- share_draws_in_range: 0.011
- rho0_crossing: NA
- rho0_status: none on [0, 3.0]
- rho0_ci95: [NA, NA]

## H1.2 -- SUPPORTED

- status: rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE
- cells: L, gamma_W 0.15; E-7
- rule: analysis plan G, H1.2
- rho_e=0.00: {delta_from_kappa0: [[-0.01256, 1.872e-04], [-0.0255, 2.666e-04], [-0.03796, 3.315e-04], [-0.05052, 3.905e-04], [-0.06293, 4.500e-04], [-0.07497, 5.063e-04]], increments: [[-0.01256, 1.872e-04], [-0.01294, 1.872e-04], [-0.01246, 1.906e-04], [-0.01256, 1.875e-04], [-0.0124, 1.844e-04], [-0.01204, 1.820e-04]], monotone: True}
- rho_e=0.60: {delta_from_kappa0: [[0.0542, 1.865e-04], [0.1078, 2.800e-04], [0.1606, 3.685e-04], [0.2119, 4.561e-04], [0.2614, 5.525e-04], [0.3091, 6.538e-04]], increments: [[0.0542, 1.865e-04], [0.05361, 1.901e-04], [0.05281, 1.917e-04], [0.05124, 1.974e-04], [0.04951, 2.005e-04], [0.04776, 2.089e-04]], monotone: True}
- growth_rho0_nonzero: True
- growth_rho0_smaller: True
- abs_growth_difference: 0.2342
- abs_growth_difference_mcse: 8.270e-04
- flat_rho0: False

## H1.3 -- SUPPORTED

- status: rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE
- cells: L, gamma_W 0.15, both rho_e, every kappa; E-6, E-8, E-9
- rule: analysis plan G, H1.3
- max_abs_bias: 0.01869
- exceedances: []
- refuting_cells: []
- table: [42 entries; see JSON]
- secondary_null_cells_abs_bias_ge_0_02: []

## H1.3b -- SUPPORTED

- status: PROSPECTIVE except kappa 0 and 0.60 (Experiment 5 cells)
- cells: L, gamma_W 0.15, both rho_e, every kappa; E-12a, E-12b
- rule: analysis plan G, H1.3b
- max_abs_bias: 0.002119
- exceedances: []
- refuting_cells: []
- table: [28 entries; see JSON]
- secondary_null_cells_abs_bias_ge_0_02: []

## H1.3c -- REPORTED

- status: mixed (see record 0.3)
- cells: L, gamma_W 0.15; E-5, E-12c (E-4 and E-2 in their own rows)
- rule: reported separately; kappa-0 displacement attributed to validation design
- E-5|rho_e=0.00: {bias_kappa0: 0.03535, bias_kappa0_mcse: 7.714e-04, change_from_kappa0: [[4.459e-04, 8.649e-05], [0.001109, 1.211e-04], [0.001826, 1.474e-04], [0.002826, 1.725e-04], [0.003723, 1.921e-04], [0.004486, 2.118e-04]]}
- E-12c|rho_e=0.00: {bias_kappa0: 0.03435, bias_kappa0_mcse: 7.694e-04, change_from_kappa0: [[4.838e-04, 9.315e-05], [0.001186, 1.306e-04], [0.001929, 1.593e-04], [0.003007, 1.867e-04], [0.003985, 2.081e-04], [0.00484, 2.297e-04]]}
- E-4|rho_e=0.00: {bias_kappa0: 0.008168, bias_kappa0_mcse: 9.551e-04, change_from_kappa0: [[9.609e-04, 2.165e-04], [0.002412, 3.069e-04], [0.003987, 3.826e-04], [0.006578, 4.592e-04], [0.009049, 5.300e-04], [0.01157, 6.060e-04]]}
- E-2|rho_e=0.00: {bias_kappa0: 0.001492, bias_kappa0_mcse: 0.001008, change_from_kappa0: [[0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0]]}
- E-5|rho_e=0.60: {bias_kappa0: 0.03532, bias_kappa0_mcse: 6.450e-04, change_from_kappa0: [[-0.001196, 8.202e-05], [-0.001936, 1.164e-04], [-0.002276, 1.417e-04], [-0.002349, 1.657e-04], [-0.002198, 1.873e-04], [-0.001902, 2.050e-04]]}
- E-12c|rho_e=0.60: {bias_kappa0: 0.03427, bias_kappa0_mcse: 6.433e-04, change_from_kappa0: [[-0.001297, 8.847e-05], [-0.002122, 1.258e-04], [-0.002544, 1.533e-04], [-0.002675, 1.797e-04], [-0.002561, 2.035e-04], [-0.002279, 2.232e-04]]}
- E-4|rho_e=0.60: {bias_kappa0: 0.007474, bias_kappa0_mcse: 8.130e-04, change_from_kappa0: [[-0.003049, 2.044e-04], [-0.005323, 2.925e-04], [-0.006991, 3.615e-04], [-0.008093, 4.315e-04], [-0.008789, 5.036e-04], [-0.009157, 5.708e-04]]}
- E-2|rho_e=0.60: {bias_kappa0: 5.707e-04, bias_kappa0_mcse: 8.515e-04, change_from_kappa0: [[0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0]]}

## H1.4 -- REFUTED

- status: rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE
- cells: L, gamma_W 0.15, both rho_e, every kappa; E-4, E-6, E-8, E-9
- rule: analysis plan G, H1.4
- violations: [[0, 0.9, E-4, 1.103], [0.6, 0.15, E-8, 7.196]]
- table: [56 entries; see JSON]
- secondary_null_cell_violations: []

## H2.1 -- SUPPORTED

- status: (i) PROSPECTIVE; (ii) CONFIRMATORY RE-ESTIMATE
- cells: X2 2x2, gamma_W 0.15; E-5
- rule: analysis plan H, H2.1
- clause_i: True
- clause_ii: True
- materially_displaced_uniform: []
- bias: {A0B0: [0.001393, 6.431e-04], A0B1: [0.001238, 6.769e-04], A1B0: [0.004614, 6.485e-04], A1B1: [0.09697, 6.980e-04]}
- secondary_null_cells: {A0B0: [0.001372, 6.283e-04], A0B1: [5.003e-04, 6.812e-04], A1B0: [2.048e-04, 6.490e-04], A1B1: [0.09076, 6.816e-04]}

## H2.1b -- SUPPORTED

- status: PROSPECTIVE (A0 cells never run)
- cells: X2 2x2, gamma_W 0.15; E-5
- rule: analysis plan H, H2.1b
- Delta: 0.09251
- mcse: 0.001334
- secondary_null: {Delta: 0.09143, mcse: 0.001321, z: 69.22}
- note: a null Delta is not refuting (protocol 4.3): lambda1 channel dominates

## H2.2 -- NOT SUPPORTED

- status: uniform cells PROSPECTIVE; (A1,B1) CONFIRMATORY
- cells: X2 2x2, gamma_W 0.15; E-5
- rule: analysis plan H, H2.2
- coverage: {A0B0: [0.9396, 0.003369], A0B1: [0.9582, 0.00283], A1B0: [0.9448, 0.00323], A1B1: [0.51, 0.00707]}
- A1B0_derived_from_stored_D_s: {...; see JSON}

## H2.3 -- SUPPORTED

- status: CONFIRMATORY RE-ESTIMATE
- cells: X2 (A1,B1), gamma_W 0.15; E-5
- rule: analysis plan H, H2.3 (sign decides; magnitude reported)
- observed: [0.09697, 6.980e-04]
- predicted: [0.09655, 2.861e-04]
- ratio: 1.004
- magnitude: REPORTED: no threshold pre-specified; disagreement in magnitude is not a refutation

## H2.4 -- SUPPORTED

- status: CONFIRMATORY RE-ESTIMATE (A1 cells); A0 cells PROSPECTIVE
- cells: X2 2x2, gamma_W 0.15; E-2, E-6, E-8, E-9
- rule: analysis plan H, H2.4
- table: [[E-2, B0, 2.495e-05, 0.001121], [E-2, B1, 0.003407, 0.001244], [E-6, B0, 0.003087, 0.001576], [E-6, B1, 0.004475, 0.0016], [E-8, B0, 0.003087, 0.001576], [E-8, B1, 0.004475, 0.0016], [E-9, B0, 5.371e-04, 0.001366], [E-9, B1, 0.003012, 0.001418]]
- outside_3_mcse: []
- secondary_null_outside: []
- E4_reported_separately: [[B0, -0.003943, 0.001209], [B1, 0.01879, 0.001238]]

## H2.4b -- SUPPORTED

- status: A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5)
- cells: X2 2x2, gamma_W 0.15; E-12a, E-12b
- rule: analysis plan H, H2.4b
- table: [[E-12a, B0, 1.349e-04, 9.471e-04], [E-12a, B1, 0.001217, 0.00103], [E-12b, B0, 1.216e-04, 9.449e-04], [E-12b, B1, 0.00104, 0.001025]]
- outside_3_mcse: []
- secondary_null_outside: []
- E4_reported_separately: [[B0, -0.003943, 0.001209], [B1, 0.01879, 0.001238]]

## H2.5 -- SUPPORTED

- status: A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5)
- cells: X2 2x2, gamma_W 0.15; E-12c vs E-5
- rule: analysis plan H, H2.5
- E12c: {A0B0: [0.001393, 6.431e-04], A0B1: [0.001238, 6.769e-04], A1B0: [0.004658, 6.472e-04], A1B1: [0.09388, 6.965e-04]}
- E5_displaced_cells: [A1B0, A1B1]
- centered_where_E5_displaced: []
- secondary_E2_LAMBDA: {LAMBDA-B0: [5.115e-04, 6.280e-04, 4.757e-04, 6.275e-04], LAMBDA-B1: [0.08192, 6.661e-04, 0.0817, 6.634e-04]}

## H3.1 -- SUPPORTED

- status: PROSPECTIVE (kappabar 0.60 at T 8 never run)
- cells: X3 T = 8, kappabar 0 vs 0.60; E-1
- rule: analysis plan I, H3.1
- d: -0.03697
- mcse: 1.876e-04
- z: -197.1

## H3.1b -- SUPPORTED; scaling clause: REFUTED

- status: PROSPECTIVE
- cells: X3, six T; E-1
- rule: analysis plan I, H3.1b
- detected_T: [4, 6, 8, 10, 12, 16]
- signs: {4: -1, 6: -1, 8: -1, 10: -1, 12: -1, 16: -1}
- sign_consistent_among_detectable: True

## H3.2 -- REFUTED

- status: PROSPECTIVE
- cells: X3, six T; E-1
- rule: analysis plan I, H3.2
- slope: -0.3795
- se: 0.005001
- ci95: [-0.3893, -0.3697]
- chi2: 180.1
- p: 7.159e-38
- T_abs_d_flatness_p: 0
- C3: PASSED
- max_rel_dev: 5.350e-04

## H3.3 -- SUPPORTED

- status: PROSPECTIVE
- cells: X3, six T; E-1
- rule: analysis plan I, H3.3
- d8: -0.03697
- detectable_positive_T: []

## H3.4 -- REFUTED

- status: PROSPECTIVE (T 8 cell: CONFIRMATORY)
- cells: X3 kappabar 0, six T; E-1
- rule: analysis plan I, H3.4
- slope_bias_on_logT: -0.004971
- se: 3.247e-04
- homogeneity_chi2: 255.4
- homogeneity_p: 3.864e-53
- bias: [[4, -0.08928, 5.046e-04], [6, -0.09313, 4.136e-04], [8, -0.09445, 3.407e-04], [10, -0.09615, 3.085e-04], [12, -0.09586, 2.750e-04], [16, -0.09728, 2.388e-04]]

## H3.5 -- REPORTED

- status: positioning statement (no test)
- cells: -
- rule: protocol 5.3 H3.5

## H4.1 -- SUPPORTED

- status: PROSPECTIVE (60 of 62 cells never run); not informative for E-12a/E-12b
- cells: X4 grid, gamma_W 0.15; rectified set (E-10 ABSENT)
- rule: analysis plan J, H4.1
- pays_cells: [74 entries; see JSON]
- point_below_1_cells: [111 entries; see JSON]
- pays_by_estimator: {E-4: 14, E-5: 17, E-6: 0, HT-TDS-I: 0, PS-TDS-I: 1, E-9: 2, E-12a: 20, E-12b: 20}
- pays_excluding_E12ab: [34 entries; see JSON]

## H4.2 -- E-10 part: ABSENT; interpretation rule (record 7.4) applied to E-6, E-12a, E-12b: branch 1 -- E-12a, E-12b attain R_RMSE < 1 at the baseline

- status: baseline: CONFIRMATORY (development: E-12a below 1); uniform cell PROSPECTIVE
- cells: X4 baseline f 0.35, sd_e 0.55, gamma_W 0.15 (R 2,000) and uniform-validation cell (R 5,000)
- rule: analysis plan J, H4.2
- E10: ABSENT -- gate V10 failed (V10.1); per record 3.4 no approximate replacement or substitute is created (protocol v1.10, amendment A10.1)
- E-6: {baseline: [1.523, 0.05543, labeled-only better], uniform: [1.375, 0.02201, labeled-only better], near_baseline: {f=0.2|sd=0.35: [1.524, labeled-only better], f=0.2|sd=0.55: [2.874, labeled-only better], f=0.2|sd=0.8: [11.79, labeled-only better], f=0.35|sd=0.35: [1.155, labeled-only better], f=0.35|sd=0.8: [6.054, labeled-only better], f=0.5|sd=0.35: [1.043, indeterminate], f=0.5|sd=0.55: [1.286, labeled-only better], f=0.5|sd=0.8: [1.636, labeled-only better]}, uniform_minus_baseline_log: -0.1021, mcse: 0.03967, lower_by_more_than_3_mcse: False}
- E-12a: {baseline: [0.8307, 0.008963, rectification pays], uniform: [0.8659, 0.006272, rectification pays], near_baseline: {f=0.2|sd=0.35: [0.7326, rectification pays], f=0.2|sd=0.55: [0.806, rectification pays], f=0.2|sd=0.8: [0.8971, rectification pays], f=0.35|sd=0.35: [0.7486, rectification pays], f=0.35|sd=0.8: [0.9068, rectification pays], f=0.5|sd=0.35: [0.7812, rectification pays], f=0.5|sd=0.55: [0.8421, rectification pays], f=0.5|sd=0.8: [0.8978, rectification pays]}, uniform_minus_baseline_log: 0.0415, mcse: 0.01299, lower_by_more_than_3_mcse: False}
- E-12b: {baseline: [0.827, 0.009587, rectification pays], uniform: [0.8659, 0.006272, rectification pays], near_baseline: {f=0.2|sd=0.35: [0.7337, rectification pays], f=0.2|sd=0.55: [0.8009, rectification pays], f=0.2|sd=0.8: [0.8895, rectification pays], f=0.35|sd=0.35: [0.7475, rectification pays], f=0.35|sd=0.8: [0.9029, rectification pays], f=0.5|sd=0.35: [0.7807, rectification pays], f=0.5|sd=0.55: [0.8383, rectification pays], f=0.5|sd=0.8: [0.8909, rectification pays]}, uniform_minus_baseline_log: 0.046, mcse: 0.01367, lower_by_more_than_3_mcse: False}

## H4.3 -- E-4: NOT SUPPORTED; E-5: SUPPORTED; E-6: NOT SUPPORTED; HT-TDS-I: NOT SUPPORTED; PS-TDS-I: NOT SUPPORTED; E-9: NOT SUPPORTED; E-12a: NOT SUPPORTED; E-12b: NOT SUPPORTED

- status: PROSPECTIVE
- cells: X4 grid, gamma_W 0.15
- rule: analysis plan J, H4.3
- E-4: {boundary: {0.15: [above 0.50, NA], 0.25: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.35: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.55: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.8: [below 0.03, NA]}, monotone_nonincreasing_in_sd: False, all_identical: False, outcome: NOT SUPPORTED}
- E-5: {boundary: {0.15: [above 0.50, NA], 0.25: [above 0.50, NA], 0.35: [above 0.50, NA], 0.55: [crossing, 0.4289], 0.8: [crossing, 0.2451]}, monotone_nonincreasing_in_sd: True, all_identical: False, outcome: SUPPORTED}
- E-6: {boundary: {0.15: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.25: [below 0.03, NA], 0.35: [below 0.03, NA], 0.55: [below 0.03, NA], 0.8: [below 0.03, NA]}, monotone_nonincreasing_in_sd: False, all_identical: False, outcome: NOT SUPPORTED}
- HT-TDS-I: {boundary: {0.15: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.25: [below 0.03, NA], 0.35: [below 0.03, NA], 0.55: [below 0.03, NA], 0.8: [below 0.03, NA]}, monotone_nonincreasing_in_sd: False, all_identical: False, outcome: NOT SUPPORTED}
- PS-TDS-I: {boundary: {0.15: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.25: [below 0.03, NA], 0.35: [below 0.03, NA], 0.55: [below 0.03, NA], 0.8: [below 0.03, NA]}, monotone_nonincreasing_in_sd: False, all_identical: False, outcome: NOT SUPPORTED}
- E-9: {boundary: {0.15: [above 0.50, NA], 0.25: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.35: [reverse (>= 0 at small f, < 0 at larger f), NA], 0.55: [below 0.03, NA], 0.8: [below 0.03, NA]}, monotone_nonincreasing_in_sd: False, all_identical: False, outcome: NOT SUPPORTED}
- E-12a: {boundary: {0.15: [above 0.50, NA], 0.25: [above 0.50, NA], 0.35: [above 0.50, NA], 0.55: [above 0.50, NA], 0.8: [above 0.50, NA]}, monotone_nonincreasing_in_sd: True, all_identical: True, outcome: NOT SUPPORTED}
- E-12b: {boundary: {0.15: [above 0.50, NA], 0.25: [above 0.50, NA], 0.35: [above 0.50, NA], 0.55: [above 0.50, NA], 0.8: [above 0.50, NA]}, monotone_nonincreasing_in_sd: True, all_identical: True, outcome: NOT SUPPORTED}

## H4.4 -- E-10: ABSENT; E-6: SUPPORTED

- status: PROSPECTIVE
- cells: X4 grid, 30 gamma_W 0.15 cells
- rule: analysis plan J, H4.4
- E-6: {min_coverage: 0.951, cells_below_0_93: [], refuting_cells: [], flagged_cells: [[0.03, 0.15], [0.03, 0.25], [0.03, 0.35], [0.03, 0.55]], secondary_min_coverage_null_and_uniform: 0.9525}

## H4.4b -- E-10: ABSENT; E-12a: REFUTED; E-12b: REFUTED; HT-TDS-I: SUPPORTED

- status: PROSPECTIVE
- cells: X4 grid, 30 gamma_W 0.15 cells
- rule: analysis plan J, H4.4b
- E-12a: {min_coverage: 0.8953, cells_below_0_93: [[0.03, 0.55, 0.898], [0.03, 0.8, 0.8953], [0.05, 0.55, 0.9202], [0.05, 0.8, 0.9055], [0.1, 0.55, 0.9255], [0.2, 0.8, 0.9265]], refuting_cells: [[0.03, 0.55, 0.898, 0.9454], [0.05, 0.8, 0.9055, 0.9346]], flagged_cells: [10 entries; see JSON], secondary_min_coverage_null_and_uniform: 0.9051}
- E-12b: {min_coverage: 0.8965, cells_below_0_93: [[0.03, 0.55, 0.9076], [0.03, 0.8, 0.8965], [0.05, 0.55, 0.9218], [0.05, 0.8, 0.9055], [0.1, 0.55, 0.929], [0.2, 0.8, 0.928]], refuting_cells: [[0.03, 0.55, 0.9076, 0.9522], [0.05, 0.8, 0.9055, 0.9261]], flagged_cells: [10 entries; see JSON], secondary_min_coverage_null_and_uniform: 0.9051}
- HT-TDS-I: {min_coverage: 0.951, cells_below_0_93: [], refuting_cells: [], flagged_cells: [[0.03, 0.15], [0.03, 0.25], [0.03, 0.35], [0.03, 0.55]], secondary_min_coverage_null_and_uniform: 0.9525}

## H4.5 -- REPORTED (open question)

- status: PROSPECTIVE
- cells: X4 grid, gamma_W 0.15
- rule: analysis plan J, H4.5
- E-12a: {not_paying: [[0.03, 0.8, labeled-only better, 1.058]], excluded_gt_5pct: [10 entries; see JSON]}
- E-12b: {not_paying: [[0.03, 0.8, labeled-only better, 1.071]], excluded_gt_5pct: [10 entries; see JSON]}

## H4.6 -- REPORTED (open question; table supplementary/H4.6_TDS_sparse_validation.csv)

- status: PROSPECTIVE
- cells: X4 f <= 0.10; S m 0.33, 0.50
- rule: analysis plan J, H4.6

## H5.1 -- SUPPORTED

- status: CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5)
- cells: 24 primary + 8 stress (tau 0/0.30, N 250/600)
- rule: analysis plan K, H5.1
- FINAL_V1: {outcome: SUPPORTED, displaced_cells: {E-12a: [], E-12b: []}, median_coverage_nonnull: {E-12a: 0.9442, E-12b: 0.9451}, median_coverage_all32: {E-12a: 0.9436, E-12b: 0.9448}, refuting: [], secondary_tau030_null_displaced: []}
- Experiment5_same_rule: SUPPORTED
- classification_differs_from_Experiment5: False

## H5.2 -- SUPPORTED

- status: CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5)
- cells: 24 primary + 8 stress (tau 0/0.30, N 250/600)
- rule: analysis plan K, H5.2
- FINAL_V1: {outcome: SUPPORTED, E12c: [0.09388, 6.965e-04], E5: [0.09697, 6.980e-04], same_sign: True, E12c_abs_bias_ge_0_02: True, secondary_null: [0.0876, 6.799e-04]}
- Experiment5_same_rule: SUPPORTED
- classification_differs_from_Experiment5: False

## H5.3 -- SUPPORTED

- status: CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5)
- cells: 24 primary + 8 stress (tau 0/0.30, N 250/600)
- rule: analysis plan K, H5.3
- FINAL_V1: {outcome: SUPPORTED, declines: {E-12a: {...; see JSON}, E-12b: {...; see JSON}, E-5: {...; see JSON}, E-12c: {...; see JSON}}}
- Experiment5_same_rule: SUPPORTED
- classification_differs_from_Experiment5: False
- Corollary-1: {E-5 minus E-12a: {difference_of_declines: 0.073, mcse: 0.007319, n250_paired: [-0.0588, 0.004476, 5000], n600_paired: [-0.1318, 0.005791, 5000]}, E-5 minus E-12b: {difference_of_declines: 0.0712, mcse: 0.007325, n250_paired: [-0.0604, 0.004498, 5000], n600_paired: [-0.1316, 0.005781, 5000]}}

## H5.4 -- REPORTED (open question)

- status: CONFIRMATORY RE-ESTIMATE
- cells: 32 cells
- rule: protocol 6A.5
- where: RMSE and median-width ratios of E-12a/E-12b against E-5 in every cell (Exp5_32_cells_paired.csv)

## H5.5 -- REPORTED (open question)

- status: CONFIRMATORY RE-ESTIMATE
- cells: 32 cells
- rule: protocol 6A.5
- where: RMSE ratio E-12b / E-12a in every cell (cell_level/PAIRED_CONTRASTS_WITHIN_CONFIGURATION.csv)

## H5.6 -- REPORTED (open question)

- status: CONFIRMATORY RE-ESTIMATE
- cells: 32 cells
- rule: protocol 6A.5
- where: E-6H against E-6 (pair E-6H|E-6), including sparse validation (supplementary/H4.6_TDS_sparse_validation.csv)

