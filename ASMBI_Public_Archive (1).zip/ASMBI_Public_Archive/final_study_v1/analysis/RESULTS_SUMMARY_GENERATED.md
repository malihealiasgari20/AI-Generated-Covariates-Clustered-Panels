# FINAL_V1 results summary (generated)

Final prospectively frozen study FINAL_V1 (pre-run record sealed 3 November 2026). Generated from the analysis outputs in this folder; numbers are copied from the tables, with Monte Carlo SEs in parentheses. Interpretation is limited to the pre-specified rules (record 6.6, 7, 9).

## 1. Integrity

- Sealed pre-run record SHA-256 bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0; protocol v1.10 2c2fbdf15ade74688aaa1f8ec0549f7762ab308acd6e59da1dec4fb00c553c6e.
- Gate record 808e6abf07d05d7f83dec06ad8ccb7e3f2b9f1c9a7667233cf4bf6af0343162b; theta_0 map 6d18e3f01f21ed31ebe922ed1b1f4f7f1431eccb072fb889b91fb98388af00a7; E-10 ABSENT -- gate V10 failed (V10.1); per record 3.4 no approximate replacement or substitute is created (protocol v1.10, amendment A10.1).
- Module cells 176; configurations 149; cell-level rows: {'conventional_rows': 2656, 'robust_rows': 2594, 'pair_rows': 5121}.

## 2. Hypothesis outcomes

| ID | Outcome | Status |
| --- | --- | --- |
| H1.1 | REFUTED | CONFIRMATORY RE-ESTIMATE (rho_e 0.60 arm observed in S0.11) |
| H1.2 | SUPPORTED | rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE |
| H1.3 | SUPPORTED | rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE |
| H1.3b | SUPPORTED | PROSPECTIVE except kappa 0 and 0.60 (Experiment 5 cells) |
| H1.3c | REPORTED | mixed (see record 0.3) |
| H1.4 | REFUTED | rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE |
| H2.1 | SUPPORTED | (i) PROSPECTIVE; (ii) CONFIRMATORY RE-ESTIMATE |
| H2.1b | SUPPORTED | PROSPECTIVE (A0 cells never run) |
| H2.2 | NOT SUPPORTED | uniform cells PROSPECTIVE; (A1,B1) CONFIRMATORY |
| H2.3 | SUPPORTED | CONFIRMATORY RE-ESTIMATE |
| H2.4 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (A1 cells); A0 cells PROSPECTIVE |
| H2.4b | SUPPORTED | A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5) |
| H2.5 | SUPPORTED | A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5) |
| H3.1 | SUPPORTED | PROSPECTIVE (kappabar 0.60 at T 8 never run) |
| H3.1b | SUPPORTED; scaling clause: REFUTED | PROSPECTIVE |
| H3.2 | REFUTED | PROSPECTIVE |
| H3.3 | SUPPORTED | PROSPECTIVE |
| H3.4 | REFUTED | PROSPECTIVE (T 8 cell: CONFIRMATORY) |
| H3.5 | REPORTED | positioning statement (no test) |
| H4.1 | SUPPORTED | PROSPECTIVE (60 of 62 cells never run); not informative for E-12a/E-12b |
| H4.2 | E-10 part: ABSENT; interpretation rule (record 7.4) applied to E-6, E-12a, E-12b: branch 1 -- E-12a, E-12b attain R_RMSE < 1 at the baseline | baseline: CONFIRMATORY (development: E-12a below 1); uniform cell PROSPECTIVE |
| H4.3 | E-4: NOT SUPPORTED; E-5: SUPPORTED; E-6: NOT SUPPORTED; HT-TDS-I: NOT SUPPORTED; PS-TDS-I: NOT SUPPORTED; E-9: NOT SUPPORTED; E-12a: NOT SUPPORTED; E-12b: NOT SUPPORTED | PROSPECTIVE |
| H4.4 | E-10: ABSENT; E-6: SUPPORTED | PROSPECTIVE |
| H4.4b | E-10: ABSENT; E-12a: REFUTED; E-12b: REFUTED; HT-TDS-I: SUPPORTED | PROSPECTIVE |
| H4.5 | REPORTED (open question) | PROSPECTIVE |
| H4.6 | REPORTED (open question; table supplementary/H4.6_TDS_sparse_validation.csv) | PROSPECTIVE |
| H5.1 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5) |
| H5.2 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5) |
| H5.3 | SUPPORTED | CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5) |
| H5.4 | REPORTED (open question) | CONFIRMATORY RE-ESTIMATE |
| H5.5 | REPORTED (open question) | CONFIRMATORY RE-ESTIMATE |
| H5.6 | REPORTED (open question) | CONFIRMATORY RE-ESTIMATE |

## 3. Table 4 (primary grid, 12 non-null cells; Type I from the 12 null cells)

| Procedure | Bias | RMSE | Cov. med. | Cov. min | Cov. max | Width | Type I | Power |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Naive (E-1) | -0.0826 (0.0001) | 0.0864 (0.0001) | 0.016 (0.001) | 0.001 | 0.812 | 0.087 | 0.310 (0.001) | 0.665 (0.002) |
| Lab.-only IPW (E-2) | +0.0012 (0.0004) | 0.0658 (0.0003) | 0.942 (0.002) | 0.940 | 0.947 | 0.252 | 0.058 (0.001) | 0.641 (0.003) |
| PPI (obs.) (E-3) | +0.0067 (0.0004) | 0.0656 (0.0003) | 0.940 (0.002) | 0.927 | 0.946 | 0.236 | 0.066 (0.001) | 0.732 (0.002) |
| PPI (CR) (E-4) | +0.0067 (0.0004) | 0.0656 (0.0003) | 0.970 (0.001) | 0.961 | 0.974 | 0.264 | 0.039 (0.001) | 0.663 (0.002) |
| Unw. CF rect. (E-5) | +0.0354 (0.0003) | 0.0618 (0.0002) | 0.892 (0.002) | 0.877 | 0.902 | 0.197 | 0.097 (0.002) | 0.950 (0.001) |
| HT rect. (E-6) | +0.0096 (0.0006) | 0.1081 (0.0055) | 0.969 (0.001) | 0.961 | 0.982 | 0.330 | 0.023 (0.001) | 0.412 (0.003) |
| Reg. cal. (E-7) | +0.0268 (0.0003) | 0.1029 (0.0002) | 0.887 (0.003) | 0.063 | 0.946 | 0.230 | 0.309 (0.001) | 0.665 (0.002) |
| HT rect. (jk) (E-8) | +0.0096 (0.0006) | 0.1081 (0.0055) | 0.967 (0.001) | 0.959 | 0.980 | 0.326 | 0.025 (0.001) | 0.429 (0.003) |
| Hist. CDA (E-9) | +0.0028 (0.0005) | 0.0844 (0.0004) | 0.973 (0.001) | 0.967 | 0.978 | 0.339 | 0.026 (0.001) | 0.394 (0.003) |
| CF-u HT (E-12a) | +0.0016 (0.0003) | 0.0555 (0.0002) | 0.944 (0.002) | 0.937 | 0.948 | 0.213 | 0.056 (0.001) | 0.775 (0.002) |
| CF-w HT (E-12b) | +0.0015 (0.0003) | 0.0553 (0.0002) | 0.945 (0.002) | 0.938 | 0.950 | 0.212 | 0.056 (0.001) | 0.778 (0.002) |
| HT-TDS-I (HT-TDS-I) | +0.0097 (0.0005) | 0.0976 (0.0008) | 0.969 (0.001) | 0.961 | 0.982 | 0.330 | 0.023 (0.001) | 0.412 (0.003) |
| PS-TDS-I (PS-TDS-I) | +0.0048 (0.0005) | 0.0864 (0.0004) | 0.975 (0.001) | 0.970 | 0.982 | 0.334 | 0.020 (0.001) | 0.407 (0.003) |

## 4. Experiment 1 (contamination ladder)

- E-1 zero-bias crossing, rho_e=0.00: NA (none on [0, 3.0]); bootstrap 95% interval [NA, NA]; share of draws with an in-range root 0.000.
- E-1 zero-bias crossing, rho_e=0.60: 0.912 (extrapolated (outside the simulated range)); bootstrap 95% interval [0.902, 0.923]; share of draws with an in-range root 0.011.
- O1.4 E-6|rho_e=0.00: stable centering (max |bias| / half median width 0.094).
- O1.4 E-8|rho_e=0.00: stable centering (max |bias| / half median width 0.096).
- O1.4 E-9|rho_e=0.00: stable centering (max |bias| / half median width 0.030).
- O1.4 E-12a|rho_e=0.00: stable centering (max |bias| / half median width 0.018).
- O1.4 E-12b|rho_e=0.00: stable centering (max |bias| / half median width 0.018).
- O1.4 HT-TDS-I|rho_e=0.00: stable centering (max |bias| / half median width 0.087).
- O1.4 PS-TDS-I|rho_e=0.00: stable centering (max |bias| / half median width 0.040).
- O1.4 E-6|rho_e=0.60: stable centering (max |bias| / half median width 0.065).
- O1.4 E-8|rho_e=0.60: stable centering (max |bias| / half median width 0.066).
- O1.4 E-9|rho_e=0.60: stable centering (max |bias| / half median width 0.017).
- O1.4 E-12a|rho_e=0.60: stable centering (max |bias| / half median width 0.012).
- O1.4 E-12b|rho_e=0.60: stable centering (max |bias| / half median width 0.010).
- O1.4 HT-TDS-I|rho_e=0.60: stable centering (max |bias| / half median width 0.063).
- O1.4 PS-TDS-I|rho_e=0.60: stable centering (max |bias| / half median width 0.030).

## 5. Experiment 2 (validation design x heterogeneity)

- E-5 interaction contrast Delta = +0.0925 (MCSE 0.0013).

## 6. Experiment 3 (1/T scaling)

- Control C3: PASSED.
- E-1 scaling slope b = -0.379, 95% CI [-0.389, -0.370] (predicted -1); weighted residual chi-square 180.08 on 4 df.

## 7. Experiment 4 (efficiency crossover)

- E-4 boundary f_c by sd_e: 0.15: above 0.50; 0.25: reverse (>= 0 at small f, < 0 at larger f); 0.35: reverse (>= 0 at small f, < 0 at larger f); 0.55: reverse (>= 0 at small f, < 0 at larger f); 0.8: below 0.03
- E-5 boundary f_c by sd_e: 0.15: above 0.50; 0.25: above 0.50; 0.35: above 0.50; 0.55: crossing at f = 0.429; 0.8: crossing at f = 0.245
- E-6 boundary f_c by sd_e: 0.15: reverse (>= 0 at small f, < 0 at larger f); 0.25: below 0.03; 0.35: below 0.03; 0.55: below 0.03; 0.8: below 0.03
- HT-TDS-I boundary f_c by sd_e: 0.15: reverse (>= 0 at small f, < 0 at larger f); 0.25: below 0.03; 0.35: below 0.03; 0.55: below 0.03; 0.8: below 0.03
- PS-TDS-I boundary f_c by sd_e: 0.15: reverse (>= 0 at small f, < 0 at larger f); 0.25: below 0.03; 0.35: below 0.03; 0.55: below 0.03; 0.8: below 0.03
- E-9 boundary f_c by sd_e: 0.15: above 0.50; 0.25: reverse (>= 0 at small f, < 0 at larger f); 0.35: reverse (>= 0 at small f, < 0 at larger f); 0.55: below 0.03; 0.8: below 0.03
- E-12a boundary f_c by sd_e: 0.15: above 0.50; 0.25: above 0.50; 0.35: above 0.50; 0.55: above 0.50; 0.8: above 0.50
- E-12b boundary f_c by sd_e: 0.15: above 0.50; 0.25: above 0.50; 0.35: above 0.50; 0.55: above 0.50; 0.8: above 0.50

## 8. Experiment-5 re-evaluation

- H5.1: FINAL_V1 SUPPORTED; Experiment 5 under the same rule SUPPORTED.
- H5.2: FINAL_V1 SUPPORTED; Experiment 5 under the same rule SUPPORTED.
- H5.3: FINAL_V1 SUPPORTED; Experiment 5 under the same rule SUPPORTED.

## 9. Dissociation (Table 9)

- kappa 0.0: QWK 0.7263, Spearman 0.7715, naive bias -0.0956, incremental OOS R^2 0.194%.
- kappa 0.2: QWK 0.7235, Spearman 0.7687, naive bias -0.0673, incremental OOS R^2 0.511%.
- kappa 0.4: QWK 0.7153, Spearman 0.7606, naive bias -0.0422, incremental OOS R^2 0.922%.
- kappa 0.6: QWK 0.7030, Spearman 0.7484, naive bias -0.0222, incremental OOS R^2 1.365%.
- kappa 0.8: QWK 0.6875, Spearman 0.7331, naive bias -0.0068, incremental OOS R^2 1.806%.
- kappa 1.0: QWK 0.6700, Spearman 0.7159, naive bias +0.0043, incremental OOS R^2 2.210%.

