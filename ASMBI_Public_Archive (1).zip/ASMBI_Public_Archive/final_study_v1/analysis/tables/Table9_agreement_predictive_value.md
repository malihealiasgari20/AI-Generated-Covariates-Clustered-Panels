Table 9. Agreement and predictive value against contamination intensity (module D: ICC 0.30, rho_e 0.60, gamma_W 0.15; 1,000 replications per kappa). Final prospectively frozen study FINAL_V1 (pre-run record sealed 3 November 2026). QWK: Z_L against the frozen discretization of mean(lambda1) Z_H; rank correlation: raw Spearman of Z_L with Z_H; naive bias: E-1 (negative = attenuation); incremental OOS R^2: record 7.6 [D8], a new definition (five unit folds, FINAL_V1_OOS), in percent. Descriptive only. MCSE in parentheses.

| kappa | QWK | Rank corr. (Spearman) | Naive bias | Incremental OOS R^2 (%) | Raw Pearson | Within Pearson |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 0.0 | 0.7263 (0.0004) | 0.7715 (0.0004) | -0.0956 (0.0006) | 0.194 (0.006) | 0.7583 (0.0003) | 0.6228 (0.0004) |
| 0.2 | 0.7235 (0.0004) | 0.7687 (0.0004) | -0.0673 (0.0006) | 0.511 (0.008) | 0.7555 (0.0003) | 0.6198 (0.0004) |
| 0.4 | 0.7153 (0.0004) | 0.7606 (0.0004) | -0.0422 (0.0006) | 0.922 (0.011) | 0.7475 (0.0003) | 0.6108 (0.0004) |
| 0.6 | 0.7030 (0.0004) | 0.7484 (0.0004) | -0.0222 (0.0006) | 1.365 (0.014) | 0.7355 (0.0004) | 0.5975 (0.0004) |
| 0.8 | 0.6875 (0.0004) | 0.7331 (0.0004) | -0.0068 (0.0006) | 1.806 (0.016) | 0.7204 (0.0004) | 0.5811 (0.0005) |
| 1.0 | 0.6700 (0.0005) | 0.7159 (0.0004) | +0.0043 (0.0006) | 2.210 (0.018) | 0.7034 (0.0004) | 0.5631 (0.0005) |
