# FINAL_V1 results summary

**Study.** "Stress-Testing Inference with AI-Generated Covariates in Clustered Panels" (Nejatbakhsh & Aliasgari), the final prospectively frozen study FINAL_V1 (pre-run record sealed 3 November 2026).

**Status.** All 149 configurations (567,000 panel replications) are complete, and every analysis step required by record 10.1(7) has been run. No manuscript text has been written or revised. This summary reports results and the pre-specified interpretation branches they trigger (record 9); it is not manuscript prose.

**Reading rules.**

- Monte Carlo SEs are in parentheses.
- Descriptive language follows record 6.6 (D11):
  - Coverage: below 0.920 is material undercoverage; 0.920 to below 0.940 is mild undercoverage; 0.940 to 0.960 is near-nominal; above 0.960 is conservative.
  - Centering: a bias is "centered" if |bias| ≤ 3 MCSE, a "small but detectable displacement" if it is above that but below 0.02, and "materially displaced" if it is ≥ 0.02.
- Hypothesis outcomes use the vocabulary of `ANALYSIS_OPERATIONALIZATIONS.txt` (fixed and hashed before any result). REFUTED always means that the hypothesis's own REFUTED-IF criterion was met.
- Exact numbers for every cell and estimator are in `cell_level/`, `tables/` and `experiments/`.

---

## 1. Provenance and integrity

| Item | Value |
|---|---|
| Sealed pre-run record | `FINAL_V1_PRE_RUN_RECORD_FROZEN.txt`, SHA-256 `bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0` (sealed 2026-11-03T19:00:08Z as revision 3; frozen 19:31:09Z) |
| Protocol v1.6 | `protocol/ASMBI_Post_Primary_Extension_Protocol_v1.6.txt`, SHA-256 `f97f93818cc955e82463c8eda62ec2a03ac5a54036bb2b2afc9f8ac3f40b5177` (A6, finalized 17:19:02Z) |
| Governing protocol | v1.10, SHA-256 `2c2fbdf15ade74688aaa1f8ec0549f7762ab308acd6e59da1dec4fb00c553c6e` (A10, finalized 22:35:15Z, before the run) |
| Registry | 149 unique configurations and 567,000 panel replications. `build_registry.py` rebuilds `FINAL_V1_CELL_REGISTRY_FROZEN.csv` (`cdabf999…`) byte-identically. The analysis re-enumerates all 176 module cells and maps them onto exactly these 149 configurations. |
| Gates | G-A PASS, G-B PASS, G-C PASS, G-D PASS, **G-E FAIL**, G-F PASS. Gate record `808e6abf…`. |
| E-10 | **ABSENT**. V10.1 failed: ppi-python's OLS routines compute a different, asymptotically equivalent estimator. There is no approximation and no substitute (A10.1). |
| θ₀ map | PASS. 53 keys (the 42-key frozen union plus the 11 pre-specified keys), SHA-256 `6d18e3f0…`, hashed 22:26:13Z before the first replication. |
| Run | 149/149 complete. First configuration started 22:35:30Z; RUN_END at 2026-11-04T00:35:51Z. 3.92 worker-hours; 8,352,000 estimator rows. |
| Run health | No non-finite results and no exceptions. Every failure is a pre-specified eligibility rule, an empty post-stratum, or a singular first stage (11 E-7 replications with < 2 labeled units); see §11. |
| Interruption | A container restart at 23:24Z killed the run with 46 configurations complete. C047 and C048 were in flight; they were quarantined and recomputed from their identical seeds. Logged as EXTERNAL_INTERRUPTION and INTERRUPTED_RECOMPUTE. |
| Reproducibility | Replications 0–19 were recomputed in memory for C001, C046 (before the restart, kernel 6.18.44-fc-v230), C047, C048, C100 and C149 (after it, -v233). All six are identical bit for bit in every stored field (`qa/REPRODUCIBILITY_SPOTCHECK.json`). numpy 2.5.3, scipy 1.18.1, Python 3.13.16 throughout. |
| Analysis verification | PASS (`qa/ANALYSIS_VERIFICATION.json`):<br>• 2,760 independent recomputations of record-6.1 quantities agree to ≤ 1.1e-13 relative.<br>• Table 4 re-aggregation matches.<br>• max\|E-8 − E-6\| = 1.1e-11.<br>• max\|E-12a − HT-TDS-CF\| (floor not binding) = 4.4e-16.<br>• The bootstrap index matrices are reproducible. |
| No early inspection | During the run, only run-health fields were read (completion, failure counts by type, runtime, file integrity). The first FINAL_V1 performance quantity was computed at 00:36:24Z (phase-1 start), 33 s after RUN_END. |

---

## 2. Hypothesis outcomes

| ID | Outcome | Status |
|---|---|---|
| H1.1 | **REFUTED** (no zero crossing in [0, 0.90]; estimated crossing 0.912) | confirmatory re-estimate |
| H1.2 | SUPPORTED | ρₑ 0.60 confirmatory; ρₑ 0 prospective |
| H1.3 | SUPPORTED | ρₑ 0.60 confirmatory; ρₑ 0 prospective |
| H1.3b | SUPPORTED | prospective (κ 0, 0.60 confirmatory) |
| H1.3c | REPORTED | — |
| H1.4 | **REFUTED** (E-4 1.103; E-8 7.20, tail-driven) | ρₑ 0.60 confirmatory; ρₑ 0 prospective |
| H2.1 | SUPPORTED | (i) prospective; (ii) confirmatory |
| H2.1b | SUPPORTED | prospective |
| H2.2 | **NOT SUPPORTED** (E-5 coverage in A0B0 is 0.9396, below 0.940) | mixed |
| H2.3 | SUPPORTED (sign; observed / predicted = 1.004) | confirmatory |
| H2.4 | SUPPORTED | A1 confirmatory; A0 prospective |
| H2.4b | SUPPORTED | A0 prospective |
| H2.5 | SUPPORTED | A0 prospective |
| H3.1 | SUPPORTED | prospective |
| H3.1b | sign clause SUPPORTED; scaling clause **REFUTED** | prospective |
| H3.2 | **REFUTED** (slope −0.379, 95% CI [−0.389, −0.370]) | prospective |
| H3.3 | SUPPORTED | prospective |
| H3.4 | **REFUTED** (control-arm bias depends on T) | prospective |
| H3.5 | REPORTED (positioning) | — |
| H4.1 | SUPPORTED | prospective; not informative for E-12a/b |
| H4.2 | E-10 part **ABSENT**. Rule applied to E-6 (= E-11), E-12a, E-12b: **branch 1**, because E-12a and E-12b attain R_RMSE < 1 at the baseline. | baseline confirmatory |
| H4.3 | SUPPORTED for E-5 only; NOT SUPPORTED for the other seven rectified estimators | prospective |
| H4.4 | E-10 ABSENT; E-6 SUPPORTED | prospective |
| H4.4b | E-10 ABSENT; HT-TDS-I SUPPORTED; **E-12a, E-12b REFUTED** (both refuting cells are conditional on success) | prospective |
| H4.5, H4.6 | REPORTED (open questions) | prospective |
| H5.1, H5.2, H5.3 | SUPPORTED, the same classification as Experiment 5 | confirmatory |
| H5.4–H5.6 | REPORTED (open questions) | confirmatory |

---

## 3. Primary grid (Table 4; 12 non-null cells, Type I error from the 12 null cells, R 5,000 each)

| Procedure | Bias | RMSE | Coverage med. [min, max] | Width | Type I | Power |
|---|---:|---:|---|---:|---:|---:|
| Naive (E-1) | −0.0826 (0.0001) | 0.0864 | 0.016 [0.001, 0.812] | 0.087 | 0.310 | 0.665 |
| Labeled-only IPW (E-2) | +0.0012 (0.0004) | 0.0658 | 0.942 [0.940, 0.947] | 0.252 | 0.058 | 0.641 |
| PPI, obs.-level SE (E-3) | +0.0067 (0.0004) | 0.0656 | 0.940 [0.927, 0.946] | 0.236 | 0.066 | 0.732 |
| PPI, CR SE (E-4) | +0.0067 (0.0004) | 0.0656 | 0.970 [0.961, 0.974] | 0.264 | 0.039 | 0.663 |
| Unweighted cross-fitted rectifier (E-5) | +0.0354 (0.0003) | 0.0618 | 0.892 [0.877, 0.902] | 0.197 | 0.097 | 0.950 |
| HT-weighted rectifier (E-6) | +0.0096 (0.0006) | 0.1081 (0.0055) | 0.969 [0.961, 0.982] | 0.330 | 0.023 | 0.412 |
| Regression calibration (E-7) | +0.0268 (0.0003) | 0.1029 | 0.887 [0.063, 0.946] | 0.230 | 0.309 | 0.665 |
| HT-weighted rectifier, jackknife (E-8) | +0.0096 (0.0006) | 0.1081 | 0.967 [0.959, 0.980] | 0.326 | 0.025 | 0.429 |
| Historical CDA (E-9) | +0.0028 (0.0005) | 0.0844 | 0.973 [0.967, 0.978] | 0.339 | 0.026 | 0.394 |
| E-12a (CF, unweighted fit, HT rectifier) | +0.0016 (0.0003) | 0.0555 | 0.944 [0.937, 0.948] | 0.213 | 0.056 | 0.775 |
| E-12b (design-aware CF rectifier) | +0.0015 (0.0003) | 0.0553 | 0.945 [0.938, 0.950] | 0.212 | 0.056 | 0.778 |
| HT-TDS-I | +0.0097 (0.0005) | 0.0976 (0.0008) | 0.969 [0.961, 0.982] | 0.330 | 0.023 | 0.412 |
| PS-TDS-I | +0.0048 (0.0005) | 0.0864 | 0.975 [0.970, 0.982] | 0.334 | 0.020 | 0.407 |

- **E-12a and E-12b** are centered and near-nominal. Their paired R_RMSE against E-2 is 0.82–0.87 in all 12 non-null cells, and the bootstrap interval lies below 1 in each cell.
  - E-12b has the lowest RMSE of all 16 estimators in 8 of the 12 cells; E-12a, which equals HT-TDS-CF there, is second.
  - In the other 4 cells (ρₑ 0.60, κ 0.60), the naive estimator's RMSE is lower (0.030), because its attenuation and contamination biases nearly cancel; its coverage there is 0.80–0.81.
- **E-5** is materially displaced: its bias is +0.035 in every cell, coverage is 0.877–0.902 (material undercoverage), and Type I error is 0.097. **E-4** is conservative (coverage 0.970).
- **E-6 and E-8.**
  - Their mean bias is +0.0096 but their median bias is +0.0019.
  - Their RMSE is tail-driven:
    - 3 of 12 cells are flagged.
    - The worst batch max/min ratio is 4.05.
    - The single worst replication contributes 41% of its cell's SSE.
    - The robust MAD-SD is 0.084, against an empirical SE of 0.108.
  - TDS removes those tails: HT-TDS-I is not flagged in any cell and its RMSE is 0.098. HT-TDS-I and PS-TDS-I are still less efficient than E-2 (R_RMSE 1.24–1.62).
- **Robust companion.** Table 4R and `tables/Table4_primary_aggregate.md` have the robust measures. Only E-6 and E-8 have tail-driven primary cells (3 of 12 each).

---

## 4. Experiment 1: contamination ladder (module L; Tables 5–6, Figure 2)

- **Naive estimator (E-1).**
  - ρₑ 0.60: the bias rises monotonically and on paired replications, from −0.0951 (0.0003) at κ 0. The estimated zero crossing is **κ\* = 0.912**, just outside the simulated range (PCHIP extrapolation), with bootstrap 95% interval [0.902, 0.923]; 1.1% of bootstrap draws cross inside [0, 0.90].
  - **H1.1 is REFUTED** by its "no crossing in range" clause. By the protocol's THEN clause, Section 7.2's sentence is corrected to the estimated value.
  - ρₑ 0: there is no crossing; the bias moves away from zero (−0.095 to −0.130). Coverage at ρₑ 0.60 rises from 0.004 to 0.949 as κ moves through the cancellation region; Type I error rises to 0.999.
- **Regression calibration (E-7; H1.2 SUPPORTED).** The change in bias from κ 0 to 0.90 is +0.309 at ρₑ 0.60 and −0.075 at ρₑ 0. Both are monotone on paired replications, and the ρₑ 0 change is nonzero but smaller. Coverage falls to 0.001 (ρₑ 0.60) and 0.748 (ρₑ 0).
- **Design-aware label-anchored procedures (H1.3 SUPPORTED).** E-6, E-8 and E-9 keep |bias| < 0.02 at every κ under both ρₑ; the maximum is 0.0187, for E-6/E-8 at ρₑ 0 and κ 0.90, a small but detectable drift from 0.011. Coverage is 0.964–0.984 for E-6 and 0.969–0.979 for E-9.
- **H1.3b SUPPORTED.** E-12a and E-12b have max |bias| 0.0021, coverage 0.940–0.946 and Type I error 0.056–0.063 along the whole ladder.
- **H1.3c (reported).** E-5 and E-12c carry their κ-0 design displacement (+0.035, +0.034), which changes by ≤ 0.005 along the ladder. E-4: +0.008 at κ 0, changing by up to 0.012.
- **H1.4 REFUTED** on two cells:
  - E-4 has SE ratio 1.103 at ρₑ 0, κ 0.90 (conservative).
  - E-8 has SE ratio 7.20 at ρₑ 0.60, κ 0.15. A single replication has a jackknife SE of 3,032, which is 88% of the cell's summed SEs: the tail behaviour already seen in the Experiment-5 addendum. Its robust counterpart (median SE / MAD-SD) is 0.985.
  - E-6 and E-9 stay within 10% everywhere.
- **O1.4.** All seven design-aware rectifiers show *stable centering*: |bias| / (median width / 2) is at most 0.096.

## 5. Experiment 2: validation design × slope heterogeneity (O2.1–O2.5, Figure X2)

- **E-5 bias by cell:**
  - Uniform validation: A0B0 +0.0014 (0.0006); A0B1 +0.0012 (0.0007), both centered.
  - Unequal validation: A1B0 +0.0046 (0.0006); A1B1 +0.0970 (0.0007).
  - **H2.1 SUPPORTED.**
- **Interaction.** Δ = **+0.0925 (0.0013)** (H2.1b SUPPORTED): slope heterogeneity amplifies the displacement far beyond the λ₁ channel.
- **Mechanism (H2.3 SUPPORTED).** The predicted selected-mixture displacement in A1B1 (F10a) is +0.0965 (0.0003) against an observed +0.0970; observed / predicted = 1.004.
- **H2.2 NOT SUPPORTED.**
  - E-5 coverage is 0.9396 (0.0034) in A0B0, 0.0004 below the pre-set 0.940 threshold (mild-undercoverage band).
  - It is 0.958 in A0B1 and 0.510 in A1B1 (material undercoverage); 0.945 in A1B0.
  - This hypothesis has no REFUTED-IF clause.
- **H2.4 and H2.4b SUPPORTED.** For E-2, E-6, E-8, E-9, E-12a and E-12b, every A1 − A0 bias difference is within 3 MCSE. E-4, reported separately, is displaced under unequal validation with heterogeneity (B1: +0.0188 (0.0012)), as Proposition 1 predicts for a uniform rectifier.
- **H2.5 SUPPORTED.** E-12c equals E-5 under uniform validation, because the design weights are constant there. It follows E-5 under unequal validation (+0.0939 in A1B1).
- **E2-LAMBDA (O2.5).**
  - With λ₁(s) constant, E-5 is centered at τ 0 (+0.0005) and displaced at τ 0.30 (+0.0817).
  - The realized D_s are not equal across strata even at τ 0; the calibration-rule D_s are −0.004, +0.010 and −0.005, unequal within 3 MCSE. This is reported as residual stratum dependence in the DGP, as the protocol anticipated, not as a failed arm.

## 6. Experiment 3: 1/T scaling (O3.1–O3.4, Figure X3)

- **Control C3 PASSED.** The realized within-signal moment deviates at most 0.05% from its T = 8 value.
- **Displacement, E-1** (paired within T; κ̄ 0.60 vs 0): all negative and all detectable (H3.1 SUPPORTED, z = −197 at T 8; H3.3 SUPPORTED).

  | T | 4 | 6 | 8 | 10 | 12 | 16 |
  |---|---:|---:|---:|---:|---:|---:|
  | d(T) | −0.0441 | −0.0412 | −0.0370 | −0.0334 | −0.0304 | −0.0269 |
  | T·\|d\| | 0.176 | 0.247 | 0.296 | 0.334 | 0.365 | 0.431 |

  T·|d| rises with T; it is not flat.
- **Scaling (H3.2 REFUTED).** Slope b = −0.379, 95% CI [−0.389, −0.370], against a predicted −1. The weighted residual χ² is 180 on 4 df. E-7 gives b = −0.441 [−0.454, −0.428].
  - Per the protocol's THEN clause, this is a finding: the displacement decays more slowly than 1/T, roughly as T^−0.4 over T 4–16.
  - The H3.1b scaling clause is refuted with it; its sign clause is supported.
- **Control arm (H3.4 REFUTED).** E-1's κ̄-0 bias moves from −0.0893 (T 4) to −0.0973 (T 16): slope on log T −0.0050 (SE 0.0003), homogeneity χ² 255 on 5 df.
  - The protocol's pre-specified consequence: the experiment does not isolate the channel, and it must be redesigned before any 1/T claim is made.
  - For context, not as a change of rule: the control-arm change across T (0.008) is small relative to the displacements (0.027–0.044).
- **Other estimators.** E-2's displacement is identically zero at every T, because it uses human labels only. E-6's is small and noisy.

## 7. Experiment 4: efficiency crossover (O4.1–O4.5, Figure X4; E-10 ABSENT)

- **R_RMSE against E-2** (γ_W 0.15 grid; cells with failure rate > 5% are flagged and excluded from the contour):
  - E-12a and E-12b are classified "rectification pays" in every unflagged cell (20 of 20; f ≥ 0.10). Their only non-paying cell is f 0.03, sd 0.80, which is flagged.
  - E-5 pays in 17 cells and E-4 in 14 (where the machine error is small).
  - E-9 pays in 2 cells, PS-TDS-I in 1, and E-6 and HT-TDS-I in none.
  - Identity-family R_RMSE reaches 128 for E-6 under sparse validation. TDS caps it at about 4 (HT-TDS-I ≤ 3.97).
  - **H4.1 SUPPORTED.**
- **H4.2.** The E-10 part is ABSENT. At the baseline (f 0.35, sd 0.55, R 2,000):
  - E-12a 0.831 (0.009) and E-12b 0.827 (0.010) are classified "pays"; E-6 is 1.523 (0.055), "labeled-only better".
  - This is **interpretation branch 1** (record 7.4): the efficiency headline is withdrawn (§12).
  - In the uniform-validation cell (R 5,000), E-12a and E-12b are 0.866 (0.006) and E-6 is 1.375 (0.022).
- **H4.3.** Only E-5's boundary moves toward larger f as quality improves (f_c 0.43 at sd 0.55, 0.25 at sd 0.80, beyond 0.50 below that).
  - E-12a and E-12b pay at every unflagged f for every sd_e, so their boundary lies outside the grid.
  - The identity family almost never pays.
  - All of these are NOT SUPPORTED, which is not a refutation.
- **Coverage.**
  - H4.4 SUPPORTED: E-6 has coverage ≥ 0.951 in all 30 grid cells; HT-TDS-I also ≥ 0.951.
  - **H4.4b REFUTED for E-12a and E-12b:**
    - (f 0.03, sd 0.55): coverage 0.898 / 0.908, R_RMSE 0.945 / 0.952.
    - (f 0.05, sd 0.80): coverage 0.906 / 0.906, R_RMSE 0.935 / 0.926.
    - Both cells are conditional on success: G_S ≥ 10 excludes E-12a/b in 58% and 6% of samples respectively.
    - The pre-specified consequence: report the gain as coming at a coverage cost there.
- **H4.5.** E-12a and E-12b fail to pay only at (0.03, 0.80). The G_S ≥ 10 rule excludes them in 58–60% of samples at f 0.03 and 6–6.5% at f 0.05.
- **Matched size at the baseline (O4.3).**
  - Matched-coverage median width relative to E-2: 0.844 for E-12a, 0.839 for E-12b, 1.189 for E-6.
  - Size-adjusted power: 0.843 for E-12a and 0.850 for E-12b, against 0.664 for E-2.
- **Agreement mapping (O4.4).** QWK falls from 0.824 to 0.640, and within-unit Pearson correlation from 0.774 to 0.521, as sd_e rises from 0.15 to 0.80.

## 8. Experiment-5 re-evaluation (32 configurations; Figure X5)

- **H5.1 SUPPORTED.** E-12a and E-12b are centred in all 32 cells; median coverage is 0.944 / 0.945.
- **H5.2 SUPPORTED.** At τ 0.30, E-12c is +0.0939 (0.0007) and E-5 is +0.0970.
- **H5.3 SUPPORTED.** Coverage decline from N 250 to N 600:

  | Estimator | Decline (MCSE) |
  |---|---|
  | E-12a | 0.004 (0.005) |
  | E-12b | 0.006 (0.005) |
  | E-5 | 0.077 (0.007) |
  | E-12c | 0.073 (0.007) |

- **Corollary 1.** The difference of declines, E-5 − E-12a, is 0.073 (0.007).
- All three classifications equal Experiment 5's under the same rules.

## 9. Stress grid and validation intensity (Tables 7–8, Figure 3)

- **Validation intensity.**
  - E-12a and E-12b are narrower than E-2 at every intensity: median width 0.309 vs 0.386 at 34.65 expected labeled clusters, and 0.140 vs 0.155 at 210.
  - E-6, E-9 and the TDS variants are wider than E-2 at every intensity (0.585 → 0.175 for E-6).
  - E-12a coverage is 0.929, 0.936, 0.948, 0.943, 0.944 and 0.951 across the intensities; E-2's is 0.924–0.951.
- **Stress conditions.**
  - E-12a/E-12b coverage stays within 0.929–0.953 in all 17 conditions, and their Type I error within 0.048–0.066.
  - E-5 coverage falls to 0.510 at τ 0.30 and 0.805 at N 600, with Type I error 0.442 at τ 0.30.
  - E-7 collapses under contamination (0.587 at κ 0.30; 0.001 at κ 0.90).
  - The naive estimator reaches 0.949 only at κ 0.90, through cancellation.
- **Size.** E-2's Type I error is 0.053–0.072 in the stress grid. By the record 6.6 rule it exceeds 0.05 + 3 MCSE in 37 of 78 null cells across modules (P 2, L 7, S 9, X2 2, X4 17), with values up to 0.103 in sparse X4 cells.
  - E-12a exceeds it in 18 of 78 (P 2, L 6, S 3, X4 7).
  - E-12a's Type I error is 0.043–0.066 outside X4 and up to 0.095 at f 0.03 (conditional on success).

## 10. Dissociation (Table 9, Figure 4)

- As κ rises from 0 to 1.0, agreement falls slightly: QWK from 0.726 to 0.670 and Spearman from 0.772 to 0.716.
- Over the same range, incremental out-of-sample R² rises from 0.19% to 2.21%, and the naive bias moves from −0.096 to +0.004.
- This is descriptive only (record 7.6).

## 11. Failures, tails and near-singularity

- **Failures by type.** All match the design probabilities of record 5.

  | Failure | Estimators | Replications |
  |---|---|---|
  | Below minimum, G_S < 10 | E-5, E-12a/b/c, HT-TDS-CF | 13,041 each |
  | Below minimum, G_S < 5 | identity family and E-2 | 1,033 each |
  | Empty post-stratum (full sample) | E-9 | 9,257 |
  | Empty post-stratum (deletion) | E-9 | 15,474 |
  | Empty post-stratum (PS rule) | PS-TDS-I | 8,474 |
  | Singular first stage | E-7 | 11 |

  - Examples: P(G_S < 10) at f 0.03 is 0.58–0.60 observed against 0.587 expected.
  - There are no non-finite results and no exceptions.
  - Every estimator–cell with failure rate > 5% is in module X4 and is marked † (conditional on success).
- **Tail-driven entries** (record 6.2):
  - E-6: 61 of 170; E-8: 59 of 159; E-6H: 31; E-9: 30; E-3/E-4: 25; PS-TDS-I: 11; E-7: 7; HT-TDS-I: 4.
  - None for E-1, E-2, E-5, E-12a, E-12b, E-12c or HT-TDS-CF.
  - `supplementary/S7` lists each flagged entry with its robust counterparts.
- **Near-singularity.** The identity family has s/(NT) < 0.05 in up to 33% of replications and s < 0 in up to 29% (sparse X4 cells). The cross-fitted family has neither.

## 12. Pre-specified interpretation branches triggered (record 9)

These are the branches the sealed rules select. Which manuscript sentences they govern is for the authors' review; no text has been changed.

- **C-1 mixture centering.** H5.1, H5.2 and the Experiment-2 results hold. The record's sentence applies: an unweighted cross-fitted rectifier can fail under informative cluster validation when stratum-specific moment corrections differ; a design-unbiased rectifier weight removes the failure; weighting the calibration fit alone does not.
- **C-2 leakage.**
  - Label-anchored design-aware procedures remain centered along the ladder (H1.3, H1.3b SUPPORTED).
  - The naive crossing estimate is κ\* ≈ 0.91, just above the simulated range (H1.1 REFUTED by its range clause).
  - Experiment 3 detects a negative displacement at every T. Its decay is slower than 1/T (H3.2 REFUTED), and its control arm is T-dependent (H3.4 REFUTED), so the 1/T scaling claim needs a redesigned experiment before it is made.
- **C-3 stabilization.** TDS controls the identity-family explosions:
  - Tail-driven entries fall from 61 (of 170, E-6) to 4 (of 159, HT-TDS-I).
  - Sparse-validation R_RMSE falls from up to 128 to at most about 4.

  TDS does not make that family competitive with E-2. It stabilizes the point estimate, not the inference. E-9 remains a negative lesson.
- **C-4 efficiency.** This is branch 1: E-12a and E-12b beat design-weighted labeled-only analysis at and around the baseline, and across the primary, stress and Experiment-4 grids. By record 7.4, the claim that "rectification bought nothing" is withdrawn. The finding is scoped to this DGP, E-2 remains a reporting requirement, and E-10 is ABSENT.
- **C-5 sparse validation.** E-12a and E-12b coverage, by module:

  | Module | Coverage |
  |---|---|
  | P | 0.937–0.950 |
  | L | 0.940–0.946 |
  | X2 | 0.939–0.959 |
  | S | 0.929–0.953 (0.929 at m 0.33, 34.65 clusters) |
  | X4 | down to 0.895 |

  - Cells in the 0.920–0.940 band are "near-nominal with mild finite-sample undercoverage".
  - In X4 cells with f ≤ 0.05 and sd_e ≥ 0.55, coverage is 0.895–0.922: material undercoverage, conditional on success.
  - Small-cluster corrections were not evaluated (S2).
- **D dissociation.** Descriptive only.

## 13. Corrections, deviations and disclosures

- **FINAL_V1 production code.** Unchanged after Step 5; every checkpoint carries fingerprint `2d263942…`.
- **Implementation-only corrections after sealing.** These were gate-harness fixes; none touched FINAL_V1 code or the design. All are logged in `gates/GATE_RUN_LOG.txt`.
  - **G-B:** the sealed module had to be registered in `sys.modules` before loading (a Python dataclass requirement).
  - **G-D:** the configuration selector compares π to 1e-12. The shared baseline π differs from `pi_target_fraction(0.35)` by 1 ulp.
  - **G-C:** a failure-path section was added, because the 20 sealed gate panels contained no failures. This strengthens the gate.
  - **Gate report:** a formatting fix.
- **Amendment A10** (before the run):
  - A10.1 records E-10 as ABSENT.
  - A10.2 corrects a factual statement in record 0.6(c): the S0.9 driver crashes whenever G_S ≤ 9.
  - A10.3 records the θ₀ map hash.
- **Execution.** C047 and C048 were recomputed from identical seeds after a container restart. The kernel build changed across the restart (v230 → v233); the bit-for-bit spot-check passed.
- **Analysis.**
  - Computational details left open by the sealed texts were fixed in `ANALYSIS_OPERATIONALIZATIONS.txt` (SHA-256 `b6818c56…`) before any result.
  - After the visual figure QA, the figures were regenerated three times with display-only changes (`qa/FIGURE_QA.txt`; NOTE events in `ANALYSIS_LOG.jsonl`). No number changed.
  - Figure 4 uses two panels instead of the manuscript's dual axis.
  - Table 10 has no new computation and is rewritten with the manuscript.
- **Testing.** The analysis code was tested on a throwaway 12-replication run in a separate seed namespace (FV1_ANATEST). Its outputs were viewed only for layout and mechanics and have been deleted.

## 14. Where things are

| Item | Location |
|---|---|
| Cell-level measures | `cell_level/` |
| Tables 4–9 | `tables/` |
| Figures and captions | `figures/` (captions in `FIGURE_CAPTIONS.md`) |
| Experiment outputs | `experiments/` |
| Hypotheses | `hypotheses/` |
| Supplementary tables | `supplementary/` |
| QA | `qa/` |
| Cell-definition map | `CELL_DEFINITION_MAP.csv` |
| Output map | `OUTPUT_MAP.json` |
| Execution log | `../EXECUTION_LOG.txt` |
| Final manifest | `../MANIFEST_SHA256_FINAL.txt` |
