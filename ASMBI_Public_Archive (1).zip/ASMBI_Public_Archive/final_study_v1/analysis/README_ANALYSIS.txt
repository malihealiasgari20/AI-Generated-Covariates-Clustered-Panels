FINAL_V1 ANALYSIS PACKAGE (Step 8)
==================================

Written after all 149 configurations of the production run were complete (run/EXECUTION_SUMMARY.txt).
Governing documents: FINAL_V1_PRE_RUN_RECORD_FROZEN.txt (record), protocol v1.10, and
ANALYSIS_OPERATIONALIZATIONS.txt -- the computational details the sealed texts leave open, fixed and
hashed before any performance quantity was computed (its SHA-256 is in every ANALYSIS_LOG.jsonl entry).

Rerun (deterministic; about 20 minutes on two cores):
    cd /tmp
    python3 -I -B Final_Study_v1/analysis/code/fa_closeout.py      run health and completion (run/)
    python3 -I -B Final_Study_v1/analysis/code/fa_run.py check
    python3 -I -B Final_Study_v1/analysis/code/fa_run.py phase1 --workers 2
    python3 -I -B Final_Study_v1/analysis/code/fa_run.py phase2
    python3 -I -B Final_Study_v1/analysis/code/fa_verify.py         independent re-computation checks
    python3 -I -B Final_Study_v1/analysis/code/fa_repro.py          bit-for-bit replication spot-check
Phase 1 writes per-(configuration, R) results and bootstrap draws to a cache outside the package
(FV1_CACHE, default /home/claude/fv1_analysis_cache); they are regenerated exactly from the checkpoints
and the FINAL_V1_BOOT stream.

Contents
  ANALYSIS_OPERATIONALIZATIONS.txt   pre-result computational rules (plan sections A-L)
  ANALYSIS_LOG.jsonl                 analysis steps with UTC times, plan and code SHA-256
  CELL_DEFINITION_MAP.csv            176 module cells -> configuration, seeds, R, factors, theta_0,
                                     source checkpoint and SHA-256, outputs using the cell (record 8)
  OUTPUT_MAP.json                    every table and figure -> cells, R, aggregation rule, files
  RESULTS_SUMMARY.md                 the results summary (record 10.4)
  RESULTS_SUMMARY_GENERATED.md       the machine-generated digest it is built on
  cell_level/                        every record-6 measure for every module cell and estimator:
      CELL_LEVEL_CONVENTIONAL.csv    6.1 measures, analytic MCSEs (bootstrap for ratios and medians),
                                     record-6.6 descriptive classes, conditional-on-success flag
      CELL_LEVEL_ROBUST_AND_TAILS.csv 6.2 measures with bootstrap MCSEs, batch RMSE, tail influence,
                                     tail-driven flag, tail quantiles and counts
      FAILURES_BY_TYPE.csv           failure counts by recorded type
      NEAR_SINGULAR_FREQUENCY.csv    s/(NT) < 0.05 and s < 0 for every Schur-solver estimator
      PAIRED_CONTRASTS_WITHIN_CONFIGURATION.csv   6.3 paired contrasts (intersection of successes)
      DIAGNOSTIC_MEANS.csv           replication means of every record-3.8 diagnostic
  tables/                            manuscript Tables 4 (+4R robust), 5-6 (O1.1, replacing the
                                     coverage-only tables), 7, 8, 9: CSV (full precision) and Markdown
  figures/                           Figures 1-4, X2-X5 and supplementary S2-S4: PNG (200 dpi), PDF,
                                     and a CSV twin of the plotted values; FIGURE_CAPTIONS.md
  experiments/Exp1 ... Exp4, Exp5_reevaluation   O1.1-O1.4, O2.1-O2.5, O3.1-O3.4, O4.1-O4.5, H5
  hypotheses/                        HYPOTHESES.csv, HYPOTHESIS_EVALUATION.md, HYPOTHESIS_EVIDENCE.json
  supplementary/                     S1 E-6H and HT-TDS-CF in full; S2 every estimator by module;
                                     H4.6 TDS under sparse validation; S4 floor and design diagnostics;
                                     S5-S6 failure totals and details; S7 tail-driven entries with
                                     robust counterparts; S8 P/S design-aware and TDS comparisons
  qa/                                FIGURE_QA.txt, ANALYSIS_VERIFICATION.json,
                                     REPRODUCIBILITY_SPOTCHECK.json
  code/                              the analysis code (fa_*.py)

Conventions
  Monte Carlo SEs in parentheses. Analytic MCSEs (Morris, White & Crowther 2019) for means and rates;
  bootstrap MCSEs (B = 2,000, FINAL_V1_BOOT, replication indices resampled jointly across cells) for
  medians, MAD-SD, ratios, quantiles, the zero-bias crossing, matched-size quantities and aggregates.
  A dagger marks an estimator-cell with failure rate above 5%: its entries are conditional on success.
  E-10 is ABSENT everywhere (gate V10 failed; protocol v1.10 A10.1).
  Table 10 of the manuscript has no new computation (record 8) and is rewritten with the manuscript.
  Figure 4 shows QWK and incremental OOS R^2 in two panels on separate axes instead of the
  manuscript's dual-axis layout (figure QA rules; same content, record 8).
  No manuscript text was written or revised.
