"""FINAL_V1 analysis driver (record 10.1 step 7). Run only after all 149 configurations are complete.

    python3 -I -B fa_run.py check            run-completion and integrity check (no performance quantity)
    python3 -I -B fa_run.py phase1 [--workers 2]
    python3 -I -B fa_run.py phase2
Each step appends to <out>/ANALYSIS_LOG.jsonl with UTC timestamps and the SHA-256 of the analysis
plan and of every analysis source file.
"""
import argparse, datetime, glob, json, multiprocessing, os, sys, time

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import fa_common as F  # noqa: E402

PLAN = os.path.join(F.STUDY, "analysis", "ANALYSIS_OPERATIONALIZATIONS.txt")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def code_hashes():
    return {os.path.basename(p): F.sha256(p) for p in sorted(glob.glob(os.path.join(HERE, "*.py")))}


def log(event, **kw):
    F.ensure(F.OUT)
    rec = {"utc": utc(), "event": event, "mode": F.MODE, **kw}
    with open(os.path.join(F.OUT, "ANALYSIS_LOG.jsonl"), "a") as fh:
        fh.write(json.dumps(rec, sort_keys=True, default=str) + "\n")
    print(json.dumps(rec, default=str)[:400])


def cmd_check(args):
    from fv1 import store
    import fa_cells
    cells, configs, prov = fa_cells.build()
    bad = []
    for c in configs:
        p = store.paths(F.RUN, c.name)
        if not (os.path.exists(p["npz"]) and os.path.exists(p["sha"])) or os.path.exists(p["started"]) or os.path.exists(p["partial"]):
            bad.append(c.name)
            continue
        sha, _ = store.read_sidecar(p["sha"])
        if F.sha256(p["npz"]) != sha:
            bad.append(c.name)
    log("CHECK", configurations=len(configs), incomplete_or_mismatched=bad, module_cells=len(cells),
        plan_sha256=F.sha256(PLAN), code=code_hashes())
    return 1 if bad else 0


def cmd_phase1(args):
    import fa_cells, fa_phase1
    cells, configs, _ = fa_cells.build()
    pairs = fa_cells.config_R_pairs(cells)
    by_cfg = {}
    for (cfg, R), ests in pairs.items():
        by_cfg.setdefault(cfg, {})[R] = ests
    key = {c.name: c.theta0_key for c in configs}
    tasks = []
    for cfg in sorted(by_cfg):
        Rs = sorted(by_cfg[cfg], reverse=True)
        todo = [R for R in Rs if not (os.path.exists(fa_phase1.out_paths(cfg, R)[0]) and os.path.exists(fa_phase1.out_paths(cfg, R)[1]))]
        if todo:
            tasks.append((cfg, key[cfg], todo, {R: by_cfg[cfg][R] for R in todo}))
    log("PHASE1_START", tasks=len(tasks), pairs=len(pairs), workers=args.workers, plan_sha256=F.sha256(PLAN),
        code=code_hashes(), boot_B=F.B_BOOT)
    t0 = time.time()
    ctx = multiprocessing.get_context("spawn")
    done = 0
    with ctx.Pool(args.workers) as pool:
        for r in pool.imap_unordered(fa_phase1.process, tasks):
            done += 1
            if done % 10 == 0 or done == len(tasks):
                print(f"  phase1 {done}/{len(tasks)}  last {r['config']} {r['seconds']}s  elapsed {time.time() - t0:.0f}s", flush=True)
    log("PHASE1_END", tasks=len(tasks), elapsed_s=round(time.time() - t0, 1))
    return 0


def cmd_phase2(args):
    import fa_captions, fa_celltables, fa_ctx, fa_exp1, fa_exp2, fa_exp3, fa_exp4, fa_exp5, fa_hyp, fa_main, fa_supp, fa_summary
    t0 = time.time()
    log("PHASE2_START", plan_sha256=F.sha256(PLAN), code=code_hashes())
    ctx = fa_ctx.Ctx()
    reg = {}
    info = fa_celltables.write_all(ctx)
    t4, t4r = fa_main.table4(ctx, reg)
    fa_main.figure1(ctx, reg)
    fa_main.table7(ctx, reg)
    fa_main.figure3(ctx, reg)
    fa_main.figure3(ctx, reg, fa_main.SUPP_FIG, "FigureS3_validation_intensity_other_estimators", "Supplementary Figure S3")
    fa_main.table8(ctx, reg)
    t9 = fa_main.table9(ctx, reg)
    fa_main.figure4(ctx, reg, t9)
    x1 = fa_exp1.run(ctx, reg)
    x2 = fa_exp2.run(ctx, reg)
    x3 = fa_exp3.run(ctx, reg)
    x4 = fa_exp4.run(ctx, reg)
    x5 = fa_exp5.run(ctx, reg)
    fa_supp.run(ctx, reg)
    fa_captions.ps_comparisons(ctx, reg)
    fa_captions.write_captions()
    H = fa_hyp.write(x1["H"] + x2["H"] + x3["H"] + x4["H"] + x5["H"])
    by_key = {}
    for name, r in reg.items():
        for k in r["cells"]:
            by_key.setdefault(k, []).append(name)
    fa_celltables.write_cell_map(ctx, by_key)
    F.dump_json(os.path.join(F.OUT, "OUTPUT_MAP.json"), reg)
    fa_summary.write(ctx, dict(t4=t4, t4r=t4r, t9=t9, x1=x1, x2=x2, x3=x3, x4=x4, x5=x5, H=H, info=info))
    log("PHASE2_END", elapsed_s=round(time.time() - t0, 1), outputs=len(reg), hypotheses=len(H))
    return 0


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check")
    a = sub.add_parser("phase1"); a.add_argument("--workers", type=int, default=2)
    sub.add_parser("phase2")
    args = ap.parse_args()
    return {"check": cmd_check, "phase1": cmd_phase1, "phase2": cmd_phase2}[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
