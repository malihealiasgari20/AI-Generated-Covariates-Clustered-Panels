"""FINAL_V1 analysis: shared definitions (paths, estimator metadata, display rules, I/O helpers).

Environment (all optional; defaults are the production locations):
    FV1_STUDY       Final_Study_v1 root
    FV1_RUN         run directory holding raw/C###.npz      (default <study>/run)
    FV1_OUT         analysis output directory               (default <study>/analysis)
    FV1_CACHE       intermediate cache (bootstrap draws)     (default /home/claude/fv1_analysis_cache)
    FV1_MODE        "production" (default) or "test"; test accepts a throwaway namespace and
                    capped replication counts and may never write into <study>/analysis
"""
import csv, hashlib, json, math, os, sys

sys.dont_write_bytecode = True
STUDY = os.path.abspath(os.environ.get("FV1_STUDY", "/mnt/user-data/outputs/Final_Study_v1"))
CODE = os.path.join(STUDY, "code")
if CODE not in sys.path:
    sys.path.insert(0, CODE)
import fv1.env as env  # noqa: E402  (pins BLAS threads to 1, deps on sys.path, no bytecode)
import numpy as np  # noqa: E402
from fv1 import estimators as E  # noqa: E402

MODE = os.environ.get("FV1_MODE", "production")
RUN = os.path.abspath(os.environ.get("FV1_RUN", os.path.join(STUDY, "run")))
OUT = os.path.abspath(os.environ.get("FV1_OUT", os.path.join(STUDY, "analysis")))
CACHE = os.path.abspath(os.environ.get("FV1_CACHE", "/home/claude/fv1_analysis_cache"))
if MODE != "production" and (OUT == os.path.join(STUDY, "analysis") or OUT.startswith(os.path.join(STUDY, "analysis") + os.sep)):
    raise SystemExit("test mode may not write into Final_Study_v1/analysis")
if MODE == "production" and RUN != os.path.join(STUDY, "run"):
    raise SystemExit("production mode reads Final_Study_v1/run only")

GATE_RECORD = os.path.join(STUDY, "gates", "FINAL_V1_GATE_RECORD.json")
GATE_RECORD_SHA = "808e6abf07d05d7f83dec06ad8ccb7e3f2b9f1c9a7667233cf4bf6af0343162b"
THETA0_MAP = os.path.join(STUDY, "gates", "FINAL_V1_THETA0_MAP.json")
THETA0_MAP_SHA = "6d18e3f01f21ed31ebe922ed1b1f4f7f1431eccb072fb889b91fb98388af00a7"
RECORD_SHA = "bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0"
PROTOCOL_V110_SHA = "2c2fbdf15ade74688aaa1f8ec0549f7762ab308acd6e59da1dec4fb00c553c6e"
CODE_FINGERPRINT = "2d263942e63e44db60a02d6041aba51b3fad0a55c94a0941c45ee31e1d909cbd"
PROD_NS = {"panel": "FINAL_V1_PANEL", "folds": "FINAL_V1_FOLDS", "oos": "FINAL_V1_OOS"}

B_BOOT = 2000
Z = 1.959963984540054
EST_ALL = list(E.EST_NAMES)                     # 17 names, E-10 last
EST16 = [e for e in EST_ALL if e != "E-10"]     # every computed estimator (E-10 ABSENT)
X3_EST = ["E-1", "E-7", "E-2", "E-6"]
FAIL_NAMES = list(E.FAIL_NAMES)

# record 3.7
HEADLINE_T4 = ["E-1", "E-2", "E-3", "E-4", "E-5", "E-6", "E-7", "E-8", "E-9", "E-12a", "E-12b", "HT-TDS-I", "PS-TDS-I"]
HEADLINE = [e for e in HEADLINE_T4 if e != "E-3"]
MECHANISM = HEADLINE + ["E-12c"]
SUPPLEMENTARY_ONLY = ["E-6H", "HT-TDS-CF"]
SCHUR = ["E-4", "E-5", "E-6", "E-6H", "E-12a", "E-12b", "E-12c", "HT-TDS-I", "PS-TDS-I", "HT-TDS-CF"]
BIND_EST = ["E-9", "HT-TDS-I", "PS-TDS-I", "HT-TDS-CF"]
RECTIFIED_X4 = ["E-4", "E-5", "E-6", "HT-TDS-I", "PS-TDS-I", "E-9", "E-12a", "E-12b"]   # + E-10 ABSENT
DESIGN_AWARE_O14 = ["E-6", "E-8", "E-9", "E-12a", "E-12b", "HT-TDS-I", "PS-TDS-I"]

LABEL = {
    "E-1": "Naive",
    "E-2": "Labeled-only IPW",
    "E-3": "PPI, observation-level SE",
    "E-4": "PPI, cluster-robust SE",
    "E-5": "Unweighted cross-fitted rectifier",
    "E-6": "HT-weighted rectifier (Horvitz-Thompson form of IPW-PPI)",
    "E-7": "Regression calibration",
    "E-8": "HT-weighted rectifier, jackknife SE",
    "E-9": "Historical CDA (not coding-invariant; negative lesson)",
    "E-6H": "Hajek point-estimator variant with a clustered-sandwich convention",
    "E-12a": "Cross-fitted, unweighted fit, HT rectifier",
    "E-12b": "Design-aware cross-fitted rectifier (weighted fit, HT rectifier)",
    "E-12c": "Cross-fitted, weighted fit, uniform rectifier (negative control)",
    "HT-TDS-I": "HT rectifier, identity predictor, TDS (delta 0.10)",
    "PS-TDS-I": "Post-stratified rectifier (fixed realized weights), identity predictor, TDS",
    "HT-TDS-CF": "HT rectifier, cross-fitted (E-12a fit), TDS",
    "E-10": "PPI++-style general M-estimation comparator, unweighted for the validation design",
}
SHORT = {"E-1": "Naive", "E-2": "Lab.-only IPW", "E-3": "PPI (obs.)", "E-4": "PPI (CR)", "E-5": "Unw. CF rect.",
         "E-6": "HT rect.", "E-7": "Reg. cal.", "E-8": "HT rect. (jk)", "E-9": "Hist. CDA", "E-6H": "Hajek var.",
         "E-12a": "CF-u HT", "E-12b": "CF-w HT", "E-12c": "CF-w unif.", "HT-TDS-I": "HT-TDS-I",
         "PS-TDS-I": "PS-TDS-I", "HT-TDS-CF": "HT-TDS-CF", "E-10": "E-10 (ABSENT)"}
def lab(e):
    """Display label for figures: short name plus code (code alone when they coincide)."""
    return e if SHORT.get(e, e) == e else f"{SHORT[e]} ({e})"


E10_ABSENT = ("ABSENT -- gate V10 failed (V10.1); per record 3.4 no approximate replacement or substitute "
              "is created (protocol v1.10, amendment A10.1)")
CAPTION = ("Final prospectively frozen study FINAL_V1 (pre-run record sealed 3 November 2026)")


def sha256(path):
    return env.sha256_file(path)


def ensure(path):
    os.makedirs(path, exist_ok=True)
    return path


def fnum(x, nd=4, sign=False):
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "NA"
    return f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}"


def write_csv(path, rows, fields=None):
    ensure(os.path.dirname(path))
    if fields is None:
        fields = []
        for r in rows:
            for k in r:
                if k not in fields:
                    fields.append(k)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: _csv_val(r.get(k)) for k in fields})
    return path


def _csv_val(v):
    if isinstance(v, float):
        if not math.isfinite(v):
            return "NA" if math.isnan(v) else ("Inf" if v > 0 else "-Inf")
        return repr(v)
    if isinstance(v, (np.floating,)):
        return _csv_val(float(v))
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (list, tuple)):
        return ";".join(str(_csv_val(x)) for x in v)
    return v


def dump_json(path, obj):
    ensure(os.path.dirname(path))
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=1, sort_keys=True, default=_json_default, allow_nan=True)
    return path


def _json_default(o):
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    raise TypeError(type(o))


def md_table(header, rows, align=None):
    """Plain Markdown table (text cells)."""
    align = align or ["l"] + ["r"] * (len(header) - 1)
    sep = ["---" if a == "l" else "---:" for a in align]
    out = ["| " + " | ".join(header) + " |", "| " + " | ".join(sep) + " |"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)
