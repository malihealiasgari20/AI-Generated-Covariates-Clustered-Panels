"""Hypothesis register: one row per hypothesis with its sealed rule, cells, outcome and status;
full evidence in JSON; a readable Markdown version."""
import json, math, os

import fa_common as F

ORDER = ["H1.1", "H1.2", "H1.3", "H1.3b", "H1.3c", "H1.4", "H2.1", "H2.1b", "H2.2", "H2.3", "H2.4", "H2.4b", "H2.5",
         "H3.1", "H3.1b", "H3.2", "H3.3", "H3.4", "H3.5", "H4.1", "H4.2", "H4.3", "H4.4", "H4.4b", "H4.5", "H4.6",
         "H5.1", "H5.2", "H5.3", "H5.4", "H5.5", "H5.6"]


def _short(v, depth=0):
    if isinstance(v, float):
        return "NA" if not math.isfinite(v) else (f"{v:.4g}" if abs(v) >= 1e-3 or v == 0 else f"{v:.3e}")
    if isinstance(v, (list, tuple)):
        if len(v) > 8:
            return f"[{len(v)} entries; see JSON]"
        return "[" + ", ".join(_short(x, depth + 1) for x in v) + "]"
    if isinstance(v, dict):
        if depth > 1 or len(v) > 10:
            return "{...; see JSON}"
        return "{" + ", ".join(f"{k}: {_short(x, depth + 1)}" for k, x in v.items()) + "}"
    return str(v)


def write(H):
    out = F.ensure(os.path.join(F.OUT, "hypotheses"))
    H = sorted(H, key=lambda h: ORDER.index(h["id"]) if h["id"] in ORDER else 99)
    missing = [h for h in ORDER if h not in {x["id"] for x in H}]
    assert not missing, f"hypotheses not evaluated: {missing}"
    F.dump_json(os.path.join(out, "HYPOTHESIS_EVIDENCE.json"), H)
    F.write_csv(os.path.join(out, "HYPOTHESES.csv"),
                [{k: h[k] for k in ("id", "experiment", "outcome", "status", "cells", "rule")} for h in H],
                ["id", "experiment", "outcome", "status", "cells", "rule"])
    lines = ["# FINAL_V1 hypothesis evaluation", "",
             "Rules: sealed record Sections 7.1-7.5 and protocol v1.10 (H1.1-H4.4 verbatim from v1.5), operationalized "
             "by analysis/ANALYSIS_OPERATIONALIZATIONS.txt (fixed and hashed before any result). Vocabulary: SUPPORTED, "
             "REFUTED (the hypothesis's own REFUTED-IF criterion met), NOT SUPPORTED (a predicted clause fails, the "
             "REFUTED-IF criterion is not met), INCONCLUSIVE (record rule), ABSENT (E-10), REPORTED (open question).", "",
             F.md_table(["ID", "Outcome", "Status", "Cells"], [[h["id"], h["outcome"], h["status"], h["cells"]] for h in H],
                        ["l", "l", "l", "l"]), ""]
    for h in H:
        lines += [f"## {h['id']} -- {h['outcome']}", "", f"- status: {h['status']}", f"- cells: {h['cells']}",
                  f"- rule: {h['rule']}"]
        for k, v in h["evidence"].items():
            lines.append(f"- {k}: {_short(v)}")
        lines.append("")
    open(os.path.join(out, "HYPOTHESIS_EVALUATION.md"), "w").write("\n".join(lines) + "\n")
    return H
