"""Supplementary tables (record 3.7: E-6H and HT-TDS-CF in full, every estimator in every module;
H4.6; E-9 floor diagnostics; failure-type totals; tail-driven entries with robust counterparts)."""
import os

import fa_common as F
from fa_main import vm


def run(ctx, reg):
    out = F.ensure(os.path.join(F.OUT, "supplementary"))
    files = []
    # S1: E-6H and HT-TDS-CF in full
    rows = []
    for c in ctx.cells:
        for e in F.SUPPLEMENTARY_ONLY:
            m = ctx.m(c, e)
            if m is None:
                continue
            rows.append({"module": c["module"], "cell": c["cell"], "R": c["R"], "estimator": e, "label": F.LABEL[e],
                         **{k: m.get(k) for k in ("n_success", "failure_rate", "bias", "bias_mcse", "emp_se", "mean_se",
                                                  "se_ratio", "rmse", "rmse_mcse", "coverage", "coverage_mcse",
                                                  "width_median", "rejection", "rejection_mcse", "bind_rate",
                                                  "median_bias", "mad_sd", "tail_driven", "max_abs_err")}})
    files.append(F.write_csv(os.path.join(out, "S1_E6H_and_HT-TDS-CF_all_cells.csv"), rows))
    # S2: every estimator in every module, one CSV per module (subset of the cell-level file, by module)
    import csv
    src = os.path.join(F.OUT, "cell_level", "CELL_LEVEL_CONVENTIONAL.csv")
    with open(src) as fh:
        allrows = list(csv.DictReader(fh))
    for mod in ("P", "L", "S", "X2", "X3", "X4", "D"):
        sub = [r for r in allrows if r["module"] == mod]
        files.append(F.write_csv(os.path.join(out, f"S2_all_estimators_module_{mod}.csv"), sub, list(allrows[0].keys())))
    # S3: H4.6 -- TDS against the unstabilized identity rectifiers under sparse validation
    rows = []
    sparse = [c for c in ctx.sel("X4") if c["design"] == "grid" and c["f_level"] <= 0.10] + \
             [c for c in ctx.sel("S") if c["condition"] in ("m=0.33", "m=0.5")]
    for c in sparse:
        for e in ("HT-TDS-I", "PS-TDS-I", "E-6", "E-9", "E-6H"):
            m = ctx.m(c, e)
            r = {"module": c["module"], "cell": c["cell"], "R": c["R"], "estimator": e, "failure_rate": m["failure_rate"],
                 "rmse": m["rmse"], "rmse_mcse": m["rmse_mcse"], "mad_sd": m["mad_sd"], "mad_sd_bmcse": m["mad_sd_bmcse"],
                 "median_abs_err": m["median_abs_err"], "p99_abs_err": m["p99_abs_err"], "p999_abs_err": m["p999_abs_err"],
                 "max_abs_err": m["max_abs_err"], "n_abs_err_gt1": m["n_abs_err_gt1"], "p99_se": m["p99_se"],
                 "max_se": m["max_se"], "n_se_gt5": m["n_se_gt5"], "coverage": m["coverage"], "bind_rate": m["bind_rate"],
                 "tail_driven": m["tail_driven"]}
            for ref in ("E-6", "E-9"):
                p = ctx.pair(c, e, ref)
                if p:
                    r[f"rmse_ratio_vs_{ref}"] = p["rmse_ratio"]
                    r[f"rmse_ratio_vs_{ref}_bmcse"] = p["rmse_ratio_bmcse"]
                    r[f"n_intersection_vs_{ref}"] = p["n_intersection"]
            rows.append(r)
    files.append(F.write_csv(os.path.join(out, "H4.6_TDS_sparse_validation.csv"), rows))
    # S4: E-9 floor diagnostics and TDS binding
    rows = []
    for c in ctx.cells:
        if c["battery"] != "FULL":
            continue
        r = {"module": c["module"], "cell": c["cell"], "R": c["R"]}
        for k in ("e9_bind_full", "e9_shift_full", "e9_nu_eff", "e9_bind_jk_frac", "e8_nu_eff", "kish_ht", "G_S",
                  "tds_bind__HT-TDS-I", "tds_bind__PS-TDS-I", "tds_bind__HT-TDS-CF", "e7_cZL", "delta_spread"):
            v = ctx.diag(c, k)
            r[f"{k}:mean"] = v["mean"] if v else None
            r[f"{k}:mcse"] = v["mcse"] if v else None
        rows.append(r)
    files.append(F.write_csv(os.path.join(out, "S4_floor_and_design_diagnostics.csv"), rows))
    # S5: failure-type totals per estimator over every module cell, and the recorded failure details
    tot = {}
    for c in ctx.cells:
        for e in F.EST16:
            m = ctx.m(c, e)
            if m is None:
                continue
            t = tot.setdefault((c["module"], e), {"module": c["module"], "estimator": e, "replications": 0, "failures": 0})
            t["replications"] += m["R"]
            t["failures"] += m["failures"]
            for code in range(1, len(F.FAIL_NAMES)):
                t[F.FAIL_NAMES[code]] = t.get(F.FAIL_NAMES[code], 0) + m[f"fail_code{code}"]
    files.append(F.write_csv(os.path.join(out, "S5_failure_type_totals_by_module.csv"), list(tot.values())))
    det = []
    for (cfg, R) in sorted({(c["config"], c["R"]) for c in ctx.cells}):
        p1 = ctx._p1.get((cfg, R)) or ctx.p1(next(c for c in ctx.cells if c["config"] == cfg and c["R"] == R))
        for e, dd in p1["fail_details_all_rows"].items():
            for d, n in sorted(dd.items(), key=lambda x: -x[1]):
                det.append({"config": cfg, "estimator": e, "detail": d, "count_all_rows": n})
    seen, uniq = set(), []
    for r in det:
        k = (r["config"], r["estimator"], r["detail"])
        if k not in seen:
            seen.add(k)
            uniq.append(r)
    files.append(F.write_csv(os.path.join(out, "S6_failure_details_by_configuration.csv"), uniq))
    # S7: tail-driven entries with their robust counterparts beside them (record 6.2)
    rows = []
    for c in ctx.cells:
        for e in F.EST16:
            m = ctx.m(c, e)
            if m is None or not m["tail_driven"]:
                continue
            rows.append({"module": c["module"], "cell": c["cell"], "estimator": e, "rmse": m["rmse"],
                         "median_abs_err": m["median_abs_err"], "emp_se": m["emp_se"], "mad_sd": m["mad_sd"],
                         "mean_se": m["mean_se"], "median_se": m["median_se"], "batch_rmse_ratio": m["batch_rmse_ratio"],
                         "tail_share_sse": m["tail_share_sse"], "tail_share_se": m["tail_share_se"],
                         "max_abs_err": m["max_abs_err"], "max_se": m["max_se"]})
    files.append(F.write_csv(os.path.join(out, "S7_tail_driven_entries_with_robust_counterparts.csv"), rows))
    reg["Supplementary tables S1-S7, H4.6"] = {"cells": [c["key"] for c in ctx.cells], "R": sorted({c["R"] for c in ctx.cells}),
                                               "aggregation": "per cell", "files": [os.path.relpath(f, F.OUT) for f in files]}
    return files
