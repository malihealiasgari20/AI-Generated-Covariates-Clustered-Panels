"""Experiment 3 (module X3): C3 check, O3.1-O3.4, H3.1-H3.5 (record 1.5, 7.3; protocol 5; plan I)."""
import math, os

import numpy as np
from scipy.stats import chi2

import fa_common as F
import fa_metrics as M
import fa_style as S
from fa_main import register

plt = S.plt
TS = (4, 6, 8, 10, 12, 16)
ZC = 1.959963984540054


def wls(x, y, w):
    x, y, w = map(lambda v: np.asarray(v, float), (x, y, w))
    xb, yb = np.sum(w * x) / np.sum(w), np.sum(w * y) / np.sum(w)
    sxx = np.sum(w * (x - xb) ** 2)
    b = float(np.sum(w * (x - xb) * (y - yb)) / sxx)
    a = float(yb - b * xb)
    se = float(1.0 / math.sqrt(sxx))
    res = float(np.sum(w * (y - a - b * x) ** 2))
    return {"slope": b, "intercept": a, "se": se, "ci95": (b - ZC * se, b + ZC * se), "chi2": res,
            "df": len(x) - 2, "p_chi2": float(chi2.sf(res, len(x) - 2))}


def det(d):
    """Detectable at 3 MCSE; an identically zero paired difference (MCSE 0) is not a detection."""
    return d["mcse"] > 0 and abs(d["diff"]) >= 3 * d["mcse"]


def run(ctx, reg):
    out = F.ensure(os.path.join(F.OUT, "experiments", "Exp3"))
    pairs = {T: (ctx.one("X3", T=T, kbar=0.0), ctx.one("X3", T=T, kbar=0.6)) for T in TS}
    mT = {T: ctx.diag(pairs[T][0], "within_moment")["mean"] for T in TS}
    dev = {T: abs(mT[T] - mT[8]) / mT[8] for T in TS}
    c3 = "FAILED" if max(dev.values()) > 0.05 else "PASSED"
    rows, D = [], {}
    for e in F.X3_EST:
        for T in TS:
            c0, c6 = pairs[T]
            assert c0["seed_cell_id"] == c6["seed_cell_id"], "kappabar pair must share one seed id (CRN)"
            d = M.cross_pair(ctx.arrays(c6, e), ctx.arrays(c0, e))
            m0, m6 = ctx.m(c0, e), ctx.m(c6, e)
            D[(e, T)] = d
            rows.append({"estimator": e, "T": T, "kappa_T": c6["kappa_T"], "kappabar": 0.6,
                         "bias_kbar0": m0["bias"], "bias_kbar0_mcse": m0["bias_mcse"], "bias_kbar060": m6["bias"],
                         "bias_kbar060_mcse": m6["bias_mcse"], "displacement": d["diff"], "displacement_mcse": d["mcse"],
                         "n_intersection": d["n_intersection"], "detectable_3mcse": det(d),
                         "identically_zero": d["diff"] == 0 and d["mcse"] == 0,
                         "sign": int(np.sign(d["diff"])), "T_abs_displacement": T * abs(d["diff"]),
                         "T_abs_displacement_mcse": T * d["mcse"], "within_moment_mT": mT[T],
                         "within_moment_rel_dev_vs_T8": dev[T], "coverage_kbar0": m0["coverage"],
                         "coverage_kbar060": m6["coverage"], "failure_rate_kbar060": m6["failure_rate"]})
    f1 = F.write_csv(os.path.join(out, "O3.1_displacement_by_T.csv"), rows)
    fits = {}
    for e in F.X3_EST:
        d = np.array([D[(e, T)]["diff"] for T in TS]); s = np.array([D[(e, T)]["mcse"] for T in TS])
        if np.any(s == 0) or np.any(d == 0):
            fits[e] = {"note": "displacement identically zero in at least one T (paired estimates equal: the "
                               "estimator does not use Z_L there); no scaling fit"}
            continue
        fits[e] = wls(np.log(TS), np.log(np.abs(d)), d ** 2 / s ** 2)
        tdm = np.array(TS) * np.abs(d); tds = np.array(TS) * s
        w = 1 / tds ** 2
        mu = float(np.sum(w * tdm) / np.sum(w))
        ch = float(np.sum(w * (tdm - mu) ** 2))
        fits[e]["T_abs_d_weighted_mean"] = mu
        fits[e]["T_abs_d_flatness_chi2"] = ch
        fits[e]["T_abs_d_flatness_p"] = float(chi2.sf(ch, len(TS) - 1))
    F.dump_json(os.path.join(out, "O3.3_scaling_fit.json"), {"C3": {"status": c3, "m_T": mT, "rel_dev": dev},
                                                             "fits": fits})
    figure(ctx, reg, rows, fits, c3)
    register(reg, "Experiment 3 (O3.1-O3.4)", ctx.sel("X3"), 5000, "paired within T (common random numbers)",
             [f1, os.path.join(out, "O3.3_scaling_fit.json")])
    # hypotheses (E-1 primary readout)
    H = []
    d8 = D[("E-1", 8)]
    det8 = det(d8)
    H.append(dict(id="H3.1", experiment="3", outcome="SUPPORTED" if det8 else "REFUTED",
                  status="PROSPECTIVE (kappabar 0.60 at T 8 never run)", cells="X3 T = 8, kappabar 0 vs 0.60; E-1",
                  evidence=dict(d=d8["diff"], mcse=d8["mcse"], z=d8["diff"] / d8["mcse"]), rule="analysis plan I, H3.1"))
    detected = [T for T in TS if det(D[("E-1", T)])]
    s8 = np.sign(d8["diff"])
    sign_ok = all(np.sign(D[("E-1", T)]["diff"]) == s8 for T in detected)
    f1_ = fits["E-1"]
    contains = f1_["ci95"][0] <= -1 <= f1_["ci95"][1]
    scal = "INCONCLUSIVE (C3 FAILED)" if c3 == "FAILED" else ("SUPPORTED" if contains else "REFUTED")
    H.append(dict(id="H3.1b", experiment="3", outcome=("SUPPORTED" if sign_ok else "NOT SUPPORTED") + f"; scaling clause: {scal}",
                  status="PROSPECTIVE", cells="X3, six T; E-1",
                  evidence=dict(detected_T=detected, signs={T: int(np.sign(D[('E-1', T)]['diff'])) for T in TS},
                                sign_consistent_among_detectable=sign_ok), rule="analysis plan I, H3.1b"))
    H.append(dict(id="H3.2", experiment="3", outcome=scal, status="PROSPECTIVE", cells="X3, six T; E-1",
                  evidence=dict(slope=f1_["slope"], se=f1_["se"], ci95=f1_["ci95"], chi2=f1_["chi2"], p=f1_["p_chi2"],
                                T_abs_d_flatness_p=f1_["T_abs_d_flatness_p"], C3=c3, max_rel_dev=max(dev.values())),
                  rule="analysis plan I, H3.2"))
    pos = [T for T in detected if D[("E-1", T)]["diff"] > 0]
    H.append(dict(id="H3.3", experiment="3", outcome="REFUTED" if pos else ("SUPPORTED" if d8["diff"] < 0 else "NOT SUPPORTED"),
                  status="PROSPECTIVE", cells="X3, six T; E-1",
                  evidence=dict(d8=d8["diff"], detectable_positive_T=pos), rule="analysis plan I, H3.3"))
    b0 = np.array([ctx.m(pairs[T][0], "E-1")["bias"] for T in TS]); s0 = np.array([ctx.m(pairs[T][0], "E-1")["bias_mcse"] for T in TS])
    ft = wls(np.log(TS), b0, 1 / s0 ** 2)
    w = 1 / s0 ** 2; mu = float(np.sum(w * b0) / np.sum(w)); ch = float(np.sum(w * (b0 - mu) ** 2))
    refute = abs(ft["slope"]) >= 3 * ft["se"]
    H.append(dict(id="H3.4", experiment="3", outcome="REFUTED" if refute else "SUPPORTED",
                  status="PROSPECTIVE (T 8 cell: CONFIRMATORY)", cells="X3 kappabar 0, six T; E-1",
                  evidence=dict(slope_bias_on_logT=ft["slope"], se=ft["se"], homogeneity_chi2=ch,
                                homogeneity_p=float(chi2.sf(ch, len(TS) - 1)), bias=list(zip(TS, b0.tolist(), s0.tolist()))),
                  rule="analysis plan I, H3.4"))
    H.append(dict(id="H3.5", experiment="3", outcome="REPORTED", status="positioning statement (no test)",
                  cells="-", evidence={}, rule="protocol 5.3 H3.5"))
    return {"H": H, "C3": c3, "fits": fits}


def figure(ctx, reg, rows, fits, c3):
    S.setup()
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.4))
    data = []
    for k, e in enumerate(F.X3_EST):
        rr = [r for r in rows if r["estimator"] == e]
        T = np.array([r["T"] for r in rr]) * (1 + 0.012 * (k - 1.5))
        y = np.array([r["T_abs_displacement"] for r in rr]); s = np.array([r["T_abs_displacement_mcse"] for r in rr])
        axes[0].errorbar(T, y, yerr=1.96 * s, capsize=0, elinewidth=0.8, label=F.lab(e), **S.est_kw(e))
        d = np.array([r["displacement"] for r in rr])
        data += [{"estimator": e, "T": r["T"], "T_abs_displacement": r["T_abs_displacement"],
                  "T_abs_displacement_mcse": r["T_abs_displacement_mcse"], "displacement": r["displacement"],
                  "displacement_mcse": r["displacement_mcse"], "identically_zero": r["identically_zero"]} for r in rr]
        f = fits[e]
        if "note" in f:
            continue
        axes[1].plot(np.log(np.array([r["T"] for r in rr])), np.log(np.abs(d)), **S.est_kw(e, line=False))
        xx = np.log(np.array([4, 16]))
        if e in ("E-1", "E-7"):
            axes[1].plot(xx, f["intercept"] + f["slope"] * xx, color=S.STYLE[e]["color"], lw=1.2,
                         label=f"{e} fit: slope {f['slope']:.2f} [{f['ci95'][0]:.2f}, {f['ci95'][1]:.2f}]")
    f = fits["E-1"]
    xx = np.log(np.array([4, 16]))
    x8 = math.log(8)
    y8 = f["intercept"] + f["slope"] * x8
    axes[1].plot(xx, y8 - (xx - x8), color=S.INK2, lw=0.8, ls=(0, (4, 3)), label="reference slope -1 (through E-1 fit at T 8)")
    axes[0].set_xscale("log"); axes[0].set_xticks(TS); axes[0].set_xticklabels([str(t) for t in TS]); axes[0].minorticks_off()
    axes[0].set_xlabel("panel length T"); axes[0].set_ylabel("T x |displacement|")
    axes[0].set_title("a. O3.2: T x |displacement| (flat = 1/T scaling)", fontsize=8, loc="left")
    axes[1].set_xlabel("log T"); axes[1].set_ylabel("log |displacement|")
    axes[1].set_title("b. O3.3: weighted log-log fit", fontsize=8, loc="left")
    axes[0].legend(handles=S.proxies(F.X3_EST, F.lab), fontsize=6.8, loc="upper center", ncol=2, bbox_to_anchor=(0.5, -0.2))
    axes[1].legend(fontsize=6.3, loc="upper center", ncol=1, bbox_to_anchor=(0.5, -0.2))
    note = "" if c3 == "PASSED" else " -- C3 FAILED: scaling interpretation INCONCLUSIVE"
    fig.suptitle(f"Experiment 3. Displacement = bias(kappabar 0.60) - bias(kappabar 0), paired within T, rho_e 0, "
                 f"R 5,000; bars ± 1.96 MCSE{note}", fontsize=8.5)
    fig.tight_layout()
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, "FigureX3_inverse_T.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, "FigureX3_inverse_T_data.csv"), data)
    register(reg, "Figure X3", ctx.sel("X3"), 5000, "paired within T", [p, fc])
