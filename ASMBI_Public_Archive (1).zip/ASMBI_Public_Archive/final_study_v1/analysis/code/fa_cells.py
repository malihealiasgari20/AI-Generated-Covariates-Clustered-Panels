"""Cell-definition map (record 8; protocol 2.4): the 176 module cells and their configurations.

The module cells are re-enumerated with the loops and helper functions of the sealed
build_registry.py (executed read-only by fv1.registry, whose output must be byte-identical to the
frozen registry). Each module cell maps to exactly one of the 149 configurations; the module's
replication count R is the count of record 2.1 (a module with a smaller count than its
configuration uses replications r = 0..R-1, record 2.2).
"""
import itertools
from dataclasses import replace

import numpy as np

import fa_common as F
from fv1 import registry

STRESS_ORDER = ["N=250", "N=600", "T=5 budget", "T=10 budget", "tau=0", "tau=0.30", "kappa=0.30", "kappa=0.90",
                "sd_e=0.35", "sd_e=0.80", "low within", "m=0.33", "m=0.5", "m=0.75", "m=1.5", "m=2.0"]


def build():
    configs, prov = registry.load(F.STUDY)
    ns, rebuilt, _ = registry._rebuild(F.STUDY)
    with open(f"{F.STUDY}/FINAL_V1_CELL_REGISTRY_FROZEN.csv", "rb") as fh:
        assert rebuilt == fh.read(), "registry rebuild differs from the frozen registry"
    by_id = {c.config_id: c for c in configs}
    BASE, num, vec = ns["BASE"], ns["num"], ns["vec"]
    pitf, sdW_for_T, kterm = ns["pi_target_fraction"], ns["sdW_for_T"], ns["kappa_terminal"]

    def cid(**kw):
        p = replace(BASE, **kw)
        seed = (f"N={p.N}|T={p.T}|icc={num(p.icc)}|rho={num(p.rho_e)}|tau={num(p.tau)}|pi={vec(p.pi)}"
                f"|sde={num(p.sd_e)}|sdW={num(p.sd_ZH_within)}|lam={vec(p.lambda1)}|g={num(p.gamma_W)}")
        return seed + f"|kappa={num(p.kappa)}", p

    cells = []

    def add(module, battery, R, label, extra, **kw):
        c_id, p = cid(**kw)
        c = by_id[c_id]
        cells.append(dict(module=module, cell=label, key=f"{module}|{label}", config=c.name, config_id=c_id,
                          seed_cell_id=c.seed_cell_id, battery=battery, R=R, gamma_W=float(p.gamma_W),
                          null=(p.gamma_W == 0.0), N=p.N, T=p.T, icc=float(p.icc), rho_e=float(p.rho_e),
                          kappa=float(p.kappa), tau=float(p.tau), pi=tuple(float(x) for x in p.pi),
                          f=float(np.mean(p.pi)), sd_e=float(p.sd_e), sd_W=float(p.sd_ZH_within),
                          lambda1=tuple(float(x) for x in p.lambda1),
                          expected_labeled=float(p.N * np.mean(p.pi)), theta0_key=c.theta0_key,
                          config_R=dict(c.R), modules=list(c.modules), **extra))

    G = (0.15, 0.0)
    gl = lambda g: "g=0.15" if g else "g=0"
    for icc, rho, k, g in itertools.product((0.10, 0.30, 0.50), (0.0, 0.60), (0.0, 0.60), G):
        add("P", "FULL", 5000, f"icc={icc}|rho={rho}|kappa={k}|{gl(g)}", {}, icc=icc, rho_e=rho, kappa=k, gamma_W=g)
    for k, rho, g in itertools.product((0, .15, .30, .45, .60, .75, .90), (0.0, 0.60), G):
        add("L", "FULL", 5000, f"kappa={k}|rho={rho}|{gl(g)}", {}, kappa=k, rho_e=rho, gamma_W=g)
    stress = [("N=250", dict(N=250)), ("N=600", dict(N=600)),
              ("T=5 budget", dict(T=5, pi=pitf(0.35 * 8 / 5))), ("T=10 budget", dict(T=10, pi=pitf(0.35 * 8 / 10))),
              ("tau=0", dict(tau=0.0)), ("tau=0.30", dict(tau=0.30)), ("kappa=0.30", dict(kappa=0.30)),
              ("kappa=0.90", dict(kappa=0.90)), ("sd_e=0.35", dict(sd_e=0.35)), ("sd_e=0.80", dict(sd_e=0.80)),
              ("low within", dict(sd_ZH_within=0.31))]
    stress += [(f"m={m}", dict(pi=pitf(0.35 * m))) for m in (0.33, 0.50, 0.75, 1.50, 2.00)]
    assert [s[0] for s in stress] == STRESS_ORDER
    for lab, kw in stress:
        for g in G:
            m = float(lab[2:]) if lab.startswith("m=") else None
            add("S", "FULL", 5000, f"{lab}|{gl(g)}", dict(condition=lab, m=m), gamma_W=g, **kw)
    for g in G:
        add("S", "FULL", 5000, f"baseline|{gl(g)}", dict(condition="baseline", m=1.0), gamma_W=g)
    for (A, pi), (B, tau), g in itertools.product((("A0", (0.35,) * 3), ("A1", (0.15, 0.30, 0.60))),
                                                (("B0", 0.0), ("B1", 0.30)), G):
        add("X2", "FULL", 5000, f"{A}{B}|{gl(g)}", dict(A=A, B=B, arm="2x2"), pi=pi, tau=tau, gamma_W=g)
    for B, tau in (("B0", 0.0), ("B1", 0.30)):
        add("X2", "FULL", 5000, f"LAMBDA-{B}|g=0.15", dict(A="A1", B=B, arm="E2-LAMBDA"), tau=tau,
            lambda1=(0.90, 0.90, 0.90))
    for T, kb in itertools.product((4, 6, 8, 10, 12, 16), (0.0, 0.60)):
        add("X3", "X3", 5000, f"T={T}|kbar={kb}", dict(kbar=kb, kappa_T=kterm(T, kb)), T=T, rho_e=0.0,
            sd_ZH_within=sdW_for_T(T), kappa=kterm(T, kb))
    for f, sde, g in itertools.product((0.03, 0.05, 0.10, 0.20, 0.35, 0.50), (0.15, 0.25, 0.35, 0.55, 0.80), G):
        add("X4", "FULL", 2000, f"f={f}|sde={sde}|{gl(g)}", dict(f_level=f, design="grid"), pi=pitf(f), sd_e=sde,
            gamma_W=g)
    for g in G:
        add("X4", "FULL", 5000, f"uniform|{gl(g)}", dict(f_level=0.35, design="uniform"), pi=(0.35,) * 3, gamma_W=g)
    for k in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0):
        add("D", "D", 1000, f"kappa={k}", {}, kappa=k)

    # ---- checks against the registry (record 2.1-2.3)
    assert len(cells) == 176, len(cells)
    assert len({c["key"] for c in cells}) == 176
    used = {c["config"] for c in cells}
    assert used == {c.name for c in configs}, "module cells do not cover the 149 configurations exactly"
    counts = {}
    for c in cells:
        counts[c["module"]] = counts.get(c["module"], 0) + 1
        cr = c["config_R"]
        if c["battery"] == "FULL":
            assert c["R"] <= cr["FULL"], c
        elif c["battery"] == "X3":
            assert c["R"] <= (cr["FULL"] if cr["FULL"] else cr["X3"]), c
        else:
            assert c["R"] <= cr["D"], c
        assert c["module"] in c["modules"], c
    assert counts == {"P": 24, "L": 28, "S": 34, "X2": 10, "X3": 12, "X4": 62, "D": 6}, counts
    return cells, configs, prov


def estimators_for(cell):
    """Estimators whose rows exist for this module cell."""
    if cell["battery"] == "FULL":
        return list(F.EST16)
    if cell["battery"] == "X3":
        return list(F.X3_EST)
    return ["E-1"]


def config_R_pairs(cells):
    """Every (configuration, R) pair needed by some module cell, with the estimators needed."""
    need = {}
    for c in cells:
        k = (c["config"], c["R"])
        need.setdefault(k, set()).update(estimators_for(c))
    return {k: sorted(v, key=F.EST_ALL.index) for k, v in sorted(need.items())}
