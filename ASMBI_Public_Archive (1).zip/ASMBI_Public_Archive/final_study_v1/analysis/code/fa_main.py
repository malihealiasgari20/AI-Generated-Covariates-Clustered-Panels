"""Manuscript Tables 4, 7, 8, 9 and Figures 1, 3, 4 (record 8), with CSV and Markdown versions.
Tables 5-6 (Experiment 1, O1.1) and Figure 2 are written by fa_exp1."""
import math, os

import numpy as np

import fa_common as F
import fa_metrics as M
import fa_style as S
from fa_ctx import cov_band

plt = S.plt
NAN = float("nan")


def vm(v, m, nd=4, sign=False):
    """value (MCSE)"""
    if v is None or not math.isfinite(v):
        return "NA"
    s = F.fnum(v, nd, sign)
    return s if m is None or not math.isfinite(m) else f"{s} ({F.fnum(m, nd)})"


def flag(ctx, cell, e):
    m = ctx.m(cell, e)
    return "†" if m and m["conditional_on_success"] else ""


def register(reg, name, cells, R, rule, files):
    reg[name] = {"cells": [c["key"] for c in cells], "R": sorted({c["R"] for c in cells}), "aggregation": rule,
                 "files": [os.path.relpath(f, F.OUT) for f in files]}


# --------------------------------------------------------------------------- Table 4 (record 6.5)

def table4(ctx, reg):
    P = ctx.sel("P")
    nn, nul = [c for c in P if not c["null"]], [c for c in P if c["null"]]
    assert len(nn) == 12 and len(nul) == 12
    rows, robust, md, mdr = [], [], [], []

    def agg(cells, e, stat, fn):
        vals = [ctx.m(c, e)[stat] for c in cells]
        draws = np.vstack([ctx.d(c, e, stat) for c in cells])
        return float(fn(np.asarray(vals))), M.mcse_from_draws(fn(draws, axis=0))

    for e in F.EST16:
        r = {"estimator": e, "label": F.LABEL[e], "headline": e in F.HEADLINE_T4}
        for col, cells, stat, fn in (("bias", nn, "bias", np.mean), ("median_bias", nn, "median_bias", np.mean),
                                     ("emp_se", nn, "emp_se", np.mean), ("mean_se", nn, "mean_se", np.mean),
                                     ("rmse", nn, "rmse", np.mean), ("cov_median", nn, "coverage", np.median),
                                     ("cov_min", nn, "coverage", np.min), ("cov_max", nn, "coverage", np.max),
                                     ("width", nn, "width_median", np.mean), ("type1", nul, "rejection", np.mean),
                                     ("power", nn, "rejection", np.mean)):
            r[col], r[col + "_mcse"] = agg(cells, e, stat, fn)
        r["cells_conditional_on_success"] = sum(ctx.m(c, e)["conditional_on_success"] for c in P)
        r["failures_total"] = sum(ctx.m(c, e)["failures"] for c in P)
        r["max_failure_rate"] = max(ctx.m(c, e)["failure_rate"] for c in P)
        rows.append(r)
        q = {"estimator": e, "label": F.LABEL[e], "headline": e in F.HEADLINE_T4}
        for col, stat in (("mad_sd", "mad_sd"), ("median_se", "median_se"), ("median_se_over_mad", "median_se_over_mad"),
                          ("median_abs_err", "median_abs_err"), ("se_ratio", "se_ratio")):
            q[col], q[col + "_mcse"] = agg(nn, e, stat, np.mean)
        q["tail_driven_cells"] = sum(bool(ctx.m(c, e)["tail_driven"]) for c in nn)
        q["max_batch_rmse_ratio"] = max(ctx.m(c, e)["batch_rmse_ratio"] for c in nn)
        q["max_tail_share_sse"] = max(ctx.m(c, e)["tail_share_sse"] for c in nn)
        robust.append(q)
    out = F.ensure(os.path.join(F.OUT, "tables"))
    f1 = F.write_csv(os.path.join(out, "Table4_primary_aggregate.csv"), rows)
    f2 = F.write_csv(os.path.join(out, "Table4R_primary_aggregate_robust.csv"), robust)
    hdr = ["Procedure", "Bias", "Med. bias", "Emp. SE", "Mean SE", "RMSE", "Cov. med.", "Cov. min", "Cov. max",
           "Width", "Type I", "Power"]
    body = lambda sel: [[f"{F.SHORT[r['estimator']]} ({r['estimator']}){' †' if r['cells_conditional_on_success'] else ''}",
                         vm(r["bias"], r["bias_mcse"], 4, True), vm(r["median_bias"], r["median_bias_mcse"], 4, True),
                         vm(r["emp_se"], r["emp_se_mcse"]), vm(r["mean_se"], r["mean_se_mcse"]), vm(r["rmse"], r["rmse_mcse"]),
                         vm(r["cov_median"], r["cov_median_mcse"], 3), vm(r["cov_min"], r["cov_min_mcse"], 3),
                         vm(r["cov_max"], r["cov_max_mcse"], 3), vm(r["width"], r["width_mcse"], 3),
                         vm(r["type1"], r["type1_mcse"], 3), vm(r["power"], r["power_mcse"], 3)] for r in rows if sel(r)]
    cap = (f"Table 4. Primary-grid performance averaged over the 12 cells with gamma_W = 0.15 (5,000 replications "
           f"each); Type I error from the 12 companion null cells. {F.CAPTION}. Aggregation: record 6.5. Monte Carlo "
           f"SEs in parentheses (joint bootstrap, B = 2,000, FINAL_V1_BOOT). † = at least one cell with failure "
           f"rate above 5% (conditional on success).")
    rhdr = ["Procedure", "MAD-SD", "Median SE", "Med. SE / MAD-SD", "Median |err|", "Mean SE / emp. SE",
            "Tail-driven cells", "Max batch ratio", "Max single-rep. SSE share"]
    rbody = lambda sel: [[f"{F.SHORT[q['estimator']]} ({q['estimator']})", vm(q["mad_sd"], q["mad_sd_mcse"]),
                          vm(q["median_se"], q["median_se_mcse"]), vm(q["median_se_over_mad"], q["median_se_over_mad_mcse"], 3),
                          vm(q["median_abs_err"], q["median_abs_err_mcse"]), vm(q["se_ratio"], q["se_ratio_mcse"], 3),
                          str(q["tail_driven_cells"]), F.fnum(q["max_batch_rmse_ratio"], 2), F.fnum(q["max_tail_share_sse"], 3)]
                         for q in robust if sel(q)]
    text = [cap, "", F.md_table(hdr, body(lambda r: r["headline"])), "",
            "Supplementary rows (record 3.7: E-6H, HT-TDS-CF and E-12c outside the headline set):", "",
            F.md_table(hdr, body(lambda r: not r["headline"])), "",
            "Table 4R. Robust companion (record 6.2), same cells and aggregation (means over the 12 non-null cells).", "",
            F.md_table(rhdr, rbody(lambda q: q["headline"])), "", F.md_table(rhdr, rbody(lambda q: not q["headline"]))]
    f3 = os.path.join(out, "Table4_primary_aggregate.md")
    open(f3, "w").write("\n".join(text) + "\n")
    register(reg, "Table 4 / Table 4R", P, 5000, "record 6.5 (12 non-null + 12 null primary cells)", [f1, f2, f3])
    return rows, robust


# --------------------------------------------------------------------------- Figure 1

def figure1(ctx, reg):
    P = [c for c in ctx.sel("P") if not c["null"]]
    ests = F.HEADLINE_T4
    S.setup()
    allc = [ctx.m(c, e)["coverage"] for c in P for e in ests]
    zoom = min(allc) < 0.86
    fig, axes = plt.subplots(1, 2 if zoom else 1, figsize=(7.2 if zoom else 4.6, 4.4), sharey=True,
                             gridspec_kw={"width_ratios": [1, 1.25]} if zoom else None)
    axes = np.atleast_1d(axes)
    band = 1.959964 * math.sqrt(0.95 * 0.05 / 5000)
    data = []
    for ai, ax in enumerate(axes):
        if zoom:
            lo_x = 0.0 if ai == 0 else 0.86
        else:
            lo_x = math.floor((min(allc) - 0.005) * 100) / 100
        ax.axvspan(0.95 - band, 0.95 + band, color="#d9d8d3", lw=0, zorder=0)
        ax.axvline(0.95, color=S.INK2, lw=0.7)
        ax.axvline(0.92, color=S.INK2, lw=0.7, ls=":")
        for yi, e in enumerate(ests):
            covs = []
            for c in P:
                v = ctx.m(c, e)["coverage"]
                covs.append(v)
                col = S.SLOT["blue"] if c["kappa"] == 0 else S.SLOT["orange"]
                mk = "o" if c["rho_e"] == 0 else "^"
                jitter = {0.1: -0.18, 0.3: 0.0, 0.5: 0.18}[round(c["icc"], 1)]
                xv = v
                if zoom and ai == 1 and v < lo_x:
                    ax.plot([lo_x + 0.003], [yi + jitter], marker="<", color=col, ms=3, ls="none")
                    continue
                ax.plot([xv], [yi + jitter], marker=mk, color=col, ms=4.5, ls="none", mec=S.SURFACE, mew=0.6)
                if ai == 0:
                    data.append({"estimator": e, "cell": c["cell"], "icc": c["icc"], "rho_e": c["rho_e"],
                                 "kappa": c["kappa"], "coverage": v, "coverage_mcse": ctx.m(c, e)["coverage_mcse"]})
            med = float(np.median(covs))
            if not (zoom and ai == 1 and med < lo_x):
                ax.plot([med, med], [yi - 0.32, yi + 0.32], color=S.INK, lw=1.6)
        ax.set_xlim(lo_x, 1.0)
        ax.set_ylim(-0.6, len(ests) - 0.4)
        ax.invert_yaxis()
        ax.set_xlabel("coverage of nominal 95% intervals")
        ax.grid(axis="y", visible=False)
        ax.set_title("full range" if (zoom and ai == 0) else ("near nominal (points below the axis: ◀)" if zoom else ""),
                     fontsize=8, color=S.INK2)
    axes[0].set_yticks(range(len(ests)))
    axes[0].set_yticklabels([F.lab(e) for e in ests])
    from matplotlib.lines import Line2D
    h = [Line2D([], [], marker="o", color=S.SLOT["blue"], ls="none", label="kappa 0, rho_e 0"),
         Line2D([], [], marker="^", color=S.SLOT["blue"], ls="none", label="kappa 0, rho_e 0.60"),
         Line2D([], [], marker="o", color=S.SLOT["orange"], ls="none", label="kappa 0.60, rho_e 0"),
         Line2D([], [], marker="^", color=S.SLOT["orange"], ls="none", label="kappa 0.60, rho_e 0.60"),
         Line2D([], [], color=S.INK, lw=1.6, label="median over the 12 cells"),
         Line2D([], [], color="#d9d8d3", lw=6, label="0.95 ± 1.96 MCSE (R 5,000)"),
         Line2D([], [], color=S.INK2, lw=0.7, ls=":", label="0.920 (material undercoverage)")]
    fig.legend(handles=h, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.06), fontsize=7)
    fig.suptitle("Figure 1. Coverage in the 12 primary non-null cells (ICC 0.10/0.30/0.50 offset vertically)",
                 fontsize=9, y=1.0)
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, "Figure1_primary_coverage.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, "Figure1_primary_coverage_data.csv"), data)
    register(reg, "Figure 1", P, 5000, "per-cell coverage, median over the 12 non-null primary cells", [p, fc])
    return p


# --------------------------------------------------------------------------- Table 7 / Figure 3

def _vi_cells(ctx):
    order = ["m=0.33", "m=0.5", "m=0.75", "baseline", "m=1.5", "m=2.0"]
    return [ctx.one("S", condition=o, null=False) for o in order]


def table7(ctx, reg):
    cells = _vi_cells(ctx)
    rows = []
    for c in cells:
        for e in F.EST16:
            m = ctx.m(c, e)
            rows.append({"expected_labeled_clusters": c["expected_labeled"], "m": c["m"], "pi": c["pi"], "estimator": e,
                         "width_median": m["width_median"], "width_median_bmcse": m["width_median_bmcse"],
                         "coverage": m["coverage"], "coverage_mcse": m["coverage_mcse"],
                         "failure_rate": m["failure_rate"], "conditional_on_success": m["conditional_on_success"],
                         "headline": e in F.HEADLINE})
    out = F.ensure(os.path.join(F.OUT, "tables"))
    f1 = F.write_csv(os.path.join(out, "Table7_validation_intensity.csv"), rows)
    ests = F.HEADLINE
    hdr = ["Exp. labeled clusters"] + [F.SHORT[e] for e in ests]
    w = [[F.fnum(c["expected_labeled"], 2)] + [vm(ctx.m(c, e)["width_median"], ctx.m(c, e)["width_median_bmcse"], 3) + flag(ctx, c, e)
                                               for e in ests] for c in cells]
    cv = [[F.fnum(c["expected_labeled"], 2)] + [vm(ctx.m(c, e)["coverage"], ctx.m(c, e)["coverage_mcse"], 3) + flag(ctx, c, e)
                                                for e in ests] for c in cells]
    txt = [f"Table 7. Median interval width (panel A) and coverage (panel B) against validation intensity, stress "
           f"baseline, gamma_W = 0.15, 5,000 replications per cell; m = 0.33, 0.50, 0.75, 1.00 (baseline), 1.50, 2.00 "
           f"(ledger-Q3 rule; m = 2.00 has pi = (0.367, 0.733, 1.000)). {F.CAPTION}. MCSE in parentheses (width: "
           f"bootstrap; coverage: analytic). † = failure rate above 5% (conditional on success).", "",
           "Panel A. Median width", "", F.md_table(hdr, w), "", "Panel B. Coverage", "", F.md_table(hdr, cv)]
    f2 = os.path.join(out, "Table7_validation_intensity.md")
    open(f2, "w").write("\n".join(txt) + "\n")
    register(reg, "Table 7 / Figure 3", cells, 5000, "per cell", [f1, f2])
    return rows


MAIN_FIG = ["E-1", "E-7", "E-2", "E-4", "E-5", "E-6", "E-9", "E-12a", "E-12b"]
SUPP_FIG = ["E-2", "E-8", "HT-TDS-I", "PS-TDS-I", "E-12c", "E-6H", "HT-TDS-CF", "E-3"]


def figure3(ctx, reg, ests=MAIN_FIG, name="Figure3_validation_intensity", title="Figure 3"):
    cells = _vi_cells(ctx)
    x = np.array([c["expected_labeled"] for c in cells])
    S.setup()
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.5))
    data = []
    nn = len(ests)
    for k, e in enumerate(ests):
        dx = 1.0 + 0.018 * (k - (nn - 1) / 2)
        cov = np.array([ctx.m(c, e)["coverage"] for c in cells])
        cm = np.array([ctx.m(c, e)["coverage_mcse"] for c in cells])
        wid = np.array([ctx.m(c, e)["width_median"] for c in cells])
        wm = np.array([ctx.m(c, e)["width_median_bmcse"] for c in cells])
        axes[0].errorbar(x * dx, cov, yerr=1.96 * cm, label=F.lab(e), capsize=0, elinewidth=0.8, **S.est_kw(e))
        axes[1].errorbar(x * dx, wid, yerr=1.96 * wm, capsize=0, elinewidth=0.8, **S.est_kw(e))
        for c, a, b_, cc, d in zip(cells, cov, cm, wid, wm):
            data.append({"estimator": e, "expected_labeled_clusters": c["expected_labeled"], "coverage": a,
                         "coverage_mcse": b_, "width_median": cc, "width_median_bmcse": d})
    band = 1.959964 * math.sqrt(0.95 * 0.05 / 5000)
    axes[0].axhspan(0.95 - band, 0.95 + band, color="#d9d8d3", lw=0, zorder=0)
    axes[0].axhline(0.95, color=S.INK2, lw=0.7)
    axes[0].axhline(0.92, color=S.INK2, lw=0.7, ls=":")
    axes[0].set_ylabel("coverage of nominal 95% intervals")
    low = [e for e in ests if min(ctx.m(c, e)["coverage"] for c in cells) < 0.80]
    if low:
        rest = [ctx.m(c, e)["coverage"] for c in cells for e in ests if e not in low]
        lo_y = min(0.80, math.floor((min(rest) - 0.02) * 50) / 50) if rest else 0.0
        axes[0].set_ylim(lo_y, 1.0)
        axes[0].text(0.02, 0.03, "off scale (coverage below " + f"{lo_y:.2f}" + "): " +
                     ", ".join(f"{F.lab(e)} {min(ctx.m(c, e)['coverage'] for c in cells):.3f}-"
                               f"{max(ctx.m(c, e)['coverage'] for c in cells):.3f}" for e in low),
                     transform=axes[0].transAxes, fontsize=6.5, color=S.INK2)
    axes[1].set_yscale("log")
    axes[1].set_ylabel("median interval width (log scale)")
    xr = np.array([x.min(), x.max()])
    ref_e = "E-2" if "E-2" in ests else ests[0]
    w0 = ctx.m(cells[0], ref_e)["width_median"]
    axes[1].plot(xr, w0 * np.sqrt(xr[0] / xr), color=S.INK2, lw=0.8, ls=(0, (4, 3)),
                 label="slope -1/2 reference")
    from matplotlib.ticker import FixedLocator, NullLocator
    ylo, yhi = axes[1].get_ylim()
    tk = [t for t in (0.05, 0.07, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0, 1.5, 2.0) if ylo <= t <= yhi]
    axes[1].yaxis.set_major_locator(FixedLocator(tk))
    axes[1].yaxis.set_minor_locator(NullLocator())
    axes[1].set_yticklabels([f"{t:g}" for t in tk])
    for ax in axes:
        ax.set_xscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels([f"{v:g}" for v in x])
        ax.minorticks_off()
        ax.set_xlabel("expected labeled clusters")
    h2, l2 = axes[1].get_legend_handles_labels()
    fig.legend(S.proxies(ests, F.lab) + h2, [F.lab(e) for e in ests] + l2, loc="lower center", ncol=4,
               bbox_to_anchor=(0.5, -0.17), fontsize=7)
    fig.suptitle(f"{title}. Coverage and median width against validation intensity (stress baseline, gamma_W 0.15, "
                 f"R 5,000; bars ± 1.96 MCSE)", fontsize=9)
    fig.tight_layout()
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, f"{name}.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, f"{name}_data.csv"), data)
    register(reg, title, cells, 5000, "per cell", [p, fc])
    return p


# --------------------------------------------------------------------------- Table 8 (stress grid)

def table8(ctx, reg):
    from fa_cells import STRESS_ORDER
    conds = ["baseline"] + STRESS_ORDER
    rows = []
    for cond in conds:
        cn, c0 = ctx.one("S", condition=cond, null=False), ctx.one("S", condition=cond, null=True)
        for e in F.EST16:
            m, m0 = ctx.m(cn, e), ctx.m(c0, e)
            rows.append({"condition": cond, "estimator": e, "headline": e in F.HEADLINE,
                         "coverage": m["coverage"], "coverage_mcse": m["coverage_mcse"], "bias": m["bias"],
                         "bias_mcse": m["bias_mcse"], "rmse": m["rmse"], "rmse_mcse": m["rmse_mcse"],
                         "type1": m0["rejection"], "type1_mcse": m0["rejection_mcse"],
                         "coverage_null_cell": m0["coverage"], "bias_null_cell": m0["bias"],
                         "bias_null_cell_mcse": m0["bias_mcse"], "failure_rate": m["failure_rate"],
                         "failure_rate_null": m0["failure_rate"],
                         "conditional_on_success": m["conditional_on_success"] or m0["conditional_on_success"],
                         "expected_labeled_clusters": cn["expected_labeled"], "N": cn["N"], "T": cn["T"],
                         "tau": cn["tau"], "kappa": cn["kappa"], "sd_e": cn["sd_e"], "sd_ZH_within": cn["sd_W"]})
    out = F.ensure(os.path.join(F.OUT, "tables"))
    f1 = F.write_csv(os.path.join(out, "Table8_stress_grid.csv"), rows)
    ests = F.HEADLINE
    hdr = ["Condition"] + [F.SHORT[e] for e in ests]
    get = lambda cond, e: next(r for r in rows if r["condition"] == cond and r["estimator"] == e)
    panels = []
    for title, key, nd, sign in (("A. Coverage (gamma_W 0.15)", "coverage", 3, False), ("B. Bias (gamma_W 0.15)", "bias", 4, True),
                                 ("C. RMSE (gamma_W 0.15)", "rmse", 4, False), ("D. Type I error (gamma_W 0 companions)", "type1", 3, False)):
        body = [[cond] + [vm(get(cond, e)[key], get(cond, e)[key + "_mcse"], nd, sign) + ("†" if get(cond, e)["conditional_on_success"] else "")
                          for e in ests] for cond in conds]
        panels += [f"Panel {title}", "", F.md_table(hdr, body), ""]
    txt = [f"Table 8. Stress grid: 16 one-factor conditions from the stress baseline, each with its gamma_W = 0 null "
           f"companion, plus the baseline pair; 5,000 replications per cell. {F.CAPTION}. Cells vary one factor at a time "
           f"and are not crossed. MCSE in parentheses. † = failure rate above 5% in the non-null or null cell.", ""] + panels
    f2 = os.path.join(out, "Table8_stress_grid.md")
    open(f2, "w").write("\n".join(txt) + "\n")
    register(reg, "Table 8", ctx.sel("S"), 5000, "per cell (non-null and null companion)", [f1, f2])
    return rows


# --------------------------------------------------------------------------- Table 9 / Figure 4 (module D)

DQ = [("QWK", "assoc__raw_qwk_ZL_ZHdisc"), ("rank_corr_spearman", "assoc__raw_spearman_ZL_ZH"),
      ("raw_pearson", "assoc__raw_pearson_ZL_ZH"), ("within_pearson", "assoc__within_pearson_ZL_ZH"),
      ("within_spearman", "assoc__within_spearman_ZL_ZH"), ("incremental_oos_r2_pct", "oos_r2_incr_pct"),
      ("oos_r2_base", "oos_r2_base"), ("oos_r2_aug", "oos_r2_aug")]


def table9(ctx, reg):
    cells = sorted(ctx.sel("D"), key=lambda c: c["kappa"])
    rows = []
    for c in cells:
        r = {"kappa": c["kappa"], "config": c["config"], "R": c["R"]}
        for nm, key in DQ:
            v = ctx.diag(c, key)
            r[nm], r[nm + "_mcse"], r[nm + "_n"] = v["mean"], v["mcse"], v["n"]
        m = ctx.m(c, "E-1")
        r.update(naive_bias=m["bias"], naive_bias_mcse=m["bias_mcse"], naive_failure_rate=m["failure_rate"])
        rows.append(r)
    out = F.ensure(os.path.join(F.OUT, "tables"))
    f1 = F.write_csv(os.path.join(out, "Table9_agreement_predictive_value.csv"), rows)
    hdr = ["kappa", "QWK", "Rank corr. (Spearman)", "Naive bias", "Incremental OOS R^2 (%)", "Raw Pearson", "Within Pearson"]
    body = [[F.fnum(r["kappa"], 1), vm(r["QWK"], r["QWK_mcse"], 4), vm(r["rank_corr_spearman"], r["rank_corr_spearman_mcse"], 4),
             vm(r["naive_bias"], r["naive_bias_mcse"], 4, True), vm(r["incremental_oos_r2_pct"], r["incremental_oos_r2_pct_mcse"], 3),
             vm(r["raw_pearson"], r["raw_pearson_mcse"], 4), vm(r["within_pearson"], r["within_pearson_mcse"], 4)] for r in rows]
    txt = [f"Table 9. Agreement and predictive value against contamination intensity (module D: ICC 0.30, rho_e 0.60, "
           f"gamma_W 0.15; 1,000 replications per kappa). {F.CAPTION}. QWK: Z_L against the frozen discretization of "
           f"mean(lambda1) Z_H; rank correlation: raw Spearman of Z_L with Z_H; naive bias: E-1 (negative = attenuation); "
           f"incremental OOS R^2: record 7.6 [D8], a new definition (five unit folds, FINAL_V1_OOS), in percent. "
           f"Descriptive only. MCSE in parentheses.", "", F.md_table(hdr, body)]
    f2 = os.path.join(out, "Table9_agreement_predictive_value.md")
    open(f2, "w").write("\n".join(txt) + "\n")
    register(reg, "Table 9 / Figure 4", cells, 1000, "per kappa (replication means)", [f1, f2])
    return rows


def figure4(ctx, reg, rows):
    S.setup()
    k = np.array([r["kappa"] for r in rows])
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.0))
    for nm, lab, col, mk in (("QWK", "QWK (Z_L vs discretized Z_H)", S.SLOT["blue"], "o"),
                             ("rank_corr_spearman", "rank correlation (Spearman)", S.SLOT["violet"], "s")):
        y = np.array([r[nm] for r in rows]); e = np.array([r[nm + "_mcse"] for r in rows])
        axes[0].errorbar(k, y, yerr=1.96 * e, color=col, marker=mk, lw=1.5, ms=5, label=lab, capsize=0)
    axes[0].set_ylabel("agreement")
    axes[0].set_title("a. Agreement of Z_L with Z_H", fontsize=8.5, loc="left")
    y = np.array([r["incremental_oos_r2_pct"] for r in rows]); e = np.array([r["incremental_oos_r2_pct_mcse"] for r in rows])
    axes[1].errorbar(k, y, yerr=1.96 * e, color=S.SLOT["orange"], marker="D", lw=1.5, ms=5, capsize=0,
                     label="incremental OOS R^2")
    axes[1].axhline(0, color=S.INK2, lw=0.7)
    axes[1].set_ylabel("incremental out-of-sample R^2 (%)")
    axes[1].set_title("b. Predictive value of Z_L for the within outcome", fontsize=8.5, loc="left")
    for ax in axes:
        ax.set_xlabel("contamination intensity kappa")
        ax.set_xticks(k)
    axes[0].legend(loc="best", fontsize=7)
    fig.suptitle("Figure 4. Agreement and predictive value against kappa (module D, R 1,000; bars ± 1.96 MCSE; "
                 "separate axes, no dual-axis scale)", fontsize=8.5)
    fig.tight_layout()
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, "Figure4_agreement_predictive_value.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, "Figure4_agreement_predictive_value_data.csv"), rows)
    register(reg, "Figure 4", ctx.sel("D"), 1000, "per kappa", [p, fc])
    return p
