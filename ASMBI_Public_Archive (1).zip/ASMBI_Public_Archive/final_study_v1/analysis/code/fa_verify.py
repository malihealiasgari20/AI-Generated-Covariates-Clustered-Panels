"""Independent re-computation checks of the analysis outputs (QA). Recomputes, directly from the raw
checkpoints and with plain numpy written separately from fa_metrics, the record-6.1 quantities for a
deterministic sample of (module cell, estimator) pairs and compares them with the cell-level CSV;
checks the Table-4 aggregation against the cell-level rows; checks pre-stated identities (E-8 and
E-6 share point estimates; E-12a equals HT-TDS-CF where the TDS floor does not bind); and checks that
the bootstrap index matrices are reproducible. Writes <out>/qa/ANALYSIS_VERIFICATION.json."""
import csv, hashlib, json, math, os, sys

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fa_common as F  # noqa: E402
import numpy as np  # noqa: E402
import fa_cells, fa_load, fa_metrics  # noqa: E402


def rel(a, b):
    if a is None or b is None:
        return None
    a, b = float(a), float(b)
    if not (math.isfinite(a) and math.isfinite(b)):
        return 0.0 if (math.isnan(a) and math.isnan(b)) else math.inf
    return abs(a - b) / max(1e-12, abs(b))


def main():
    cells, configs, _ = fa_cells.build()
    rows = list(csv.DictReader(open(os.path.join(F.OUT, "cell_level", "CELL_LEVEL_CONVENTIONAL.csv"))))
    idx = {(r["module"], r["cell"], r["estimator"]): r for r in rows}
    key = {c.name: c.theta0_key for c in configs}
    rng = np.random.default_rng(20261104)
    sample = [cells[i] for i in sorted(rng.choice(len(cells), size=24, replace=False))]
    worst, checked, fails = 0.0, 0, []
    cache = {}
    for c in sample:
        cfg = cache.get(c["config"]) or fa_load.Config(c["config"], key[c["config"]])
        cache[c["config"]] = cfg
        R = min(c["R"], min(a["fail"].size for a in cfg.est.values())) if F.MODE != "production" else c["R"]
        for e in cfg.est:
            if e == "E-10" or (c["battery"] == "D" and e != "E-1") or (c["battery"] == "X3" and e not in F.X3_EST):
                continue
            r = idx.get((c["module"], c["cell"], e))
            if r is None:
                fails.append(f"missing row {c['key']} {e}")
                continue
            a = cfg.est[e]
            ok = a["fail"][:R] == 0
            th = a["th"][:R][ok]
            err = th - cfg.theta0
            mine = {"bias": err.mean(), "emp_se": th.std(ddof=1), "mean_se": a["se"][:R][ok].mean(),
                    "rmse": math.sqrt((err ** 2).mean()), "coverage": ((a["lo"][:R][ok] <= cfg.theta0) & (cfg.theta0 <= a["hi"][:R][ok])).mean(),
                    "rejection": ((a["lo"][:R][ok] > 0) | (a["hi"][:R][ok] < 0)).mean(),
                    "width_median": np.median((a["hi"] - a["lo"])[:R][ok]), "failure_rate": 1 - ok.mean()}
            for k, v in mine.items():
                if r[k] in ("NA", ""):
                    d = 0.0 if not math.isfinite(float(v)) else None
                else:
                    d = rel(r[k], v)
                checked += 1
                if d is None or d > 1e-12:
                    fails.append(f"{c['key']} {e} {k}: csv {r[k]} vs {v}")
                else:
                    worst = max(worst, d)
    # Table 4 aggregation
    t4 = list(csv.DictReader(open(os.path.join(F.OUT, "tables", "Table4_primary_aggregate.csv"))))
    P = [c for c in cells if c["module"] == "P"]
    t4_bad = []
    for t in t4:
        e = t["estimator"]
        nn = [idx[("P", c["cell"], e)] for c in P if not c["null"]]
        nl = [idx[("P", c["cell"], e)] for c in P if c["null"]]
        chk = {"bias": np.mean([float(x["bias"]) for x in nn]), "rmse": np.mean([float(x["rmse"]) for x in nn]),
               "cov_median": np.median([float(x["coverage"]) for x in nn]), "cov_min": min(float(x["coverage"]) for x in nn),
               "type1": np.mean([float(x["rejection"]) for x in nl]), "power": np.mean([float(x["rejection"]) for x in nn]),
               "width": np.mean([float(x["width_median"]) for x in nn])}
        for k, v in chk.items():
            if rel(t[k], v) > 1e-12:
                t4_bad.append((e, k, t[k], v))
    # identities
    ident = {}
    for c in [x for x in cells if x["battery"] == "FULL"][:40]:
        cfg = cache.get(c["config"]) or fa_load.Config(c["config"], key[c["config"]])
        cache[c["config"]] = cfg
        R = min(c["R"], cfg.est["E-6"]["fail"].size)
        a6, a8 = cfg.est["E-6"], cfg.est["E-8"]
        ok = (a6["fail"][:R] == 0) & (a8["fail"][:R] == 0)
        d68 = float(np.max(np.abs(a6["th"][:R][ok] - a8["th"][:R][ok]))) if ok.any() else None
        a12, acf = cfg.est["E-12a"], cfg.est["HT-TDS-CF"]
        ok2 = (a12["fail"][:R] == 0) & (acf["fail"][:R] == 0) & (acf["bind"][:R] == 0)
        d12 = float(np.max(np.abs(a12["th"][:R][ok2] - acf["th"][:R][ok2]))) if ok2.any() else None
        ident[c["key"]] = {"max|E-8 - E-6|": d68, "max|E-12a - HT-TDS-CF| (floor not binding)": d12}
        if len(cache) > 12:
            cache.pop(next(iter(cache)))
    m68 = max(v["max|E-8 - E-6|"] or 0 for v in ident.values())
    m12 = max(v["max|E-12a - HT-TDS-CF| (floor not binding)"] or 0 for v in ident.values())
    # bootstrap reproducibility
    boot = {}
    for R in sorted({min(c["R"], 10 ** 9) for c in cells}) if F.MODE == "production" else []:
        I1, _ = fa_metrics.boot_indices(R)
        I2, _ = fa_metrics.boot_indices(R)
        boot[R] = {"reproducible": bool(np.array_equal(I1, I2)),
                   "sha256": hashlib.sha256(np.ascontiguousarray(I1).tobytes()).hexdigest()}
    out = {"cell_metric_checks": checked, "cell_metric_failures": fails, "worst_relative_difference": worst,
           "table4_mismatches": t4_bad, "identity_max_E8_minus_E6": m68,
           "identity_max_E12a_minus_HTTDSCF_unbound": m12, "bootstrap_index_matrices": boot,
           "status": "PASS" if (not fails and not t4_bad and m68 < 1e-10 and m12 < 1e-12) else "FAIL"}
    F.dump_json(os.path.join(F.OUT, "qa", "ANALYSIS_VERIFICATION.json"), out)
    print(json.dumps({k: v for k, v in out.items() if k != "cell_metric_failures"}, default=str, indent=1)[:2000])
    print("failures:", fails[:10])
    return 0 if out["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
