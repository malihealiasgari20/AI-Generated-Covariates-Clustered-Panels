"""Experiment 1 (module L): O1.1-O1.4, Tables 5-6 (replacing the coverage-only tables), Figure 2,
hypotheses H1.1-H1.4, H1.3b, H1.3c (record 7.1; protocol 3; analysis plan G)."""
import math, os

import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq

import fa_common as F
import fa_metrics as M
import fa_style as S
from fa_ctx import centering, cov_band
from fa_main import MAIN_FIG, SUPP_FIG, flag, register, vm

plt = S.plt
K = (0.0, 0.15, 0.30, 0.45, 0.60, 0.75, 0.90)
RHO = (0.0, 0.60)
NAN = float("nan")


def ladder(ctx, rho, null):
    cells = [ctx.one("L", kappa=k, rho_e=rho, null=null) for k in K]
    assert [c["kappa"] for c in cells] == list(K)
    return cells


# --------------------------------------------------------------------------- O1.1, Tables 5-6

def o11(ctx, reg):
    rows = []
    for rho in RHO:
        for null in (False, True):
            for c in ladder(ctx, rho, null):
                for e in F.EST16:
                    m = ctx.m(c, e)
                    rows.append({"rho_e": rho, "gamma_W": c["gamma_W"], "kappa": c["kappa"], "estimator": e,
                                 "headline": e in F.HEADLINE, "bias": m["bias"], "bias_mcse": m["bias_mcse"],
                                 "emp_se": m["emp_se"], "emp_se_mcse": m["emp_se_mcse"], "mean_se": m["mean_se"],
                                 "mean_se_mcse": m["mean_se_mcse"], "se_ratio": m["se_ratio"],
                                 "se_ratio_bmcse": m["se_ratio_bmcse"], "rmse": m["rmse"], "rmse_mcse": m["rmse_mcse"],
                                 "coverage": m["coverage"], "coverage_mcse": m["coverage_mcse"],
                                 "width_median": m["width_median"], "width_median_bmcse": m["width_median_bmcse"],
                                 "rejection": m["rejection"], "rejection_mcse": m["rejection_mcse"],
                                 "rejection_is": "Type I error" if null else "power",
                                 "median_bias": m["median_bias"], "median_bias_bmcse": m["median_bias_bmcse"],
                                 "mad_sd": m["mad_sd"], "failure_rate": m["failure_rate"],
                                 "conditional_on_success": m["conditional_on_success"], "tail_driven": m["tail_driven"],
                                 "coverage_band": cov_band(m["coverage"]), "centering": centering(m["bias"], m["bias_mcse"])})
    out = F.ensure(os.path.join(F.OUT, "experiments", "Exp1"))
    f1 = F.write_csv(os.path.join(out, "O1.1_full_performance_table.csv"), rows)
    # compact Tables 5 and 6
    t = F.ensure(os.path.join(F.OUT, "tables"))
    ests = F.HEADLINE
    hdr = ["kappa"] + [F.SHORT[e] for e in ests]
    txt5 = [f"Table 5 (replaces the coverage-only Table 5; O1.1). Contamination ladder, gamma_W = 0.15, ICC 0.30, "
            f"5,000 replications per point; rho_e reported separately and never pooled. {F.CAPTION}. MCSE in "
            f"parentheses. The full O1.1 table (every estimator, every measure) is experiments/Exp1/O1.1_full_performance_table.csv.", ""]
    txt6 = [f"Table 6 (replaces the Type-I-only Table 6; O1.1). Contamination ladder, gamma_W = 0 null companions, "
            f"ICC 0.30, 5,000 replications per point. Rejection of theta = 0 at nominal 0.05. {F.CAPTION}.", ""]
    for rho in RHO:
        cn, c0 = ladder(ctx, rho, False), ladder(ctx, rho, True)
        for title, key, nd, sign in (("coverage", "coverage", 3, False), ("bias", "bias", 4, True),
                                     ("RMSE", "rmse", 4, False), ("mean SE / empirical SE", "se_ratio", 3, False),
                                     ("median width", "width_median", 3, False)):
            mk = {"coverage": "coverage_mcse", "bias": "bias_mcse", "rmse": "rmse_mcse", "se_ratio": "se_ratio_bmcse",
                  "width_median": "width_median_bmcse"}[key]
            body = [[F.fnum(c["kappa"], 2)] + [vm(ctx.m(c, e)[key], ctx.m(c, e)[mk], nd, sign) + flag(ctx, c, e) for e in ests]
                    for c in cn]
            txt5 += [f"rho_e = {rho:.2f}: {title}", "", F.md_table(hdr, body), ""]
        body = [[F.fnum(c["kappa"], 2)] + [vm(ctx.m(c, e)["rejection"], ctx.m(c, e)["rejection_mcse"], 3) + flag(ctx, c, e)
                                           for e in ests] for c in c0]
        txt6 += [f"rho_e = {rho:.2f}: Type I error", "", F.md_table(hdr, body), ""]
        body = [[F.fnum(c["kappa"], 2)] + [vm(ctx.m(c, e)["bias"], ctx.m(c, e)["bias_mcse"], 4, True) for e in ests] for c in c0]
        txt6 += [f"rho_e = {rho:.2f}: bias in the null cells", "", F.md_table(hdr, body), ""]
    f5 = os.path.join(t, "Table5_ladder_nonnull_O1.1.md")
    f6 = os.path.join(t, "Table6_ladder_null_O1.1.md")
    open(f5, "w").write("\n".join(txt5) + "\n")
    open(f6, "w").write("\n".join(txt6) + "\n")
    f5c = F.write_csv(os.path.join(t, "Table5_ladder_nonnull_O1.1.csv"), [r for r in rows if r["gamma_W"] > 0])
    f6c = F.write_csv(os.path.join(t, "Table6_ladder_null_O1.1.csv"), [r for r in rows if r["gamma_W"] == 0])
    register(reg, "Tables 5-6 (O1.1)", ctx.sel("L"), 5000, "per cell", [f1, f5, f6, f5c, f6c])
    return rows


# --------------------------------------------------------------------------- Figure 2 (O1.2 + coverage, Type I)

def figure2(ctx, reg, ests=MAIN_FIG, name="Figure2_ladder", title="Figure 2"):
    S.setup()
    fig, axes = plt.subplots(2, 4, figsize=(11.0, 5.6), sharex=True)
    data = []
    nn = len(ests)
    for i, rho in enumerate(RHO):
        cn, c0 = ladder(ctx, rho, False), ladder(ctx, rho, True)
        for k, e in enumerate(ests):
            dx = 0.016 * (k - (nn - 1) / 2)
            x = np.array(K) + dx
            m = [ctx.m(c, e) for c in cn]
            m0 = [ctx.m(c, e) for c in c0]
            series = (("bias", [q["bias"] for q in m], [q["bias_mcse"] for q in m]),
                      ("se_ratio", [q["se_ratio"] for q in m], [q["se_ratio_bmcse"] for q in m]),
                      ("coverage", [q["coverage"] for q in m], [q["coverage_mcse"] for q in m]),
                      ("type1", [q["rejection"] for q in m0], [q["rejection_mcse"] for q in m0]))
            for j, (nm, y, err) in enumerate(series):
                axes[i, j].errorbar(x, y, yerr=1.96 * np.array(err), capsize=0, elinewidth=0.8,
                                    label=F.lab(e) if (i == 0 and j == 0) else None, **S.est_kw(e, markersize=4))
                for kk, yy, ee in zip(K, y, err):
                    data.append({"rho_e": rho, "kappa": kk, "estimator": e, "quantity": nm, "value": yy, "mcse": ee})
        ax = axes[i]
        ax[0].axhspan(-0.02, 0.02, color="#ecebe7", lw=0, zorder=0)
        ax[0].axhline(0, color=S.INK2, lw=0.7)
        ax[1].axhspan(0.9, 1.1, color="#ecebe7", lw=0, zorder=0)
        ax[1].axhline(1, color=S.INK2, lw=0.7)
        band = 1.959964 * math.sqrt(0.95 * 0.05 / 5000)
        ax[2].axhspan(0.95 - band, 0.95 + band, color="#d9d8d3", lw=0, zorder=0)
        ax[2].axhline(0.95, color=S.INK2, lw=0.7)
        ax[2].axhline(0.92, color=S.INK2, lw=0.7, ls=":")
        b1 = 1.959964 * math.sqrt(0.05 * 0.95 / 5000)
        ax[3].axhspan(0.05 - b1, 0.05 + b1, color="#d9d8d3", lw=0, zorder=0)
        ax[3].axhline(0.05, color=S.INK2, lw=0.7)
        for j, lab in enumerate(("bias (gamma_W 0.15)", "mean SE / empirical SE", "coverage (gamma_W 0.15)",
                                 "Type I error (gamma_W 0)")):
            if not ax[j].get_title(loc="left"):
                ax[j].set_title(f"rho_e = {rho:.2f}: {lab}", fontsize=8, loc="left")
            if i == 1:
                ax[j].set_xlabel("contamination intensity kappa")
        if all(0.6 < v["value"] < 1.4 for v in data if v["quantity"] == "se_ratio" and v["rho_e"] == rho):
            ax[1].set_ylim(0.6, 1.4)
        else:
            ax[1].set_yscale("log")
            from matplotlib.ticker import FixedLocator, NullLocator
            lo_, hi_ = ax[1].get_ylim()
            tk = [t for t in (0.5, 0.7, 1.0, 1.5, 2.0, 3.0, 5.0, 7.0, 10.0, 20.0, 50.0) if lo_ <= t <= hi_]
            ax[1].yaxis.set_major_locator(FixedLocator(tk))
            ax[1].yaxis.set_minor_locator(NullLocator())
            ax[1].set_yticklabels([f"{t:g}" for t in tk])
            ax[1].set_title(f"rho_e = {rho:.2f}: SE ratio (log scale)", fontsize=8, loc="left")
    for a in axes.ravel():
        a.set_xticks(K)
        a.set_xticklabels(["0", ".15", ".30", ".45", ".60", ".75", ".90"])
    fig.legend(handles=S.proxies(ests, F.lab), loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.06), fontsize=7.5)
    fig.suptitle(f"{title}. Contamination ladder (module L, ICC 0.30, R 5,000 per point): bias and SE calibration (O1.2), "
                 f"coverage and size\nbars ± 1.96 MCSE; shaded: |bias| < 0.02, SE ratio 0.90-1.10, Monte Carlo band "
                 f"around the nominal level; points dodged horizontally so that every series is visible", fontsize=8.5)
    fig.tight_layout(rect=(0, 0.02, 1, 0.97))
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, f"{name}.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, f"{name}_data.csv"), data)
    register(reg, title, ctx.sel("L"), 5000, "per cell", [p, fc])
    return p


# --------------------------------------------------------------------------- O1.3 crossing

def crossing(k, b):
    k, b = np.asarray(k, float), np.asarray(b, float)
    if not np.all(np.isfinite(b)):
        return NAN, "undefined"
    for j in range(len(k) - 1):
        if b[j] == 0:
            return float(k[j]), "in range"
        if b[j] * b[j + 1] < 0:
            p = PchipInterpolator(k, b)
            return float(brentq(p, k[j], k[j + 1], xtol=1e-12)), "in range"
    if b[-1] == 0:
        return float(k[-1]), "in range"
    p = PchipInterpolator(k, b, extrapolate=True)
    g = np.linspace(k[-1], 3.0, 2101)
    v = p(g)
    s = np.flatnonzero(np.sign(v[:-1]) * np.sign(v[1:]) < 0)
    if s.size:
        j = s[0]
        return float(brentq(p, g[j], g[j + 1], xtol=1e-12)), "extrapolated (outside the simulated range)"
    return math.inf, "none on [0, 3.0]"


def o13(ctx, est="E-1"):
    res = {}
    for rho in RHO:
        cells = ladder(ctx, rho, False)
        b = [ctx.m(c, est)["bias"] for c in cells]
        root, status = crossing(K, b)
        D = np.vstack([ctx.d(c, est, "bias") for c in cells])
        roots, inr = [], 0
        for j in range(D.shape[1]):
            r_, st = crossing(K, D[:, j])
            roots.append(r_ if st != "undefined" else NAN)
            inr += st == "in range"
        roots = np.array(roots)
        fin = roots[np.isfinite(roots) & (roots <= 0.90)]
        res[f"rho_e={rho:.2f}"] = {"estimator": est, "bias_by_kappa": dict(zip([str(k) for k in K], b)),
                                   "root": root, "status": status, "ci95_percentile": M.pct(roots),
                                   "share_draws_in_range_root": inr / D.shape[1],
                                   "bmcse_in_range_roots": M.mcse_from_draws(fin) if fin.size > 1 else NAN,
                                   "B": int(D.shape[1])}
    return res


# --------------------------------------------------------------------------- O1.4

def o14(ctx):
    rows, stmt = [], {}
    for rho in RHO:
        for e in F.DESIGN_AWARE_O14:
            worst, absorb, under = 0.0, False, False
            for c in ladder(ctx, rho, False):
                m = ctx.m(c, e)
                ratio = abs(m["bias"]) / (m["width_median"] / 2) if m["width_median"] > 0 else NAN
                worst = max(worst, ratio)
                big = abs(m["bias"]) >= 0.02
                absorb |= big and m["coverage"] >= 0.940
                under |= big and m["coverage"] < 0.940
                rows.append({"rho_e": rho, "estimator": e, "kappa": c["kappa"], "bias": m["bias"],
                             "bias_mcse": m["bias_mcse"], "width_median": m["width_median"],
                             "ratio_abs_bias_to_half_width": ratio, "coverage": m["coverage"]})
            s = ("displacement with undercoverage" if under else "width absorbing displacement" if absorb
                 else "stable centering")
            stmt[f"{e}|rho_e={rho:.2f}"] = {"statement": s, "max_ratio": worst}
    out = F.ensure(os.path.join(F.OUT, "experiments", "Exp1"))
    F.write_csv(os.path.join(out, "O1.4_centering_vs_width.csv"), rows)
    return rows, stmt


# --------------------------------------------------------------------------- hypotheses

def _inc(ctx, cells, est):
    """successive paired increments and paired changes from kappa 0 (plan D2)."""
    inc, dlt = [], []
    assert len({c["seed_cell_id"] for c in cells}) == 1, "ladder cells must share one seed id (CRN)"
    for j in range(1, len(cells)):
        a1, a0 = ctx.arrays(cells[j], est), ctx.arrays(cells[j - 1], est)
        inc.append(M.cross_pair(a1, a0))
        dlt.append(M.cross_pair(a1, ctx.arrays(cells[0], est)))
    return inc, dlt


def hypotheses(ctx, cr):
    H = []
    # H1.1
    cn = ladder(ctx, 0.60, False)
    m0 = ctx.m(cn[0], "E-1")
    inc, _ = _inc(ctx, cn, "E-1")
    a = m0["bias"] <= -3 * m0["bias_mcse"]
    b = all(x["diff"] >= -3 * x["mcse"] for x in inc)
    c = cr["rho_e=0.60"]
    root, st = c["root"], c["status"]
    inrange = st == "in range" and 0 < root <= 0.90
    refuted = (st != "in range") or (root < 0.45)
    H.append(dict(id="H1.1", experiment="1", outcome="REFUTED" if refuted else ("SUPPORTED" if (a and b and inrange) else "NOT SUPPORTED"),
                  status="CONFIRMATORY RE-ESTIMATE (rho_e 0.60 arm observed in S0.11)",
                  cells="L, rho_e 0.60, gamma_W 0.15, kappa 0-0.90; E-1",
                  evidence=dict(bias_kappa0=m0["bias"], bias_kappa0_mcse=m0["bias_mcse"], clause_a_negative=a,
                                clause_b_monotone=b, increments=[(x["diff"], x["mcse"]) for x in inc],
                                crossing=root, crossing_status=st, crossing_ci95=c["ci95_percentile"],
                                share_draws_in_range=c["share_draws_in_range_root"],
                                rho0_crossing=cr["rho_e=0.00"]["root"], rho0_status=cr["rho_e=0.00"]["status"],
                                rho0_ci95=cr["rho_e=0.00"]["ci95_percentile"]),
                  rule="analysis plan G, H1.1"))
    # H1.2 (E-7)
    ev, delta6, flat0, mono = {}, {}, None, True
    for rho in RHO:
        cells = ladder(ctx, rho, False)
        inc, dlt = _inc(ctx, cells, "E-7")
        s6 = np.sign(dlt[-1]["diff"])
        mono_r = all(not (s6 * x["diff"] < 0 and abs(x["diff"]) > 3 * x["mcse"]) for x in inc)
        mono &= mono_r
        delta6[rho] = dlt[-1]
        ev[f"rho_e={rho:.2f}"] = dict(delta_from_kappa0=[(x["diff"], x["mcse"]) for x in dlt],
                                      increments=[(x["diff"], x["mcse"]) for x in inc], monotone=mono_r)
        if rho == 0.0:
            flat0 = all(abs(x["diff"]) <= 3 * x["mcse"] for x in dlt)
    bclause = abs(delta6[0.0]["diff"]) >= 3 * delta6[0.0]["mcse"]
    cclause = abs(delta6[0.0]["diff"]) < abs(delta6[0.60]["diff"])
    ev.update(growth_rho0_nonzero=bclause, growth_rho0_smaller=cclause,
              abs_growth_difference=abs(delta6[0.60]["diff"]) - abs(delta6[0.0]["diff"]),
              abs_growth_difference_mcse=math.hypot(delta6[0.60]["mcse"], delta6[0.0]["mcse"]), flat_rho0=flat0)
    H.append(dict(id="H1.2", experiment="1", outcome="REFUTED" if flat0 else ("SUPPORTED" if (mono and bclause and cclause) else "NOT SUPPORTED"),
                  status="rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE", cells="L, gamma_W 0.15; E-7",
                  evidence=ev, rule="analysis plan G, H1.2"))
    # H1.3 and H1.3b
    for hid, ests, high_only in (("H1.3", ["E-6", "E-8", "E-9"], True), ("H1.3b", ["E-12a", "E-12b"], False)):
        viol, refute, tab = [], [], []
        for rho in RHO:
            for c in ladder(ctx, rho, False):
                for e in ests:
                    m = ctx.m(c, e)
                    tab.append((rho, c["kappa"], e, m["bias"], m["bias_mcse"], m["coverage"]))
                    if hid == "H1.3":
                        if abs(m["bias"]) >= 0.02:
                            viol.append((rho, c["kappa"], e))
                        if abs(m["bias"]) > 0.02 and c["kappa"] >= 0.60 and m["coverage"] >= 0.95:
                            refute.append((rho, c["kappa"], e))
                    else:
                        if abs(m["bias"]) >= 0.02:
                            refute.append((rho, c["kappa"], e))
        if hid == "H1.3":
            outcome = "REFUTED" if refute else ("NOT SUPPORTED" if viol else "SUPPORTED")
        else:
            outcome = "REFUTED" if refute else "SUPPORTED"
        secondary = []
        for rho in RHO:
            for c in ladder(ctx, rho, True):
                for e in ests:
                    m = ctx.m(c, e)
                    if abs(m["bias"]) >= 0.02:
                        secondary.append((rho, c["kappa"], e, m["bias"]))
        H.append(dict(id=hid, experiment="1", outcome=outcome,
                      status=("rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE" if hid == "H1.3" else
                              "PROSPECTIVE except kappa 0 and 0.60 (Experiment 5 cells)"),
                      cells="L, gamma_W 0.15, both rho_e, every kappa; " + ", ".join(ests),
                      evidence=dict(max_abs_bias=max(abs(t[3]) for t in tab), exceedances=viol if hid == "H1.3" else refute,
                                    refuting_cells=refute, table=tab, secondary_null_cells_abs_bias_ge_0_02=secondary),
                      rule=f"analysis plan G, {hid}"))
    # H1.3c, E-4, E-2 reported
    rep = {}
    for rho in RHO:
        cells = ladder(ctx, rho, False)
        for e in ("E-5", "E-12c", "E-4", "E-2"):
            _, dlt = _inc(ctx, cells, e)
            m0_ = ctx.m(cells[0], e)
            rep[f"{e}|rho_e={rho:.2f}"] = dict(bias_kappa0=m0_["bias"], bias_kappa0_mcse=m0_["bias_mcse"],
                                               change_from_kappa0=[(x["diff"], x["mcse"]) for x in dlt])
    H.append(dict(id="H1.3c", experiment="1", outcome="REPORTED", status="mixed (see record 0.3)",
                  cells="L, gamma_W 0.15; E-5, E-12c (E-4 and E-2 in their own rows)", evidence=rep,
                  rule="reported separately; kappa-0 displacement attributed to validation design"))
    # H1.4
    viol, tab, sec = [], [], []
    for rho in RHO:
        for null in (False, True):
            for c in ladder(ctx, rho, null):
                for e in ("E-4", "E-6", "E-8", "E-9"):
                    m = ctx.m(c, e)
                    bad = not (0.90 <= m["se_ratio"] <= 1.10)
                    (sec if null else viol).append((rho, c["kappa"], e, m["se_ratio"])) if bad else None
                    if not null:
                        tab.append((rho, c["kappa"], e, m["se_ratio"], m["se_ratio_bmcse"]))
    H.append(dict(id="H1.4", experiment="1", outcome="REFUTED" if viol else "SUPPORTED",
                  status="rho_e 0.60: CONFIRMATORY RE-ESTIMATE; rho_e 0: PROSPECTIVE",
                  cells="L, gamma_W 0.15, both rho_e, every kappa; E-4, E-6, E-8, E-9",
                  evidence=dict(violations=viol, table=tab, secondary_null_cell_violations=sec),
                  rule="analysis plan G, H1.4"))
    return H


def run(ctx, reg):
    o11(ctx, reg)
    figure2(ctx, reg)
    figure2(ctx, reg, SUPP_FIG, "FigureS2_ladder_other_estimators", "Supplementary Figure S2")
    cr = o13(ctx)
    cr0 = o13(ctx, "E-7")
    out = F.ensure(os.path.join(F.OUT, "experiments", "Exp1"))
    F.dump_json(os.path.join(out, "O1.3_zero_bias_crossing.json"), {"E-1 (protocol 3.3)": cr, "E-7 (descriptive)": cr0})
    rows, stmt = o14(ctx)
    F.dump_json(os.path.join(out, "O1.4_statements.json"), stmt)
    H = hypotheses(ctx, cr)
    return {"crossing": cr, "o14": stmt, "H": H}
