"""Figure captions (record 8: every caption states the study, the cells, R and the aggregation rule),
and the P/S design-aware and TDS comparison table (record 8, "New")."""
import os

import fa_common as F
from fa_main import vm

CAP = {
    "Figure1_primary_coverage": (
        "Figure 1. Coverage of nominal 95% intervals in the 12 primary non-null cells (ICC 0.10/0.30/0.50 x rho_e 0/0.60 "
        "x kappa 0/0.60, gamma_W 0.15; N 300, T 8), 5,000 replications per cell, one panel per (cell, replication) shared "
        "by every estimator. Each point is one cell (colour: kappa; marker: rho_e; vertical offset: ICC); the black tick "
        "is the median over the 12 cells (record 6.5); the grey band is 0.95 +/- 1.96 x 0.0031 (per-cell Monte Carlo "
        "band); the dotted line is the 0.920 material-undercoverage threshold (record 6.6). Right panel: the same "
        "points near nominal; points below its axis are marked by arrows. "),
    "Figure2_ladder": (
        "Figure 2. Experiment 1 (module L): contamination ladder kappa 0-0.90 at ICC 0.30, rho_e 0 (top) and 0.60 "
        "(bottom), 5,000 replications per point with kappa excluded from the seed key (common random numbers along the "
        "ladder). Columns: bias and mean SE / empirical SE in the gamma_W 0.15 cells (O1.2), coverage in the gamma_W 0.15 "
        "cells, Type I error in the gamma_W 0 cells. Per-cell values; bars +/- 1.96 MCSE (analytic; SE ratio: bootstrap). "
        "Headline estimators except E-3, E-8, HT-TDS-I and PS-TDS-I, which appear in Supplementary Figure S2. "),
    "FigureS2_ladder_other_estimators": (
        "Supplementary Figure S2. As Figure 2 for E-8 (whose point estimate is E-6's), HT-TDS-I, PS-TDS-I, E-12c "
        "(negative control), E-6H (Hajek point-estimator variant with a clustered-sandwich convention), HT-TDS-CF and "
        "E-3, with E-2 as reference. "),
    "Figure3_validation_intensity": (
        "Figure 3. Validation intensity (module S, stress baseline, gamma_W 0.15): expected labeled clusters 34.65, 52.5, "
        "78.75, 105 (baseline), 157.5, 210 (m 0.33-2.00, ledger-Q3 rule), 5,000 replications per cell. Left: coverage; "
        "right: median interval width on a log scale with a slope -1/2 reference. Per-cell values; bars +/- 1.96 MCSE. "
        "Series whose coverage lies far below the plotted range (the naive estimator) are listed in the panel with their "
        "range instead of being drawn. Remaining estimators in Supplementary Figure S3. "),
    "FigureS3_validation_intensity_other_estimators": "Supplementary Figure S3. As Figure 3 for the remaining estimators. ",
    "Figure4_agreement_predictive_value": (
        "Figure 4. Dissociation diagnostic (module D: ICC 0.30, rho_e 0.60, gamma_W 0.15; kappa 0-1.0), 1,000 "
        "replications per kappa. Left: QWK of Z_L with the frozen discretization of mean(lambda1) Z_H, and the raw "
        "Spearman rank correlation of Z_L with Z_H; right: incremental out-of-sample R^2 of Z~_L for the within outcome "
        "(record 7.6 [D8], a new definition). Replication means; bars +/- 1.96 MCSE. Two panels on separate axes "
        "(no dual-axis scale). Descriptive only. "),
    "FigureX2_design_heterogeneity": (
        "Figure X2. Experiment 2 (module X2): validation design (A0 uniform pi 0.35; A1 unequal 0.15/0.30/0.60) x slope "
        "heterogeneity (B0 tau 0; B1 tau 0.30), kappa 0, rho_e 0.60, gamma_W 0.15, plus the E2-LAMBDA arm (A1, lambda1(s) "
        "= 0.90; mechanism diagnostic only), 5,000 replications per cell. (a) Bias per cell (categorical, not joined); "
        "bars +/- 1.96 MCSE. (b) Observed bias against the predicted selected-mixture displacement (record 3.8, F10a), "
        "all X2 cells. "),
    "FigureX3_inverse_T": (
        "Figure X3. Experiment 3 (module X3): T 4-16 at rho_e 0, gamma_W 0.15, N 300; displacement = bias(kappabar 0.60) "
        "- bias(kappabar 0), paired within T on common random numbers, 5,000 replications per cell. (a) O3.2, T x "
        "|displacement| (flat = 1/T scaling); (b) O3.3, weighted regression of log|displacement| on log T (weights "
        "d^2/MCSE^2), with the predicted slope -1. Bars +/- 1.96 MCSE. Interpretation subject to control C3 (record 1.5). "
        "E-2 uses human labels only, so its paired displacement is identically zero at every T (no fit). "),
    "FigureX4_crossover_contours": (
        "Figure X4. Experiment 4 (module X4), O4.2: log R_RMSE = log RMSE(estimator)/RMSE(E-2) on paired replications "
        "over labeled-cluster fraction f (0.03-0.50, log scale) x machine-error SD (0.15-0.80), gamma_W 0.15, 2,000 "
        "replications per cell; bilinear interpolation in (log f, sd_e) over rectangles with four unflagged corners; "
        "black line: log R_RMSE = 0. Markers: classification by the bootstrap 95% interval of log R_RMSE (B 2,000). "
        "Hatched: failure rate above 5% for the estimator or E-2 (conditional on success; excluded from the "
        "interpolation). E-10 (PPI++-style general M-estimation comparator, unweighted for the validation design) is "
        "ABSENT: gate V10 failed. "),
    "FigureS4_crossover_contours_null": "Supplementary Figure S4. As Figure X4 for the gamma_W 0 companion cells. ",
    "FigureX5_exp5_reevaluation": (
        "Figure X5. Experiment-5 re-evaluation on FINAL_V1 panels: the 12 primary non-null cells and the four stress "
        "cells N 250, N 600, tau 0, tau 0.30 (gamma_W 0.15), 5,000 replications per cell. (a) bias; (b) coverage; per "
        "cell (categorical, not joined); bars +/- 1.96 MCSE. "),
}


def write_captions():
    lines = ["# Figure captions", ""]
    for k, v in CAP.items():
        lines += [f"## {k}", "", v + F.CAPTION + ".", ""]
    p = os.path.join(F.OUT, "figures", "FIGURE_CAPTIONS.md")
    open(p, "w").write("\n".join(lines) + "\n")
    return p


def ps_comparisons(ctx, reg):
    """record 8 'New': P/S design-aware and TDS comparisons -- paired RMSE ratios and bias differences."""
    ests = ["E-6", "E-8", "E-9", "E-12a", "E-12b", "HT-TDS-I", "PS-TDS-I", "HT-TDS-CF", "E-6H", "E-5", "E-4"]
    rows = []
    cells = [c for c in ctx.sel("P") if not c["null"]] + [c for c in ctx.sel("S") if not c["null"]]
    for c in cells:
        for e in ests:
            for ref in ("E-2", "E-6"):
                if e == ref:
                    continue
                p = ctx.pair(c, e, ref)
                if not p:
                    continue
                rows.append({"module": c["module"], "cell": c["cell"], "estimator": e, "reference": ref,
                             "rmse_ratio": p["rmse_ratio"], "rmse_ratio_bmcse": p["rmse_ratio_bmcse"],
                             "log_ci95_lo": p["log_rmse_ratio_ci95"][0], "log_ci95_hi": p["log_rmse_ratio_ci95"][1],
                             "bias_diff": p["bias_diff"], "bias_diff_mcse": p["bias_diff_mcse"],
                             "n_intersection": p["n_intersection"]})
    out = F.ensure(os.path.join(F.OUT, "supplementary"))
    f1 = F.write_csv(os.path.join(out, "S8_P_S_design_aware_and_TDS_paired_comparisons.csv"), rows)
    hdr = ["Cell"] + [F.SHORT[e] for e in ests]
    body = []
    for c in cells:
        r = [f"{c['module']} {c['cell'].replace('|g=0.15', '')}"]
        for e in ests:
            p = ctx.pair(c, e, "E-2")
            r.append(vm(p["rmse_ratio"], p["rmse_ratio_bmcse"], 3) if p else "")
        body.append(r)
    txt = [f"S8. RMSE ratio against labeled-only IPW (E-2) on paired replications, primary non-null cells and stress "
           f"non-null cells, 5,000 replications per cell; bootstrap MCSE in parentheses. {F.CAPTION}.", "",
           F.md_table(hdr, body)]
    f2 = os.path.join(out, "S8_P_S_design_aware_and_TDS_paired_comparisons.md")
    open(f2, "w").write("\n".join(txt) + "\n")
    reg["S8 P/S design-aware and TDS comparisons"] = {"cells": [c["key"] for c in cells], "R": [5000],
                                                     "aggregation": "per cell, paired within cell",
                                                     "files": [os.path.relpath(f, F.OUT) for f in (f1, f2)]}
