"""SHA-256 manifest of the production run folder (run/), written once the close-out check passes."""
import datetime, hashlib, os

STUDY = "/mnt/user-data/outputs/Final_Study_v1"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


t = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
out = os.path.join(STUDY, "MANIFEST_SHA256_RUN.txt")
assert not os.path.exists(out), "run manifest exists; not overwritten"
files = sorted(os.path.relpath(os.path.join(r, f), STUDY) for r, _, fs in os.walk(os.path.join(STUDY, "run")) for f in fs)
with open(out, "w") as fh:
    fh.write(f"SHA-256 MANIFEST -- Final_Study_v1/run (FINAL_V1 production run, after close-out), {t}\n{len(files)} files\n\n")
    for f in files:
        fh.write(f"{sha(os.path.join(STUDY, f))}  {f}\n")
print(len(files), "files;", sha(out))
