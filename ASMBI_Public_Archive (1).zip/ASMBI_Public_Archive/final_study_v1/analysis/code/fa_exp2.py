"""Experiment 2 (module X2): O2.1-O2.5 and hypotheses H2.1-H2.5 (record 7.2; protocol 4; plan H)."""
import itertools, math, os

import numpy as np

import fa_common as F
import fa_style as S
from fa_main import register, vm

plt = S.plt
CELLS = ("A0B0", "A0B1", "A1B0", "A1B1")
PRED_EST = ["E-4", "E-5", "E-6", "E-6H", "E-12a", "E-12b", "E-12c"]


def cell(ctx, ab, null=False):
    if ab.startswith("LAMBDA"):
        return ctx.one("X2", arm="E2-LAMBDA", B=ab[-2:])
    return ctx.one("X2", arm="2x2", A=ab[:2], B=ab[2:], null=null)


def ds_table(ctx):
    """O2.5 (and every X2 cell): realized D_s by stratum and pairwise equality checks."""
    rows = []
    for ab, null in [(x, n) for x in CELLS for n in (False, True)] + [("LAMBDA-B0", False), ("LAMBDA-B1", False)]:
        c = cell(ctx, ab, null)
        rc = ctx.raw(c)
        R = ctx.R_used(c)
        for rule in ("L", "u", "w"):
            vals = [np.asarray(rc.diag.get(f"D_{rule}_s{j}", np.full(R, np.nan))[:R], float) for j in range(3)]
            r = {"cell": c["cell"], "rule": rule}
            for j in range(3):
                v = vals[j][np.isfinite(vals[j])]
                r[f"D_s{j}"] = float(v.mean()) if v.size else None
                r[f"D_s{j}_mcse"] = float(v.std(ddof=1) / math.sqrt(v.size)) if v.size > 1 else None
                r[f"D_s{j}_n"] = int(v.size)
            eq = True
            for j, k in itertools.combinations(range(3), 2):
                ok = np.isfinite(vals[j]) & np.isfinite(vals[k])
                d = vals[j][ok] - vals[k][ok]
                if d.size > 1:
                    mu, se = float(d.mean()), float(d.std(ddof=1) / math.sqrt(d.size))
                    r[f"diff_s{j}_s{k}"], r[f"diff_s{j}_s{k}_mcse"] = mu, se
                    eq &= abs(mu) <= 3 * se
                else:
                    r[f"diff_s{j}_s{k}"] = None
                    eq = None if d.size <= 1 else eq
            r["equal_within_3_mcse"] = eq
            rows.append(r)
    return rows


def run(ctx, reg):
    out = F.ensure(os.path.join(F.OUT, "experiments", "Exp2"))
    # O2.1
    rows = []
    for null in (False, True):
        labs = list(CELLS) + ([] if null else ["LAMBDA-B0", "LAMBDA-B1"])
        for ab in labs:
            c = cell(ctx, ab, null)
            for e in F.EST16:
                m = ctx.m(c, e)
                rows.append({"cell": ab, "gamma_W": c["gamma_W"], "estimator": e, "mechanism_table": e in F.MECHANISM,
                             "bias": m["bias"], "bias_mcse": m["bias_mcse"], "coverage": m["coverage"],
                             "coverage_mcse": m["coverage_mcse"], "rmse": m["rmse"], "rmse_mcse": m["rmse_mcse"],
                             "rejection": m["rejection"], "rejection_mcse": m["rejection_mcse"],
                             "failure_rate": m["failure_rate"], "conditional_on_success": m["conditional_on_success"]})
    f1 = F.write_csv(os.path.join(out, "O2.1_2x2_tables.csv"), rows)
    get = lambda ab, g, e: next(r for r in rows if r["cell"] == ab and r["gamma_W"] == g and r["estimator"] == e)
    txt = [f"O2.1. Experiment 2, validation design (A0 uniform pi 0.35; A1 unequal pi 0.15/0.30/0.60) x slope "
           f"heterogeneity (B0 tau 0; B1 tau 0.30), kappa 0, rho_e 0.60, 5,000 replications per cell; E2-LAMBDA: A1 with "
           f"lambda1(s) = 0.90 (mechanism diagnostic only). {F.CAPTION}. MCSE in parentheses.", ""]
    for g in (0.15, 0.0):
        labs = list(CELLS) + (["LAMBDA-B0", "LAMBDA-B1"] if g else [])
        for q, nd, sign in (("bias", 4, True), ("coverage", 3, False), ("rmse", 4, False)) + ((("rejection", 3, False),) if g == 0 else ()):
            hdr = ["Estimator"] + labs
            body = [[F.lab(e)] + [vm(get(ab, g, e)[q], get(ab, g, e)[q + "_mcse"], nd, sign) for ab in labs]
                    for e in F.MECHANISM]
            nm = "Type I error" if q == "rejection" else q
            txt += [f"gamma_W = {g}: {nm}", "", F.md_table(hdr, body), ""]
    f2 = os.path.join(out, "O2.1_2x2_tables.md")
    open(f2, "w").write("\n".join(txt) + "\n")
    # O2.2 interaction contrast (every estimator; E-5 governs H2.1b)
    o22 = {}
    for g in (0.15, 0.0):
        for e in F.EST16:
            b = {ab: get(ab, g, e) for ab in CELLS}
            D = (b["A1B1"]["bias"] - b["A1B0"]["bias"]) - (b["A0B1"]["bias"] - b["A0B0"]["bias"])
            se = math.sqrt(sum(b[ab]["bias_mcse"] ** 2 for ab in CELLS))
            o22[f"{e}|g={g}"] = {"Delta": D, "mcse": se, "z": D / se if se > 0 else None}
    # O2.3 observed vs predicted
    o23 = []
    for null in (False, True):
        for ab in list(CELLS) + ([] if null else ["LAMBDA-B0", "LAMBDA-B1"]):
            c = cell(ctx, ab, null)
            for e in PRED_EST:
                pr = ctx.diag(c, f"pred__{e}")
                m = ctx.m(c, e)
                o23.append({"cell": ab, "gamma_W": c["gamma_W"], "estimator": e, "observed_bias": m["bias"],
                            "observed_bias_mcse": m["bias_mcse"], "predicted": pr["mean"] if pr else None,
                            "predicted_mcse": pr["mcse"] if pr else None, "predicted_n": pr["n"] if pr else 0,
                            "ratio_observed_to_predicted": (m["bias"] / pr["mean"]) if pr and pr["mean"] else None,
                            "same_sign": (np.sign(m["bias"]) == np.sign(pr["mean"])) if pr and pr["mean"] is not None else None})
    f3 = F.write_csv(os.path.join(out, "O2.3_observed_vs_predicted.csv"), o23)
    # O2.4
    o24 = []
    for g in (0.15, 0.0):
        for e in ["E-2", "E-6", "E-8", "E-9", "E-12a", "E-12b", "E-4", "E-5", "E-12c"]:
            for B in ("B0", "B1"):
                m1, m0 = get(f"A1{B}", g, e), get(f"A0{B}", g, e)
                d = m1["bias"] - m0["bias"]
                se = math.hypot(m1["bias_mcse"], m0["bias_mcse"])
                o24.append({"gamma_W": g, "estimator": e, "B": B, "diff_A1_minus_A0": d, "mcse": se,
                            "within_3_mcse": abs(d) <= 3 * se})
    f4 = F.write_csv(os.path.join(out, "O2.4_design_displacement.csv"), o24)
    # O2.5
    o25 = ds_table(ctx)
    f5 = F.write_csv(os.path.join(out, "O2.5_D_s_by_stratum.csv"), o25)
    F.dump_json(os.path.join(out, "O2.2_interaction_contrast.json"), o22)
    figure(ctx, reg, rows, o23)
    register(reg, "Experiment 2 (O2.1-O2.5)", ctx.sel("X2"), 5000, "per cell; Delta from four independent cells",
             [f1, f2, f3, f4, f5])
    return {"H": hypotheses(get, o22, o23, o24, o25), "o22": o22}


def hypotheses(get, o22, o23, o24, o25):
    H = []
    e5 = {ab: get(ab, 0.15, "E-5") for ab in CELLS}
    i_ok = all(abs(e5[ab]["bias"]) <= 3 * e5[ab]["bias_mcse"] for ab in ("A0B0", "A0B1"))
    ii_ok = abs(e5["A1B1"]["bias"]) >= 3 * e5["A1B1"]["bias_mcse"]
    material = [ab for ab in ("A0B0", "A0B1") if abs(e5[ab]["bias"]) >= 0.02 and abs(e5[ab]["bias"]) > 3 * e5[ab]["bias_mcse"]]
    sec = {ab: (get(ab, 0.0, "E-5")["bias"], get(ab, 0.0, "E-5")["bias_mcse"]) for ab in CELLS}
    H.append(dict(id="H2.1", experiment="2", outcome="REFUTED" if material else ("SUPPORTED" if i_ok and ii_ok else "NOT SUPPORTED"),
                  status="(i) PROSPECTIVE; (ii) CONFIRMATORY RE-ESTIMATE", cells="X2 2x2, gamma_W 0.15; E-5",
                  evidence=dict(clause_i=i_ok, clause_ii=ii_ok, materially_displaced_uniform=material,
                                bias={ab: (e5[ab]["bias"], e5[ab]["bias_mcse"]) for ab in CELLS},
                                secondary_null_cells=sec), rule="analysis plan H, H2.1"))
    d = o22["E-5|g=0.15"]
    H.append(dict(id="H2.1b", experiment="2", outcome="SUPPORTED" if abs(d["Delta"]) >= 3 * d["mcse"] else "NOT SUPPORTED",
                  status="PROSPECTIVE (A0 cells never run)", cells="X2 2x2, gamma_W 0.15; E-5",
                  evidence=dict(Delta=d["Delta"], mcse=d["mcse"], secondary_null=o22["E-5|g=0.0"],
                                note="a null Delta is not refuting (protocol 4.3): lambda1 channel dominates"),
                  rule="analysis plan H, H2.1b"))
    cv = {ab: e5[ab]["coverage"] for ab in CELLS}
    ok22 = cv["A0B0"] >= 0.940 and cv["A0B1"] >= 0.940 and cv["A1B1"] < 0.920
    a1b0_ds = next((r for r in o25 if r["cell"].startswith("A1B0|g=0.15") and r["rule"] == "u"), None)
    H.append(dict(id="H2.2", experiment="2", outcome="SUPPORTED" if ok22 else "NOT SUPPORTED",
                  status="uniform cells PROSPECTIVE; (A1,B1) CONFIRMATORY", cells="X2 2x2, gamma_W 0.15; E-5",
                  evidence=dict(coverage={ab: (e5[ab]["coverage"], e5[ab]["coverage_mcse"]) for ab in CELLS},
                                A1B0_derived_from_stored_D_s=a1b0_ds), rule="analysis plan H, H2.2"))
    p = next(r for r in o23 if r["cell"] == "A1B1" and r["gamma_W"] == 0.15 and r["estimator"] == "E-5")
    H.append(dict(id="H2.3", experiment="2", outcome="SUPPORTED" if p["same_sign"] else "NOT SUPPORTED",
                  status="CONFIRMATORY RE-ESTIMATE", cells="X2 (A1,B1), gamma_W 0.15; E-5",
                  evidence=dict(observed=(p["observed_bias"], p["observed_bias_mcse"]),
                                predicted=(p["predicted"], p["predicted_mcse"]), ratio=p["ratio_observed_to_predicted"],
                                magnitude="REPORTED: no threshold pre-specified; disagreement in magnitude is not a refutation"),
                  rule="analysis plan H, H2.3 (sign decides; magnitude reported)"))
    for hid, ests, st in (("H2.4", ["E-2", "E-6", "E-8", "E-9"], "CONFIRMATORY RE-ESTIMATE (A1 cells); A0 cells PROSPECTIVE"),
                          ("H2.4b", ["E-12a", "E-12b"], "A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5)")):
        rel = [r for r in o24 if r["gamma_W"] == 0.15 and r["estimator"] in ests]
        bad = [r for r in rel if not r["within_3_mcse"]]
        sec = [r for r in o24 if r["gamma_W"] == 0.0 and r["estimator"] in ests and not r["within_3_mcse"]]
        H.append(dict(id=hid, experiment="2", outcome="REFUTED" if bad else "SUPPORTED", status=st,
                      cells="X2 2x2, gamma_W 0.15; " + ", ".join(ests),
                      evidence=dict(table=[(r["estimator"], r["B"], r["diff_A1_minus_A0"], r["mcse"]) for r in rel],
                                    outside_3_mcse=[(r["estimator"], r["B"]) for r in bad],
                                    secondary_null_outside=[(r["estimator"], r["B"]) for r in sec],
                                    E4_reported_separately=[(r["B"], r["diff_A1_minus_A0"], r["mcse"]) for r in o24
                                                            if r["gamma_W"] == 0.15 and r["estimator"] == "E-4"]),
                      rule=f"analysis plan H, {hid}"))
    c = {ab: get(ab, 0.15, "E-12c") for ab in CELLS}
    unif_ok = all(abs(c[ab]["bias"]) <= 3 * c[ab]["bias_mcse"] for ab in ("A0B0", "A0B1"))
    e5_disp = [ab for ab in ("A1B0", "A1B1") if abs(e5[ab]["bias"]) >= 3 * e5[ab]["bias_mcse"]]
    follow = all(abs(c[ab]["bias"]) >= 3 * c[ab]["bias_mcse"] for ab in e5_disp)
    refute = [ab for ab in e5_disp if abs(c[ab]["bias"]) <= 3 * c[ab]["bias_mcse"]]
    lam = {ab: (get(ab, 0.15, "E-12c")["bias"], get(ab, 0.15, "E-12c")["bias_mcse"], get(ab, 0.15, "E-5")["bias"],
                get(ab, 0.15, "E-5")["bias_mcse"]) for ab in ("LAMBDA-B0", "LAMBDA-B1")}
    H.append(dict(id="H2.5", experiment="2", outcome="REFUTED" if refute else ("SUPPORTED" if unif_ok and follow else "NOT SUPPORTED"),
                  status="A0 cells PROSPECTIVE; A1 cells CONFIRMATORY (Experiment 5)", cells="X2 2x2, gamma_W 0.15; E-12c vs E-5",
                  evidence=dict(E12c={ab: (c[ab]["bias"], c[ab]["bias_mcse"]) for ab in CELLS}, E5_displaced_cells=e5_disp,
                                centered_where_E5_displaced=refute, secondary_E2_LAMBDA=lam), rule="analysis plan H, H2.5"))
    return H


def figure(ctx, reg, rows, o23):
    S.setup()
    labs = list(CELLS) + ["LAMBDA-B0", "LAMBDA-B1"]
    ests = ["E-5", "E-12c", "E-4", "E-12a", "E-12b", "E-6", "E-2"]
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 3.8), gridspec_kw={"width_ratios": [1.6, 1]})
    ax = axes[0]
    data = []
    for k, e in enumerate(ests):
        dx = 0.09 * (k - (len(ests) - 1) / 2)
        y = [next(r for r in rows if r["cell"] == ab and r["gamma_W"] == 0.15 and r["estimator"] == e) for ab in labs]
        ax.errorbar(np.arange(len(labs)) + dx, [r["bias"] for r in y], yerr=[1.96 * r["bias_mcse"] for r in y],
                    capsize=0, elinewidth=0.8, label=F.lab(e), **S.est_kw(e, line=False))
        data += [{"panel": "a", "cell": ab, "estimator": e, "bias": r["bias"], "bias_mcse": r["bias_mcse"]} for ab, r in zip(labs, y)]
    ax.axhline(0, color=S.INK2, lw=0.7)
    ax.axvline(3.5, color=GRID_SEP, lw=0.8)
    ax.set_xticks(range(len(labs)))
    ax.set_xticklabels(["A0B0\nuniform, tau 0", "A0B1\nuniform, tau .30", "A1B0\nunequal, tau 0", "A1B1\nunequal, tau .30",
                        "E2-LAMBDA\ntau 0", "E2-LAMBDA\ntau .30"], fontsize=7)
    ax.grid(axis="x", visible=False)
    ax.set_ylabel("bias (gamma_W 0.15)")
    ax.set_title("a. Bias by design cell (categorical; not joined), bars ± 1.96 MCSE", fontsize=8, loc="left")
    ax.legend(handles=S.proxies(ests, F.lab, line=False), fontsize=6.8, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.2))
    ax = axes[1]
    lo, hi = 0.0, 0.0
    for e in ["E-4", "E-5", "E-12c", "E-6", "E-12a", "E-12b"]:
        pts = [r for r in o23 if r["estimator"] == e and r["predicted"] is not None]
        xs = [r["predicted"] for r in pts]; ys = [r["observed_bias"] for r in pts]
        ax.plot(xs, ys, label=F.lab(e), **S.est_kw(e, line=False))
        lo, hi = min([lo] + xs + ys), max([hi] + xs + ys)
        data += [{"panel": "b", "cell": r["cell"], "gamma_W": r["gamma_W"], "estimator": e, "predicted": r["predicted"],
                  "observed_bias": r["observed_bias"]} for r in pts]
    pad = 0.05 * (hi - lo + 1e-9)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], color=S.INK2, lw=0.8, ls=(0, (4, 3)), label="observed = predicted")
    ax.set_xlabel("predicted selected-mixture displacement (F10a)")
    ax.set_ylabel("observed bias")
    ax.set_title("b. Observed vs predicted, all X2 cells", fontsize=8, loc="left")
    ax.legend(fontsize=6.5, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.2))
    fig.suptitle("Experiment 2. Validation design x slope heterogeneity (R 5,000 per cell)", fontsize=9)
    fig.tight_layout()
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, "FigureX2_design_heterogeneity.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, "FigureX2_design_heterogeneity_data.csv"), data)
    register(reg, "Figure X2", ctx.sel("X2"), 5000, "per cell", [p, fc])


GRID_SEP = "#bdbcb6"
