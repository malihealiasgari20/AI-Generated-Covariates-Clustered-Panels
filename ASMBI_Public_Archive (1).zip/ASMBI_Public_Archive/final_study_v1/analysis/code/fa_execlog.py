"""Consolidated FINAL_V1 execution log (record 10.4): seal, gates, amendment A10, production run,
interruption and recomputation, close-out, analysis steps, QA. Compiled from the logs and records in
the package; writes Final_Study_v1/EXECUTION_LOG.txt."""
import collections, json, os, sys

sys.dont_write_bytecode = True
STUDY = "/mnt/user-data/outputs/Final_Study_v1"


def rd(p):
    return open(os.path.join(STUDY, p)).read()


def sha_line(p):
    t = rd(p).split()
    return t[0], " ".join(t[2:]) if len(t) > 2 else ""


def main():
    L = []
    a = L.append
    a("FINAL_V1 EXECUTION LOG")
    a("=" * 100)
    a("Study: Stress-Testing Inference with AI-Generated Covariates in Clustered Panels (Nejatbakhsh & Aliasgari)")
    a("All times UTC. Compiled from the records, logs and manifests inside Final_Study_v1/.")
    a("")
    a("1. SEALED DESIGN")
    for x in rd('FINAL_V1_FROZEN.sha256').splitlines():
        a(f"  {x.strip()}")
    a("  " + rd("FINAL_V1_SEAL_RECORD.txt").splitlines()[4].strip())
    import hashlib
    for v in ("1.5", "1.6", "1.7", "1.8", "1.9", "1.10"):
        p = f"protocol/ASMBI_Post_Primary_Extension_Protocol_v{v}.sha256"
        t = f"protocol/ASMBI_Post_Primary_Extension_Protocol_v{v}.txt"
        if os.path.exists(os.path.join(STUDY, p)):
            a(f"  protocol v{v}: " + " | ".join(x.strip() for x in rd(p).splitlines()))
        elif os.path.exists(os.path.join(STUDY, t)):
            h = hashlib.sha256(open(os.path.join(STUDY, t), "rb").read()).hexdigest()
            a(f"  protocol v{v}: {h}  {os.path.basename(t)} (listed in the package manifests)")
    a("")
    a("2. CODE (Step 5)")
    a("  code/README_CODE.txt; MANIFEST_SHA256_CODE.txt; code fingerprint 2d263942e63e44db60a02d6041aba51b3fad0a55c94a0941c45ee31e1d909cbd")
    a("")
    a("3. PRE-PERFORMANCE GATES (Step 6)")
    g = json.load(open(os.path.join(STUDY, "gates", "FINAL_V1_GATE_RECORD.json")))
    a(f"  gate record: {' | '.join(x.strip() for x in rd('gates/FINAL_V1_GATE_RECORD.sha256').splitlines())}")
    a(f"  gates: {g.get('gates')}; e10_status: {g.get('e10_status')}")
    a(f"  theta_0 map: {' | '.join(x.strip() for x in rd('gates/FINAL_V1_THETA0_MAP.sha256').splitlines())}")
    a("  gate-script corrections (implementation only; GATE_RUN_LOG.txt): G-B module registration before loading; "
      "G-D configuration matching to 1e-12; G-C supplementary failure-path section. No FINAL_V1 code or design change.")
    a("  amendment A10 (protocol v1.10): E-10 ABSENT (A10.1); clarification of record 0.6(c) (A10.2); theta_0 map (A10.3).")
    a("")
    a("4. PRODUCTION RUN (Step 7)")
    ev = [json.loads(l) for l in open(os.path.join(STUDY, "run", "RUN_LOG.jsonl"))]
    c = collections.Counter(x["event"] for x in ev)
    a(f"  events: {dict(c)}")
    for x in ev:
        if x["event"] in ("RUN_START", "PLAN", "EXTERNAL_INTERRUPTION", "INTERRUPTED_RECOMPUTE", "BUDGET_STOP", "RUN_END",
                          "CONFIG_ERROR", "REFUSED"):
            keep = {k: v for k, v in x.items() if k in ("event", "utc", "complete", "pending", "first_pending", "cause",
                                                        "in_flight", "action", "config", "quarantined", "note", "remaining",
                                                        "all_complete", "selected", "elapsed_s", "workers", "budget_min")}
            if x["event"] == "RUN_START":
                keep["platform"] = x["environment"]["platform"]
                keep["numpy/scipy/python"] = (x["environment"]["numpy"], x["environment"]["scipy"], x["environment"]["python"])
            a("  " + json.dumps(keep, default=str))
    done = [x for x in ev if x["event"] == "CONFIG_DONE"]
    a(f"  configurations completed: {len(set(d['config'] for d in done))}; first CONFIG_DONE {done[0]['utc']}; last {done[-1]['utc']}")
    p = os.path.join(STUDY, "run", "EXECUTION_SUMMARY.txt")
    if os.path.exists(p):
        a("  close-out (run/EXECUTION_SUMMARY.txt):")
        for l in open(p).read().splitlines()[2:6]:
            a("    " + l)
    a("")
    a("5. ANALYSIS (Step 8)")
    import hashlib
    pl = os.path.join(STUDY, "analysis", "ANALYSIS_OPERATIONALIZATIONS.txt")
    a(f"  analysis plan: {hashlib.sha256(open(pl, 'rb').read()).hexdigest()}  analysis/ANALYSIS_OPERATIONALIZATIONS.txt "
      f"(written during the run, before any performance quantity; hash logged at every analysis step)")
    p = os.path.join(STUDY, "analysis", "ANALYSIS_LOG.jsonl")
    if os.path.exists(p):
        for l in open(p):
            x = json.loads(l)
            keep = {k: v for k, v in x.items() if k in ("utc", "event", "tasks", "pairs", "workers", "elapsed_s", "plan_sha256",
                                                        "outputs", "hypotheses", "configurations", "incomplete_or_mismatched",
                                                        "module_cells", "boot_B", "note", "status")}
            a("  " + json.dumps(keep, default=str))
    for q in ("qa/ANALYSIS_VERIFICATION.json", "qa/REPRODUCIBILITY_SPOTCHECK.json"):
        pq = os.path.join(STUDY, "analysis", q)
        if os.path.exists(pq):
            st = json.load(open(pq)).get("status")
            a(f"  QA {q}: {st}")
    pq = os.path.join(STUDY, "analysis", "qa", "FIGURE_QA.txt")
    if os.path.exists(pq):
        a("  QA analysis/qa/FIGURE_QA.txt: every figure inspected visually (see file)")
    a("")
    a("6. MANIFEST AND ARCHIVE")
    a("  MANIFEST_SHA256_FINAL.txt lists every file of Final_Study_v1/ except itself; its SHA-256 is in")
    a("  MANIFEST_SHA256_FINAL.sha256. The archive Final_Study_v1_FINAL.zip (outputs folder) holds the whole package;")
    a("  its SHA-256 is in Final_Study_v1_FINAL.zip.sha256.")
    open(os.path.join(STUDY, "EXECUTION_LOG.txt"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
