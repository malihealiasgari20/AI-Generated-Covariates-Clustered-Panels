"""Reproducibility spot-check after completion (QA; no performance quantity): recompute replications
r = 0..K-1 of selected production configurations with the production code and seeds, in memory only,
and compare every stored replication-level field bit for bit with the checkpoints. Configurations are
chosen from before and after the logged container restart (environment kernel changed). Writes
<analysis>/qa/REPRODUCIBILITY_SPOTCHECK.json."""
import json, os, sys, time

sys.dont_write_bytecode = True
STUDY = "/mnt/user-data/outputs/Final_Study_v1"
sys.path.insert(0, os.path.join(STUDY, "code"))
import fv1.env as env  # noqa: E402
import numpy as np  # noqa: E402
from fv1 import compute, registry, seeds, store, theta0 as T0  # noqa: E402

K = int(os.environ.get("FV1_REPRO_K", "20"))
NAMES = sys.argv[1:] or ["C001", "C046", "C047", "C100", "C149"]
configs, _ = registry.load(STUDY)
rec = json.load(open(os.path.join(STUDY, "gates", "FINAL_V1_GATE_RECORD.json")))
tm = rec["theta0_map"]
th = T0.lookup(T0.load_production_map(os.path.join(STUDY, tm["path"]) if not os.path.isabs(tm["path"]) else tm["path"],
                                      tm["sha256"]), configs, require_all=True)
out = {"K": K, "configs": {}}
ok_all = True
for nm in NAMES:
    c = next(x for x in configs if x.name == nm)
    t0 = time.time()
    arrays, info = compute.run_configuration(c, seeds.PRODUCTION, th[c.index], False, cap=K)
    p = store.paths(os.path.join(STUDY, "run"), nm)
    z = np.load(p["npz"])
    res = {}
    for k in ("estimate", "se", "crit", "lo", "hi", "cover", "reject", "fail", "bind"):
        new_r, new_e, new_v = arrays["rows_r"], arrays["rows_est"], arrays[f"rows_{k}"]
        old_r, old_e, old_v = z["rows_r"], z["rows_est"], z[f"rows_{k}"]
        mism = 0
        for e in np.unique(new_e):
            a = new_v[(new_e == e)]
            b = old_v[(old_e == e) & (old_r < K)]
            if a.shape != b.shape or not np.array_equal(a, b, equal_nan=True):
                mism += 1
        res[k] = mism
    dk = [k for k in arrays if k.startswith("diag__") and k != "diag__diag_runtime"]
    dmis = [k for k in dk if not np.array_equal(arrays[k][:K], z[k][:K], equal_nan=True)]
    meta = json.loads(str(z["meta_run"]))
    same = all(v == 0 for v in res.values()) and not dmis
    ok_all &= same
    out["configs"][nm] = {"identical": same, "field_mismatches_by_estimator": res, "diag_mismatches": dmis,
                          "stored_environment_platform": meta["environment"]["platform"],
                          "stored_start_utc": meta["start_utc"], "seconds": round(time.time() - t0, 2)}
out["current_environment"] = env.environment_record()
out["status"] = "PASS" if ok_all else "FAIL"
os.makedirs(os.path.join(STUDY, "analysis", "qa"), exist_ok=True)
json.dump(out, open(os.path.join(STUDY, "analysis", "qa", "REPRODUCIBILITY_SPOTCHECK.json"), "w"), indent=1, default=str)
print(json.dumps({k: (v if k != "current_environment" else "...") for k, v in out.items()}, indent=1, default=str)[:3000])
sys.exit(0 if ok_all else 1)
