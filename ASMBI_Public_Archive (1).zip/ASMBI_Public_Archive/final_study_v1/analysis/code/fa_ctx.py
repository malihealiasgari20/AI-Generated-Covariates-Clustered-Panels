"""Analysis context: cell map, phase-1 results and bootstrap draws, raw configurations on demand,
and the record-6.6 (D11) descriptive classifications."""
import json, math, os
from collections import OrderedDict

import numpy as np

import fa_cells
import fa_common as F
import fa_load
import fa_phase1

NAN = float("nan")


def cov_band(c):
    if c is None or not math.isfinite(c):
        return "NA"
    if c < 0.920:
        return "material undercoverage"
    if c < 0.940:
        return "mild undercoverage"
    if c <= 0.960:
        return "near-nominal"
    return "conservative"


def centering(b, m):
    if b is None or m is None or not (math.isfinite(b) and math.isfinite(m)):
        return "NA"
    if abs(b) <= 3 * m:
        return "centered"
    if abs(b) < 0.02:
        return "small but detectable displacement"
    return "materially displaced"


def size_class(p, m):
    if p is None or m is None or not (math.isfinite(p) and math.isfinite(m)):
        return "NA"
    if p > 0.05 + 3 * m:
        return "inflated"
    if p < 0.05 - 3 * m:
        return "conservative"
    return "within MC error of 0.05"


class Ctx:
    def __init__(self):
        self.cells, self.configs, self.prov = fa_cells.build()
        self.by_key = {c["key"]: c for c in self.cells}
        self.cfg_by_name = {c.name: c for c in self.configs}
        self._p1, self._npz, self._raw = {}, {}, OrderedDict()

    # ----------------------------------------------------------------- selection
    def sel(self, module, **kw):
        out = []
        for c in self.cells:
            if c["module"] != module:
                continue
            if all((abs(c.get(k) - v) < 1e-9) if isinstance(v, float) and isinstance(c.get(k), float) else c.get(k) == v
                   for k, v in kw.items()):
                out.append(c)
        return out

    def one(self, module, **kw):
        s = self.sel(module, **kw)
        assert len(s) == 1, (module, kw, [c["key"] for c in s])
        return s[0]

    # ----------------------------------------------------------------- phase-1 results
    def p1(self, cell):
        k = (cell["config"], cell["R"])
        if k not in self._p1:
            pj, pn = fa_phase1.out_paths(*k)
            with open(pj) as fh:
                self._p1[k] = json.load(fh)
        return self._p1[k]

    def m(self, cell, est):
        """Every phase-1 quantity of one estimator in one module cell (dict), or None if not computed."""
        return self.p1(cell)["estimators"].get(est)

    def pair(self, cell, a, b):
        return self.p1(cell)["pairs"].get(f"{a}|{b}")

    def theta0(self, cell):
        return self.p1(cell)["theta0"]

    def R_used(self, cell):
        return self.p1(cell)["R_used"]

    def draws(self, cell, key):
        k = (cell["config"], cell["R"])
        if k not in self._npz:
            self._npz[k] = np.load(fa_phase1.out_paths(*k)[1])
        return np.asarray(self._npz[k][key], dtype=np.float64)

    def d(self, cell, est, stat):
        return self.draws(cell, f"{est}|{stat}")

    def diag(self, cell, key):
        return self.p1(cell)["diag"].get(key)

    # ----------------------------------------------------------------- raw arrays
    def raw(self, cell_or_name):
        name = cell_or_name if isinstance(cell_or_name, str) else cell_or_name["config"]
        if name not in self._raw:
            cfg = self.cfg_by_name[name]
            self._raw[name] = fa_load.Config(name, cfg.theta0_key)
            while len(self._raw) > 16:
                self._raw.popitem(last=False)
        else:
            self._raw.move_to_end(name)
        return self._raw[name]

    def arrays(self, cell, est):
        rc = self.raw(cell)
        return rc.arrays(est, self.R_used(cell))

    # ----------------------------------------------------------------- D11 classifications
    def classes(self, cell, est):
        m = self.m(cell, est)
        if m is None:
            return {}
        out = {"coverage_band": cov_band(m.get("coverage")),
               "centering": centering(m.get("bias"), m.get("bias_mcse"))}
        if cell["null"]:
            out["size"] = size_class(m.get("rejection"), m.get("rejection_mcse"))
        return out
