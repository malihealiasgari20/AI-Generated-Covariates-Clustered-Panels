"""FINAL_V1 run close-out: completion, integrity and run health only (record D13; Step-7 instruction).

Reads from each checkpoint ONLY: the sidecar hash, meta_det, meta_run, rows_r, rows_est and rows_fail.
No estimate, SE, interval, coverage, rejection or diagnostic array is opened, and no performance quantity
(bias, coverage, RMSE, Type I error, power, rankings, ratios, hypothesis outcomes) is computed.

Writes run/EXECUTION_SUMMARY.txt and run/closeout_report.json; Final_Study_v1/MANIFEST_SHA256_RUN.txt is
written separately once this check passes.
"""
import collections, json, os, sys

sys.dont_write_bytecode = True
STUDY = "/mnt/user-data/outputs/Final_Study_v1"
CODE = os.path.join(STUDY, "code")
sys.path.insert(0, CODE)
import fv1.env as env  # noqa: E402
import numpy as np  # noqa: E402
from fv1 import estimators as E, runner, store  # noqa: E402

RUN = os.path.join(STUDY, "run")


class A:
    study_root, out, cap, inject, configs, namespace, no_e10, mode = STUDY, None, None, None, None, None, False, "production"
    gate_record = os.path.join(STUDY, "gates", "FINAL_V1_GATE_RECORD.json")


S = runner._settings(A())                     # same checks as the production start (no computation)
cfgs = S["configs"]
problems, rows_total = [], 0
fails = collections.Counter()
per_cfg = []
envs = collections.Counter()
for c in cfgs:
    st = store.status(RUN, c.name, runner._expect(S, c))
    if st != "complete":
        problems.append(f"{c.name}: {st}")
        continue
    p = store.paths(RUN, c.name)
    sha, digest = store.read_sidecar(p["sha"])
    with np.load(p["npz"]) as z:                          # health and structure fields only
        meta = json.loads(str(z["meta_det"])); mrun = json.loads(str(z["meta_run"]))
        r, e, f = z["rows_r"], z["rows_est"], z["rows_fail"]
    R = c.R
    exp_rows = R["FULL"] * 16 + (R["X3"] * 4 if not R["FULL"] else 0) + (R["D"] if not R["FULL"] else 0)
    pairs = len(set(zip(r.tolist(), e.tolist())))
    if r.size != exp_rows or pairs != exp_rows:
        problems.append(f"{c.name}: {r.size} rows / {pairs} unique (r, estimator) pairs, expected {exp_rows}")
    if np.any(e == E.EST_INDEX["E-10"]):
        problems.append(f"{c.name}: E-10 rows present although E-10 is ABSENT")
    if meta["namespace"] != {"panel": "FINAL_V1_PANEL", "folds": "FINAL_V1_FOLDS", "oos": "FINAL_V1_OOS"} or \
            meta["e10"] != "ABSENT" or meta["code_fingerprint"] != S["fingerprint"]:
        problems.append(f"{c.name}: metadata does not match the production run")
    rows_total += r.size
    for ei, code in zip(e[f != 0], f[f != 0]):
        fails[(E.EST_NAMES[ei], int(code))] += 1
    envs[(mrun["environment"]["numpy"], mrun["environment"]["scipy"], mrun["environment"]["python"])] += 1
    per_cfg.append({"config": c.name, "panel_reps": c.R_panel, "rows": int(r.size), "wall_s": round(mrun["wall_s"], 1),
                    "sha256": sha, "content_digest": digest, "start_utc": mrun["start_utc"], "end_utc": mrun["end_utc"]})

ev = [json.loads(l) for l in open(os.path.join(RUN, "RUN_LOG.jsonl"))]
evc = collections.Counter(x["event"] for x in ev)
done = [x["config"] for x in ev if x["event"] == "CONFIG_DONE"]
interrupts = [x for x in ev if x["event"] in ("EXTERNAL_INTERRUPTION", "INTERRUPTED_RECOMPUTE")]
bad_events = [x for x in ev if x["event"] in ("CONFIG_ERROR", "REFUSED")]
dup = [k for k, v in collections.Counter(done).items() if v > 1]
quarantined = sorted(os.listdir(os.path.join(RUN, "quarantine"))) if os.path.isdir(os.path.join(RUN, "quarantine")) else []
leftover = [f for f in os.listdir(os.path.join(RUN, "raw")) if not f.endswith((".npz", ".sha256"))]
if bad_events:
    problems.append(f"log has {len(bad_events)} error events")
if dup:
    problems.append(f"configurations completed twice: {dup}")
if leftover:
    problems.append(f"leftover marker or partial files: {leftover}")
malfunction = {k: v for k, v in fails.items() if k[1] in (E.NONFINITE, E.EXCEPTION)}
wall = sum(x["wall_s"] for x in per_cfg)
first = min(x["start_utc"] for x in per_cfg); last = max(x["end_utc"] for x in per_cfg)
ok = not problems and len(per_cfg) == 149
report = {"status": "COMPLETE" if ok else "PROBLEMS", "configurations_complete": len(per_cfg),
          "panel_replications": sum(x["panel_reps"] for x in per_cfg), "rows": rows_total,
          "worker_wall_hours": round(wall / 3600, 3), "first_start_utc": first, "last_end_utc": last,
          "events": dict(evc), "interruptions": interrupts, "quarantined_files": quarantined,
          "environments": {"|".join(k): v for k, v in envs.items()},
          "failure_counts": {f"{k[0]}|{E.FAIL_NAMES[k[1]]}": v for k, v in sorted(fails.items())},
          "possible_malfunction_codes": {f"{k[0]}|{E.FAIL_NAMES[k[1]]}": v for k, v in malfunction.items()},
          "problems": problems, "per_configuration": per_cfg}
json.dump(report, open(os.path.join(RUN, "closeout_report.json"), "w"), indent=1, sort_keys=True)

L = ["FINAL_V1 EXECUTION SUMMARY (run health only; no performance quantity computed or inspected)", "=" * 96,
     f"status: {report['status']}  -- {len(per_cfg)}/149 configurations complete, "
     f"{report['panel_replications']:,} panel replications, {rows_total:,} estimator rows (E-10 ABSENT)",
     f"first configuration started {first}; last finished {last}; worker wall time {wall / 3600:.2f} h",
     f"environment(s): {report['environments']}",
     f"log events: {dict(evc)}", "", "interruptions and recomputations:"]
L += [f"  {x['utc']}  {x['event']}  " + json.dumps({k: v for k, v in x.items() if k not in ('utc', 'event')}) for x in interrupts] or ["  none"]
L += ["", "failure counts by estimator and type (eligibility rules, empty post-strata, singular systems are design-",
      "driven; non-finite and exception codes would indicate a software malfunction):"]
L += [f"  {k[0]:<10} {E.FAIL_NAMES[k[1]]:<56} {v:>8,}" for k, v in sorted(fails.items())]
L += ["", f"possible-malfunction codes (non-finite / exception): {report['possible_malfunction_codes'] or 'none'}",
      f"problems: {problems or 'none'}"]
open(os.path.join(RUN, "EXECUTION_SUMMARY.txt"), "w").write("\n".join(L) + "\n")
print("\n".join(L))
sys.exit(0 if ok else 1)
