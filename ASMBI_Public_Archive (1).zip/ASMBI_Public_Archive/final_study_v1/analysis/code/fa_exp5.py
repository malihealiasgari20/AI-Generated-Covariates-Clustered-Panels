"""Experiment-5 re-evaluation on the 32 configurations (record 7.5; protocol 6A.5; plan K):
H5.1-H5.3 with their frozen rules, the Corollary-1 contrast, H5.4-H5.6 (reported), and the
Experiment-5 classification under the same rules (from the sealed Experiment-5 cell files)."""
import json, math, os

import numpy as np

import fa_common as F
import fa_style as S
from fa_main import register, vm

plt = S.plt
E5_DIR = "/mnt/user-data/outputs/Stage1_Experiment5"
E5_FILES = {"e5_primary_cells.json": "86e30a5e74d89711823b5f11814f21b70035d119bd1e22584acf78222e062edc",
            "e5_stress_cells.json": "17c893fbd45723fc9454d6227027ef8360aac9b2dcfb0562fa7ea9ada45c1bb8"}
E5_NAME = {"E-2": "E2", "E-4": "E4", "E-5": "E5", "E-6": "E6", "E-6H": "E6H", "E-8": "E8", "E-9": "E9",
           "E-12a": "E12a", "E-12b": "E12b", "E-12c": "E12c"}


def cells32(ctx):
    P = ctx.sel("P")
    Sx = [c for c in ctx.sel("S") if c["condition"] in ("tau=0", "tau=0.30", "N=250", "N=600")]
    assert len(P) == 24 and len(Sx) == 8
    return P + Sx


def rules(get_m, cells, tau30, tau30_null, n250, n600, n250_0, n600_0, pair_cov):
    """The plan-K rules on any source of per-cell metrics. get_m(cell, est) -> dict with bias, bias_mcse,
    coverage, coverage_mcse."""
    H = {}
    disp = {}
    for e in ("E-12a", "E-12b"):
        bad = []
        for c in cells:
            m = get_m(c, e)
            if abs(m["bias"]) > max(3 * m["bias_mcse"], 0.02):
                bad.append(c)
        disp[e] = bad
    cov_nn = {e: float(np.median([get_m(c, e)["coverage"] for c in cells if not _null(c)])) for e in ("E-12a", "E-12b")}
    cov_all = {e: float(np.median([get_m(c, e)["coverage"] for c in cells])) for e in ("E-12a", "E-12b")}
    ref = [e for e in ("E-12a", "E-12b") if abs(get_m(tau30, e)["bias"]) > max(3 * get_m(tau30, e)["bias_mcse"], 0.02)]
    sec = [e for e in ("E-12a", "E-12b") if abs(get_m(tau30_null, e)["bias"]) > max(3 * get_m(tau30_null, e)["bias_mcse"], 0.02)]
    ok = not disp["E-12a"] and not disp["E-12b"] and cov_nn["E-12a"] >= 0.93 and cov_nn["E-12b"] >= 0.93
    H["H5.1"] = dict(outcome="REFUTED" if ref else ("SUPPORTED" if ok else "NOT SUPPORTED"),
                     displaced_cells={e: [_lab(c) for c in v] for e, v in disp.items()},
                     median_coverage_nonnull=cov_nn, median_coverage_all32=cov_all, refuting=ref,
                     secondary_tau030_null_displaced=sec)
    c, e5 = get_m(tau30, "E-12c"), get_m(tau30, "E-5")
    det = abs(c["bias"]) >= 3 * c["bias_mcse"]
    same = np.sign(c["bias"]) == np.sign(e5["bias"])
    H["H5.2"] = dict(outcome="REFUTED" if not det else ("SUPPORTED" if same else "NOT SUPPORTED"),
                     E12c=(c["bias"], c["bias_mcse"]), E5=(e5["bias"], e5["bias_mcse"]), same_sign=bool(same),
                     E12c_abs_bias_ge_0_02=abs(c["bias"]) >= 0.02,
                     secondary_null=(get_m(tau30_null, "E-12c")["bias"], get_m(tau30_null, "E-12c")["bias_mcse"]))
    dec = {}
    for e in ("E-12a", "E-12b", "E-5", "E-12c"):
        a, b = get_m(n250, e), get_m(n600, e)
        d = a["coverage"] - b["coverage"]
        se = math.hypot(a["coverage_mcse"], b["coverage_mcse"])
        a0, b0 = get_m(n250_0, e), get_m(n600_0, e)
        dec[e] = dict(decline=d, mcse=se, beyond_3_mcse=d > 3 * se, cov_N250=a["coverage"], cov_N600=b["coverage"],
                      secondary_null_decline=a0["coverage"] - b0["coverage"],
                      secondary_null_mcse=math.hypot(a0["coverage_mcse"], b0["coverage_mcse"]))
    ok3 = (not dec["E-12a"]["beyond_3_mcse"] and not dec["E-12b"]["beyond_3_mcse"] and dec["E-5"]["beyond_3_mcse"]
           and dec["E-12c"]["beyond_3_mcse"])
    H["H5.3"] = dict(outcome="SUPPORTED" if ok3 else "NOT SUPPORTED", declines=dec)
    if pair_cov is not None:
        cor = {}
        for e in ("E-12a", "E-12b"):
            p250, p600 = pair_cov(n250, "E-5", e), pair_cov(n600, "E-5", e)
            dd = p250["cov_diff"] - p600["cov_diff"]
            cor[f"E-5 minus {e}"] = dict(difference_of_declines=dd,
                                         mcse=math.hypot(p250["cov_diff_mcse"], p600["cov_diff_mcse"]),
                                         n250_paired=(p250["cov_diff"], p250["cov_diff_mcse"], p250["n_intersection"]),
                                         n600_paired=(p600["cov_diff"], p600["cov_diff_mcse"], p600["n_intersection"]))
        H["Corollary-1"] = cor
    return H


def _null(c):
    return c["null"] if isinstance(c, dict) and "null" in c else c.endswith("g=0.0")


def _lab(c):
    return c["key"] if isinstance(c, dict) else c


def e5_previous():
    for fn, h in E5_FILES.items():
        assert F.sha256(os.path.join(E5_DIR, fn)) == h, f"{fn} differs from the sealed Experiment-5 manifest"
    P = json.load(open(os.path.join(E5_DIR, "e5_primary_cells.json")))
    S_ = json.load(open(os.path.join(E5_DIR, "e5_stress_cells.json")))
    allc = {**P, **S_}
    get = lambda c, e: allc[c]["metrics"][E5_NAME[e]]
    cells = list(allc)
    t30 = "N=300|tau=0.3|icc=0.3|rho=0.6|kappa=0.0|g=0.15"
    t30n = "N=300|tau=0.3|icc=0.3|rho=0.6|kappa=0.0|g=0.0"
    n250, n600 = "N=250|tau=0.1|icc=0.3|rho=0.6|kappa=0.0|g=0.15", "N=600|tau=0.1|icc=0.3|rho=0.6|kappa=0.0|g=0.15"
    for k in (t30, t30n, n250, n600):
        assert k in allc, k
    return rules(get, cells, t30, t30n, n250, n600, n250.replace("g=0.15", "g=0.0"), n600.replace("g=0.15", "g=0.0"), None)


def run(ctx, reg):
    out = F.ensure(os.path.join(F.OUT, "experiments", "Exp5_reevaluation"))
    cells = cells32(ctx)
    s = lambda cond, null: ctx.one("S", condition=cond, null=null)
    get = lambda c, e: ctx.m(c, e)
    pair_cov = lambda c, a, b: ctx.pair(c, a, b)
    Hn = rules(get, cells, s("tau=0.30", False), s("tau=0.30", True), s("N=250", False), s("N=600", False),
               s("N=250", True), s("N=600", True), pair_cov)
    Hp = e5_previous()
    rows = []
    for c in cells:
        for e in ("E-2", "E-4", "E-5", "E-6", "E-6H", "E-8", "E-9", "E-12a", "E-12b", "E-12c", "HT-TDS-I", "PS-TDS-I", "HT-TDS-CF"):
            m = ctx.m(c, e)
            r = {"module": c["module"], "cell": c["cell"], "estimator": e, "bias": m["bias"], "bias_mcse": m["bias_mcse"],
                 "coverage": m["coverage"], "coverage_mcse": m["coverage_mcse"], "rmse": m["rmse"],
                 "width_median": m["width_median"], "rejection": m["rejection"], "failure_rate": m["failure_rate"]}
            for ref in ("E-5", "E-12a", "E-6", "E-2"):
                p = ctx.pair(c, e, ref)
                if p:
                    r[f"bias_diff_vs_{ref}"] = p["bias_diff"]
                    r[f"bias_diff_vs_{ref}_mcse"] = p["bias_diff_mcse"]
                    r[f"rmse_ratio_vs_{ref}"] = p["rmse_ratio"]
                    r[f"rmse_ratio_vs_{ref}_bmcse"] = p["rmse_ratio_bmcse"]
            if e in ("E-12a", "E-12b"):
                r["median_width_ratio_vs_E-5"] = m["width_median"] / ctx.m(c, "E-5")["width_median"]
            rows.append(r)
    f1 = F.write_csv(os.path.join(out, "Exp5_32_cells_paired.csv"), rows)
    F.dump_json(os.path.join(out, "H5_FINAL_V1_vs_Experiment5.json"), {"FINAL_V1": Hn, "Experiment5_same_rules": Hp})
    figure(ctx, reg, cells)
    register(reg, "Experiment 5 re-evaluation (H5.1-H5.6)", cells, 5000, "per cell; paired contrasts within cell", [f1])
    H = []
    for hid in ("H5.1", "H5.2", "H5.3"):
        differs = Hn[hid]["outcome"] != Hp[hid]["outcome"]
        H.append(dict(id=hid, experiment="5 (re-evaluation)", outcome=Hn[hid]["outcome"],
                      status="CONFIRMATORY RE-ESTIMATE (all 32 configurations run in Experiment 5)",
                      cells="24 primary + 8 stress (tau 0/0.30, N 250/600)",
                      evidence=dict(FINAL_V1=Hn[hid], Experiment5_same_rule=Hp[hid]["outcome"],
                                    classification_differs_from_Experiment5=differs,
                                    **({"Corollary-1": Hn["Corollary-1"]} if hid == "H5.3" else {})),
                      rule=f"analysis plan K, {hid}"))
    for hid, note in (("H5.4", "RMSE and median-width ratios of E-12a/E-12b against E-5 in every cell (Exp5_32_cells_paired.csv)"),
                      ("H5.5", "RMSE ratio E-12b / E-12a in every cell (cell_level/PAIRED_CONTRASTS_WITHIN_CONFIGURATION.csv)"),
                      ("H5.6", "E-6H against E-6 (pair E-6H|E-6), including sparse validation (supplementary/H4.6_TDS_sparse_validation.csv)")):
        H.append(dict(id=hid, experiment="5 (re-evaluation)", outcome="REPORTED (open question)",
                      status="CONFIRMATORY RE-ESTIMATE", cells="32 cells", evidence={"where": note}, rule="protocol 6A.5"))
    return {"H": H, "FINAL_V1": Hn, "E5": Hp}


def figure(ctx, reg, cells):
    S.setup()
    nn = [c for c in cells if not c["null"]]
    ests = ["E-5", "E-12c", "E-12a", "E-12b", "E-2", "E-6"]
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 5.6), sharex=True)
    data = []
    for k, e in enumerate(ests):
        dx = 0.11 * (k - (len(ests) - 1) / 2)
        x = np.arange(len(nn)) + dx
        m = [ctx.m(c, e) for c in nn]
        axes[0].errorbar(x, [q["bias"] for q in m], yerr=[1.96 * q["bias_mcse"] for q in m], capsize=0, elinewidth=0.8,
                         label=F.lab(e), **S.est_kw(e, line=False, markersize=4))
        axes[1].errorbar(x, [q["coverage"] for q in m], yerr=[1.96 * q["coverage_mcse"] for q in m], capsize=0,
                         elinewidth=0.8, **S.est_kw(e, line=False, markersize=4))
        data += [{"cell": c["key"], "estimator": e, "bias": q["bias"], "bias_mcse": q["bias_mcse"], "coverage": q["coverage"],
                  "coverage_mcse": q["coverage_mcse"]} for c, q in zip(nn, m)]
    axes[0].axhline(0, color=S.INK2, lw=0.7)
    axes[0].axhspan(-0.02, 0.02, color="#ecebe7", lw=0, zorder=0)
    band = 1.959964 * math.sqrt(0.95 * 0.05 / 5000)
    axes[1].axhspan(0.95 - band, 0.95 + band, color="#d9d8d3", lw=0, zorder=0)
    axes[1].axhline(0.95, color=S.INK2, lw=0.7)
    axes[1].axhline(0.92, color=S.INK2, lw=0.7, ls=":")
    labs = []
    for c in nn:
        if c["module"] == "P":
            labs.append(f"ICC {c['icc']:.1f}\nrho {c['rho_e']:.1f}\nk {c['kappa']:.1f}")
        else:
            labs.append(c["condition"].replace("tau=", "tau ").replace("N=", "N "))
    for ax in axes:
        ax.axvline(11.5, color="#bdbcb6", lw=0.8)
        ax.grid(axis="x", visible=False)
    axes[1].set_xticks(range(len(nn)))
    axes[1].set_xticklabels(labs, fontsize=6.3)
    axes[0].set_ylabel("bias")
    axes[1].set_ylabel("coverage")
    axes[0].set_title("a. Bias (12 primary non-null cells | 4 stress cells; categorical, not joined); bars ± 1.96 MCSE",
                      fontsize=8, loc="left")
    axes[1].set_title("b. Coverage of nominal 95% intervals", fontsize=8, loc="left")
    axes[0].legend(handles=S.proxies(ests, F.lab, line=False), ncol=6, fontsize=7, loc="lower left", bbox_to_anchor=(0, 1.08))
    fig.suptitle("Experiment-5 re-evaluation on FINAL_V1 panels (R 5,000 per cell): the 2x2 {fit weighted?} x "
                 "{rectifier design-unbiased?}", fontsize=8.5, y=1.04)
    fig.tight_layout()
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, "FigureX5_exp5_reevaluation.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, "FigureX5_exp5_reevaluation_data.csv"), data)
    register(reg, "Figure X5", nn, 5000, "per cell", [p, fc])
