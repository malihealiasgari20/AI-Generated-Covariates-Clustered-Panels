"""Figure style: the validated reference palette (dataviz skill, light mode), composite encoding
(colour = estimator family or member, plus marker and line style), hairline grids, CSV twins.

Palette check (scripts/validate_palette.js, light mode, adjacent pairs): all hard gates PASS; three
slots sit below 3:1 contrast on the surface, so every figure carries a legend, marker shapes and a
CSV table twin (relief rule). Estimators that share a hue always differ in marker and line style.
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#e4e3df"
SLOT = {"blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a", "yellow": "#eda100", "magenta": "#e87ba4",
        "green": "#008300", "violet": "#6250d6", "red": "#e34948", "gray": "#52514e"}
DIVERGING = ("#1c5cab", "#f0efec", "#c0392f")   # blue pole, neutral midpoint, red pole

STYLE = {
    "E-1": dict(color=SLOT["gray"], marker="o", ls="-"),
    "E-2": dict(color=SLOT["yellow"], marker="D", ls="-"),
    "E-3": dict(color=SLOT["orange"], marker="v", ls=":"),
    "E-4": dict(color=SLOT["orange"], marker="s", ls="--"),
    "E-5": dict(color=SLOT["orange"], marker="o", ls="-"),
    "E-12c": dict(color=SLOT["orange"], marker="X", ls="-."),
    "E-6": dict(color=SLOT["aqua"], marker="^", ls="-"),
    "E-8": dict(color=SLOT["aqua"], marker="v", ls="--", mfc="none"),
    "E-6H": dict(color=SLOT["aqua"], marker="<", ls=":"),
    "E-9": dict(color=SLOT["magenta"], marker="P", ls="-"),
    "E-7": dict(color=SLOT["red"], marker="X", ls="-"),
    "E-12a": dict(color=SLOT["blue"], marker="o", ls="-"),
    "HT-TDS-CF": dict(color=SLOT["blue"], marker="*", ls=":"),
    "E-12b": dict(color=SLOT["violet"], marker="s", ls="-", mfc="none"),
    "HT-TDS-I": dict(color=SLOT["green"], marker="^", ls="-"),
    "PS-TDS-I": dict(color=SLOT["green"], marker="v", ls="--", mfc="none"),
}


def setup():
    plt.rcParams.update({
        "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
        "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5,
        "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
        "axes.edgecolor": INK2, "axes.linewidth": 0.6, "axes.labelcolor": INK, "text.color": INK,
        "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
        "grid.linestyle": "-", "axes.axisbelow": True, "lines.linewidth": 1.5, "lines.markersize": 5,
        "legend.frameon": False, "axes.spines.top": False, "axes.spines.right": False,
    })


def est_kw(e, line=True, **over):
    s = dict(STYLE[e])
    kw = dict(color=s["color"], marker=s["marker"], markersize=5, markeredgewidth=0.9,
              markerfacecolor=s.get("mfc", s["color"]), markeredgecolor=s["color"])
    if line:
        kw.update(linestyle=s["ls"], linewidth=1.5)
    else:
        kw.update(linestyle="none")
    kw.update(over)
    return kw


def proxies(ests, label, line=True):
    from matplotlib.lines import Line2D
    return [Line2D([], [], label=label(e), **est_kw(e, line=line)) for e in ests]


def save(fig, path_png, dpi=200):
    fig.savefig(path_png, dpi=dpi, bbox_inches="tight")
    fig.savefig(path_png[:-4] + ".pdf", bbox_inches="tight")
    plt.close(fig)
