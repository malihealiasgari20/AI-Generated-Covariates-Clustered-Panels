"""Read one configuration checkpoint (run/raw/C###.npz) after verifying its integrity.

Integrity (analysis plan A1): the file's SHA-256 equals its sidecar; meta_det names the expected
namespace, E-10 ABSENT and the production code fingerprint; the stored theta_0 equals the sealed
theta_0 map; for every estimator the replication indices are exactly 0..R_e-1; the stored coverage
indicator equals (lo <= theta_0 <= hi) on every success.
"""
import json, math, os

import numpy as np

import fa_common as F
from fv1 import store

FIELDS = ("estimate", "se", "crit", "lo", "hi", "cover", "reject", "fail", "bind")
_THETA_MAP = None


def theta_map():
    global _THETA_MAP
    if _THETA_MAP is None:
        assert F.sha256(F.THETA0_MAP) == F.THETA0_MAP_SHA, "theta_0 map hash mismatch"
        with open(F.THETA0_MAP) as fh:
            _THETA_MAP = json.load(fh)
    return _THETA_MAP


class Config:
    """Raw replication-level arrays of one configuration, by estimator."""

    def __init__(self, name, theta0_key, expect_R=None):
        p = store.paths(F.RUN, name)
        sha, digest = store.read_sidecar(p["sha"])
        got = F.sha256(p["npz"])
        if got != sha:
            raise RuntimeError(f"{name}: checkpoint SHA-256 {got} != sidecar {sha}")
        self.name, self.sha256, self.content_digest = name, sha, digest
        th_map = float(theta_map()[theta0_key]["theta0"])
        with np.load(p["npz"]) as z:
            self.meta = json.loads(str(z["meta_det"]))
            self.meta_run = json.loads(str(z["meta_run"]))
            rows = {k: z[f"rows_{k}"] for k in ("r", "est") + FIELDS}
            self.diag = {k[6:]: z[k] for k in z.files if k.startswith("diag__")}
            fail_row, fail_detail = z["fail_row"], z["fail_detail"]
            est_names = [str(x) for x in z["est_names"]]
        assert est_names == F.EST_ALL, "estimator list differs"
        m = self.meta
        if F.MODE == "production":
            assert m["namespace"] == F.PROD_NS and m["production"] is True, f"{name}: not a production checkpoint"
            assert m["code_fingerprint"] == F.CODE_FINGERPRINT, f"{name}: code fingerprint differs"
            assert m["e10"] == "ABSENT", f"{name}: E-10 status {m['e10']}"
            assert m["cap"] is None and not m["inject"], f"{name}: capped or fault-injected checkpoint"
            assert float(m["theta0"]) == th_map, f"{name}: stored theta_0 differs from the sealed map"
        assert m["theta0_key"] == theta0_key
        self.theta0 = th_map
        self.theta0_stored = float(m["theta0"])
        self.config_id = m["config_id"]
        self.R_registry = m["R_registry"]
        self.est = {}
        self.fail_details = {}
        for ri, d in zip(fail_row.tolist(), [str(x) for x in fail_detail]):
            nm = F.EST_ALL[int(rows["est"][ri])]
            dd = self.fail_details.setdefault(nm, {})
            dd[d] = dd.get(d, 0) + 1
        for ei, nm in enumerate(F.EST_ALL):
            idx = np.flatnonzero(rows["est"] == ei)
            if idx.size == 0:
                continue
            r = rows["r"][idx]
            if not np.array_equal(r, np.arange(idx.size)):
                raise RuntimeError(f"{name} {nm}: replication indices are not 0..{idx.size - 1}")
            a = {k: rows[k][idx] for k in FIELDS}
            a["th"] = a.pop("estimate").astype(float)
            ok = a["fail"] == 0
            if F.MODE == "production" or math.isfinite(self.theta0_stored):
                assert np.all(np.isin(a["cover"][ok], (0, 1))), f"{name} {nm}: coverage indicator not 0/1"
                recomputed = ((a["lo"][ok] <= self.theta0) & (self.theta0 <= a["hi"][ok])).astype(np.int8)
                assert np.array_equal(recomputed, a["cover"][ok]), f"{name} {nm}: stored coverage inconsistent"
            else:   # test namespace without theta_0 in the frozen union: recompute from the sealed map
                a["cover"] = np.where(ok, (a["lo"] <= self.theta0) & (self.theta0 <= a["hi"]), -1).astype(np.int8)
            assert np.all(np.isin(a["reject"][ok], (0, 1)))
            for k in ("th", "se", "lo", "hi"):
                a[k] = np.where(ok, a[k], np.nan)
            self.est[nm] = a
            self.fail_details.setdefault(nm, {})
        if expect_R:
            for nm, R in expect_R.items():
                assert nm in self.est and self.est[nm]["fail"].size >= R, f"{name} {nm}: fewer than {R} rows"

    def arrays(self, nm, R):
        a = self.est[nm]
        return {k: v[:R] for k, v in a.items()}

    def diag_r(self, key, R):
        v = self.diag.get(key)
        return None if v is None else v[:R]
