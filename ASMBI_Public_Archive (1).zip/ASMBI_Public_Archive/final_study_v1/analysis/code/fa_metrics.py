"""Performance quantities (record 6.1-6.4; analysis plan B-D) for one estimator in one cell.

point(a, theta0)        every point quantity with its analytic MCSE (plan B, C1)
boot(a, theta0, I, C)   the plan-C2 bootstrap: one value per draw for every bootstrapped quantity
pair_point / pair_boot  paired contrasts on the intersection of successes (plan D)

a is the dict of replication-level arrays of one estimator restricted to r < R (failures carry
NaN in th, se, lo, hi). I is the B x R index matrix and C the matching B x R count matrix
(C[b, j] = number of times replication j appears in draw b).
"""
import math

import numpy as np

import fa_common as F

BOOT_STATS = ("bias", "emp_se", "mean_se", "se_ratio", "rmse", "coverage", "width_mean", "width_median",
              "rejection", "bind_rate", "failure_rate", "n_success", "median_bias", "mad_sd", "median_se",
              "median_se_over_mad", "median_abs_err", "p99_abs_err", "p999_abs_err", "p99_se", "p999_se")
MAD_K = 1.4826
NAN = float("nan")


def boot_indices(R, B=F.B_BOOT):
    """Plan C2: one index matrix per replication count, from the FINAL_V1_BOOT stream."""
    from stage0_dgp import make_rng
    I = make_rng("FINAL_V1_BOOT", f"R={R}", 0).integers(0, R, size=(B, R))
    C = np.stack([np.bincount(I[b], minlength=R) for b in range(B)]).astype(np.float64)
    return I, C


def _rate_mcse(p, n):
    return math.sqrt(p * (1 - p) / n) if n > 0 and math.isfinite(p) else NAN


def point(a, theta0):
    f = a["fail"]
    R = int(f.size)
    ok = f == 0
    n = int(ok.sum())
    out = {"R": R, "n_success": n, "failures": R - n, "failure_rate": (R - n) / R,
           "failure_rate_mcse": _rate_mcse((R - n) / R, R), "conditional_on_success": (R - n) / R > 0.05}
    for code in range(1, len(F.FAIL_NAMES)):
        out[f"fail_code{code}"] = int(np.sum(f == code))
    keys_nan = ("bias", "bias_mcse", "emp_se", "emp_se_mcse", "mean_se", "mean_se_mcse", "se_ratio", "rmse",
                "rmse_mcse", "coverage", "coverage_mcse", "width_mean", "width_mean_mcse", "width_median",
                "rejection", "rejection_mcse", "bind_rate", "bind_rate_mcse", "median_bias", "mad_sd", "median_se",
                "median_se_over_mad", "median_abs_err", "batch_rmse_min", "batch_rmse_min_mcse", "batch_rmse_max",
                "batch_rmse_max_mcse", "batch_rmse_ratio", "tail_share_sse", "tail_share_se", "p99_abs_err",
                "p999_abs_err", "max_abs_err", "p99_se", "p999_se", "max_se")
    if n < 1:
        out.update({k: NAN for k in keys_nan})
        out.update(tail_driven=False, n_abs_err_gt1=0, n_se_gt0_5=0, n_se_gt1=0, n_se_gt5=0)
        return out
    th, se = a["th"][ok], a["se"][ok]
    w = (a["hi"] - a["lo"])[ok]
    cov = a["cover"][ok].astype(float)
    rej = a["reject"][ok].astype(float)
    err = th - theta0
    e2 = err ** 2
    sd = float(np.std(th, ddof=1)) if n > 1 else NAN
    sdf = lambda v: float(np.std(v, ddof=1)) if n > 1 else NAN
    rmse = float(np.sqrt(np.mean(e2)))
    out.update(
        bias=float(np.mean(err)), bias_mcse=sd / math.sqrt(n),
        emp_se=sd, emp_se_mcse=sd / math.sqrt(2 * (n - 1)) if n > 1 else NAN,
        mean_se=float(np.mean(se)), mean_se_mcse=sdf(se) / math.sqrt(n),
        se_ratio=float(np.mean(se)) / sd if (n > 1 and sd > 0) else NAN,
        rmse=rmse, rmse_mcse=sdf(e2) / (2 * rmse * math.sqrt(n)) if rmse > 0 else NAN,
        coverage=float(np.mean(cov)), coverage_mcse=_rate_mcse(float(np.mean(cov)), n),
        width_mean=float(np.mean(w)), width_mean_mcse=sdf(w) / math.sqrt(n),
        width_median=float(np.median(w)),
        rejection=float(np.mean(rej)), rejection_mcse=_rate_mcse(float(np.mean(rej)), n),
    )
    b = a["bind"][ok]
    if np.any(b >= 0):
        br = float(np.mean(b == 1))
        out.update(bind_rate=br, bind_rate_mcse=_rate_mcse(br, n))
    else:
        out.update(bind_rate=NAN, bind_rate_mcse=NAN)
    med = float(np.median(th))
    mad = MAD_K * float(np.median(np.abs(th - med)))
    mse_ = float(np.median(se))
    out.update(median_bias=med - theta0, mad_sd=mad, median_se=mse_,
               median_se_over_mad=mse_ / mad if mad > 0 else NAN, median_abs_err=float(np.median(np.abs(err))))
    # batch RMSE stability (plan B3): 10 consecutive batches in replication-index order
    e_all = a["th"] - theta0
    bounds = [(k * R) // 10 for k in range(11)]
    brm, bmc = [], []
    for k in range(10):
        seg = e_all[bounds[k]:bounds[k + 1]]
        seg = seg[np.isfinite(seg)]
        if seg.size >= 2:
            r_ = float(np.sqrt(np.mean(seg ** 2)))
            brm.append(r_)
            bmc.append(float(np.std(seg ** 2, ddof=1)) / (2 * r_ * math.sqrt(seg.size)) if r_ > 0 else NAN)
        else:
            brm.append(NAN)
            bmc.append(NAN)
    brm_a = np.array(brm)
    if np.all(np.isfinite(brm_a)):
        i_min, i_max = int(np.argmin(brm_a)), int(np.argmax(brm_a))
        out.update(batch_rmse_min=brm[i_min], batch_rmse_min_mcse=bmc[i_min], batch_rmse_max=brm[i_max],
                   batch_rmse_max_mcse=bmc[i_max], batch_rmse_ratio=brm[i_max] / brm[i_min] if brm[i_min] > 0 else NAN)
    else:
        out.update(batch_rmse_min=NAN, batch_rmse_min_mcse=NAN, batch_rmse_max=NAN, batch_rmse_max_mcse=NAN,
                   batch_rmse_ratio=NAN)
    out["batch_rmse"] = brm
    out["tail_share_sse"] = float(np.max(e2) / np.sum(e2)) if np.sum(e2) > 0 else NAN
    out["tail_share_se"] = float(np.max(se) / np.sum(se)) if np.sum(se) > 0 else NAN
    br_ = out["batch_rmse_ratio"]
    out["tail_driven"] = bool((math.isfinite(br_) and br_ > 2) or out["tail_share_sse"] > 0.10
                              or out["tail_share_se"] > 0.10)
    ae = np.abs(err)
    q = np.quantile(ae, [0.99, 0.999])
    qs = np.quantile(se, [0.99, 0.999])
    out.update(p99_abs_err=float(q[0]), p999_abs_err=float(q[1]), max_abs_err=float(ae.max()),
               p99_se=float(qs[0]), p999_se=float(qs[1]), max_se=float(se.max()),
               n_abs_err_gt1=int(np.sum(ae > 1)), n_se_gt0_5=int(np.sum(se > 0.5)), n_se_gt1=int(np.sum(se > 1)),
               n_se_gt5=int(np.sum(se > 5)))
    for k in ("n_abs_err_gt1", "n_se_gt0_5", "n_se_gt1", "n_se_gt5"):
        p = out[k] / n
        out[k + "_mcse"] = math.sqrt(n * p * (1 - p))
    crit = a["crit"][ok]
    out["crit_constant"] = bool(np.all(crit == crit[0]))
    return out


# --------------------------------------------------------------------------- bootstrap helpers

def rowq(G, qs, has_nan):
    """Per-row quantiles of the non-NaN entries of G (numpy 'linear' definition, as np.quantile)."""
    B, R = G.shape
    if not has_nan:
        hs = [(R - 1) * q for q in qs]
        ks = sorted({int(math.floor(h)) for h in hs} | {min(int(math.floor(h)) + 1, R - 1) for h in hs})
        P = np.partition(G, ks, axis=1)
        out = []
        for h in hs:
            lo = int(math.floor(h)); hi = min(lo + 1, R - 1); fr = h - lo
            out.append(P[:, lo] + fr * (P[:, hi] - P[:, lo]))
        return out
    nb = np.sum(~np.isnan(G), axis=1)
    S = np.sort(np.where(np.isnan(G), np.inf, G), axis=1)
    out = []
    for q in qs:
        h = (nb - 1) * q
        lo = np.floor(np.maximum(h, 0)).astype(int)
        hi = np.minimum(lo + 1, np.maximum(nb - 1, 0))
        fr = h - lo
        vlo = np.take_along_axis(S, lo[:, None], 1)[:, 0]
        vhi = np.take_along_axis(S, hi[:, None], 1)[:, 0]
        with np.errstate(invalid="ignore"):
            v = vlo + fr * (vhi - vlo)
        out.append(np.where(nb > 0, v, np.nan))
    return out


def boot(a, theta0, I, C):
    """Plan C2: per-draw values of every bootstrapped quantity (dict of length-B arrays)."""
    f = a["fail"]
    ok = (f == 0)
    okf = ok.astype(float)
    has_nan = not bool(ok.all())
    B = I.shape[0]
    R = f.size
    nb = C @ okf
    out = {"n_success": nb, "failure_rate": 1.0 - nb / R}
    if ok.sum() < 2:
        for k in BOOT_STATS:
            out.setdefault(k, np.full(B, np.nan))
        return out
    z = lambda v: np.where(ok, v, 0.0)
    err = a["th"] - theta0
    with np.errstate(invalid="ignore", divide="ignore"):
        s1 = C @ z(err)
        s2 = C @ z(err ** 2)
        mean_e = s1 / nb
        var = (s2 - nb * mean_e ** 2) / (nb - 1)
        emp = np.sqrt(np.maximum(var, 0.0))
        mse = C @ z(a["se"]) / nb
        out.update(bias=mean_e, emp_se=emp, mean_se=mse, se_ratio=mse / emp, rmse=np.sqrt(s2 / nb),
                   coverage=C @ z(a["cover"].astype(float)) / nb, width_mean=C @ z(a["hi"] - a["lo"]) / nb,
                   rejection=C @ z(a["reject"].astype(float)) / nb)
        bnd = a["bind"]
        out["bind_rate"] = (C @ z((bnd == 1).astype(float)) / nb) if np.any(bnd[ok] >= 0) else np.full(B, np.nan)
    G = a["th"][I]
    (med,) = rowq(G, [0.5], has_nan)
    out["median_bias"] = med - theta0
    (mad,) = rowq(np.abs(G - med[:, None]), [0.5], has_nan)
    out["mad_sd"] = MAD_K * mad
    Gae = np.abs(G - theta0)
    del G
    m_ae, q99, q999 = rowq(Gae, [0.5, 0.99, 0.999], has_nan)
    del Gae
    out.update(median_abs_err=m_ae, p99_abs_err=q99, p999_abs_err=q999)
    Gse = a["se"][I]
    m_se, s99, s999 = rowq(Gse, [0.5, 0.99, 0.999], has_nan)
    del Gse
    out.update(median_se=m_se, p99_se=s99, p999_se=s999)
    with np.errstate(invalid="ignore", divide="ignore"):
        out["median_se_over_mad"] = m_se / out["mad_sd"]
    crit = a["crit"][ok]
    if np.all(crit == crit[0]):
        w_ok = (a["hi"] - a["lo"])[ok]
        # constant critical value: width = 2 crit SE replication by replication, so the median width is
        # 2 crit x median SE; the factor is taken from the stored widths
        fac = float(np.median(w_ok / a["se"][ok]))
        out["width_median"] = fac * m_se
    else:
        (wm,) = rowq((a["hi"] - a["lo"])[I], [0.5], has_nan)
        out["width_median"] = wm
    return out


def mcse_from_draws(d):
    d = np.asarray(d, dtype=float)
    d = d[np.isfinite(d)]
    return float(np.std(d, ddof=1)) if d.size > 1 else NAN


def pct(d, lo=2.5, hi=97.5):
    """Percentile interval; non-finite draws (e.g. +inf for an absent root) are kept in the ordering."""
    d = np.asarray(d, dtype=float)
    d = d[~np.isnan(d)]
    if d.size == 0:
        return (NAN, NAN)
    return (float(np.percentile(d, lo)), float(np.percentile(d, hi)))


# --------------------------------------------------------------------------- paired contrasts (plan D)

def pair_point(a, b, theta0):
    """a minus b on the intersection of successes: bias difference, RMSE ratio, coverage difference."""
    ok = (a["fail"] == 0) & (b["fail"] == 0)
    n = int(ok.sum())
    out = {"n_intersection": n}
    if n < 2:
        out.update(bias_diff=NAN, bias_diff_mcse=NAN, rmse_ratio=NAN, log_rmse_ratio=NAN, cov_diff=NAN,
                   cov_diff_mcse=NAN)
        return out
    d = a["th"][ok] - b["th"][ok]
    ea, eb = a["th"][ok] - theta0, b["th"][ok] - theta0
    rr = math.sqrt(np.mean(ea ** 2) / np.mean(eb ** 2)) if np.mean(eb ** 2) > 0 else NAN
    dc = a["cover"][ok].astype(float) - b["cover"][ok].astype(float)
    out.update(bias_diff=float(np.mean(d)), bias_diff_mcse=float(np.std(d, ddof=1)) / math.sqrt(n),
               rmse_ratio=rr, log_rmse_ratio=math.log(rr) if rr > 0 else NAN,
               cov_diff=float(np.mean(dc)), cov_diff_mcse=float(np.std(dc, ddof=1)) / math.sqrt(n))
    return out


def pair_boot(a, b, theta0, C):
    """Per-draw RMSE ratio a/b on the intersection of successes."""
    ok = (a["fail"] == 0) & (b["fail"] == 0)
    ea2 = np.where(ok, (a["th"] - theta0) ** 2, 0.0)
    eb2 = np.where(ok, (b["th"] - theta0) ** 2, 0.0)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.sqrt((C @ ea2) / (C @ eb2))


def cross_pair(a, b, R=None):
    """Plan D2: paired replication differences of theta^ between two configurations sharing seeds."""
    if R is not None:
        a = {k: v[:R] for k, v in a.items()}
        b = {k: v[:R] for k, v in b.items()}
    ok = (a["fail"] == 0) & (b["fail"] == 0)
    n = int(ok.sum())
    if n < 2:
        return {"diff": NAN, "mcse": NAN, "n_intersection": n}
    d = a["th"][ok] - b["th"][ok]
    return {"diff": float(np.mean(d)), "mcse": float(np.std(d, ddof=1)) / math.sqrt(n), "n_intersection": n}
