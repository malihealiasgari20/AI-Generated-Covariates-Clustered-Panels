"""Experiment 4 (module X4): O4.1-O4.5, H4.1-H4.6 (record 7.4; protocol 6; plan J). E-10 ABSENT."""
import math, os

import numpy as np
from matplotlib.patches import Rectangle
from scipy.interpolate import RegularGridInterpolator

import fa_common as F
import fa_metrics as M
import fa_phase1
import fa_style as S
from fa_main import register, vm

plt = S.plt
FL = (0.03, 0.05, 0.10, 0.20, 0.35, 0.50)
SD = (0.15, 0.25, 0.35, 0.55, 0.80)
NAN = float("nan")


def grid_cell(ctx, f, sd, null):
    return ctx.one("X4", design="grid", f_level=f, sd_e=sd, null=null)


def uni_cell(ctx, null):
    return ctx.one("X4", design="uniform", null=null)


def rr_info(ctx, c, e):
    p = ctx.pair(c, e, "E-2")
    m, m2 = ctx.m(c, e), ctx.m(c, "E-2")
    flagged = bool(m["conditional_on_success"] or m2["conditional_on_success"])
    lo, hi = p["log_rmse_ratio_ci95"]
    cls = "rectification pays" if hi < 0 else ("labeled-only better" if lo > 0 else "indeterminate")
    return dict(rmse_ratio=p["rmse_ratio"], rmse_ratio_bmcse=p["rmse_ratio_bmcse"], log_rmse_ratio=p["log_rmse_ratio"],
                log_ci95=(lo, hi), log_bmcse=p["log_rmse_ratio_bmcse"], n_intersection=p["n_intersection"],
                classification=cls, flagged=flagged, failure_rate=m["failure_rate"], failure_rate_E2=m2["failure_rate"])


def o41(ctx):
    rows = []
    cells = [grid_cell(ctx, f, sd, n) for n in (False, True) for f in FL for sd in SD] + [uni_cell(ctx, False), uni_cell(ctx, True)]
    for c in cells:
        for e in F.EST16:
            if e == "E-2":
                continue
            r = rr_info(ctx, c, e)
            m = ctx.m(c, e)
            rows.append({"cell": c["cell"], "design": c["design"], "f": c["f_level"], "sd_e": c["sd_e"], "gamma_W": c["gamma_W"],
                         "estimator": e, "rectified_set": e in F.RECTIFIED_X4, **{k: v for k, v in r.items() if k != "log_ci95"},
                         "log_ci95_lo": r["log_ci95"][0], "log_ci95_hi": r["log_ci95"][1], "coverage": m["coverage"],
                         "coverage_mcse": m["coverage_mcse"], "bias": m["bias"], "bias_mcse": m["bias_mcse"],
                         "rmse": m["rmse"], "rmse_E2": ctx.m(c, "E-2")["rmse"]})
        rows.append({"cell": c["cell"], "design": c["design"], "f": c["f_level"], "sd_e": c["sd_e"], "gamma_W": c["gamma_W"],
                     "estimator": "E-10", "rectified_set": True, "classification": F.E10_ABSENT})
    return rows


def field(ctx, e, null):
    Z = np.full((len(FL), len(SD)), np.nan)
    info = {}
    for i, f in enumerate(FL):
        for j, sd in enumerate(SD):
            r = rr_info(ctx, grid_cell(ctx, f, sd, null), e)
            info[(f, sd)] = r
            if not r["flagged"] and math.isfinite(r["log_rmse_ratio"]):
                Z[i, j] = r["log_rmse_ratio"]
    return Z, info


def boundary(Z):
    """H4.3: per sd_e column, the f where log R_RMSE crosses from < 0 to >= 0 scanning f upward."""
    out = {}
    lf = np.log(FL)
    for j, sd in enumerate(SD):
        v = Z[:, j]
        idx = [i for i in range(len(FL)) if np.isfinite(v[i])]
        if not idx:
            out[sd] = ("undefined", NAN)
            continue
        vv = v[idx]
        if np.all(vv < 0):
            out[sd] = ("above 0.50", math.inf)
            continue
        if np.all(vv >= 0):
            out[sd] = ("below 0.03", -math.inf)
            continue
        fc = None
        for a, b in zip(idx[:-1], idx[1:]):
            if v[a] < 0 <= v[b]:
                t = -v[a] / (v[b] - v[a])
                fc = float(math.exp(lf[a] + t * (lf[b] - lf[a])))
                break
        if fc is None:
            out[sd] = ("reverse (>= 0 at small f, < 0 at larger f)", NAN)
        else:
            later_neg = any(v[i] < 0 for i in idx if FL[i] > fc)
            out[sd] = ("crossing" + (" (non-monotone: negative again at larger f)" if later_neg else ""), fc)
    return out


def contour_figure(ctx, reg, null, name, title):
    S.setup()
    ests = F.RECTIFIED_X4
    fig, axes = plt.subplots(2, 4, figsize=(11.0, 5.6), sharex=True, sharey=True)
    lf = np.log(FL)
    gx = np.linspace(lf[0], lf[-1], 241)
    gy = np.linspace(SD[0], SD[-1], 201)
    GX, GY = np.meshgrid(gx, gy, indexing="ij")
    allZ = [field(ctx, e, null) for e in ests]
    vmax = max(0.25, max(float(np.nanmax(np.abs(Z))) if np.isfinite(Z).any() else 0 for Z, _ in allZ))
    vmax = min(vmax, 2.5)
    from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
    cmap = LinearSegmentedColormap.from_list("div", [S.DIVERGING[0], S.DIVERGING[1], S.DIVERGING[2]])
    norm = TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)
    data = []
    im = None
    for ax, e, (Z, info) in zip(axes.ravel(), ests, allZ):
        rgi = RegularGridInterpolator((lf, np.array(SD)), Z, method="linear", bounds_error=False, fill_value=np.nan)
        V = rgi(np.stack([GX.ravel(), GY.ravel()], axis=1)).reshape(GX.shape)
        Vc = np.clip(V, -vmax, vmax)
        im = ax.pcolormesh(gx, gy, Vc.T, cmap=cmap, norm=norm, shading="auto", rasterized=True)
        if np.isfinite(V).any() and np.nanmin(V) < 0 < np.nanmax(V):
            ax.contour(gx, gy, V.T, levels=[0.0], colors=S.INK, linewidths=1.4)
        for (f, sd), r in info.items():
            x, y = math.log(f), sd
            if r["flagged"]:
                ax.add_patch(Rectangle((x - 0.14, y - 0.035), 0.28, 0.07, fill=False, hatch="////", edgecolor=S.INK2, lw=0.6))
            mk = {"rectification pays": ("v", S.INK, S.INK), "labeled-only better": ("^", S.INK, S.INK),
                  "indeterminate": ("o", S.INK, "white")}[r["classification"]]
            ax.plot([x], [y], marker=mk[0], color=mk[1], mfc=mk[2], ms=4.2, mew=0.8, ls="none")
            data.append({"estimator": e, "f": f, "sd_e": sd, "gamma_W": 0.0 if null else 0.15, **{k: v for k, v in r.items() if k != "log_ci95"},
                         "log_ci95_lo": r["log_ci95"][0], "log_ci95_hi": r["log_ci95"][1]})
        ax.set_title(F.lab(e), fontsize=8, loc="left")
        ax.set_xticks(lf)
        ax.set_xticklabels([str(f) for f in FL], fontsize=6.5, rotation=45)
        ax.set_yticks(SD)
        ax.set_xlim(lf[0] - 0.25, lf[-1] + 0.25)
        ax.set_ylim(SD[0] - 0.06, SD[-1] + 0.06)
        ax.grid(False)
    fig.supxlabel("labeled-cluster fraction f (log scale)", fontsize=8.5, y=0.02)
    for ax in axes[:, 0]:
        ax.set_ylabel("machine-error SD sd_e")
    cb = fig.colorbar(im, ax=axes, shrink=0.8, pad=0.015, extend="both")
    cb.set_label("log R_RMSE  (< 0: rectification pays)")
    from matplotlib.lines import Line2D
    h = [Line2D([], [], marker="v", color=S.INK, ls="none", label="pays (95% CI of log R_RMSE < 0)"),
         Line2D([], [], marker="^", color=S.INK, ls="none", label="labeled-only better (CI > 0)"),
         Line2D([], [], marker="o", color=S.INK, mfc="white", ls="none", label="indeterminate"),
         Line2D([], [], color=S.INK, lw=1.4, label="contour log R_RMSE = 0 (bilinear in log f, sd_e)"),
         Rectangle((0, 0), 1, 1, fill=False, hatch="////", edgecolor=S.INK2, label="failure rate > 5% (excluded)")]
    fig.legend(handles=h, loc="lower center", ncol=3, bbox_to_anchor=(0.45, -0.1), fontsize=7)
    fig.suptitle(f"{title}. RMSE ratio against labeled-only IPW (E-2) on paired replications, gamma_W "
                 f"{'0' if null else '0.15'}, R 2,000 per cell; E-10 ABSENT (gate V10)", fontsize=8.5)
    out = F.ensure(os.path.join(F.OUT, "figures"))
    p = os.path.join(out, f"{name}.png")
    S.save(fig, p)
    fc = F.write_csv(os.path.join(out, f"{name}_data.csv"), data)
    register(reg, title, [grid_cell(ctx, f, sd, null) for f in FL for sd in SD], 2000, "per cell", [p, fc])
    return {e: allZ[k] for k, e in enumerate(ests)}


def matched(ctx, c0, c1, e, I):
    """O4.3 on one (null, non-null) pair."""
    a0, a1 = ctx.arrays(c0, e), ctx.arrays(c1, e)
    th0 = ctx.theta0(c1)
    t0 = np.abs(a0["th"]) / a0["se"]
    t1 = np.abs(a1["th"]) / a1["se"]
    k1 = np.abs(a1["th"] - th0) / a1["se"]
    ok0, ok1 = np.isfinite(t0), np.isfinite(t1)
    if ok0.sum() < 20 or ok1.sum() < 20:
        return None
    cstar = float(np.quantile(t0[ok0], 0.95))
    power = float(np.mean(t1[ok1] > cstar))
    kz = float(np.quantile(k1[ok1], 0.95))
    se1 = a1["se"][ok1]
    out = {"c_star": cstar, "size_adjusted_power": power, "k_star_z": kz, "matched_width_median": 2 * kz * float(np.median(se1)),
           "matched_width_mean": 2 * kz * float(np.mean(se1)), "nominal_power": ctx.m(c1, e)["rejection"],
           "nominal_type1": ctx.m(c0, e)["rejection"], "coverage": ctx.m(c1, e)["coverage"],
           "n_null": int(ok0.sum()), "n_nonnull": int(ok1.sum())}
    hn0, hn1 = bool((~ok0).any()), bool((~ok1).any())
    (cb,) = M.rowq(t0[I], [0.95], hn0)
    T1 = t1[I]
    nb = np.sum(np.isfinite(T1), axis=1)
    pw = np.sum(np.where(np.isfinite(T1), T1 > cb[:, None], False), axis=1) / nb
    (kb,) = M.rowq(k1[I], [0.95], hn1)
    S1 = a1["se"][I]
    (smed,) = M.rowq(S1, [0.5], hn1)
    smean = np.nanmean(S1, axis=1)
    out.update(c_star_bmcse=M.mcse_from_draws(cb), size_adjusted_power_bmcse=M.mcse_from_draws(pw),
               k_star_z_bmcse=M.mcse_from_draws(kb), matched_width_median_bmcse=M.mcse_from_draws(2 * kb * smed),
               matched_width_mean_bmcse=M.mcse_from_draws(2 * kb * smean))
    out["_draws_width_median"] = 2 * kb * smed
    out["_draws_power"] = pw
    return out


def o43(ctx):
    rows = []
    pairs = [(f, sd, grid_cell(ctx, f, sd, True), grid_cell(ctx, f, sd, False)) for f in FL for sd in SD]
    pairs.append(("uniform", 0.55, uni_cell(ctx, True), uni_cell(ctx, False)))
    for f, sd, c0, c1 in pairs:
        R = ctx.R_used(c1)
        assert ctx.R_used(c0) == R
        I, _ = fa_phase1.boot_matrices(R)
        ref = None
        res = {}
        for e in F.EST16:
            r = matched(ctx, c0, c1, e, I)
            res[e] = r
        ref = res.get("E-2")
        for e, r in res.items():
            row = {"f": f, "sd_e": sd, "pair": f"{c1['cell']} / {c0['cell']}", "estimator": e,
                   "rectified_set": e in F.RECTIFIED_X4}
            if r is None:
                row["note"] = "fewer than 20 successes in a cell of the pair"
            else:
                row.update({k: v for k, v in r.items() if not k.startswith("_")})
                if ref is not None and e != "E-2":
                    row["matched_width_median_ratio_vs_E2"] = r["matched_width_median"] / ref["matched_width_median"]
                    row["matched_width_median_ratio_vs_E2_bmcse"] = M.mcse_from_draws(r["_draws_width_median"] / ref["_draws_width_median"])
                    row["size_adjusted_power_diff_vs_E2"] = r["size_adjusted_power"] - ref["size_adjusted_power"]
                    row["size_adjusted_power_diff_vs_E2_bmcse"] = M.mcse_from_draws(r["_draws_power"] - ref["_draws_power"])
            rows.append(row)
        rows.append({"f": f, "sd_e": sd, "pair": f"{c1['cell']} / {c0['cell']}", "estimator": "E-10", "note": F.E10_ABSENT})
    return rows


AQ = [("QWK", "assoc__raw_qwk_ZL_ZHdisc"), ("raw_pearson", "assoc__raw_pearson_ZL_ZH"),
      ("raw_spearman", "assoc__raw_spearman_ZL_ZH"), ("within_pearson", "assoc__within_pearson_ZL_ZH")]


def o44(ctx):
    rows = []
    for null in (False, True):
        for sd in SD:
            r = {"sd_e": sd, "gamma_W": 0.0 if null else 0.15, "pooled_cells": len(FL)}
            for nm, key in AQ:
                vals = []
                for f in FL:
                    c = grid_cell(ctx, f, sd, null)
                    v = ctx.raw(c).diag.get(key)
                    if v is not None:
                        v = np.asarray(v[:ctx.R_used(c)], float)
                        vals.append(v[np.isfinite(v)])
                v = np.concatenate(vals) if vals else np.array([])
                r[nm] = float(v.mean()) if v.size else None
                r[nm + "_mcse"] = float(v.std(ddof=1) / math.sqrt(v.size)) if v.size > 1 else None
                r[nm + "_n"] = int(v.size)
            rows.append(r)
    return rows


def o45(ctx):
    rows = []
    for c in ctx.sel("X4"):
        for e in F.EST16:
            m = ctx.m(c, e)
            r = {"cell": c["cell"], "design": c["design"], "f": c["f_level"], "sd_e": c["sd_e"], "gamma_W": c["gamma_W"],
                 "estimator": e, "failure_rate": m["failure_rate"], "failure_rate_mcse": m["failure_rate_mcse"],
                 "bind_rate": m["bind_rate"], "bind_rate_mcse": m["bind_rate_mcse"],
                 "conditional_on_success": m["conditional_on_success"]}
            for code in range(1, len(F.FAIL_NAMES)):
                r[F.FAIL_NAMES[code]] = m[f"fail_code{code}"]
            rows.append(r)
        rows.append({"cell": c["cell"], "estimator": "E-10", "failure_rate": None, "note": F.E10_ABSENT})
    return rows


def run(ctx, reg):
    out = F.ensure(os.path.join(F.OUT, "experiments", "Exp4"))
    r41 = o41(ctx)
    f1 = F.write_csv(os.path.join(out, "O4.1_rmse_ratio_vs_E2.csv"), r41)
    Zs = contour_figure(ctx, reg, False, "FigureX4_crossover_contours", "Figure X4 (O4.2)")
    Zs0 = contour_figure(ctx, reg, True, "FigureS4_crossover_contours_null", "Supplementary Figure S4 (O4.2, null cells)")
    r43 = o43(ctx)
    f3 = F.write_csv(os.path.join(out, "O4.3_matched_size.csv"), r43)
    r44 = o44(ctx)
    f4 = F.write_csv(os.path.join(out, "O4.4_agreement_to_sd_mapping.csv"), r44)
    r45 = o45(ctx)
    f5 = F.write_csv(os.path.join(out, "O4.5_failure_and_binding_rates.csv"), r45)
    bnd = {e: boundary(Zs[e][0]) for e in F.RECTIFIED_X4}
    F.dump_json(os.path.join(out, "O4.2_boundaries.json"), {e: {str(k): v for k, v in b.items()} for e, b in bnd.items()})
    # markdown summary of O4.1/O4.2 for the rectified set (gamma 0.15)
    hdr = ["sd_e \\ f"] + [str(f) for f in FL]
    txt = [f"O4.1/O4.2. R_RMSE = RMSE(estimator) / RMSE(E-2) on paired replications, gamma_W 0.15, R 2,000 per cell; "
           f"bootstrap MCSE in parentheses; v = rectification pays, ^ = labeled-only better, o = indeterminate; "
           f"† = failure rate above 5% for the estimator or E-2 (excluded from the contour). {F.CAPTION}. "
           f"E-10: {F.E10_ABSENT}.", ""]
    sym = {"rectification pays": "v", "labeled-only better": "^", "indeterminate": "o"}
    for e in F.RECTIFIED_X4:
        body = []
        for sd in SD:
            row = [str(sd)]
            for f in FL:
                r = rr_info(ctx, grid_cell(ctx, f, sd, False), e)
                row.append(f"{vm(r['rmse_ratio'], r['rmse_ratio_bmcse'], 3)} {sym[r['classification']]}{'†' if r['flagged'] else ''}")
            body.append(row)
        txt += [F.lab(e), "", F.md_table(hdr, body), ""]
    f2 = os.path.join(out, "O4.1_O4.2_rmse_ratio_grid.md")
    open(f2, "w").write("\n".join(txt) + "\n")
    register(reg, "Experiment 4 (O4.1-O4.5)", ctx.sel("X4"), 2000, "per cell; paired replications within cell",
             [f1, f2, f3, f4, f5])
    return {"H": hypotheses(ctx, r41, Zs, bnd, r43), "boundaries": bnd}


def hypotheses(ctx, r41, Zs, bnd, r43):
    H = []
    g15 = [r for r in r41 if r.get("gamma_W") == 0.15 and r.get("design") == "grid" and r["estimator"] in F.RECTIFIED_X4]
    pays = [(r["estimator"], r["f"], r["sd_e"]) for r in g15 if r["classification"] == "rectification pays" and not r["flagged"]]
    below1 = [(r["estimator"], r["f"], r["sd_e"]) for r in g15 if r["rmse_ratio"] < 1]
    out = "SUPPORTED" if pays else ("REFUTED" if not below1 else "NOT SUPPORTED")
    H.append(dict(id="H4.1", experiment="4", outcome=out, status="PROSPECTIVE (60 of 62 cells never run); not informative for E-12a/E-12b",
                  cells="X4 grid, gamma_W 0.15; rectified set (E-10 ABSENT)",
                  evidence=dict(pays_cells=pays, point_below_1_cells=below1,
                                pays_by_estimator={e: sum(1 for p in pays if p[0] == e) for e in F.RECTIFIED_X4},
                                pays_excluding_E12ab=[p for p in pays if p[0] not in ("E-12a", "E-12b")]),
                  rule="analysis plan J, H4.1"))
    base = grid_cell(ctx, 0.35, 0.55, False)
    uni = uni_cell(ctx, False)
    ev = {}
    attains = []
    for e in ("E-6", "E-12a", "E-12b"):
        rb, ru = rr_info(ctx, base, e), rr_info(ctx, uni, e)
        near = {f"f={f}|sd={sd}": (rr_info(ctx, grid_cell(ctx, f, sd, False), e)["rmse_ratio"],
                                  rr_info(ctx, grid_cell(ctx, f, sd, False), e)["classification"])
                for f in (0.20, 0.35, 0.50) for sd in (0.35, 0.55, 0.80) if not (f == 0.35 and sd == 0.55)}
        dlog = ru["log_rmse_ratio"] - rb["log_rmse_ratio"]
        dse = math.hypot(ru["log_bmcse"], rb["log_bmcse"])
        ev[e] = dict(baseline=(rb["rmse_ratio"], rb["rmse_ratio_bmcse"], rb["classification"]),
                     uniform=(ru["rmse_ratio"], ru["rmse_ratio_bmcse"], ru["classification"]), near_baseline=near,
                     uniform_minus_baseline_log=dlog, mcse=dse, lower_by_more_than_3_mcse=dlog < -3 * dse)
        if rb["classification"] == "rectification pays":
            attains.append(e)
    H.append(dict(id="H4.2", experiment="4", outcome="E-10 part: ABSENT; interpretation rule (record 7.4) applied to E-6, E-12a, E-12b: "
                  + ("branch 1 -- " + ", ".join(attains) + " attain R_RMSE < 1 at the baseline" if attains
                     else "branch 2 -- none attains R_RMSE < 1 at the baseline"),
                  status="baseline: CONFIRMATORY (development: E-12a below 1); uniform cell PROSPECTIVE",
                  cells="X4 baseline f 0.35, sd_e 0.55, gamma_W 0.15 (R 2,000) and uniform-validation cell (R 5,000)",
                  evidence=dict(E10=F.E10_ABSENT, **ev), rule="analysis plan J, H4.2"))
    h43 = {}
    for e in F.RECTIFIED_X4:
        b = bnd[e]
        vals = [b[sd][1] for sd in SD]
        defined = all(not (isinstance(v, float) and math.isnan(v)) for v in vals)
        mono = defined and all(vals[i] >= vals[i + 1] for i in range(len(vals) - 1))
        const = defined and len({str(v) for v in vals}) == 1
        h43[e] = dict(boundary={str(sd): b[sd] for sd in SD}, monotone_nonincreasing_in_sd=mono, all_identical=const,
                      outcome="SUPPORTED" if (mono and not const) else "NOT SUPPORTED")
    H.append(dict(id="H4.3", experiment="4", outcome="; ".join(f"{e}: {h43[e]['outcome']}" for e in F.RECTIFIED_X4),
                  status="PROSPECTIVE", cells="X4 grid, gamma_W 0.15", evidence=h43, rule="analysis plan J, H4.3"))
    for hid, ests in (("H4.4", ["E-6"]), ("H4.4b", ["E-12a", "E-12b", "HT-TDS-I"])):
        ev, outs = {}, []
        for e in ests:
            rows = [r for r in g15 if r["estimator"] == e]
            low = [(r["f"], r["sd_e"], r["coverage"]) for r in rows if r["coverage"] < 0.93]
            refute = [(r["f"], r["sd_e"], r["coverage"], r["rmse_ratio"]) for r in rows
                      if r["coverage"] < 0.920 and r["rmse_ratio"] < 1]
            o = "REFUTED" if refute else ("SUPPORTED" if not low else "NOT SUPPORTED")
            outs.append(f"{e}: {o}")
            sec = [r for r in r41 if r["estimator"] == e and (r.get("gamma_W") == 0.0 or r.get("design") == "uniform")]
            ev[e] = dict(min_coverage=min(r["coverage"] for r in rows), cells_below_0_93=low,
                         refuting_cells=refute, flagged_cells=[(r["f"], r["sd_e"]) for r in rows if r["flagged"]],
                         secondary_min_coverage_null_and_uniform=min(r["coverage"] for r in sec) if sec else None)
        H.append(dict(id=hid, experiment="4", outcome="E-10: ABSENT; " + "; ".join(outs), status="PROSPECTIVE",
                      cells="X4 grid, 30 gamma_W 0.15 cells", evidence=ev, rule=f"analysis plan J, {hid}"))
    h45 = {}
    for e in ("E-12a", "E-12b"):
        rows = [r for r in g15 if r["estimator"] == e]
        h45[e] = dict(not_paying=[(r["f"], r["sd_e"], r["classification"], r["rmse_ratio"]) for r in rows
                                  if r["classification"] != "rectification pays"],
                      excluded_gt_5pct=[(r["f"], r["sd_e"], r["failure_rate"]) for r in rows if r["failure_rate"] > 0.05])
    H.append(dict(id="H4.5", experiment="4", outcome="REPORTED (open question)", status="PROSPECTIVE",
                  cells="X4 grid, gamma_W 0.15", evidence=h45, rule="analysis plan J, H4.5"))
    H.append(dict(id="H4.6", experiment="4", outcome="REPORTED (open question; table supplementary/H4.6_TDS_sparse_validation.csv)",
                  status="PROSPECTIVE", cells="X4 f <= 0.10; S m 0.33, 0.50", evidence={}, rule="analysis plan J, H4.6"))
    return H
