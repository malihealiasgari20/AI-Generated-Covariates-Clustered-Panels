"""Results summary (record 10.4): a factual digest generated from the analysis outputs. Every number
is taken from the written tables; nothing is recomputed here."""
import json, math, os

import fa_common as F
from fa_ctx import cov_band
from fa_main import vm


def write(ctx, R):
    L = []
    add = L.append
    add("# FINAL_V1 results summary (generated)")
    add("")
    add(f"{F.CAPTION}. Generated from the analysis outputs in this folder; numbers are copied from the tables, with "
        f"Monte Carlo SEs in parentheses. Interpretation is limited to the pre-specified rules (record 6.6, 7, 9).")
    add("")
    add("## 1. Integrity")
    add("")
    add(f"- Sealed pre-run record SHA-256 {F.RECORD_SHA}; protocol v1.10 {F.PROTOCOL_V110_SHA}.")
    add(f"- Gate record {F.GATE_RECORD_SHA}; theta_0 map {F.THETA0_MAP_SHA}; E-10 {F.E10_ABSENT}.")
    add(f"- Module cells {len(ctx.cells)}; configurations {len(ctx.configs)}; cell-level rows: {R['info']}.")
    add("")
    add("## 2. Hypothesis outcomes")
    add("")
    add(F.md_table(["ID", "Outcome", "Status"], [[h["id"], h["outcome"], h["status"]] for h in R["H"]], ["l", "l", "l"]))
    add("")
    add("## 3. Table 4 (primary grid, 12 non-null cells; Type I from the 12 null cells)")
    add("")
    hdr = ["Procedure", "Bias", "RMSE", "Cov. med.", "Cov. min", "Cov. max", "Width", "Type I", "Power"]
    rows = [[f"{F.SHORT[r['estimator']]} ({r['estimator']})", vm(r["bias"], r["bias_mcse"], 4, True), vm(r["rmse"], r["rmse_mcse"]),
             vm(r["cov_median"], r["cov_median_mcse"], 3), F.fnum(r["cov_min"], 3), F.fnum(r["cov_max"], 3),
             F.fnum(r["width"], 3), vm(r["type1"], r["type1_mcse"], 3), vm(r["power"], r["power_mcse"], 3)]
            for r in R["t4"] if r["headline"]]
    add(F.md_table(hdr, rows))
    add("")
    add("## 4. Experiment 1 (contamination ladder)")
    add("")
    for k, v in R["x1"]["crossing"].items():
        lo, hi = v["ci95_percentile"]
        add(f"- E-1 zero-bias crossing, {k}: {F.fnum(v['root'], 3)} ({v['status']}); bootstrap 95% interval "
            f"[{F.fnum(lo, 3)}, {F.fnum(hi, 3)}]; share of draws with an in-range root {v['share_draws_in_range_root']:.3f}.")
    for k, v in R["x1"]["o14"].items():
        add(f"- O1.4 {k}: {v['statement']} (max |bias| / half median width {v['max_ratio']:.3f}).")
    add("")
    add("## 5. Experiment 2 (validation design x heterogeneity)")
    add("")
    d = R["x2"]["o22"]["E-5|g=0.15"]
    add(f"- E-5 interaction contrast Delta = {F.fnum(d['Delta'], 4, True)} (MCSE {F.fnum(d['mcse'], 4)}).")
    add("")
    add("## 6. Experiment 3 (1/T scaling)")
    add("")
    add(f"- Control C3: {R['x3']['C3']}.")
    f = R["x3"]["fits"]["E-1"]
    add(f"- E-1 scaling slope b = {f['slope']:.3f}, 95% CI [{f['ci95'][0]:.3f}, {f['ci95'][1]:.3f}] (predicted -1); "
        f"weighted residual chi-square {f['chi2']:.2f} on {f['df']} df.")
    add("")
    add("## 7. Experiment 4 (efficiency crossover)")
    add("")
    for e, b in R["x4"]["boundaries"].items():
        add(f"- {e} boundary f_c by sd_e: " + "; ".join(f"{sd}: {v[0]}{'' if not isinstance(v[1], float) or not math.isfinite(v[1]) else f' at f = {v[1]:.3f}'}"
                                                         for sd, v in b.items()))
    add("")
    add("## 8. Experiment-5 re-evaluation")
    add("")
    for hid in ("H5.1", "H5.2", "H5.3"):
        add(f"- {hid}: FINAL_V1 {R['x5']['FINAL_V1'][hid]['outcome']}; Experiment 5 under the same rule "
            f"{R['x5']['E5'][hid]['outcome']}.")
    add("")
    add("## 9. Dissociation (Table 9)")
    add("")
    for r in R["t9"]:
        add(f"- kappa {r['kappa']:.1f}: QWK {r['QWK']:.4f}, Spearman {r['rank_corr_spearman']:.4f}, naive bias "
            f"{r['naive_bias']:+.4f}, incremental OOS R^2 {r['incremental_oos_r2_pct']:.3f}%.")
    add("")
    open(os.path.join(F.OUT, "RESULTS_SUMMARY_GENERATED.md"), "w").write("\n".join(L) + "\n")
