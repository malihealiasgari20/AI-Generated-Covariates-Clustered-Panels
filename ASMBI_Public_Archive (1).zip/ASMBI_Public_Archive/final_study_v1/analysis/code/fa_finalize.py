"""Final SHA-256 manifest and archive of the whole FINAL_V1 package (record 10.1 step 7).

1. Every earlier Final_Study_v1 manifest must still verify (nothing sealed was altered).
2. MANIFEST_SHA256_FINAL.txt: SHA-256 of every file under Final_Study_v1/ except itself and its .sha256.
3. Final_Study_v1_FINAL.zip in the outputs folder (stored, not recompressed; the checkpoints are already
   compressed), then re-opened and every member checked against the manifest.
"""
import datetime, hashlib, os, sys, zipfile

STUDY = "/mnt/user-data/outputs/Final_Study_v1"
OUTD = os.path.dirname(STUDY)
FINAL = "MANIFEST_SHA256_FINAL.txt"
EARLIER = ["MANIFEST_SHA256.txt", "MANIFEST_SHA256_REV2.txt", "MANIFEST_SHA256_REV3.txt", "MANIFEST_SHA256_FROZEN.txt",
           "MANIFEST_SHA256_A9.txt", "MANIFEST_SHA256_CODE.txt", "MANIFEST_SHA256_GATES.txt", "MANIFEST_SHA256_A10.txt",
           "MANIFEST_SHA256_RUN.txt"]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def verify_manifest(m):
    path = os.path.join(STUDY, m)
    if not os.path.exists(path):
        return None
    bad, n = [], 0
    for line in open(path).read().splitlines():
        parts = line.split("  ", 1)
        if len(parts) == 2 and len(parts[0]) == 64:
            n += 1
            f = os.path.join(STUDY, parts[1])
            if not os.path.exists(f) or sha(f) != parts[0]:
                bad.append(parts[1])
    return n, bad


def main():
    t = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    report = []
    for m in EARLIER:
        r = verify_manifest(m)
        if r is None:
            continue
        n, bad = r
        report.append(f"{m}: {n} entries, {len(bad)} mismatches")
        if bad:
            print("\n".join(report))
            raise SystemExit(f"{m} does not verify: {bad[:5]}")
    files = sorted(os.path.relpath(os.path.join(r, f), STUDY) for r, _, fs in os.walk(STUDY) for f in fs
                   if os.path.relpath(os.path.join(r, f), STUDY) not in (FINAL, FINAL.replace(".txt", ".sha256")))
    files = [f for f in files if "__pycache__" not in f and not f.endswith(".pyc")]
    with open(os.path.join(STUDY, FINAL), "w") as fh:
        fh.write(f"SHA-256 MANIFEST -- Final_Study_v1, final (after FINAL_V1 run and analysis), {t}\n{len(files)} files\n\n")
        for f in files:
            fh.write(f"{sha(os.path.join(STUDY, f))}  {f}\n")
    msha = sha(os.path.join(STUDY, FINAL))
    open(os.path.join(STUDY, FINAL.replace(".txt", ".sha256")), "w").write(f"{msha}  {FINAL}\nfinalized {t}\n")
    zpath = os.path.join(OUTD, "Final_Study_v1_FINAL.zip")
    if os.path.exists(zpath):
        raise SystemExit("archive exists; not overwritten")
    allf = files + [FINAL, FINAL.replace(".txt", ".sha256")]
    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as z:
        for f in allf:
            z.write(os.path.join(STUDY, f), arcname=os.path.join("Final_Study_v1", f))
    man = {l.split("  ", 1)[1]: l.split("  ", 1)[0] for l in open(os.path.join(STUDY, FINAL)).read().splitlines()
           if len(l.split("  ", 1)) == 2 and len(l.split("  ", 1)[0]) == 64}
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(allf)
        for n in names:
            rel = n[len("Final_Study_v1/"):]
            if rel in man:
                h = hashlib.sha256(z.read(n)).hexdigest()
                assert h == man[rel], f"zip member {rel} differs"
    zsha = sha(zpath)
    open(zpath + ".sha256", "w").write(f"{zsha}  Final_Study_v1_FINAL.zip\nfinalized {t}\n")
    print("\n".join(report))
    print(f"manifest {FINAL}: {len(files)} files, SHA-256 {msha}")
    print(f"archive {zpath}: {len(allf)} members, {os.path.getsize(zpath) / 1e6:.1f} MB, SHA-256 {zsha}")


if __name__ == "__main__":
    main()
