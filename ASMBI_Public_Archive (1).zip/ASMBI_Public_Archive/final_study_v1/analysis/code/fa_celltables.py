"""Cell-level outputs (record 10.4): every Section-6 measure with MCSEs for every module cell and
estimator, failures by type, near-singular frequencies, paired contrasts, diagnostic means, and the
cell-definition map."""
import os

import fa_common as F
from fa_ctx import cov_band, centering, size_class

CONV = ["n_success", "failures", "failure_rate", "failure_rate_mcse", "conditional_on_success", "bias", "bias_mcse",
        "emp_se", "emp_se_mcse", "mean_se", "mean_se_mcse", "se_ratio", "se_ratio_bmcse", "rmse", "rmse_mcse",
        "coverage", "coverage_mcse", "width_mean", "width_mean_mcse", "width_median", "width_median_bmcse",
        "rejection", "rejection_mcse", "bind_rate", "bind_rate_mcse"]
ROB = ["median_bias", "median_bias_bmcse", "mad_sd", "mad_sd_bmcse", "median_se", "median_se_bmcse",
       "median_se_over_mad", "median_se_over_mad_bmcse", "median_abs_err", "median_abs_err_bmcse",
       "batch_rmse_min", "batch_rmse_min_mcse", "batch_rmse_max", "batch_rmse_max_mcse", "batch_rmse_ratio",
       "tail_share_sse", "tail_share_se", "tail_driven", "p99_abs_err", "p99_abs_err_bmcse", "p999_abs_err",
       "p999_abs_err_bmcse", "max_abs_err", "p99_se", "p99_se_bmcse", "p999_se", "p999_se_bmcse", "max_se",
       "n_abs_err_gt1", "n_abs_err_gt1_mcse", "n_se_gt0_5", "n_se_gt0_5_mcse", "n_se_gt1", "n_se_gt1_mcse",
       "n_se_gt5", "n_se_gt5_mcse"]
BASE_COLS = ["module", "cell", "config", "R", "gamma_W", "rejection_is", "estimator", "label", "display"]


def _display(cell, e):
    if e in F.SUPPLEMENTARY_ONLY:
        return "supplementary"
    if e == "E-3":
        return "headline (Table 4 only)"
    if e == "E-12c":
        return "mechanism tables"
    if e in F.HEADLINE:
        return "headline"
    return "supplementary"


def base(cell, e):
    return {"module": cell["module"], "cell": cell["cell"], "config": cell["config"], "R": cell["R"],
            "gamma_W": cell["gamma_W"], "rejection_is": "Type I error" if cell["null"] else "power",
            "estimator": e, "label": F.LABEL[e], "display": _display(cell, e)}


def write_all(ctx):
    out = F.ensure(os.path.join(F.OUT, "cell_level"))
    conv, rob, fails, ns_rows, pair_rows, diag_rows = [], [], [], [], [], []
    for cell in ctx.cells:
        p1 = ctx.p1(cell)
        for e in F.EST_ALL:
            m = p1["estimators"].get(e)
            if e == "E-10":
                if cell["battery"] == "FULL" and cell["module"] == "X4":
                    r = base(cell, e)
                    r["status"] = F.E10_ABSENT
                    conv.append(r)
                continue
            if m is None:
                continue
            r = base(cell, e)
            r.update({k: m.get(k) for k in CONV})
            r["coverage_band"] = cov_band(m.get("coverage"))
            r["centering"] = centering(m.get("bias"), m.get("bias_mcse"))
            r["size"] = size_class(m.get("rejection"), m.get("rejection_mcse")) if cell["null"] else ""
            r["R_used"] = p1["R_used"]
            conv.append(r)
            q = base(cell, e)
            q.update({k: m.get(k) for k in ROB})
            q["batch_rmse"] = m.get("batch_rmse")
            rob.append(q)
            fr = base(cell, e)
            fr.update(n_success=m["n_success"], failure_rate=m["failure_rate"],
                      conditional_on_success=m["conditional_on_success"])
            for code in range(1, len(F.FAIL_NAMES)):
                fr[F.FAIL_NAMES[code]] = m[f"fail_code{code}"]
            fails.append(fr)
        for e, v in p1["near_singular"].items():
            r = base(cell, e)
            r.update(v)
            ns_rows.append(r)
        for k, v in p1["pairs"].items():
            a, b = k.split("|")
            r = {kk: cell[kk] for kk in ("module", "cell", "config", "R", "gamma_W")}
            r.update(estimator=a, reference=b, **{kk: vv for kk, vv in v.items()})
            pair_rows.append(r)
        d = {kk: cell[kk] for kk in ("module", "cell", "config", "R", "gamma_W")}
        for k, v in p1["diag"].items():
            if k.startswith("_"):
                d.update({f"group_failures:{kk}": vv for kk, vv in v.items()})
                continue
            d[f"{k}:mean"] = v["mean"]
            d[f"{k}:mcse"] = v["mcse"]
            d[f"{k}:n"] = v["n"]
        diag_rows.append(d)
    F.write_csv(os.path.join(out, "CELL_LEVEL_CONVENTIONAL.csv"), conv,
                BASE_COLS + ["R_used"] + CONV + ["coverage_band", "centering", "size", "status"])
    F.write_csv(os.path.join(out, "CELL_LEVEL_ROBUST_AND_TAILS.csv"), rob, BASE_COLS + ROB + ["batch_rmse"])
    F.write_csv(os.path.join(out, "FAILURES_BY_TYPE.csv"), fails)
    F.write_csv(os.path.join(out, "NEAR_SINGULAR_FREQUENCY.csv"), ns_rows)
    F.write_csv(os.path.join(out, "PAIRED_CONTRASTS_WITHIN_CONFIGURATION.csv"), pair_rows)
    F.write_csv(os.path.join(out, "DIAGNOSTIC_MEANS.csv"), diag_rows)
    return {"conventional_rows": len(conv), "robust_rows": len(rob), "pair_rows": len(pair_rows)}


def write_cell_map(ctx, outputs_by_key):
    rows = []
    for c in ctx.cells:
        p1 = ctx.p1(c)
        rows.append({
            "module": c["module"], "cell": c["cell"], "config": c["config"], "config_id": c["config_id"],
            "seed_cell_id": c["seed_cell_id"],
            "seed_range": f"FINAL_V1_PANEL|{c['seed_cell_id']}|r, r = 0..{c['R'] - 1} (folds FINAL_V1_FOLDS, "
                          f"same key){'; OOS FINAL_V1_OOS' if c['module'] == 'D' else ''}",
            "R": c["R"], "R_used": p1["R_used"], "battery": c["battery"], "gamma_W": c["gamma_W"], "N": c["N"],
            "T": c["T"], "icc": c["icc"], "rho_e": c["rho_e"], "kappa": c["kappa"], "tau": c["tau"],
            "pi": c["pi"], "f": c["f"], "sd_e": c["sd_e"], "sd_ZH_within": c["sd_W"], "lambda1": c["lambda1"],
            "expected_labeled_clusters": c["expected_labeled"], "theta0_key": c["theta0_key"],
            "theta0": p1["theta0"], "source_file": f"run/raw/{c['config']}.npz",
            "source_sha256": p1["checkpoint_sha256"], "configuration_modules": "+".join(c["modules"]),
            "outputs": ";".join(sorted(outputs_by_key.get(c["key"], []))),
        })
    return F.write_csv(os.path.join(F.OUT, "CELL_DEFINITION_MAP.csv"), rows)
