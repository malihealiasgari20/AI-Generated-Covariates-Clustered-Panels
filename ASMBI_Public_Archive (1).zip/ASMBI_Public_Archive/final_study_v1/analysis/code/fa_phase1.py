"""Phase 1: per (configuration, R) quantities -- every record-6 measure for every estimator, with
analytic and bootstrap MCSEs, within-configuration paired contrasts, failure detail, near-singular
frequencies and per-replication diagnostic means. One JSON (point values) and one NPZ (bootstrap
draws, float32) per (configuration, R) in the cache. No across-cell quantity is computed here.
"""
import json, math, os, time

import numpy as np

import fa_common as F
import fa_load
import fa_metrics as M

PAIRS_FULL = [("E-12a", "E-5"), ("E-12b", "E-12a"), ("E-12c", "E-5"), ("E-12b", "E-5"), ("E-8", "E-6"),
              ("E-12a", "HT-TDS-CF"), ("E-5", "E-12a"), ("E-5", "E-12b"), ("E-12c", "E-12a"), ("E-12c", "E-12b"),
              ("HT-TDS-I", "E-6"), ("PS-TDS-I", "E-6"), ("HT-TDS-I", "E-9"), ("PS-TDS-I", "E-9"),
              ("E-12a", "E-6"), ("E-12b", "E-6"), ("E-6H", "E-6")]
_IDX = {}


def boot_matrices(R):
    if R not in _IDX:
        _IDX[R] = M.boot_indices(R)
    return _IDX[R]


def out_paths(name, R):
    d = F.ensure(os.path.join(F.CACHE, "phase1"))
    return os.path.join(d, f"{name}_R{R}.json"), os.path.join(d, f"{name}_R{R}.npz")


def diag_summary(cfg, R):
    out = {}
    for k, v in sorted(cfg.diag.items()):
        if k == "diag_runtime" or k.startswith("diag_fail__"):
            continue
        x = np.asarray(v[:R], dtype=float)
        fin = np.isfinite(x)
        n = int(fin.sum())
        if n == 0:
            out[k] = {"n": 0, "mean": None, "sd": None, "mcse": None}
            continue
        sd = float(np.std(x[fin], ddof=1)) if n > 1 else float("nan")
        out[k] = {"n": n, "mean": float(np.mean(x[fin])), "sd": sd, "mcse": sd / math.sqrt(n) if n > 1 else None,
                  "min": float(np.min(x[fin])), "max": float(np.max(x[fin]))}
    fails = {k: int(np.nansum(np.asarray(v[:R], dtype=float))) for k, v in cfg.diag.items() if k.startswith("diag_fail__")}
    out["_diagnostic_group_failures"] = fails
    return out


def near_singular(cfg, R, ests):
    out = {}
    for e in ests:
        if e not in F.SCHUR:
            continue
        v = cfg.diag.get(f"s_nt__{e}")
        if v is None:
            continue
        v = np.asarray(v[:R], dtype=float)
        ok = cfg.est[e]["fail"][:R] == 0
        m = ok & np.isfinite(v)
        n = int(m.sum())
        out[e] = {"n_recorded": n, "n_success": int(ok.sum()),
                  "freq_snt_lt_0.05": float(np.mean(v[m] < 0.05)) if n else None,
                  "freq_s_negative": float(np.mean(v[m] < 0)) if n else None,
                  "min_snt": float(np.min(v[m])) if n else None}
    return out


def process(task):
    name, theta0_key, R_list, ests_by_R = task
    t0 = time.time()
    cfg = fa_load.Config(name, theta0_key)
    written = []
    for R in R_list:
        ests = ests_by_R[R]
        R_eff = R
        if F.MODE != "production":       # mechanical test runs are capped
            R_eff = min(R, min(cfg.est[e]["fail"].size for e in ests))
        else:
            for e in ests:
                assert cfg.est[e]["fail"].size >= R, f"{name} {e}: {cfg.est[e]['fail'].size} rows < {R}"
        I, C = boot_matrices(R_eff)
        res = {"config": name, "config_id": cfg.config_id, "R_module": R, "R_used": R_eff, "theta0": cfg.theta0,
               "checkpoint_sha256": cfg.sha256, "content_digest": cfg.content_digest, "estimators": {},
               "pairs": {}, "near_singular": {}, "diag": diag_summary(cfg, R_eff),
               "fail_details_all_rows": cfg.fail_details}
        draws = {}
        for e in ests:
            a = cfg.arrays(e, R_eff)
            pt = M.point(a, cfg.theta0)
            bd = M.boot(a, cfg.theta0, I, C)
            for s in M.BOOT_STATS:
                pt[f"{s}_bmcse"] = M.mcse_from_draws(bd[s])
                draws[f"{e}|{s}"] = np.asarray(bd[s], dtype=np.float32)
            res["estimators"][e] = pt
        pairs = []
        if "E-2" in ests:
            pairs += [(e, "E-2") for e in ests if e != "E-2"]
        pairs += [p for p in PAIRS_FULL if p[0] in ests and p[1] in ests]
        for a_, b_ in pairs:
            A, Bb = cfg.arrays(a_, R_eff), cfg.arrays(b_, R_eff)
            pp = M.pair_point(A, Bb, cfg.theta0)
            rr = M.pair_boot(A, Bb, cfg.theta0, C)
            with np.errstate(invalid="ignore", divide="ignore"):
                lrr = np.log(rr)
            pp["rmse_ratio_bmcse"] = M.mcse_from_draws(rr)
            pp["log_rmse_ratio_bmcse"] = M.mcse_from_draws(lrr)
            pp["log_rmse_ratio_ci95"] = M.pct(lrr)
            pp["rmse_ratio_ci95"] = M.pct(rr)
            res["pairs"][f"{a_}|{b_}"] = pp
            draws[f"RR|{a_}|{b_}"] = np.asarray(rr, dtype=np.float32)
        res["near_singular"] = near_singular(cfg, R_eff, ests)
        res["seconds"] = round(time.time() - t0, 2)
        pj, pn = out_paths(name, R)
        F.dump_json(pj, res)
        np.savez(pn, **draws)
        written.append((pj, pn))
    return {"config": name, "R": R_list, "seconds": round(time.time() - t0, 2)}
