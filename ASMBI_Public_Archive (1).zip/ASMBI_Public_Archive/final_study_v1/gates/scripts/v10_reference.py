"""G-E (V10), step 2 of 3 -- the reference implementation (isolated ppi-python 0.2.3 environment only).

Reads v10_inputs.npz and writes v10_ppi_outputs.npz with
  V10.1: ppi_ols_pointestimate and ppi_ols_ci (alpha 0.05) for each dataset, coord in {0, None},
         lambda in {1.0, 0.5, None}
  V10.2: ppi_py.ppi._calc_lam_glm(grads, grads_hat, grads_hat_unlabeled, inv_hessian, coord=0, clip=True)
         and the same with clip=False, on each gate panel's arrays.
Usage: <venv>/bin/python -I -B v10_reference.py <v10_inputs.npz> <v10_ppi_outputs.npz> <versions.json>
"""
import json, sys
from importlib import metadata

import numpy as np
from ppi_py.ppi import _calc_lam_glm, ppi_ols_ci, ppi_ols_pointestimate

inp = np.load(sys.argv[1])
out = {}
CASES = [("given", 1.0), ("given", 0.5), ("estimated", None)]
for j in range(5):
    X, Y, Yh, Xu, Yhu = (inp[f"d{j}_{k}"] for k in ("X", "Y", "Yhat", "X_unlabeled", "Yhat_unlabeled"))
    for coord in (0, None):
        for kind, lam in CASES:
            tag = f"d{j}_c{coord}_{kind}{'' if lam is None else lam}"
            out[f"{tag}_theta"] = np.asarray(ppi_ols_pointestimate(X, Y, Yh, Xu, Yhu, lam=lam, coord=coord), dtype=float)
            lo, hi = ppi_ols_ci(X, Y, Yh, Xu, Yhu, alpha=0.05, lam=lam, coord=coord)
            out[f"{tag}_lo"], out[f"{tag}_hi"] = np.asarray(lo, dtype=float), np.asarray(hi, dtype=float)
i = 0
while f"p{i}_grads" in inp.files:
    a = [inp[f"p{i}_{k}"] for k in ("grads", "grads_hat", "grads_hat_unlabeled", "inv_hessian")]
    out[f"p{i}_lam"] = np.asarray(_calc_lam_glm(*a, coord=0, clip=True), dtype=float)
    out[f"p{i}_lam_raw"] = np.asarray(_calc_lam_glm(*a, coord=0, clip=False), dtype=float)
    i += 1
np.savez(sys.argv[2], **out)
vers = {p: metadata.version(p) for p in ("ppi-python", "numpy", "scipy", "statsmodels", "numba", "llvmlite",
                                         "pandas", "scikit-learn")}
vers["python"] = sys.version.split()[0]
json.dump(vers, open(sys.argv[3], "w"), indent=1, sort_keys=True)
print(f"reference outputs written: {len(out)} arrays; versions {vers}")
