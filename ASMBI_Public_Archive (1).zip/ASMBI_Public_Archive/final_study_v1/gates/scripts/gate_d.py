"""G-D -- coding invariance (record 10.1 step 4; 3.3, 3.4 V10.3).

Part 1. The Stage-2 coding-invariance battery (s2_invariance.py, frozen bd5960a3) on FINAL_V1 gate panels,
at delta = 0.10 only (record 0.5 and 3.3: the only TDS constant computed in FINAL_V1; the frozen battery's
extra delta = 1.0 pass is not repeated). Its helper functions, transformations and comparison metric are
copied verbatim. Panels: 8 per configuration (FINAL_V1_GATE|G-D|PANEL|<seed id>|r) for four FINAL_V1
configurations: baseline (ICC 0.30, rho 0, kappa 0), contaminated (rho 0.60, kappa 0.60), sparse
validation (m 0.33) and very sparse, noisy validation (X4 f 0.10, sd_e 0.80), where the floor binds.
Tests (a) nuisance recoding (diagonal, upper-triangular), (b) period-column scaling, (c) outcome span,
(d) target scaling, (e) inactive floor = base, (f) cluster and within-cluster row reordering, cross-checks;
tolerance 1e-10 for every Schur-solver output of s2_core.estimate_all (G-C shows the FINAL_V1 TDS wrappers
equal it exactly). Negative control: the historical CDA (full-Gram floor), whose target estimate moves.
Part 2. E-10 (V10.3): tests (a)-(d) and (f) to 1e-10 on the 20 V10 gate panels (gate_common.v10_gate_panels),
through fv1.e10.e10_core on transformed designs; the untransformed harness must equal e10_fit exactly.
"""
import json, os, sys
from dataclasses import replace

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
import numpy as np  # noqa: E402
from stage0_dgp import generate_panel, make_rng, within_demean  # noqa: E402
from stage0_naive import _period_design  # noqa: E402
from stage0_ht import ht_fit  # noqa: E402
from stage0_cda import e9_fit  # noqa: E402
from stage1_design_aware import generalized_rectifier_fit, _calibration_matrix, _rows, crossfit_predictions  # noqa: E402
from s2_core import estimate_all, full_gram_floor_point  # noqa: E402
from fv1 import registry, e10  # noqa: E402

G.check_code_identity()
configs, _ = registry.load(G.STUDY)
ns, _, _ = registry._rebuild(G.STUDY)
TOL = 1e-10


# ---- verbatim from s2_invariance.py (frozen, bd5960a3) -----------------------------------------
def cf_explicit(pan, fold_of):        # crossfit predictions with fold membership carried by unit
    N, T = pan.Y.shape; C = _calibration_matrix(pan); zh = pan.ZH.reshape(-1); lab = np.flatnonzero(pan.labeled)
    Zo = np.zeros((N, T)); coefs = []
    for f in range(5):
        te = lab[fold_of[lab] == f]; tr = lab[fold_of[lab] != f]
        cf, *_ = np.linalg.lstsq(C[_rows(tr, T)], zh[_rows(tr, T)], rcond=None); coefs.append(cf)
        Zo[te] = (C[_rows(te, T)] @ cf).reshape(te.size, T)
    return (C @ np.mean(coefs, axis=0)).reshape(N, T), Zo
def fold_labels(pan, key):
    lab = np.flatnonzero(pan.labeled); fo = np.full(pan.Y.shape[0], -1)
    for f, idx in enumerate(np.array_split(make_rng(*key).permutation(lab), 5)): fo[idx] = f
    return fo
def permute_units(pan, p):
    from dataclasses import fields
    kw = {f.name: (getattr(pan, f.name)[p] if isinstance(getattr(pan, f.name), np.ndarray) and getattr(pan, f.name).ndim >= 1
                   and getattr(pan, f.name).shape[0] == pan.Y.shape[0] else getattr(pan, f.name)) for f in fields(pan)}
    return type(pan)(**kw)
Rdiag = np.diag([2.0, 0.5, 3.0, 0.25, 1.5, 4.0, 0.7, 1.2]); Rup = np.eye(8) + np.triu(np.full((8, 8), 0.3), 1)
Rper = np.diag([1.0, 0.5, 2.0, 3.0, 0.2, 1.7, 5.0, 0.8]); cvec = np.array([-0.30, -0.20, -0.10, 0.10, 0.20, 0.30, 0.40, 0.0])
def cmp(a, b):
    return max(min(abs(a[k][i] - b[k][i]), abs(a[k][i] - b[k][i]) / max(abs(b[k][i]), 1e-300)) for k in a if not k.startswith("_") and not np.isnan(b[k][0]) for i in (0, 1))
# -------------------------------------------------------------------------------------------------

FV1_TDS = ("HT-TDS-I@0.1", "PS-TDS-I@0.1", "HT-TDS-CF@0.1")


def cmp_fv1(a, b):  # the same metric restricted to the three TDS variants FINAL_V1 uses
    return cmp({k: a[k] for k in FV1_TDS}, {k: b[k] for k in FV1_TDS if True})


base0 = dict(N=300, T=8, icc=0.3, tau=0.1, sd_ZH_within=0.62, lambda1=(1.2, 1.05, 0.45), gamma_W=0.15)
cells = {
    "baseline": G.one(configs, **base0, rho_e=0.0, kappa=0.0, pi=(0.15, 0.3, 0.6), sd_e=0.55),
    "contaminated": G.one(configs, **base0, rho_e=0.6, kappa=0.6, pi=(0.15, 0.3, 0.6), sd_e=0.55),
    "sparse m 0.33": G.one(configs, **base0, rho_e=0.6, kappa=0.0, pi=ns["pi_target_fraction"](0.35 * 0.33), sd_e=0.55),
    "very sparse f 0.10, sd_e 0.80": G.one(configs, **base0, rho_e=0.6, kappa=0.0, pi=ns["pi_target_fraction"](0.10), sd_e=0.80),
}
keys = ["recode_diag", "recode_upper", "period_scale", "outcome_span", "target_scale", "inactive", "perm_cluster", "perm_row", "xcheck"]
res = {k: [] for k in keys}
res_fv1 = {k: [] for k in keys if k not in ("inactive", "xcheck")}
neg = {"recode": [], "period_scale": [], "outcome_span_frozen_e9": []}
nbind = {k: 0 for k in FV1_TDS}; nrep = 0; skipped = []
dl = 0.10
for cname, cfg in cells.items():
    D = _period_design(cfg.p.N, cfg.p.T)
    sid = cfg.seed_cell_id
    for r in range(8):
        pan = generate_panel(cfg.p, G.gate_rng("G-D", "PANEL", sid, r)); key = G.gate_key("G-D", "FOLDS", sid, r)
        if pan.labeled.sum() < 10:
            skipped.append(f"{cname} r={r}"); continue
        Zf, Zo, _ = crossfit_predictions(pan, make_rng(*key), False); nrep += 1
        fo = fold_labels(pan, key); Zf2, Zo2 = cf_explicit(pan, fo)
        res["xcheck"].append(max(np.abs(Zf - Zf2).max(), np.abs(Zo - Zo2).max()))
        base = estimate_all(pan, D, Zf, Zo, deltas=(dl,))
        for k in FV1_TDS:
            nbind[k] += int(base[k][3])
        tr = {"recode_diag": estimate_all(pan, D, Zf, Zo, (dl,), nuis_R=Rdiag),
              "recode_upper": estimate_all(pan, D, Zf, Zo, (dl,), nuis_R=Rup),
              "period_scale": estimate_all(pan, D, Zf, Zo, (dl,), nuis_R=Rper),
              "outcome_span": estimate_all(replace(pan, Y=pan.Y + 0.75 * pan.X + cvec[None, :]), D, Zf, Zo, (dl,))}
        p = make_rng(*G.gate_key("G-D", "PERM", sid, r)).permutation(pan.Y.shape[0]); pp = permute_units(pan, p)
        Zfp, Zop = cf_explicit(pp, fo[p]); tr["perm_cluster"] = estimate_all(pp, D, Zfp, Zop, (dl,))
        N, T = pan.Y.shape
        rp = np.concatenate([i * T + make_rng(G.GATE_ID, f"G-D|ROWPERM|{sid}|{i}", r).permutation(T) for i in range(N)])
        tr["perm_row"] = estimate_all(pan, D, Zf, Zo, (dl,), rowperm=rp)
        for k, v in tr.items():
            res[k].append(cmp(v, base)); res_fv1[k].append(cmp_fv1(v, base))
        p2 = replace(pan, ZH=2 * pan.ZH, ZL=2 * pan.ZL.astype(float)); Zf2s, Zo2s, _ = crossfit_predictions(p2, make_rng(*key), False)
        s2 = estimate_all(p2, D, Zf2s, Zo2s, (dl,))
        res["target_scale"].append(max(abs(2 * s2[k][i] - base[k][i]) / max(abs(base[k][i]), 1e-12) for k in base if not k.startswith("_") and not np.isnan(base[k][0]) for i in (0, 1)))
        res_fv1["target_scale"].append(max(abs(2 * s2[k][i] - base[k][i]) / max(abs(base[k][i]), 1e-12) for k in FV1_TDS if not np.isnan(base[k][0]) for i in (0, 1)))
        for k, v in base.items():
            if "@" in k and not v[3]:
                b0 = base[k.split("@")[0].replace("HT-TDS-I","E6").replace("PS-TDS-I","PS-I").replace("HT-TDS-CF","E12a").replace("PS-TDS-CF","PS-CF")]
                res["inactive"].append(max(abs(v[0] - b0[0]), abs(v[1] - b0[1])))
        e6 = ht_fit(pan, D)
        e12 = generalized_rectifier_fit(pan, "ht", "crossfit", make_rng(*key), False, D)
        res["xcheck"].append(max(abs(base["E6"][0] - e6[0]), abs(base["E6"][1] - e6[1]), abs(base["E12a"][0] - e12[0]), abs(base["E12a"][1] - e12[1])))
        e9 = e9_fit(pan, D)
        if "fail" not in e9:
            fg = full_gram_floor_point(pan, D); res["xcheck"].append(abs(fg - e9["theta"]))
            neg["recode"].append(abs(full_gram_floor_point(pan, D, Rup) - fg)); neg["period_scale"].append(abs(full_gram_floor_point(pan, D, Rper) - fg))
            e9s = e9_fit(replace(pan, Y=pan.Y + 0.75 * pan.X + cvec[None, :]), D)
            if "fail" not in e9s: neg["outcome_span_frozen_e9"].append(abs(e9s["theta"] - e9["theta"]))

checks = []


def check(label, ok, **info):
    checks.append({"check": label, "pass": bool(ok), **info})
    print(f"  {'PASS' if ok else 'FAIL'}  {label}  " + ", ".join(f"{k} {v}" for k, v in info.items()), flush=True)


lab = {"recode_diag": "(a) nuisance recoding, diagonal", "recode_upper": "(a) nuisance recoding, upper-triangular mix",
       "period_scale": "(b) nonuniform period-column scaling", "outcome_span": "(c) Y* = Y + 0.75X + Dc",
       "target_scale": "(d) target scaling 2Z: 2theta, 2SE (relative)", "inactive": "(e) inactive floor == base (point, SE)",
       "perm_cluster": "(f) cluster reordering (folds carried by unit)", "perm_row": "(f) within-cluster row reordering",
       "xcheck": "cross-checks: folds, E6/E12a vs Exp-5, floor re-impl vs e9"}
print(f"Part 1: Stage-2 battery on {nrep} FINAL_V1 gate panels, delta 0.10; floor binding instances "
      f"{ {k.split('@')[0]: v for k, v in nbind.items()} }")
for k in keys:
    m = max(res[k]) if res[k] else float("nan")
    extra = {"max_dev": f"{m:.1e}", "n": len(res[k])}
    if k in res_fv1 and res_fv1[k]:
        extra["max_dev_FINAL_V1_TDS"] = f"{max(res_fv1[k]):.1e}"
    check(f"TDS battery {lab[k]}", bool(res[k]) and m <= TOL, **extra)
check("the TDS floor binds on gate panels at delta 0.10 (the invariance of the bound floor is exercised)",
      sum(nbind.values()) > 0, binding=sum(nbind.values()))
negsum = {k: (max(v) if v else None, float(np.median(v)) if v else None, len(v)) for k, v in neg.items()}
print("  NEGATIVE CONTROL -- historical CDA (full-Gram floor) target shifts, expected NONZERO:")
for k, (mx, md, n) in negsum.items():
    print(f"    {k:<26} max |change| {mx:.2e}  median {md:.2e}  (n={n})")
check("negative control: the historical CDA moves under recoding (the battery detects non-invariance)",
      negsum["recode"][0] is not None and negsum["recode"][0] > 1e-8, max_change=f"{negsum['recode'][0]:.2e}")

# ---- Part 2: E-10 (V10.3)


def e10_from(pan, D, nuis_R=None, rowperm=None):
    N, T = pan.Y.shape
    yy = within_demean(pan.Y)
    nu = np.column_stack([within_demean(pan.X).reshape(N * T), D])
    if nuis_R is not None:
        nu = nu @ nuis_R
    W = lambda Z: np.column_stack([within_demean(np.asarray(Z, dtype=float)).reshape(N * T), nu]).reshape(N, T, -1)
    WL, WH = W(pan.ZL), W(pan.ZH)
    if rowperm is not None:
        WL = np.take_along_axis(WL, rowperm[:, :, None], axis=1); WH = np.take_along_axis(WH, rowperm[:, :, None], axis=1)
        yy = np.take_along_axis(yy, rowperm, axis=1)
    AL, AH = np.einsum("ntj,ntk->njk", WL, WL), np.einsum("ntj,ntk->njk", WH, WH)
    bL, bH = np.einsum("ntk,nt->nk", WL, yy), np.einsum("ntk,nt->nk", WH, yy)
    lab = pan.labeled.astype(bool); U = ~lab; n = lab.sum()
    out = e10.e10_core(AH[lab], bH[lab], AL[lab], bL[lab], AL[U], bL[U], AH[lab].sum(axis=0) / n, coord=0)
    return (out["theta"][0], out["se"][0])


def m2(a, b):
    return max(min(abs(a[i] - b[i]), abs(a[i] - b[i]) / max(abs(b[i]), 1e-300)) for i in (0, 1))


panels = G.v10_gate_panels(configs, ns["pi_target_fraction"])
e = {k: [] for k in ("recode_diag", "recode_upper", "period_scale", "outcome_span", "target_scale", "perm_cluster", "perm_row")}
harness_exact = True
for cfg, r, pan, D in panels:
    th, se, _x = e10.e10_fit(pan, D)
    b = e10_from(pan, D)
    harness_exact &= (b[0] == th and b[1] == se)
    e["recode_diag"].append(m2(e10_from(pan, D, Rdiag), b))
    e["recode_upper"].append(m2(e10_from(pan, D, Rup), b))
    e["period_scale"].append(m2(e10_from(pan, D, Rper), b))
    e["outcome_span"].append(m2(e10_from(replace(pan, Y=pan.Y + 0.75 * pan.X + cvec[None, :]), D), b))
    s = e10_from(replace(pan, ZH=2 * pan.ZH, ZL=2 * pan.ZL.astype(float)), D)
    e["target_scale"].append(max(abs(2 * s[i] - b[i]) / max(abs(b[i]), 1e-12) for i in (0, 1)))
    p = make_rng(*G.gate_key("V10", "PERM", cfg.seed_cell_id, r)).permutation(pan.Y.shape[0])
    e["perm_cluster"].append(m2(e10_from(permute_units(pan, p), D), b))
    rpT = np.stack([make_rng(G.GATE_ID, f"V10|ROWPERM|{cfg.seed_cell_id}|{i}", r).permutation(pan.Y.shape[1])
                    for i in range(pan.Y.shape[0])])
    e["perm_row"].append(m2(e10_from(pan, D, rowperm=rpT), b))
print(f"Part 2: E-10 (V10.3) on the 20 V10 gate panels")
check("E-10 harness without transformation equals fv1.e10.e10_fit exactly", harness_exact)
for k, v in e.items():
    check(f"E-10 {lab[k]}", max(v) <= TOL, max_dev=f"{max(v):.1e}", n=len(v))

part1 = all(c["pass"] for c in checks if c["check"].startswith(("TDS", "the TDS", "negative")))
part2 = all(c["pass"] for c in checks if c["check"].startswith("E-10"))
status = "PASS" if part1 and part2 else "FAIL"
G.write_report("G-D", {"gate": "G-D", "status": status, "utc": G.utc(), "delta": dl, "panels_part1": nrep,
                       "skipped_part1": skipped, "configurations_part1": {k: v.name for k, v in cells.items()},
                       "floor_binding": nbind, "negative_control": negsum, "e10_V10.3": {"pass": part2,
                       "max_dev": {k: max(v) for k, v in e.items()},
                       "panels": [(c.name, r) for c, r, _, _ in panels]}, "checks": checks})
G.write_report("V10.3", {"test": "V10.3", "status": "PASS" if part2 else "FAIL", "utc": G.utc(), "tolerance": TOL,
                         "max_dev": {k: max(v) for k, v in e.items()}, "harness_exact": harness_exact,
                         "panels": [(c.name, r) for c, r, _, _ in panels]})
print(f"G-D {status} (Part 1 {'PASS' if part1 else 'FAIL'}; Part 2 / V10.3 {'PASS' if part2 else 'FAIL'})")
sys.exit(0 if status == "PASS" else 1)
