"""G-A -- dependency integrity (record 10.1 step 4): dependency hashes equal the sealed manifests.

For every frozen dependency used by the FINAL_V1 code, five hashes must agree:
  the copy in code/deps/, its entry in deps/DEPENDENCY_HASHES.json, its entry in the sealed package
  manifest, the file in the unpacked sealed package, and the member of the sealed zip archive.
The sealed manifests and zips must match the fingerprints recorded for the packages, the FINAL_V1
seals and every Final_Study_v1 manifest must verify, the code under test must be the delivered
package, and the ppi-python wheel must match the hash recorded in record 0.6(d).
"""
import io, json, os, sys, zipfile, hashlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402

PKG = {  # recorded fingerprints (package records; project status document)
    "Stage0_Reconstruction_v1.1_FROZEN": ("34de2e3f6558421311e4da84762a717715cd805bc35e9fd43e49a4a23136687a",
                                          "679f20b0f8daa67fa47016b7251ff2502a8eaca0c35a89289b9804b8f81a716a"),
    "S0.11_Holdout_Package": ("a32af1d205c7f8e0a843a32098692229138dbfa914fcaf7619d945caa7a13959",
                              "b039f138c7c6eae2cd85226454b2509572a73bd12b16ee66e3c6c035477e5528"),
    "Stage1_Experiment5": ("4c8bcb245aac86509ec77611797a43df5c6e21ff49b281ec792e4f0235fc2baf",
                           "9a9b08b1a34b4a5011268e6db9c80a43521e8e4782479efe5ac2955f0f15decb"),
    "Stage1_Experiment5_addendum": ("33b60baa15e32825902c7ff905e16812140d0a0ab0436ea13fa094ae12375581", None),
    "Stage2_Target_Direction_Stabilization": ("6e70c01d069393134c3920e223d6b77fcee69a3d1bb1afe66c17fa82de7547f8",
                                              "782b2e010ee1152468de88a3e818b312ea521ef8fdbf436de638ad4df04b77c7"),
}
PPI_WHEEL = ("/home/claude/untrusted_ppi/ppi_python-0.2.3-py3-none-any.whl",
             "f20ea31f90af3339de0f4a48f556c281493e347f49a9fea3d0e164769fdf8b24")
FV1_MANIFESTS = ("MANIFEST_SHA256.txt", "MANIFEST_SHA256_REV2.txt", "MANIFEST_SHA256_REV3.txt",
                 "MANIFEST_SHA256_FROZEN.txt", "MANIFEST_SHA256_A9.txt", "MANIFEST_SHA256_CODE.txt")


def manifest_entries(path):
    m = {}
    for line in open(path):
        parts = line.rstrip("\n").split("  ", 1)
        if len(parts) == 2 and len(parts[0]) == 64:
            m.setdefault(parts[1], set()).add(parts[0])
    return m


def verify_manifest(root, path):
    bad = []
    for rel, hs in manifest_entries(path).items():
        p = os.path.join(root, rel)
        if not os.path.exists(p) or G.sha256_file(p) not in hs or len(hs) != 1:
            bad.append(rel)
    return bad


checks, fail = [], []


def check(label, ok, **info):
    checks.append({"check": label, "pass": bool(ok), **info})
    print(f"  {'PASS' if ok else 'FAIL'}  {label}" + (f"  {info}" if info and not ok else ""), flush=True)
    if not ok:
        fail.append(label)


# 1. sealed development packages: manifests and zips against recorded fingerprints
man = {}
for pkg, (mh, zh) in PKG.items():
    mp = os.path.join(G.OUT_ROOT, pkg, "MANIFEST_SHA256.txt")
    got = G.sha256_file(mp)
    check(f"{pkg}: MANIFEST_SHA256.txt equals its recorded fingerprint", got == mh, got=got)
    man[pkg] = manifest_entries(mp)
    if zh:
        zp = os.path.join(G.OUT_ROOT, f"{pkg}.zip")
        got = G.sha256_file(zp)
        check(f"{pkg}.zip equals its recorded fingerprint", got == zh, got=got)

# 2. every dependency: deps copy = dependency record = sealed manifest = sealed file = sealed zip member
rec = json.load(open(os.path.join(G.env.DEPS_DIR, "DEPENDENCY_HASHES.json")))
zips = {pkg: zipfile.ZipFile(os.path.join(G.OUT_ROOT, f"{pkg}.zip")) for pkg, (_, zh) in PKG.items() if zh}
deps_table = []
for dest, info in sorted(rec.items()):
    if dest.startswith("_"):
        continue
    pkg, rel, want = info["source_package"], info["source_path"], info["sha256"]
    h_copy = G.sha256_file(os.path.join(G.env.DEPS_DIR, dest))
    h_man = man[pkg].get(rel, set())
    h_file = G.sha256_file(os.path.join(G.OUT_ROOT, pkg, rel))
    member = f"{pkg}/{rel}"
    h_zip = hashlib.sha256(zips[pkg].read(member)).hexdigest() if pkg in zips else None
    ok = (h_copy == want and h_man == {want} and h_file == want and (h_zip == want))
    deps_table.append({"dependency": dest, "sha256": want, "source": member, "copy": h_copy == want,
                       "sealed_manifest": h_man == {want}, "sealed_file": h_file == want,
                       "sealed_zip_member": h_zip == want})
    check(f"dependency {dest}: copy, record, sealed manifest, sealed file and zip member agree", ok)
n_deps = len(deps_table)

# 3. FINAL_V1 seals and every Final_Study_v1 manifest
for line in open(os.path.join(G.STUDY, "FINAL_V1_FROZEN.sha256")):
    h, name = line.rstrip("\n").split("  ", 1)
    check(f"FINAL_V1_FROZEN.sha256: {name}", G.sha256_file(os.path.join(G.STUDY, name)) == h)
check("frozen pre-run record is the governing record", G.sha256_file(os.path.join(G.STUDY,
      "FINAL_V1_PRE_RUN_RECORD_FROZEN.txt")) == G.RECORD_SHA)
for m in FV1_MANIFESTS:
    bad = verify_manifest(G.STUDY, os.path.join(G.STUDY, m))
    check(f"Final_Study_v1/{m} verifies", not bad, mismatched=bad)

# 4. the code under test is the delivered Step-5 package
fp, per = G.env.code_fingerprint()
check("code fingerprint equals the delivered package", fp == G.CODE_FINGERPRINT, got=fp)
check("MANIFEST_SHA256_CODE.txt equals its recorded hash",
      G.sha256_file(os.path.join(G.STUDY, "MANIFEST_SHA256_CODE.txt")) == G.CODE_MANIFEST_SHA)
G.env.verify_deps()
check("fv1.env.verify_deps() accepts every dependency", True)

# 5. the reference implementation for V10
check("ppi-python 0.2.3 wheel equals the hash recorded in record 0.6(d)",
      os.path.exists(PPI_WHEEL[0]) and G.sha256_file(PPI_WHEEL[0]) == PPI_WHEEL[1])

status = "PASS" if not fail else "FAIL"
G.write_report("G-A", {"gate": "G-A", "status": status, "utc": G.utc(), "dependencies_checked": n_deps,
                       "dependencies": deps_table, "checks": checks, "failures": fail})
print(f"G-A {status}: {len(checks) - len(fail)}/{len(checks)} checks; {n_deps} dependencies")
sys.exit(0 if not fail else 1)
