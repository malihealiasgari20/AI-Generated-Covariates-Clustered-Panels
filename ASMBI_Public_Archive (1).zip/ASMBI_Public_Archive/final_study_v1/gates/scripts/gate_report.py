"""Compose gates/FINAL_V1_GATE_REPORT.txt from the gate reports (all numbers are read from reports/*.json)."""
import json, os, sys, textwrap

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402

R = {g: json.load(open(os.path.join(G.REPORTS, f"{g}.json"))) for g in
     ("G-A", "G-B", "G-C", "G-D", "G-E", "G-F", "V10.3", "G-E_diagnosis")}
rec = json.load(open(os.path.join(G.GATES, "FINAL_V1_GATE_RECORD.json")))
vers = json.load(open(os.path.join(G.GATES, "v10", "V10_REFERENCE_VERSIONS.json")))
runlog = open(os.path.join(G.GATES, "GATE_RUN_LOG.txt")).read().strip().splitlines()
a, b, c, d, e, f, v3, dg = (R[k] for k in ("G-A", "G-B", "G-C", "G-D", "G-E", "G-F", "V10.3", "G-E_diagnosis"))
gc = lambda prefix: next(x for x in c["checks"] if x["check"].startswith(prefix))
sf = c["supplementary"]["failure_paths"]
dmax = {x["check"].replace("TDS battery ", ""): x for x in d["checks"] if x["check"].startswith("TDS battery")}
v1, v2 = e["detail"]["V10.1"], e["detail"]["V10.2"]
W = lambda s, ind="  ": textwrap.fill(s, 96, initial_indent=ind, subsequent_indent=ind)
L = []
L += ["=" * 100, "FINAL_V1 PRE-PERFORMANCE GATES -- REPORT (Step 6)",
      "Stress-Testing Inference with AI-Generated Covariates in Clustered Panels -- Nejatbakhsh & Aliasgari",
      "=" * 100, ""]
L += [W(f"Governing record FINAL_V1_PRE_RUN_RECORD_FROZEN.txt ({G.RECORD_SHA}), Section 10.1 step 4. Code under "
        f"test: the Step-5 package, fingerprint {rec['code_fingerprint']}, manifest {rec['code_manifest_sha256']}. "
        f"Every simulated quantity in the gates came from experiment id FINAL_V1_GATE (cell ids name the gate and "
        f"the stream's purpose); no FINAL_V1_PANEL, _FOLDS, _OOS or _BOOT stream was drawn, no production run was "
        f"started, and no FINAL_V1 performance quantity exists. Gate outputs are equalities, deviations, counts "
        f"and flags only."), "",
      f"  Gate record: FINAL_V1_GATE_RECORD.json, finalized {rec['finalized_utc']}", ""]
L += ["RESULT", "-" * 100]
for g in ("G-A", "G-B", "G-C", "G-D", "G-E", "G-F"):
    extra = {"G-E": f"   V10.1 {e['tests']['V10.1']}, V10.2 {e['tests']['V10.2']}, V10.3 {e['tests']['V10.3']}  ->  E-10 {rec['e10_status']}"}.get(g, "")
    L.append(f"  {g}  {rec['gates'][g]}{extra}")
L += ["", W("Consequence: the five gates the run depends on (G-A to G-D, G-F) pass. G-E fails on V10.1, so by "
            "record 3.4 E-10 is reported ABSENT for FINAL_V1 (protocol 2.2): no E-10 row is computed, no "
            "approximate replacement or substitute estimator is created, and no tolerance was relaxed. Nothing "
            "else in the design changes."), ""]

L += ["G-A  DEPENDENCY INTEGRITY", "-" * 100,
      W(f"{len(a['checks'])} checks, all {a['status']}. The manifests and zip archives of the five sealed development "
        f"packages equal their recorded fingerprints. For each of the {a['dependencies_checked']} dependencies in "
        f"code/deps/ five hashes agree: the copy, deps/DEPENDENCY_HASHES.json, the sealed package manifest, the "
        f"file in the unpacked sealed package and the member of the sealed zip. The FINAL_V1 seals "
        f"(FINAL_V1_FROZEN.sha256) and all six Final_Study_v1 manifests verify; the code fingerprint and the code "
        f"manifest equal the Step-5 package; the ppi-python 0.2.3 wheel equals the hash in record 0.6(d)."), ""]

L += ["G-B  GENERATOR EQUIVALENCE", "-" * 100,
      W(f"Reference: the sealed file Stage0_Reconstruction_v1.1_FROZEN/estimators/stage0_dgp.py itself, loaded "
        f"under a separate module name, with the sealed parameterization config/dgp_config.json and only each "
        f"configuration's design factors set. All {b['baseline_configurations']} baseline-parameter configurations "
        f"(families {', '.join(f'{k} {v}' for k, v in sorted(b['baseline_families'].items()))}): parameters equal "
        f"field by field (cut_spacing 0.65 exactly), and {b['panels_compared']} gate panels are bit-identical in "
        f"all 12 arrays. All 149 configurations: absolute cut scale within {b['max_scale_dev']:.1e} of "
        f"0.8050009202070365 and the four thresholds within {b['max_cut_dev']:.1e} of the sealed cut points "
        f"(tolerance 1e-14); the generated Z_L equals Z* discretized by the sealed absolute thresholds."), ""]

L += ["G-C  ESTIMATOR EQUIVALENCE", "-" * 100,
      W(f"20 gate panels, one for each of: " + "; ".join(f"{x['config']} {x['label']}" for x in c["configurations"]) + "."),
      W(f"{gc('every wrapper result equ')['exact_comparisons']} wrapper results equal the frozen functions "
        f"bitwise (estimate, SE, critical value, interval): E-1..E-9 against stage0_*, E-6H and E-12a/b/c against "
        f"e5_core.fit_all, HT-TDS-I, PS-TDS-I and HT-TDS-CF against s2_core.estimate_all(deltas=(0.10,)). "
        f"E-8's point estimate equals E-6's to {gc('E-8 point estimate equals')['max_abs_diff']:.1e} on "
        f"{gc('E-8 point estimate equals')['panels']} panels (tolerance 1e-10, declared before the run from the "
        f"frozen S0.9 identity check). E-12a equals HT-TDS-CF to {gc('E-12a (solve_rect) equal')['max_abs_diff']:.1e} "
        f"on the {gc('E-12a (solve_rect) equal')['panels_unbound']} panels where the floor does not bind "
        f"(tolerance 1e-12)."),
      W(f"Supplementary (beyond the pre-specified gate). The 20 panels contained no estimator failure, so the same "
        f"comparison was repeated on {sf['panels']} further gate panels of the four sparsest crossover cells: "
        f"{sf['failure_types_matched']} wrapper failures carry exactly the failure type implied by the frozen "
        f"function's outcome or the pre-specified eligibility rule, {sf['exact']} further values are bitwise equal, "
        f"0 disagreements. The record-3.8 mechanism diagnostics equal e5_core.fit_all. The S0.9 driver "
        f"s09_run.one agrees wherever it runs; it raised a TypeError on every panel with G_S <= 9, because it "
        f"cannot handle E-5 returning None below 10 labeled units (as well as E-2 below 5, the case named in "
        f"record 0.6(c)). FINAL_V1 never calls the driver, so this changes nothing; it is a clarification of 0.6(c)."), ""]

L += ["G-D  CODING INVARIANCE", "-" * 100,
      W(f"Part 1: the frozen Stage-2 battery (s2_invariance.py; functions, transformations and metric copied "
        f"verbatim) on {d['panels_part1']} FINAL_V1 gate panels of four configurations "
        f"({', '.join(f'{k} {v}' for k, v in d['configurations_part1'].items())}), at delta = 0.10 only (record 0.5, "
        f"3.3). Maximum deviations, tolerance 1e-10: " + "; ".join(f"{k} {v['max_dev']}" for k, v in dmax.items()) +
        f". The floor bound {sum(d['floor_binding'].values())} times. Negative control: the historical CDA's target "
        f"estimate moved by up to {d['negative_control']['recode'][0]:.1e} under nuisance recoding, "
        f"{d['negative_control']['period_scale'][0]:.1e} under period scaling and "
        f"{d['negative_control']['outcome_span_frozen_e9'][0]:.1e} under the outcome span (expected non-zero)."),
      W(f"Part 2 (= V10.3): E-10 on the 20 V10 gate panels; the harness without transformation equals e10_fit "
        f"exactly; maximum deviations " + "; ".join(f"{k} {val:.1e}" for k, val in v3["max_dev"].items()) +
        " (tolerance 1e-10)."), ""]

L += ["G-E  V10: E-10 AGAINST PPI-PYTHON 0.2.3", "-" * 100,
      W(f"Reference environment (isolated virtual environment, used for V10 only): " +
        ", ".join(f"{k} {v}" for k, v in sorted(vers.items())) + ". The installed ppi_py sources are identical to the "
        f"hash-verified wheel."),
      W(f"V10.1 {e['tests']['V10.1']}. Five i.i.d. predicted-outcome OLS datasets (FINAL_V1_GATE|V10.1|DATA), "
        f"coord 0 and None, lambda given (1.0, 0.5) and estimated: {v1['cases_passing']} of {v1['cases_total']} "
        f"cases within 1e-8; largest difference {v1['max_abs_diff']:.1e} (point estimate and interval)."),
      W(f"V10.2 {e['tests']['V10.2']}. On the 20 V10 gate panels, FINAL_V1's lambda^ and ppi_py._calc_lam_glm on the "
        f"same gradient arrays agree to {v2['max_abs_diff']:.1e} (clipped; unclipped {v2['max_abs_diff_unclipped']:.1e}; "
        f"tolerance 1e-12)."),
      W(f"V10.3 {e['tests']['V10.3']} (G-D Part 2)."),
      W("Diagnosis under the stop rule (reports/G-E_diagnosis.json). R1: ppi-python's outputs equal the closed form "
        f"'imputed fit + rectifier fit' to {dg['R1_reference_equals_closed_form']:.1e}, so the reference run is "
        f"valid. R2: FINAL_V1's generic code equals the solution of the PPI++ M-estimation equation, E-10's sealed "
        f"definition (record 3.4), to {dg['R2_fv1_equals_m_estimation']:.1e}. R3: on i.i.d. data the two estimators "
        f"differ by {dg['R3_structural_gap_range'][0]:.1e} to {dg['R3_structural_gap_range'][1]:.1e}; the difference "
        f"vanishes only when the labeled and unlabeled Gram matrices coincide. R4: with lambda estimated the "
        f"pilots differ for the same reason, and ppi_ols_ci also re-estimates lambda at the tuned estimate. "
        f"Verdict: {dg['verdict']}."),
      W("Stop-rule classification. No implementation defect was found, so no implementation correction exists. A "
        "change that would make V10.1 pass would change the sealed design (E-10's definition, which has no "
        "closed form for a predicted covariate, or V10.1's specification) and would need the authors' review and "
        "a dated amendment; none was made. As pre-specified in record 3.4 and instructed for Step 6, E-10 is ABSENT "
        "for FINAL_V1."), ""]

L += ["G-F  THETA_0 MAP", "-" * 100,
      W(f"The four frozen maps hold 63 entries; the 21 keys present in more than one map carry identical entries; "
        f"the union has {f['keys_union']} keys. The keys still needed are exactly the 11 listed in record 1.7, and "
        f"only those were computed, by the frozen procedure (compute_theta0, 20 auxiliary panels of 120,000 units, "
        f"contamination disabled, seeds S0_1_DGP|theta0|T|icc|rho), each with MCSE between "
        f"{min(f['new_key_mcse'].values()):.1e} and {max(f['new_key_mcse'].values()):.1e}. Complete map: "
        f"{f['keys_total']} keys, gates/FINAL_V1_THETA0_MAP.json, SHA-256 {f['map_sha256']}; every one of the 149 "
        f"configurations has a finite theta_0, and the map loads through the runner's production loader."), ""]

L += ["GATE-SCRIPT CORRECTIONS DURING THIS STEP (none touched the FINAL_V1 code or design)", "-" * 100]
L += [textwrap.fill(x, 96, initial_indent="  - ", subsequent_indent="    ") for x in runlog]
L += ["", "FILES (gates/)", "-" * 100,
      "  FINAL_V1_GATE_RECORD.json (+ .sha256)  read by the runner before any production run",
      "  FINAL_V1_THETA0_MAP.json (+ .sha256)   complete theta_0 map (G-F)",
      "  reports/                              G-A ... G-F, V10.3, G-E_diagnosis (JSON)",
      "  scripts/                              the gate scripts as run",
      "  v10/                                  V10 inputs, FINAL_V1 and ppi-python outputs, reference versions, pip log",
      "  reference/                            the ppi-python 0.2.3 wheel (hash-verified)",
      "  GATE_RUN_LOG.txt                      script corrections and reruns",
      "", "=" * 100, "END OF GATE REPORT", "=" * 100]
open(os.path.join(G.GATES, "FINAL_V1_GATE_REPORT.txt"), "w").write("\n".join(L) + "\n")
print("\n".join(L))
