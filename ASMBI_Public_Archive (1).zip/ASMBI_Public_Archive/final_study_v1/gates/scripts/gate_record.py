"""Assemble the gate record (record 10.1 step 4; runner interlock in fv1/runner.py::_gate_record).

Writes gates/FINAL_V1_GATE_RECORD.json from the six gate reports. Stop rule (Step-6 instruction):
  - G-A, G-B, G-C, G-D or G-F not PASS -> the record is written with those statuses, so the runner refuses
    any production run, and the failure is documented for diagnosis;
  - G-E (V10) not PASS -> E-10 is ABSENT for FINAL_V1 (record 3.4); no tolerance is relaxed and no
    approximation or substitute is introduced.
Finally the runner's own gate-record check is applied to the written file (nothing is computed).
"""
import json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
from fv1 import runner  # noqa: E402

rep = {g: json.load(open(os.path.join(G.REPORTS, f"{g}.json"))) for g in ("G-A", "G-B", "G-C", "G-D", "G-E", "G-F")}
gates = {g: r["status"] for g, r in rep.items()}
fp = G.check_code_identity()
e10 = rep["G-E"]["e10_status"]
record = {
    "record_sha256": G.RECORD_SHA,
    "code_fingerprint": fp,
    "code_manifest_sha256": G.CODE_MANIFEST_SHA,
    "gates": gates,
    "e10_status": e10,
    "v10_tests": rep["G-E"]["tests"],
    "theta0_map": {"path": rep["G-F"]["map_path"], "sha256": rep["G-F"]["map_sha256"]},
    "gate_stream": "FINAL_V1_GATE (no gate drew from FINAL_V1_PANEL, _FOLDS, _OOS or _BOOT)",
    "stop_rule": ("G-E failed on V10.1 only. Diagnosis (reports/G-E_diagnosis.json): no implementation defect; "
                  "ppi-python 0.2.3's OLS routines compute a different, asymptotically equivalent estimator. By "
                  "record 3.4 E-10 is ABSENT; no correction was applied and no design element changed.")
                 if e10 == "ABSENT" and all(gates[g] == "PASS" for g in runner.GATES_REQUIRED) else None,
    "finalized_utc": G.utc(),
}
path = os.path.join(G.GATES, "FINAL_V1_GATE_RECORD.json")
with open(path, "w") as fh:
    json.dump(record, fh, indent=1, sort_keys=True)
print("gate record:", json.dumps({k: record[k] for k in ("gates", "e10_status")}))
try:
    _rec, tpath, tsha, e10_seen = runner._gate_record(path, fp, G.STUDY)
    print(f"runner interlock: production would be ALLOWED with E-10 {e10_seen}; theta_0 map {tsha[:16]}...")
except SystemExit as ex:
    print(f"runner interlock: production REFUSED ({ex})")
sha = G.sha256_file(path)
with open(path[:-5] + ".sha256", "w") as fh:
    fh.write(f"{sha}  FINAL_V1_GATE_RECORD.json\nfinalized {record['finalized_utc']}\n")
print("gate record SHA-256:", sha)
