"""G-E (V10), step 3 of 3 -- comparisons, exactly as pre-specified in record 3.4.

V10.1  every (dataset, coord, lambda case): |FINAL_V1 point estimate - ppi_ols_pointestimate| <= 1e-8 and
       |FINAL_V1 interval bound - ppi_ols_ci bound| <= 1e-8, every coordinate.
V10.2  every gate panel: |FINAL_V1 lambda^ - _calc_lam_glm| <= 1e-12 (coord 0, clipped). The unclipped values
       are compared as well (supplementary).
V10.3  from gate_d.py (reports/V10.3.json): tests (a)-(d), (f) <= 1e-10.
G-E passes only if all three pass. If any fails or cannot be completed, E-10 is ABSENT for FINAL_V1; no
tolerance is relaxed and no approximation or substitute is introduced (record 3.4; Step-6 instruction).
"""
import json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
import numpy as np  # noqa: E402

V10 = os.path.join(G.GATES, "v10")
status = {}
detail = {}
try:
    a = np.load(os.path.join(V10, "v10_fv1_outputs.npz")); b = np.load(os.path.join(V10, "v10_ppi_outputs.npz"))
    completed = True
except FileNotFoundError as ex:
    completed, a, b = False, None, None
    detail["not_completed"] = str(ex)

if completed:
    rows, worst = [], 0.0
    for j in range(5):
        for coord in (0, None):
            for kind, lam in (("given", 1.0), ("given", 0.5), ("estimated", None)):
                tag = f"d{j}_c{coord}_{kind}{'' if lam is None else lam}"
                dp = float(np.abs(a[f"{tag}_theta"] - b[f"{tag}_theta"]).max())
                dci = float(max(np.abs(a[f"{tag}_lo"] - b[f"{tag}_lo"]).max(), np.abs(a[f"{tag}_hi"] - b[f"{tag}_hi"]).max()))
                rows.append({"case": tag, "max_abs_diff_point": dp, "max_abs_diff_interval": dci,
                             "pass": dp <= 1e-8 and dci <= 1e-8})
                worst = max(worst, dp, dci)
    status["V10.1"] = "PASS" if all(r["pass"] for r in rows) else "FAIL"
    detail["V10.1"] = {"cases": rows, "cases_passing": sum(r["pass"] for r in rows), "cases_total": len(rows),
                       "max_abs_diff": worst, "tolerance": 1e-8}
    prow, i = [], 0
    while f"p{i}_lam" in b.files:
        d1 = abs(float(a[f"p{i}_lam"]) - float(b[f"p{i}_lam"]))
        d2 = abs(float(a[f"p{i}_lam_raw"]) - float(b[f"p{i}_lam_raw"]))
        prow.append({"panel": str(a[f"p{i}_config"]), "abs_diff_lambda": d1, "abs_diff_lambda_unclipped": d2,
                     "pass": d1 <= 1e-12})
        i += 1
    status["V10.2"] = "PASS" if prow and all(r["pass"] for r in prow) and len(prow) == 20 else "FAIL"
    detail["V10.2"] = {"panels": prow, "max_abs_diff": max(r["abs_diff_lambda"] for r in prow),
                       "max_abs_diff_unclipped": max(r["abs_diff_lambda_unclipped"] for r in prow), "tolerance": 1e-12}
else:
    status["V10.1"] = status["V10.2"] = "NOT COMPLETED"
v3 = json.load(open(os.path.join(G.REPORTS, "V10.3.json")))
status["V10.3"] = v3["status"]
detail["V10.3"] = v3
overall = "PASS" if all(v == "PASS" for v in status.values()) else "FAIL"
e10 = "COMPUTED" if overall == "PASS" else "ABSENT"
G.write_report("G-E", {"gate": "G-E", "status": overall, "e10_status": e10, "tests": status, "detail": detail,
                       "utc": G.utc()})
for k, v in status.items():
    print(f"  {v:<13} {k}")
if completed:
    print(f"  V10.1: {detail['V10.1']['cases_passing']}/{detail['V10.1']['cases_total']} cases within 1e-8; "
          f"max |diff| {detail['V10.1']['max_abs_diff']:.2e}")
    print(f"  V10.2: max |diff| {detail['V10.2']['max_abs_diff']:.1e} (unclipped {detail['V10.2']['max_abs_diff_unclipped']:.1e})")
print(f"G-E {overall}: E-10 {e10}")
