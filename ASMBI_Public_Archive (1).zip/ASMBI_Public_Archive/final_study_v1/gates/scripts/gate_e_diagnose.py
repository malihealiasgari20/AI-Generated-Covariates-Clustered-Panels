"""G-E diagnosis (stop rule): is the V10.1 failure an implementation defect?

On the five V10.1 datasets, independently of fv1.e10:
  R1  ppi-python's own outputs (lambda given) equal the closed form imputed fit + rectifier fit computed here
      with numpy least squares   -> the reference run is valid and its formula is what the source says;
  R2  FINAL_V1's generic point estimate (lambda given) equals the solution of the PPI++ M-estimation equation
      [(1 - lambda) H_L + lambda H_U] theta = g_L(Y) - lambda g_L(Yhat) + lambda g_U(Yhat), solved here directly
      -> the FINAL_V1 code computes E-10's sealed definition (record 3.4);
  R3  the two estimators differ by the structural term
      closed form - M-estimation, which vanishes when H_L = H_U (labeled and unlabeled Gram matrices equal);
  R4  with lambda estimated, the lambda ppi-python uses differs from E-10's pilot lambda because the two pilot
      point estimates differ (R3), and ppi_ols_ci additionally re-estimates lambda at the tuned estimate.
Only differences between implementations are reported.
"""
import json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
import numpy as np  # noqa: E402

V10 = os.path.join(G.GATES, "v10")
inp = np.load(os.path.join(V10, "v10_inputs.npz"))
fv1 = np.load(os.path.join(V10, "v10_fv1_outputs.npz"))
ref = np.load(os.path.join(V10, "v10_ppi_outputs.npz"))
ols = lambda X, y: np.linalg.lstsq(X, y, rcond=None)[0]
r1 = r2 = 0.0
gaps = []
for j in range(5):
    X, Y, Yh, Xu, Yhu = (inp[f"d{j}_{k}"] for k in ("X", "Y", "Yhat", "X_unlabeled", "Yhat_unlabeled"))
    n, N = len(Y), len(Yhu)
    HL, HU = X.T @ X / n, Xu.T @ Xu / N
    for lam in (1.0, 0.5):
        tag = f"d{j}_c0_given{lam}"
        closed = ols(Xu, lam * Yhu) + ols(X, Y - lam * Yh)
        mest = np.linalg.solve((1 - lam) * HL + lam * HU, X.T @ (Y - lam * Yh) / n + lam * Xu.T @ Yhu / N)
        r1 = max(r1, float(np.abs(closed - ref[f"{tag}_theta"]).max()))
        r2 = max(r2, float(np.abs(mest - fv1[f"{tag}_theta"]).max()))
        gaps.append(float(np.abs(closed - mest).max()))
print(f"  R1  ppi-python output = closed form (imputed + rectifier), max |diff| {r1:.1e}")
print(f"  R2  FINAL_V1 generic code = PPI++ M-estimation solution, max |diff| {r2:.1e}")
print(f"  R3  closed form - M-estimation solution on i.i.d. data: {min(gaps):.1e} to {max(gaps):.1e}")
lam_gap = []
for j in range(5):
    for coord in (0, None):
        t = f"d{j}_c{coord}_estimated"
        lam_gap.append(float(np.abs(fv1[f"{t}_theta"] - ref[f"{t}_theta"]).max()))
print(f"  R4  lambda estimated: point estimates differ by {min(lam_gap):.1e} to {max(lam_gap):.1e}")
verdict = ("no implementation defect: the FINAL_V1 code reproduces E-10's sealed definition (R2) and the reference run "
           "is valid (R1); V10.1 fails because ppi-python 0.2.3's OLS routines compute a different, asymptotically "
           "equivalent estimator (R3, R4)") if r1 <= 1e-10 and r2 <= 1e-10 else "UNRESOLVED -- inspect"
print("  verdict:", verdict)
G.write_report("G-E_diagnosis", {"R1_reference_equals_closed_form": r1, "R2_fv1_equals_m_estimation": r2,
                                 "R3_structural_gap_range": [min(gaps), max(gaps)],
                                 "R4_lambda_estimated_gap_range": [min(lam_gap), max(lam_gap)],
                                 "verdict": verdict, "utc": G.utc()})
