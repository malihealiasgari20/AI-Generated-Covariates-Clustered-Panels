"""G-E (V10), step 1 of 3 -- inputs and FINAL_V1 generic-code outputs (main environment).

V10.1 (record 3.4): ppi-python's own setting -- i.i.d. predicted-outcome OLS. Five synthetic datasets from
FINAL_V1_GATE|V10.1|DATA|dataset<j>|0, declared here before any run:
    sizes (n labeled, N unlabeled, d incl. intercept): (200,1000,2) (300,2000,3) (500,5000,4) (150,3000,3) (1000,4000,5)
    X = [1, Z], Z ~ N(0, I);  Y = X beta + N(0,1);  Yhat = X beta_f + 0.6 N(0,1), for labeled and unlabeled
    alike, beta = (1, .5, -.3, .2, .1)[:d], beta_f = beta + (.2, -.1, .05, 0, 0)[:d].
  For coord in {0, None} and lambda in {given 1.0, given 0.5, estimated}, the FINAL_V1 generic code
  (fv1.e10: theta_lambda, unit_gradients, calc_lam_glm, ppi_sigma, e10_core) with ppi-python's own Hessian
  convention for that setting -- the pooled Hessian (X'X + Xu'Xu)/(n + N) of _ols_get_stats -- computes the
  point estimate and the alpha = 0.05 interval. Step 2 computes ppi_ols_pointestimate and ppi_ols_ci on the
  same data; step 3 requires agreement to 1e-8.
V10.2: on the 20 V10 gate panels (gate_common.v10_gate_panels) the gradient arrays at the pilot and inv(H),
  exactly as e10_core forms them, and FINAL_V1's lambda^ (coord 0, clipped). Step 2 evaluates ppi-python's
  _calc_lam_glm on the same arrays; step 3 requires agreement to 1e-12.
"""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
import numpy as np  # noqa: E402
from scipy.stats import norm  # noqa: E402
from stage0_cda import contributions  # noqa: E402
from fv1 import registry, e10  # noqa: E402

G.check_code_identity()
configs, _ = registry.load(G.STUDY)
ns, _, _ = registry._rebuild(G.STUDY)
V10 = os.path.join(G.GATES, "v10")
os.makedirs(V10, exist_ok=True)
SIZES = [(200, 1000, 2), (300, 2000, 3), (500, 5000, 4), (150, 3000, 3), (1000, 4000, 5)]
BETA = np.array([1.0, 0.5, -0.3, 0.2, 0.1]); SHIFT = np.array([0.2, -0.1, 0.05, 0.0, 0.0])
CASES = [("given", 1.0), ("given", 0.5), ("estimated", None)]
COORDS = (0, None)
z = float(norm.ppf(1 - 0.05 / 2))
A = lambda X: np.einsum("ij,ik->ijk", X, X)
inp, fv1 = {}, {}
for j, (n, Nu, d) in enumerate(SIZES):
    rng = G.gate_rng("V10.1", "DATA", f"dataset{j}", 0)
    beta, beta_f = BETA[:d], BETA[:d] + SHIFT[:d]

    def draw(m):
        X = np.column_stack([np.ones(m), rng.normal(size=(m, d - 1))])
        Y = X @ beta + rng.normal(size=m)
        Yh = X @ beta_f + 0.6 * rng.normal(size=m)
        return X, Y, Yh

    X, Y, Yh = draw(n)
    Xu, _Yu_unobserved, Yhu = draw(Nu)
    for k, v in (("X", X), ("Y", Y), ("Yhat", Yh), ("X_unlabeled", Xu), ("Yhat_unlabeled", Yhu)):
        inp[f"d{j}_{k}"] = v
    H = (X.T @ X + Xu.T @ Xu) / (n + Nu)            # _ols_get_stats, unit weights, use_unlabeled
    args = (A(X), X * Y[:, None], A(X), X * Yh[:, None], A(Xu), Xu * Yhu[:, None])
    for coord in COORDS:
        for kind, lam in CASES:
            tag = f"d{j}_c{coord}_{kind}{'' if lam is None else lam}"
            if kind == "estimated":
                out = e10.e10_core(*args, H, coord=coord)
                th, se = out["theta"], out["se"]
                fv1[f"{tag}_lam"] = np.asarray(out["lam"])
            else:
                th = e10.theta_lambda(*args, lam)
                g = (e10.unit_gradients(args[0], args[1], th), e10.unit_gradients(args[2], args[3], th),
                     e10.unit_gradients(args[4], args[5], th))
                se = np.sqrt(np.diag(e10.ppi_sigma(*g, np.linalg.inv(H), lam)) / n)
            fv1[f"{tag}_theta"], fv1[f"{tag}_lo"], fv1[f"{tag}_hi"] = th, th - z * se, th + z * se

panels = G.v10_gate_panels(configs, ns["pi_target_fraction"])
consistent = True
for i, (cfg, r, pan, D) in enumerate(panels):
    AL, AH, bL, bH = contributions(pan, D)
    lab = pan.labeled.astype(bool); U = ~lab; n = int(lab.sum())
    inv_h = np.linalg.inv(AH[lab].sum(axis=0) / n)
    th1 = e10.theta_lambda(AH[lab], bH[lab], AL[lab], bL[lab], AL[U], bL[U], 1.0)
    g = e10.unit_gradients(AH[lab], bH[lab], th1)
    gh = e10.unit_gradients(AL[lab], bL[lab], th1)
    ghu = e10.unit_gradients(AL[U], bL[U], th1)
    lam = e10.calc_lam_glm(g, gh, ghu, inv_h, coord=0, clip=True)
    lam_raw = e10.calc_lam_glm(g, gh, ghu, inv_h, coord=0, clip=False)
    consistent &= (e10.e10_fit(pan, D)[2]["e10_lam"] == float(lam))
    for k, v in (("grads", g), ("grads_hat", gh), ("grads_hat_unlabeled", ghu), ("inv_hessian", inv_h)):
        inp[f"p{i}_{k}"] = v
    fv1[f"p{i}_lam"], fv1[f"p{i}_lam_raw"] = np.asarray(lam, dtype=float), np.asarray(lam_raw, dtype=float)
    fv1[f"p{i}_config"] = np.asarray(f"{cfg.name}|r={r}")
assert consistent, "arrays do not reproduce e10_fit's lambda"
np.savez(os.path.join(V10, "v10_inputs.npz"), **inp)
np.savez(os.path.join(V10, "v10_fv1_outputs.npz"), **fv1)
print(f"V10 inputs written: {len(SIZES)} datasets x {len(COORDS)} coords x {len(CASES)} cases; {len(panels)} gate panels; "
      f"arrays reproduce e10_fit's lambda: {consistent}")
