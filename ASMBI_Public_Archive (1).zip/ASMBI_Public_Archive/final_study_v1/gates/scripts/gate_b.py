"""G-B -- generator equivalence (record 10.1 step 4; 1.1-1.2).

Part 1, the 87 baseline-parameter configurations (sd_e, sd_ZH_within and lambda1 at baseline; every
family listed in record 1.2):
  the FINAL_V1 path      registry parameters -> fv1 effective cut spacing -> deps stage0_dgp.generate_panel
  the frozen path        the SEALED file Stage0_Reconstruction_v1.1_FROZEN/estimators/stage0_dgp.py, loaded
                         under a separate module name, with the SEALED parameterization
                         config/dgp_config.json (base_parameters) and only the configuration's design factors
                         (N, T, icc, rho_e, tau, pi, kappa, gamma_W) set
  must give identical parameters (every non-design field, including cut_spacing = 0.65 exactly) and
  bit-identical panels (every array of the Panel) on 3 gate streams per configuration.
Part 2, all 149 configurations: |latent_reference_sd x effective cut spacing - 0.8050009202070365| <= 1e-14;
  the four absolute thresholds equal the sealed cut points (dgp_config.json, derived) to 1e-14; and on a gate
  panel the generated Z_L equals the discretization of Z* by the sealed absolute thresholds, element for element.
"""
import importlib.util, json, os, sys
from dataclasses import fields

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
import numpy as np  # noqa: E402
import stage0_dgp  # noqa: E402
from fv1 import registry  # noqa: E402

G.check_code_identity()
configs, _ = registry.load(G.STUDY)
SEALED = os.path.join(G.OUT_ROOT, "Stage0_Reconstruction_v1.1_FROZEN")
spec = importlib.util.spec_from_file_location("sealed_stage0_dgp", os.path.join(SEALED, "estimators", "stage0_dgp.py"))
sealed = importlib.util.module_from_spec(spec)
sys.modules["sealed_stage0_dgp"] = sealed        # dataclasses look the module up by name
spec.loader.exec_module(sealed)
assert G.sha256_file(spec.origin) == "d05c95be78c2507ef4cb741bfbf1f1ee9413ef7a0ae403020925038e4eb2132b"
cfgjson = json.load(open(os.path.join(SEALED, "config", "dgp_config.json")))
base = {k: (tuple(v) if isinstance(v, list) else v) for k, v in cfgjson["base_parameters"].items()}
frozen_cuts = np.array(cfgjson["derived"]["cut_points_latent_units"])
REF = 0.8050009202070365
DESIGN = ("N", "T", "icc", "rho_e", "tau", "pi", "kappa", "gamma_W")
ARRAYS = ("Y", "ZH", "ZL", "Zstar", "X", "eps", "eps_next", "C", "u", "strata", "labeled", "kappa_t")
checks, fail = [], []


def check(label, ok, **info):
    checks.append({"check": label, "pass": bool(ok), **info})
    print(f"  {'PASS' if ok else 'FAIL'}  {label}", flush=True)
    if not ok:
        fail.append(label)


def baseline_scale(p):
    return p.sd_e == 0.55 and p.sd_ZH_within == 0.62 and tuple(p.lambda1) == (1.20, 1.05, 0.45)


# Part 1
fam = {}
n_panels = param_bad = panel_bad = 0
bad_cfgs = []
for c in configs:
    if not baseline_scale(c.p):
        continue
    for m in c.modules:
        fam[m] = fam.get(m, 0) + 1
    q = sealed.DGPParams(**{**base, **{f: getattr(c.p, f) for f in DESIGN}})
    pv = {f.name: getattr(c.p, f.name) for f in fields(c.p)}
    qv = {f.name: getattr(q, f.name) for f in fields(q)}
    same_params = all((tuple(map(float, pv[k])) == tuple(map(float, qv[k]))) if isinstance(pv[k], tuple)
                      else pv[k] == qv[k] for k in pv) and set(pv) == set(qv)
    param_bad += not same_params
    ok_c = same_params
    for r in range(3):
        rng_v = stage0_dgp.make_rng(G.GATE_ID, f"G-B|PANEL|{c.seed_cell_id}", r)
        rng_f = sealed.make_rng(G.GATE_ID, f"G-B|PANEL|{c.seed_cell_id}", r)
        a, b = stage0_dgp.generate_panel(c.p, rng_v), sealed.generate_panel(q, rng_f)
        same = all(np.asarray(getattr(a, k)).tobytes() == np.asarray(getattr(b, k)).tobytes()
                   and np.asarray(getattr(a, k)).dtype == np.asarray(getattr(b, k)).dtype for k in ARRAYS)
        panel_bad += not same
        ok_c &= same
        n_panels += 1
    if not ok_c:
        bad_cfgs.append(c.name)
n_base = sum(baseline_scale(c.p) for c in configs)
check("87 baseline-parameter configurations identified", n_base == 87, families=fam)
check("every baseline-parameter configuration: FINAL_V1 parameters equal the sealed parameterization "
      "field by field (cut_spacing 0.65 exactly)", param_bad == 0, mismatches=param_bad)
check(f"every baseline-parameter configuration: FINAL_V1 panels equal the sealed generator's bit for bit "
      f"({n_panels} gate panels, {len(ARRAYS)} arrays each)", panel_bad == 0, mismatched_panels=panel_bad,
      configurations=bad_cfgs)

# Part 2
scale_dev, cut_dev, zl_bad, scale_rows = 0.0, 0.0, [], []
for c in configs:
    p = c.p
    scale = stage0_dgp.latent_reference_sd(p) * p.cut_spacing
    cuts = stage0_dgp.EQUAL_WIDTH_CUTS * scale
    d1, d2 = abs(scale - REF), float(np.abs(cuts - frozen_cuts).max())
    scale_dev, cut_dev = max(scale_dev, d1), max(cut_dev, d2)
    pan = stage0_dgp.generate_panel(p, stage0_dgp.make_rng(G.GATE_ID, f"G-B|CUTS|{c.seed_cell_id}", 0))
    zl_ref = np.searchsorted(frozen_cuts, pan.Zstar, side="right") + 1
    if not np.array_equal(pan.ZL, zl_ref):
        zl_bad.append(c.name)
    scale_rows.append({"config": c.name, "cut_spacing": repr(p.cut_spacing), "scale_dev": d1, "cut_dev": d2})
check("all 149 configurations: absolute cut scale equals 0.8050009202070365 to 1e-14", scale_dev <= 1e-14,
      max_abs_dev=scale_dev)
check("all 149 configurations: the four thresholds equal the sealed cut points to 1e-14", cut_dev <= 1e-14,
      max_abs_dev=cut_dev)
check("all 149 configurations: generated Z_L equals Z* discretized by the sealed absolute thresholds",
      not zl_bad, mismatched=zl_bad)

status = "PASS" if not fail else "FAIL"
G.write_report("G-B", {"gate": "G-B", "status": status, "utc": G.utc(), "baseline_configurations": n_base,
                       "baseline_families": fam, "panels_compared": n_panels, "max_scale_dev": scale_dev,
                       "max_cut_dev": cut_dev, "per_configuration_scale": scale_rows, "checks": checks,
                       "failures": fail})
print(f"G-B {status}")
sys.exit(0 if not fail else 1)
