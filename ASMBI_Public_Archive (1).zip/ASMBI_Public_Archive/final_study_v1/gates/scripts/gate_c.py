"""G-C -- estimator equivalence (record 10.1 step 4; 3.1-3.3, 5).

20 gate panels: one panel (FINAL_V1_GATE|G-C|PANEL|<seed id>|0; folds from G-C|FOLDS) for each of 20
configurations chosen to span every module, battery and design family, including a very sparse cell in
which the eligibility/failure rules bind. On each panel the FINAL_V1 battery of that configuration is run
through estimators.run_battery and compared with the frozen functions called directly on the same panel:

  E-1..E-9    stage0_naive, _labeled_only, _ppi, _crossppi, _ht, _rc, _cda (e8_fit, e9_fit)
  E-6H, E-12a/b/c   e5_core.fit_all (Experiment-5 composition of solve_rect)
  HT-TDS-I, PS-TDS-I, HT-TDS-CF   s2_core.estimate_all(deltas=(0.10,))

Required: wherever the frozen function returns an estimate and the FINAL_V1 eligibility rule admits the
estimator, the wrapper's estimate, SE, critical value and interval equal the frozen values exactly
(bitwise); wherever the frozen function fails or the rule excludes the estimator, the wrapper records the
matching failure type. Also required: E-12a = HT-TDS-CF to 1e-12 (estimate and SE) wherever the TDS floor
does not bind; E-8's point estimate = E-6's to 1e-10 (declared before the run: an algebraic identity whose
rounding reached 1.5e-10 over 120,000 replications in the frozen S0.9 identity check).
Supplementary (beyond the pre-specified gate, reported separately): the S0.9 driver s09_run.one where it
runs, and the record-3.8 mechanism diagnostics against e5_core.fit_all.
"""
import math, os, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
import numpy as np  # noqa: E402
from scipy.stats import t as tdist  # noqa: E402
from stage0_dgp import generate_panel, make_rng  # noqa: E402
from stage0_naive import naive_fit, _period_design  # noqa: E402
from stage0_labeled_only import labeled_only_fit  # noqa: E402
from stage0_ppi import ppi_fit  # noqa: E402
from stage0_crossppi import crossppi_fit  # noqa: E402
from stage0_ht import ht_fit  # noqa: E402
from stage0_rc import rc_fit  # noqa: E402
from stage0_cda import e8_fit, e9_fit  # noqa: E402
from stage1_design_aware import crossfit_predictions  # noqa: E402
import e5_core, s2_core, s09_run  # noqa: E402
from fv1 import registry, estimators as E, diagnostics, theta0 as T0  # noqa: E402

G.check_code_identity()
configs, _ = registry.load(G.STUDY)
ns, _, _ = registry._rebuild(G.STUDY)
ptf, sdW, kT = ns["pi_target_fraction"], ns["sdW_for_T"], ns["kappa_terminal"]
gf = __import__("json").load(open(os.path.join(G.REPORTS, "G-F.json")))
assert gf["status"] == "PASS"
th_map = T0.lookup(T0.load_production_map(os.path.join(G.STUDY, gf["map_path"]), gf["map_sha256"]), configs, True)

D0 = dict(N=300, T=8, icc=0.3, rho_e=0.6, tau=0.1, pi=(0.15, 0.3, 0.6), kappa=0.0, gamma_W=0.15, sd_e=0.55,
          sd_ZH_within=0.62, lambda1=(1.2, 1.05, 0.45))
SPECS = [
    ("baseline (P, L, S, X4, D)", {}),
    ("primary kappa 0.60", dict(kappa=0.6)),
    ("primary ICC 0.10, rho 0, kappa 0.60, null", dict(icc=0.1, rho_e=0.0, kappa=0.6, gamma_W=0.0)),
    ("primary ICC 0.50, rho 0.60, kappa 0.60", dict(icc=0.5, kappa=0.6)),
    ("D-only kappa 1.0", dict(kappa=1.0)),
    ("stress N 250", dict(N=250)),
    ("stress N 600, null", dict(N=600, gamma_W=0.0)),
    ("stress T 5 budget", dict(T=5, pi=ptf(0.35 * 8 / 5))),
    ("stress T 10 budget, null", dict(T=10, pi=ptf(0.35 * 8 / 10), gamma_W=0.0)),
    ("stress tau 0.30", dict(tau=0.3)),
    ("stress / X4 sd_e 0.80", dict(sd_e=0.8)),
    ("stress low within-unit variation", dict(sd_ZH_within=0.31)),
    ("validation intensity m 0.33", dict(pi=ptf(0.35 * 0.33))),
    ("validation intensity m 2.00, null", dict(pi=ptf(0.70), gamma_W=0.0)),
    ("X2 uniform validation, tau 0, null", dict(pi=(0.35, 0.35, 0.35), tau=0.0, gamma_W=0.0)),
    ("X2 E2-LAMBDA, tau 0.30", dict(lambda1=(0.9, 0.9, 0.9), tau=0.3)),
    ("X3 T 4, kappabar 0.60", dict(T=4, rho_e=0.0, sd_ZH_within=sdW(4), kappa=kT(4, 0.6))),
    ("X3 T 16, kappabar 0", dict(T=16, rho_e=0.0, sd_ZH_within=sdW(16))),
    ("X4 f 0.03, sd_e 0.15", dict(pi=ptf(0.03), sd_e=0.15)),
    ("X4 uniform-validation diagnostic, null", dict(pi=(0.35, 0.35, 0.35), gamma_W=0.0)),
]
FAIL = {"below_min": E.BELOW_MIN, "ps_full": E.EMPTY_PS_FULL, "ps_del": E.EMPTY_PS_DEL, "singular": E.SINGULAR,
        "nonfinite": E.NONFINITE, "exception": E.EXCEPTION}
rows, problems, supp_rows, supp_problems = [], [], [], []
counts = {"exact": 0, "failure_matched": 0}
ident = {"E8_E6_max": 0.0, "E8_E6_n": 0, "E12a_CF_max": 0.0, "E12a_CF_n": 0, "CF_bound_n": 0}


def call(f):
    try:
        return ("ok", f())
    except np.linalg.LinAlgError as ex:
        return ("singular", f"LinAlgError: {ex}")
    except Exception as ex:  # noqa: BLE001
        return ("exception", f"{type(ex).__name__}: {ex}")


def finite(*v):
    return all(np.isfinite(x) for x in v)


def compare(panel, name, w, kind, ref=None, crit=None, expect_fail=None):
    """kind 'value': ref = (est, se); 'fail': expect_fail = failure type the wrapper must record."""
    rec = {"panel": panel, "estimator": name}
    if kind == "fail":
        ok = w.fail == FAIL[expect_fail]
        rec.update(result="failure matched" if ok else "MISMATCH", expected=expect_fail, wrapper_code=w.fail)
        counts["failure_matched"] += ok
    else:
        est, se = ref
        if not finite(est, se, crit):
            ok = w.fail == E.NONFINITE
            rec.update(result="non-finite matched" if ok else "MISMATCH", wrapper_code=w.fail)
            counts["failure_matched"] += ok
        else:
            ok = (w.fail == E.OK and w.est == est and w.se == se and w.crit == crit
                  and w.lo == est - crit * se and w.hi == est + crit * se)
            rec.update(result="exact" if ok else "MISMATCH", wrapper_code=w.fail)
            if not ok:
                rec.update(d_est=abs(w.est - est) if finite(w.est) else None, d_se=abs(w.se - se) if finite(w.se) else None)
            counts["exact"] += ok
    rows.append(rec)
    if not ok:
        problems.append(rec)


t_start = time.time()
def run_panel(label, cfg, r):
    sid = cfg.seed_cell_id
    pan = generate_panel(cfg.p, G.gate_rng("G-C", "PANEL", sid, r))
    D = _period_design(cfg.p.N, cfg.p.T)
    fk = G.gate_key("G-C", "FOLDS", sid, r)
    N, GS = cfg.p.N, int(pan.labeled.sum())
    rep = E.Rep(pan, D, fk, float(tdist.ppf(0.975, N - 1)))
    th0 = th_map[cfg.index]
    if cfg.R["FULL"]:
        battery = E.FULL
    elif cfg.R["X3"]:
        battery = E.X3
    else:
        battery = E.D_ONLY
    W = E.run_battery(battery, rep, th0, time.perf_counter)
    tag = f"{cfg.name} r={r} {label} (G_S={GS})"
    zc = Z = E.Z_CRIT
    # ---- E-1
    st, v = call(lambda: naive_fit(pan, D))
    compare(tag, "E-1", W["E-1"], "value", v, float(tdist.ppf(0.975, N - 1))) if st == "ok" else compare(tag, "E-1", W["E-1"], "fail", expect_fail=st)
    if "E-7" in W:  # X3 or FULL
        st, v = call(lambda: rc_fit(pan, D))
        if st == "ok":
            compare(tag, "E-7", W["E-7"], "value", v[:2], Z)
            if W["E-7"].extras.get("e7_cZL") != v[2]:
                problems.append({"panel": tag, "estimator": "E-7", "result": "MISMATCH c_ZL"})
        else:
            compare(tag, "E-7", W["E-7"], "fail", expect_fail=st)
        st, v = call(lambda: labeled_only_fit(pan, D))
        if st == "ok" and v is None:
            compare(tag, "E-2", W["E-2"], "fail", expect_fail="below_min")
        elif st == "ok":
            crit2 = float(tdist.ppf(0.975, v[3] - 1))
            compare(tag, "E-2", W["E-2"], "value", v[:2], crit2)
            if W["E-2"].fail == E.OK and W["E-2"].crit * W["E-2"].se != v[2]:
                problems.append({"panel": tag, "estimator": "E-2", "result": "MISMATCH half-width"})
        else:
            compare(tag, "E-2", W["E-2"], "fail", expect_fail=st)
        st, v = call(lambda: ht_fit(pan, D))
        if st == "ok" and v is None:
            compare(tag, "E-6", W["E-6"], "fail", expect_fail="below_min")
        elif st == "ok":
            compare(tag, "E-6", W["E-6"], "value", v[:2], Z)
        else:
            compare(tag, "E-6", W["E-6"], "fail", expect_fail=st)
    if battery is E.FULL:
        st, v = call(lambda: ppi_fit(pan, D))
        for nm, k in (("E-3", 1), ("E-4", 2)):
            if st == "ok" and v is None:
                compare(tag, nm, W[nm], "fail", expect_fail="below_min")
            elif st == "ok":
                compare(tag, nm, W[nm], "value", (v[0], v[k]), Z)
            else:
                compare(tag, nm, W[nm], "fail", expect_fail=st)
        st, v = call(lambda: crossppi_fit(pan, make_rng(*fk), D))
        if st == "ok" and v is None:
            compare(tag, "E-5", W["E-5"], "fail", expect_fail="below_min")
        elif st == "ok":
            compare(tag, "E-5", W["E-5"], "value", v[:2], Z)
        else:
            compare(tag, "E-5", W["E-5"], "fail", expect_fail=st)
        # E-8: FINAL_V1 rule G_S < 5 (inherits E-6's minimum), else the frozen e8_fit
        if GS < 5:
            compare(tag, "E-8", W["E-8"], "fail", expect_fail="below_min")
        else:
            st, v = call(lambda: e8_fit(pan, D))
            if st != "ok":
                compare(tag, "E-8", W["E-8"], "fail", expect_fail=st)
            elif "fail" in v:
                compare(tag, "E-8", W["E-8"], "fail", expect_fail={"sum d^4 = 0": "singular"}.get(v["fail"], "exception"))
            else:
                compare(tag, "E-8", W["E-8"], "value", (v["theta"], v["se"]), v["crit"])
        st, v = call(lambda: e9_fit(pan, D))
        if st != "ok":
            compare(tag, "E-9", W["E-9"], "fail", expect_fail=st)
        elif "fail" in v:
            mp = {"empty post-stratum (full sample)": "ps_full", "empty post-stratum (jackknife deletion)": "ps_del",
                  "sum d^4 = 0": "singular"}
            compare(tag, "E-9", W["E-9"], "fail", expect_fail=mp.get(v["fail"], "exception"))
        else:
            compare(tag, "E-9", W["E-9"], "value", (v["theta"], v["se"]), v["crit"])
            if W["E-9"].fail == E.OK and W["E-9"].bind != int(bool(v["bind_full"])):
                problems.append({"panel": tag, "estimator": "E-9", "result": "MISMATCH floor flag"})
        # Experiment-5 set against e5_core.fit_all
        st5, f5 = call(lambda: dict(zip(e5_core.COLS, e5_core.fit_all(pan, D, fk, th0))))
        for nm, c, need in (("E-6H", "E6H", 5), ("E-12a", "E12a", 10), ("E-12b", "E12b", 10), ("E-12c", "E12c", 10)):
            if GS < need:
                compare(tag, nm, W[nm], "fail", expect_fail="below_min")
            elif st5 != "ok":
                problems.append({"panel": tag, "estimator": nm, "result": f"frozen fit_all raised: {f5}"})
            elif np.isnan(f5[f"{c}_th"]):
                compare(tag, nm, W[nm], "fail", expect_fail="singular")
            else:
                compare(tag, nm, W[nm], "value", (f5[f"{c}_th"], f5[f"{c}_se"]), Z)
                if W[nm].fail == E.OK and W[nm].extras.get(f"s_nt__{nm}") != f5[f"{c}_schur"]:
                    problems.append({"panel": tag, "estimator": nm, "result": "MISMATCH Schur information"})
        # Stage-2 set against s2_core.estimate_all(deltas=(0.10,))
        stI, sI = call(lambda: s2_core.estimate_all(pan, D, pan.ZL, pan.ZL, deltas=(0.10,)))
        for nm in ("HT-TDS-I", "PS-TDS-I"):
            if GS < 5:
                compare(tag, nm, W[nm], "fail", expect_fail="below_min")
            elif stI != "ok":
                compare(tag, nm, W[nm], "fail", expect_fail=stI)
            elif np.isnan(sI[f"{nm}@0.1"][0]) and nm == "PS-TDS-I":
                compare(tag, nm, W[nm], "fail", expect_fail="ps_full")
            else:
                th_, se_, s_, b_ = sI[f"{nm}@0.1"]
                compare(tag, nm, W[nm], "value", (th_, se_), Z)
                if W[nm].fail == E.OK and (W[nm].bind != int(b_) or W[nm].extras[f"s_nt__{nm}"] != s_ / (N * cfg.p.T)):
                    problems.append({"panel": tag, "estimator": nm, "result": "MISMATCH floor flag or s"})
        if GS < 10:
            compare(tag, "HT-TDS-CF", W["HT-TDS-CF"], "fail", expect_fail="below_min")
        else:
            Zf, Zo, _ = crossfit_predictions(pan, make_rng(*fk), False)
            stC, sC = call(lambda: s2_core.estimate_all(pan, D, Zf, Zo, deltas=(0.10,)))
            if stC != "ok":
                compare(tag, "HT-TDS-CF", W["HT-TDS-CF"], "fail", expect_fail=stC)
            else:
                th_, se_, s_, b_ = sC["HT-TDS-CF@0.1"]
                compare(tag, "HT-TDS-CF", W["HT-TDS-CF"], "value", (th_, se_), Z)
                if W["HT-TDS-CF"].fail == E.OK and W["HT-TDS-CF"].bind != int(b_):
                    problems.append({"panel": tag, "estimator": "HT-TDS-CF", "result": "MISMATCH floor flag"})
        # identities
        w6, w8, wa, wc = W["E-6"], W["E-8"], W["E-12a"], W["HT-TDS-CF"]
        if w6.fail == E.OK and w8.fail == E.OK:
            d = abs(w8.est - w6.est); ident["E8_E6_max"] = max(ident["E8_E6_max"], d); ident["E8_E6_n"] += 1
            if d > 1e-10:
                problems.append({"panel": tag, "estimator": "E-8 vs E-6", "result": f"point estimates differ by {d:.2e}"})
        if wa.fail == E.OK and wc.fail == E.OK:
            if wc.bind == 0:
                d = max(abs(wa.est - wc.est), abs(wa.se - wc.se))
                ident["E12a_CF_max"] = max(ident["E12a_CF_max"], d); ident["E12a_CF_n"] += 1
                if d > 1e-12:
                    problems.append({"panel": tag, "estimator": "E-12a vs HT-TDS-CF", "result": f"differ by {d:.2e}"})
            else:
                ident["CF_bound_n"] += 1
        # ---- supplementary 1: the S0.9 driver where it runs
        stS, row = call(lambda: dict(zip(s09_run.COLS, s09_run.one(pan, D, make_rng(*fk)))))
        if stS != "ok":
            supp_rows.append({"panel": tag, "check": "s09_run.one", "result": f"driver raised ({row[:60]})"})
        else:
            pairs = [("E-1", "e1_th", "e1_se"), ("E-2", "e2_th", "e2_se"), ("E-3", "e34_th", "e3_se"),
                     ("E-4", "e34_th", "e4_se"), ("E-5", "e5_th", "e5_se"), ("E-6", "e6_th", "e6_se"),
                     ("E-7", "e7_th", "e7_se"), ("E-8", "e8_th", "e8_se"), ("E-9", "e9_th", "e9_se")]
            okS = all(W[e].est == row[a] and W[e].se == row[b] for e, a, b in pairs if W[e].fail == E.OK)
            supp_rows.append({"panel": tag, "check": "s09_run.one", "result": "exact" if okS else "MISMATCH"})
            if not okS:
                supp_problems.append(supp_rows[-1])
        # ---- supplementary 2: record-3.8 mechanism diagnostics against fit_all
        if st5 == "ok":
            vals, bad = diagnostics.full(rep, W, th0)
            okD = not bad
            for fr in "Luw":
                for s in range(3):
                    k = f"D_{fr}_s{s}"
                    if k in vals:
                        okD &= vals[k] == f5[k] or (np.isnan(vals[k]) and np.isnan(f5[k]))
            for rr in ("uniform", "ht", "hajek"):
                for s in range(3):
                    k = f"share_{rr}_s{s}"
                    okD &= vals[k] == f5[k] or (np.isnan(vals[k]) and np.isnan(f5[k]))
            for e, c in (("E-4", "E4"), ("E-5", "E5"), ("E-6", "E6"), ("E-6H", "E6H"), ("E-12a", "E12a"),
                         ("E-12b", "E12b"), ("E-12c", "E12c")):
                k = f"pred__{e}"
                if k in vals:
                    okD &= abs(vals[k] - f5[f"pred_{c}"]) <= 1e-12 * max(1.0, abs(f5[f"pred_{c}"]))
            okD &= (vals["kish_ht"] == f5["kish_ht"] or (np.isnan(vals["kish_ht"]) and np.isnan(f5["kish_ht"])))
            okD &= vals["delta_spread"] == f5["delta_spread"] and diagnostics.basic(rep)["G_S"] == f5["G_S"]
            supp_rows.append({"panel": tag, "check": "mechanism diagnostics vs fit_all", "result": "equal" if okD else "MISMATCH"})
            if not okD:
                supp_problems.append(supp_rows[-1])
    if r == 0:
        print(f"    {tag}: {len(W)} estimator results compared", flush=True)


for label, over in SPECS:                              # the 20 pre-specified gate panels
    run_panel(label, G.one(configs, **{**D0, **over}), 0)

checks = [
    {"check": "every wrapper result equals the frozen function exactly, or records the matching failure type",
     "pass": not [p for p in problems if p["estimator"] not in ("E-8 vs E-6", "E-12a vs HT-TDS-CF")],
     "exact_comparisons": counts["exact"], "failure_types_matched": counts["failure_matched"]},
    {"check": "E-8 point estimate equals E-6 point estimate (|diff| <= 1e-10)", "pass": ident["E8_E6_max"] <= 1e-10
     and ident["E8_E6_n"] > 0, "panels": ident["E8_E6_n"], "max_abs_diff": ident["E8_E6_max"]},
    {"check": "E-12a (solve_rect) equals HT-TDS-CF where its floor does not bind (estimate and SE, <= 1e-12)",
     "pass": ident["E12a_CF_max"] <= 1e-12 and ident["E12a_CF_n"] > 0, "panels_unbound": ident["E12a_CF_n"],
     "panels_bound": ident["CF_bound_n"], "max_abs_diff": ident["E12a_CF_max"]},
]
for c in checks:
    print(f"  {'PASS' if c['pass'] else 'FAIL'}  {c['check']}  " +
          str({k: v for k, v in c.items() if k not in ('check', 'pass')}), flush=True)
gate_rows, gate_problems, gate_counts = rows, problems, dict(counts)
# ---- supplementary 3 (beyond the pre-specified 20 panels): failure paths. The 20 gate panels happened to contain no
# estimator failure, so the same comparison is repeated on 30 further gate panels (r = 1..30) of each of the four
# sparsest crossover cells, where the eligibility/failure rules bind.
rows, problems, counts = [], [], {"exact": 0, "failure_matched": 0}
ident_gate = dict(ident)
FAILCELLS = [("X4 f 0.03, sd_e 0.15", dict(pi=ptf(0.03), sd_e=0.15)), ("X4 f 0.03, sd_e 0.55", dict(pi=ptf(0.03), sd_e=0.55)),
             ("X4 f 0.03, sd_e 0.80", dict(pi=ptf(0.03), sd_e=0.8)), ("X4 f 0.05, sd_e 0.80", dict(pi=ptf(0.05), sd_e=0.8))]
for label, over in FAILCELLS:
    c_ = G.one(configs, **{**D0, **over})
    for r in range(1, 31):
        run_panel(label, c_, r)
fail_types = {}
for rr in rows:
    if rr["result"] != "exact":
        fail_types[rr["estimator"]] = fail_types.get(rr["estimator"], 0) + 1
supp_fail = {"pass": not problems, "panels": 30 * len(FAILCELLS), "exact": counts["exact"],
             "failure_types_matched": counts["failure_matched"], "failures_by_estimator": fail_types,
             "problems": problems[:50]}
print(f"  supplementary failure paths: {'agree' if not problems else 'DISAGREE'} -- {counts['failure_matched']} "
      f"wrapper failures matched to the frozen functions' outcomes, {counts['exact']} exact values, "
      f"{len(problems)} problems, on {30 * len(FAILCELLS)} further gate panels")
rows, problems, counts, ident = gate_rows, gate_problems, gate_counts, ident_gate
supp_ok = not supp_problems and supp_fail["pass"]
print(f"  supplementary: S0.9 driver and mechanism diagnostics {'agree' if supp_ok else 'DISAGREE'} "
      f"({len(supp_rows)} checks; driver raised on "
      f"{sum('raised' in r['result'] for r in supp_rows)} panel(s), the known record-0.6(c) defect)")
status = "PASS" if all(c["pass"] for c in checks) else "FAIL"
G.write_report("G-C", {"gate": "G-C", "status": status, "utc": G.utc(), "panels": len(SPECS),
                       "panel_stream": "FINAL_V1_GATE|G-C|PANEL|<seed_cell_id>|0 (folds G-C|FOLDS)",
                       "configurations": [{"label": l, "config": G.one(configs, **{**D0, **o}).name} for l, o in SPECS],
                       "checks": checks, "comparisons": rows, "problems": problems,
                       "supplementary": {"pass": supp_ok, "rows": supp_rows, "problems": supp_problems,
                                         "failure_paths": supp_fail},
                       "seconds": round(time.time() - t_start, 1)})
print(f"G-C {status}: {counts['exact']} exact comparisons, {counts['failure_matched']} matched failures, "
      f"{len(problems)} problems")
sys.exit(0 if status == "PASS" else 1)
