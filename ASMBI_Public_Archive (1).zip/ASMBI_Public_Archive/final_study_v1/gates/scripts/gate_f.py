"""G-F -- theta_0 map (record 1.7; 10.1 step 4).

1. Union of the four frozen maps (v1.1 config, S0.11, Experiment 5, Stage 2): every key present in
   more than one map must carry the identical value.
2. The keys the 149 configurations need but the union lacks must be exactly the 11 keys listed in
   record 1.7 (T 5 and 10 at rho_e 0.60, gamma_W 0.15 and 0; sd_ZH_within 0.31 at gamma_W 0.15 and 0;
   T 4, 6, 10, 12, 16 at rho_e 0, gamma_W 0.15, Experiment-3 sd_ZH_within(T)).
3. Only those 11 keys are computed, by the frozen procedure of stage0_theta0.theta0_for:
   q = replace(BASE, **cell); stage0_dgp.compute_theta0(q, n_panels = 20) -- 20 auxiliary panels of
   120,000 units, contamination disabled, seeds "S0_1_DGP|theta0|T=..|icc=..|rho=..|j". (theta0_for
   itself is not called because it writes a cache file into the working directory.)
4. The complete map is written to gates/FINAL_V1_THETA0_MAP.json and hashed; every configuration's
   key must be present with a finite value.
"""
import json, math, os, sys, time
from dataclasses import replace

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_common as G  # noqa: E402
import stage0_dgp, stage0_theta0  # noqa: E402
from fv1 import registry, theta0 as T0  # noqa: E402

G.check_code_identity()
configs, prov = registry.load(G.STUDY)
ns, _, _ = registry._rebuild(G.STUDY)
BASE, sdW_for_T = ns["BASE"], ns["sdW_for_T"]
checks, fail = [], []


def check(label, ok, **info):
    checks.append({"check": label, "pass": bool(ok), **info})
    print(f"  {'PASS' if ok else 'FAIL'}  {label}", flush=True)
    if not ok:
        fail.append(label)


# 1. union and consistency
union, overlaps, conflicts, per_map = {}, 0, [], {}
for rel in T0.FROZEN_MAPS:
    m = json.load(open(os.path.join(G.env.DEPS_DIR, rel)))
    per_map[rel] = len(m)
    for k, v in m.items():
        if k in union:
            overlaps += 1
            if union[k] != v:
                conflicts.append({"key": k, "map": rel, "theta0_equal": union[k]["theta0"] == v["theta0"]})
        union.setdefault(k, v)
check("frozen maps: every overlapping key carries an identical entry", not conflicts,
      overlapping_entries=overlaps, conflicts=conflicts)
check("union holds 42 keys (record 1.7)", len(union) == 42, union_keys=len(union), per_map=per_map)

# 2. the keys still needed
need = sorted({c.theta0_key for c in configs} - set(union))
cell_of = {}
for k in need:
    c = next(c for c in configs if c.theta0_key == k)
    cell_of[k] = {f: getattr(c.p, f) for f in ("T", "gamma_W", "tau", "icc", "rho_e", "sd_ZH_within")}
expected = set()
for g in (0.15, 0.0):
    for T in (5, 10):
        expected.add(stage0_theta0._key(BASE, dict(T=T, gamma_W=g)))
    expected.add(stage0_theta0._key(BASE, dict(gamma_W=g, sd_ZH_within=0.31)))
for T in (4, 6, 10, 12, 16):
    expected.add(stage0_theta0._key(BASE, dict(T=T, rho_e=0.0, gamma_W=0.15, sd_ZH_within=sdW_for_T(T))))
check("keys missing from the union are exactly the 11 keys of record 1.7", set(need) == expected and len(need) == 11,
      needed=need)

# 3. compute only those keys, by the frozen procedure
new = {}
for k in need:
    cell = cell_of[k]
    q = replace(BASE, **cell)
    assert stage0_theta0._key(BASE, cell) == k
    t0 = time.time()
    mean, mcse, sd1 = stage0_dgp.compute_theta0(q, n_panels=stage0_theta0.N_PANELS)
    new[k] = {"theta0": mean, "mcse": mcse, "sd_single_panel": sd1}
    print(f"    computed key T={q.T} sdW={q.sd_ZH_within!r} rho={q.rho_e} g={q.gamma_W}: "
          f"{stage0_theta0.N_PANELS} panels, {time.time() - t0:.1f} s, MCSE {mcse:.1e}", flush=True)
check("11 new keys computed with finite value and MCSE", len(new) == 11 and all(
      math.isfinite(v["theta0"]) and math.isfinite(v["mcse"]) for v in new.values()))

# 4. complete map, hash, coverage of all 149 configurations
full = {**union, **new}
th = T0.lookup(full, configs, require_all=False)
check("every one of the 149 configurations has a finite theta_0", all(math.isfinite(v) for v in th.values()))
os.makedirs(G.GATES, exist_ok=True)
path = os.path.join(G.GATES, "FINAL_V1_THETA0_MAP.json")
with open(path, "w") as fh:
    json.dump(full, fh, indent=1, sort_keys=True)
sha = G.sha256_file(path)
with open(path[:-5] + ".sha256", "w") as fh:
    fh.write(f"{sha}  FINAL_V1_THETA0_MAP.json\nhashed {G.utc()}\n")
T0.load_production_map(path, sha)
check("map written and re-read through the runner's production loader", True, sha256=sha, keys=len(full))

status = "PASS" if not fail else "FAIL"
G.write_report("G-F", {"gate": "G-F", "status": status, "utc": G.utc(), "map_path": "gates/FINAL_V1_THETA0_MAP.json",
                       "map_sha256": sha, "keys_union": len(union), "keys_new": sorted(new), "keys_total": len(full),
                       "new_key_mcse": {k: v["mcse"] for k, v in new.items()}, "checks": checks, "failures": fail})
print(f"G-F {status}: map {sha} ({len(full)} keys)")
sys.exit(0 if not fail else 1)
