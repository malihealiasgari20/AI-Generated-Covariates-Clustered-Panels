"""Shared helpers for the FINAL_V1 pre-performance gates (record Section 10.1, step 4).

Every simulated quantity in the gates comes from experiment id FINAL_V1_GATE, with a cell id that
names the gate and the purpose of the stream, e.g. "G-C|PANEL|<seed_cell_id>". No gate draws from
FINAL_V1_PANEL, _FOLDS, _OOS or _BOOT. Gate reports hold equalities, deviations, counts and pass/fail
flags only; no estimator performance quantity (bias, SE level, RMSE, coverage, rejection rate) is
computed or reported.
"""
import datetime, hashlib, json, os, sys

sys.dont_write_bytecode = True
OUT_ROOT = "/mnt/user-data/outputs"
STUDY = os.path.join(OUT_ROOT, "Final_Study_v1")
CODE = os.path.join(STUDY, "code")
GATES = os.path.join(STUDY, "gates")
REPORTS = os.path.join(GATES, "reports")
if CODE not in sys.path:
    sys.path.insert(0, CODE)
import fv1.env as env  # noqa: E402  (thread pinning and deps path before numpy)

GATE_ID = "FINAL_V1_GATE"
sha256_file = env.sha256_file
CODE_FINGERPRINT = "2d263942e63e44db60a02d6041aba51b3fad0a55c94a0941c45ee31e1d909cbd"
CODE_MANIFEST_SHA = "769882d270ed8e5e654e42d44d1014b8dd421dac78e1a2b0ab85bf6ac085ef0f"
RECORD_SHA = "bd001cda9665cd0ff18cef4b4dc7bca29d6407dd3725448aaf9f3bd12419cea0"


def utc():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def gate_rng(gate, purpose, cell, r):
    from stage0_dgp import make_rng
    return make_rng(GATE_ID, f"{gate}|{purpose}|{cell}", r)


def gate_key(gate, purpose, cell, r):
    return (GATE_ID, f"{gate}|{purpose}|{cell}", r)


def write_report(name, obj):
    os.makedirs(REPORTS, exist_ok=True)
    path = os.path.join(REPORTS, f"{name}.json")
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=1, sort_keys=True, default=_default)
    return path


def _default(o):
    import numpy as np
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (set, tuple)):
        return list(o)
    return str(o)


def check_code_identity():
    """The gates run on the delivered code: fingerprint and code manifest must match Step 5."""
    fp, _ = env.code_fingerprint()
    man = os.path.join(STUDY, "MANIFEST_SHA256_CODE.txt")
    if fp != CODE_FINGERPRINT or env.sha256_file(man) != CODE_MANIFEST_SHA:
        raise SystemExit(f"code under test is not the delivered package (fingerprint {fp})")
    return fp


def find(configs, **want):
    """Configurations whose FINAL_V1 parameters match every keyword (to 1e-12)."""
    out = []
    for c in configs:
        ok = True
        for k, v in want.items():
            have = getattr(c.p, k)
            if isinstance(v, tuple):   # 1e-12: registry configurations differ at the 12-digit level
                ok &= len(have) == len(v) and all(abs(float(x) - float(y)) <= 1e-12 for x, y in zip(have, v))
            else:
                ok &= abs(float(have) - float(v)) <= 1e-12
        if ok:
            out.append(c)
    return out


def one(configs, **want):
    hits = find(configs, **want)
    if len(hits) != 1:
        raise RuntimeError(f"{len(hits)} configurations match {want}")
    return hits[0]


# ----------------------------------------------------------------------------- V10 gate panels
V10_F = (0.03, 0.05, 0.10, 0.20, 0.35, 0.50)
V10_SDE = (0.15, 0.55, 0.80)


def v10_gate_panels(configs, ptf):
    """The 20 gate panels of V10.2 / V10.3 (declared before any run): the two uniform-validation
    diagnostic cells and the 18 crossover cells f in V10_F x sd_e in V10_SDE at gamma_W 0.15; in each,
    the first replication r >= 0 of FINAL_V1_GATE|V10|PANEL|<seed id> on which E-10 is eligible
    (G_S >= 5, N_u >= 2, cond(H) <= 1e12)."""
    from stage0_dgp import generate_panel
    from stage0_naive import _period_design
    from fv1 import e10
    base = dict(N=300, T=8, icc=0.3, rho_e=0.6, tau=0.1, kappa=0.0, sd_ZH_within=0.62, lambda1=(1.2, 1.05, 0.45))
    cells = [one(configs, **base, pi=(0.35, 0.35, 0.35), sd_e=0.55, gamma_W=g) for g in (0.15, 0.0)]
    cells += [one(configs, **base, pi=ptf(f), sd_e=s, gamma_W=0.15) for f in V10_F for s in V10_SDE]
    out = []
    for c in cells:
        D = _period_design(c.p.N, c.p.T)
        for r in range(100):
            pan = generate_panel(c.p, gate_rng("V10", "PANEL", c.seed_cell_id, r))
            if not isinstance(e10.e10_fit(pan, D), dict):
                out.append((c, r, pan, D))
                break
    assert len(out) == 20
    return out
